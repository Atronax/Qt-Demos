#ifndef TOWERBUILDICON_H
#define TOWERBUILDICON_H

class Game;

#include "tower.h"
#include <QGraphicsPixmapItem>
class TowerBuildIcon : public QGraphicsPixmapItem
{
public:
    TowerBuildIcon(Game *parent = nullptr, const Tower::FORM& form = Tower::NOTHING);
    ~TowerBuildIcon();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *ev);

private:
    QString iconPath() const;
    void initGraphics();

    Tower::FORM m_form;
    Game* m_parent;    
};

#endif // TOWERBUILDICON_H
