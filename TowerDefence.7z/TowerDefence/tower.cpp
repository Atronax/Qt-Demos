// Logic
#include <QPolygonF>
#include <QVector>
#include <QPointF>

#include <QPixmap>
#include <QTimer>

// Items
#include "game.h"
#include "tower.h"
#include "bullet.h"
#include "enemy.h"

Tower::Tower(Game* parent, const Tower::FORM& form)
{
    // parent
    m_parent = parent;

    // graphics
    setForm(form);
    initGraphics();
    initBulletsParameters();

    // current target
    m_current_target = nullptr;

    // attack range polygon
    QVector<QPointF> points;
    points << QPointF(1.0f, 0.0f) << QPointF(2.0f, 0.0f) << QPointF(3.0f, 1.0f) <<
              QPointF(3.0f, 2.0f) << QPointF(2.0f, 3.0f) << QPointF(1.0f, 3.0f) <<
              QPointF(0.0f, 2.0f) << QPointF(0.0f, 1.0f);

    m_attack_area_scale = 100;
    for (int i = 0; i < points.size(); ++i)
        points[i] *= m_attack_area_scale;

    m_attack_area = new QGraphicsPolygonItem (QPolygonF(points), this);
    m_attack_area->setPen(QPen(Qt::DotLine));
    m_attack_area->setBrush(QBrush(QColor(0,255,0,10)));
    m_attack_area->moveBy((pos().x() + 50) - (m_attack_area->pos().x() + 1.5*m_attack_area_scale) ,
                          (pos().y() + 50) - (m_attack_area->pos().y() + 1.5*m_attack_area_scale));


    // connect a timer to attack target
    QTimer *attack_target_timer = new QTimer;
    connect (attack_target_timer, SIGNAL(timeout()), this, SLOT(acquire_target()));
    attack_target_timer->start(1000);

}

Tower::~Tower()
{

}

const Tower::FORM &Tower::form() const
{
    return m_form;
}

void Tower::setForm(const Tower::FORM &form)
{
    m_form = form;
}

const int &Tower::bulletsCount() const
{
    return m_bulletsCount;
}

const int &Tower::bulletsAngle() const
{
    return m_bulletsAngle;
}

void Tower::setBulletsCount(const int &bullets_count)
{
    m_bulletsCount = bullets_count;
}

void Tower::setBulletsAngle(const int &bullets_angle)
{
    m_bulletsAngle = bullets_angle;
}

QGraphicsPolygonItem *Tower::attack_area() const
{
    return m_attack_area;
}

void Tower::initGraphics()
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);
    if (m_form == Tower::KNIVES)
        setPixmap(QPixmap(":/images/tower_knives.png"));
    if (m_form == Tower::LASER)
        setPixmap(QPixmap(":/images/tower_laser.png"));
    if (m_form == Tower::LEGO)
        setPixmap(QPixmap(":/images/tower_lego.png"));
    if (m_form == Tower::EIFFEL)
        setPixmap(QPixmap(":/images/tower_eiffel.png"));
}

void Tower::initBulletsParameters()
{
    switch (m_form)
    {
    case Tower::KNIVES:
        setBulletsCount(1);
        break;

    case Tower::LASER:
        setBulletsCount(1);
        break;

    case Tower::LEGO:
        setBulletsCount(1);
        break;

    case Tower::EIFFEL:
        setBulletsCount(1);
        break;

    case Tower::NOTHING:
        break;
    }
}

double Tower::distanceTo(QGraphicsItem *item)
{   
    return QLineF(pos(),item->pos()).length();
}

void Tower::fire(const QPointF& point)
{
    double angleToEnemy = -QLineF(pos(), point).angle();

    Bullet *bullet;
    for (int i = 0; i < bulletsCount(); ++i)
    {
         bullet = new Bullet (this, m_form);
         bullet->setPos(pos() + boundingRect().center());
         bullet->setRotation(angleToEnemy + i*bulletsAngle());
         m_parent->scene()->addItem(bullet);
    }
}

// slots
void Tower::acquire_target()
{    
    double closest_dist = m_attack_area->boundingRect().width()/2.0f;
    QList<QGraphicsItem*> within_attack_range = m_attack_area->collidingItems();
    for (int i = 0; i < within_attack_range.size(); ++i)
    {        
        Enemy *enemy = dynamic_cast<Enemy*>(within_attack_range[i]);
        if (enemy)
        {
            double dist = distanceTo(enemy);
            if (dist < closest_dist)
            {
                closest_dist = dist;
                m_current_target = enemy;
            }
        }
    }

    if (m_current_target)
    {
        fire(m_current_target->pos());
        m_current_target = nullptr;
    }
}
