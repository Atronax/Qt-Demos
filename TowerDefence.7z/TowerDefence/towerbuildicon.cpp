// Logic
#include <QGraphicsSceneMouseEvent>

// Items
#include "game.h"
#include "tower.h"

#include "towerbuildicon.h"
TowerBuildIcon::TowerBuildIcon(Game* parent, const Tower::FORM& form)
{
    m_parent = parent;
    m_form = form;
    initGraphics();
}

TowerBuildIcon::~TowerBuildIcon()
{

}

void TowerBuildIcon::initGraphics()
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);
    if (m_form == Tower::KNIVES)
        setPixmap(QPixmap(":/images/towericon_knives.png"));
    if (m_form == Tower::LASER)
        setPixmap(QPixmap(":/images/towericon_laser.png"));
    if (m_form == Tower::LEGO)
        setPixmap(QPixmap(":/images/towericon_lego.png"));
    if (m_form == Tower::EIFFEL)
        setPixmap(QPixmap(":/images/towericon_eiffel.png"));
}

QString TowerBuildIcon::iconPath() const
{
    QString filename;
    if (m_form == Tower::KNIVES)
        filename = ":/images/tower_knives.png";
    if (m_form == Tower::LASER)
        filename = ":/images/tower_laser.png";
    if (m_form == Tower::LEGO)
        filename = ":/images/tower_lego.png";
    if (m_form == Tower::EIFFEL)
        filename = ":/images/tower_eiffel.png";
    return filename;
}

void TowerBuildIcon::mousePressEvent(QGraphicsSceneMouseEvent *ev)
{
    Q_UNUSED(ev);
    if (!m_parent->building())
    {
        m_parent->setBuilding(new Tower(m_parent, m_form));
        m_parent->setCursor(iconPath());
    }
}



