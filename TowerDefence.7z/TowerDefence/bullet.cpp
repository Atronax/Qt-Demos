// Logic
#include <QPixmap>
#include <qmath.h>
#include <QTimer>

// Items
#include "enemy.h"

#include "bullet.h"
Bullet::Bullet(QGraphicsItem* parent, const Tower::FORM& form)
{
    // setParentItem(parent);
    m_form = form;
    initGraphics();

    // moving
    speed = 40;
    maxRange = 400;
    distanceTravelled = 0;

    QTimer *move_timer = new QTimer(this);
    connect (move_timer, SIGNAL(timeout()), this, SLOT(move()));
    connect (this, SIGNAL(destroyed()), move_timer, SLOT(deleteLater()));
    move_timer->start(1000/30);
}

Bullet::~Bullet()
{
}

void Bullet::initGraphics()
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);
    if (m_form == Tower::KNIVES)
        setPixmap(QPixmap(":/images/arrow_knives.png"));
    if (m_form == Tower::LASER)
        setPixmap(QPixmap(":/images/arrow_laser_lv1.png"));
    if (m_form == Tower::LEGO)
        setPixmap(QPixmap(":/images/arrow_lego.png"));
    if (m_form == Tower::EIFFEL)
        setPixmap(QPixmap(":/images/arrow_eiffel.png"));
}


const double &Bullet::getMaxRange() const
{
    return maxRange;
}

void Bullet::setMaxRange(const double &range)
{
    maxRange = range;
}

const double &Bullet::getDistanceTravelled() const
{
    return distanceTravelled;
}

void Bullet::setDistanceTravelled(const double &distance)
{
    distanceTravelled = distance;
}

void Bullet::makeStep()
{
    // выражаем катеты через гипотенузу и угол:
    // sin - отношение противоположного катета к гипотенузе
    // cos - отношение прилежащего катета к гипотенузе
    double alpha = rotation();
    double dx = speed*qCos(qDegreesToRadians(alpha));
    double dy = speed*qSin(qDegreesToRadians(alpha));
    setPos(x()+dx, y()+dy);

    setDistanceTravelled(QLineF(pos(), QPointF(pos().x()+dx,pos().y()+dy)).length() + getDistanceTravelled());
    if (getDistanceTravelled() >= getMaxRange())
        delete this;
}

void Bullet::resolveCollisions()
{
    QList<QGraphicsItem*> items = collidingItems();
    foreach (QGraphicsItem* item, items)
    {
        Enemy *enemy = dynamic_cast<Enemy*>(item);
        if (enemy)
        {
            delete enemy;
            // enemy->setPixmap(QPixmap(":/images/enemy_dead.png"));
            delete this;
            break;
        }
    }
}

// slots
void Bullet::move()
{    
    makeStep();
    resolveCollisions();
}
