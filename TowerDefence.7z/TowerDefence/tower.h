#ifndef TOWER_H
#define TOWER_H

class Game;
class Enemy;

#include <QObject>
#include <QGraphicsPixmapItem>
class Tower : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    enum FORM {NOTHING, KNIVES, LASER, LEGO, EIFFEL};

    Tower(Game *parent = nullptr, const Tower::FORM& form = NOTHING);
    ~Tower();

    QGraphicsPolygonItem* attack_area() const;

    // form
    const Tower::FORM& form() const;
    void setForm (const Tower::FORM& form);

    // bullets
    const int& bulletsCount() const;
    const int& bulletsAngle() const;
    void setBulletsCount(const int& bullets_count);
    void setBulletsAngle(const int& bullets_angle);

private:
    void initGraphics();
    void initBulletsParameters();

    double distanceTo(QGraphicsItem* item);
    void fire(const QPointF& point);

    Tower::FORM m_form;
    Game *m_parent;

    // attack area
    QGraphicsPolygonItem *m_attack_area;
    int m_attack_area_scale;

    // current target
    Enemy *m_current_target;

    // bullets parameters
    int m_bulletsCount;
    int m_bulletsAngle;

public slots:
    void acquire_target();
};

#endif // TOWER_H
