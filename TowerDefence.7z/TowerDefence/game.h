#ifndef GAME_H
#define GAME_H

class Tower;
class SpriteImages;

// #include <QList>

#include <QGraphicsView>
class Game : public QGraphicsView
{
    Q_OBJECT

public:
    Game();
    ~Game();

    Tower* building() const;
    void setBuilding(Tower* new_tower);

    SpriteImages* imagesCache() const;

    void setCursor(const QString& filename);

protected:
    void mousePressEvent (QMouseEvent *ev);
    void mouseMoveEvent (QMouseEvent *ev);

private:
    void createEnemies(int count);
    void visualizeRoad();

    void makeSceneview();
    void setupBuilding();
    void setupSpawning();
    void makeInterface();

    // main
    QGraphicsScene *m_scene;
    SpriteImages *m_imagesCache;

    // moving
    QList<QPointF> m_keypoints;

    // building
    QGraphicsPixmapItem *m_cursor;
    Tower *m_building;

    // spawning
    QTimer *m_spawnTimer;
    int m_current_enemies;
    int m_maximum_enemies;

public slots:
    void spawnEnemy();
};

#endif // GAME_H
