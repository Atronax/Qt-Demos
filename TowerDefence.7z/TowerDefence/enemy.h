#ifndef ENEMY_H
#define ENEMY_H

class Game;

#include "sprite.h"

#include <QList>
#include <QPointF>

#include <QObject>
#include <QGraphicsPixmapItem>
class Enemy : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    // enum TYPE {NOTHING, OGRE, MINOTAUR, };

    Enemy(QList<QPointF> keypoints, Game* parent = nullptr);
    ~Enemy();

    Sprite* sprite() const;
    void setSprite(Sprite* sprite);

    void rotateToPoint(const QPointF& dest);

protected:
    void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);    

private:
    Game* m_parent;

    // visuals
    Sprite* m_sprite;

    // moving
    QList<QPointF> m_keypoints;
    QPointF curr_destination;
    int curr_keypoint_index;
    int speed;


public slots:
    void move_forward();
};

#endif // ENEMY_H
