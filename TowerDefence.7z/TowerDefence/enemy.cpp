// Logic
#include <QPainter>
#include <QPixmap>

#include <QTimer>
#include <QtMath>

#include "game.h"
#include "enemy.h"
Enemy::Enemy(QList<QPointF> keypoints, Game* parent)    
{
    m_parent = parent;

    // set graphics
    setSprite(new Sprite(this));
    setPixmap(QPixmap(":/images/enemy.png").scaled(50,50));
    sprite()->fillComponents(m_parent->imagesCache()->dwarf(), m_parent->imagesCache()->dwarf_framesizes());
    sprite()->setState(Sprite::MOVING_RIGHT);
    // sprite()->setState(Sprite::ATTACKING);

    // set keypoints
    m_keypoints = keypoints;
    curr_destination = m_keypoints[0];
    rotateToPoint(curr_destination);
    curr_keypoint_index = 0;
    speed = 3;

    QTimer *move_forward_timer = new QTimer(this);
    connect (move_forward_timer, SIGNAL(timeout()), this, SLOT(move_forward()));
    move_forward_timer->start(1000/30);
}

Enemy::~Enemy()
{

}

Sprite *Enemy::sprite() const
{
    return m_sprite;
}

void Enemy::setSprite(Sprite *sprite)
{
    m_sprite = sprite;
}

void Enemy::rotateToPoint(const QPointF &dest)
{
    QLineF line (pos(), dest);
    setRotation(-line.angle());
}

void Enemy::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);

    // painter->drawPixmap(boundingRect().toRect(),pixmap());
    // painter->drawRect(boundingRect());

    if (sprite())
    {
        int type = sprite()->type();
        if (type == Sprite::STATIC)
            sprite()->drawStatic(painter);
        if (type == Sprite::DYNAMIC)
            sprite()->drawDynamic(painter);
    }

}

void Enemy::move_forward()
{
    sprite()->nextFrame();

    QLineF line (pos(), curr_destination);
    if (line.length() < 5)
    {
        ++curr_keypoint_index;
        if (curr_keypoint_index > m_keypoints.size() - 1)
            curr_keypoint_index = 0;

        curr_destination = m_keypoints[curr_keypoint_index];
        rotateToPoint(curr_destination);
    }

    double dx = speed*qCos(qDegreesToRadians(rotation()));
    double dy = speed*qSin(qDegreesToRadians(rotation()));
    setPos(x()+dx, y()+dy);

}

