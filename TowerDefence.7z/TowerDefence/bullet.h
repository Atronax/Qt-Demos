#ifndef BULLET_H
#define BULLET_H

#include "tower.h"
#include <QObject>
#include <QGraphicsPixmapItem>
class Bullet : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    Bullet(QGraphicsItem* parent = nullptr, const Tower::FORM& form = Tower::NOTHING);
    ~Bullet();

    const double& getMaxRange() const;
    void setMaxRange(const double& range);

    const double& getDistanceTravelled() const;
    void setDistanceTravelled(const double& distance);

private:
    void initGraphics();

    void makeStep();
    void resolveCollisions();

    Tower::FORM m_form;

    int speed;
    double maxRange;
    double distanceTravelled;

signals:

public slots:
    void move();
};

#endif // BULLET_H
