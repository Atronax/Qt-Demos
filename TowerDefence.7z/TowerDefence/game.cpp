// Logic
#include <QGraphicsScene>
#include <QTimer>

// Events
#include <QMouseEvent>

// Widgets
#include <QScrollBar>

// Items
#include "towerbuildicon.h"
#include "tower.h"
#include "bullet.h"
#include "enemy.h"

#include "game.h"
Game::Game()
{
    makeSceneview();
    makeInterface();
    setupBuilding();
    setupSpawning();

    m_keypoints = QList<QPointF>() << QPointF(100,100) << QPointF(100,500) << QPointF(200,400) << QPointF(700,500) << QPointF(700,100);
    createEnemies(100);
    visualizeRoad();
}

Game::~Game()
{
}

// builders
void Game::makeSceneview()
{
    // adjust the scene
    m_scene = new QGraphicsScene(this);
    m_scene->setSceneRect(0,0,800,800);    

    // adjust the view
    setFixedSize(800,800);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // making caches
    m_imagesCache = new SpriteImages;

    setScene(m_scene);
}

void Game::setupBuilding()
{
    m_cursor = nullptr;
    m_building = nullptr;
    setMouseTracking(true);
}

void Game::setupSpawning()
{
    m_spawnTimer = new QTimer(this);
    m_current_enemies = 0;
    m_maximum_enemies = 0;
}

void Game::makeInterface()
{
    TowerBuildIcon *tbi_laser = new TowerBuildIcon(this, Tower::LASER);
    TowerBuildIcon *tbi_knives = new TowerBuildIcon(this, Tower::KNIVES);
    TowerBuildIcon *tbi_eiffel = new TowerBuildIcon(this, Tower::EIFFEL);
    TowerBuildIcon *tbi_lego = new TowerBuildIcon(this, Tower::LEGO);

    tbi_lego->setPos(0,0);
    tbi_laser->setPos(100,0);
    tbi_knives->setPos(200,0);
    tbi_eiffel->setPos(300,0);

    m_scene->addItem(tbi_lego);
    m_scene->addItem(tbi_laser);
    m_scene->addItem(tbi_knives);
    m_scene->addItem(tbi_eiffel);
}


// setters & getters
Tower *Game::building() const
{
    return m_building;
}

void Game::setBuilding(Tower *new_tower)
{
    m_building = new_tower;
}

SpriteImages *Game::imagesCache() const
{
    return m_imagesCache;
}

// events
void Game::mousePressEvent(QMouseEvent *ev)
{
    if (m_building)
    {
        QList<QGraphicsItem*> items = m_cursor->collidingItems();
        for (int i = 0; i < items.size(); ++i)
            if (dynamic_cast<Tower*>(items[i]))
                return;

        m_building->setPos(ev->pos());
        m_scene->addItem(m_building);
        m_building = nullptr;
        m_cursor = nullptr;

    }
    else
        QGraphicsView::mousePressEvent(ev);
}

void Game::mouseMoveEvent(QMouseEvent *ev)
{
    if (m_cursor)
        m_cursor->setPos(ev->pos());
}

void Game::createEnemies(int count)
{
    m_current_enemies = 0;
    m_maximum_enemies = count;
    connect (m_spawnTimer, SIGNAL(timeout()), this, SLOT(spawnEnemy()));
    m_spawnTimer->start(1000);
}

void Game::visualizeRoad()
{
    for (int i = 0; i < m_keypoints.size() - 1; ++i)
    {
        QLineF line (m_keypoints[i], m_keypoints[i+1]);
        QGraphicsLineItem *line_item = new QGraphicsLineItem(line);
        m_scene->addItem(line_item);
    }
}

void Game::spawnEnemy()
{
    if (m_current_enemies < m_maximum_enemies)
    {
        Enemy *e = new Enemy(m_keypoints, this);
        e->setPos(m_keypoints[0]);
        m_scene->addItem(e);
        ++m_current_enemies;
    }
    else
    {
        disconnect(m_spawnTimer, SIGNAL(timeout()), this, SLOT(spawnEnemy()));
        m_spawnTimer->stop();
    }
}

void Game::setCursor(const QString &filename)
{
    if (m_cursor)
    {
        m_scene->removeItem(m_cursor);
        delete m_cursor;
    }

    m_cursor = new QGraphicsPixmapItem;
    m_cursor->setPixmap(QPixmap(filename));
    m_scene->addItem(m_cursor);
}
