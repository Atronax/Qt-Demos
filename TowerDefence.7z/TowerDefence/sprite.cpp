#include <QPainter>

#include "sprite.h"
Sprite::Sprite(QGraphicsItem* parent)
{
    m_parent = parent;
    m_type = NOTHING;

    m_static_sprite = nullptr;
    m_dynamic_sprite = nullptr;
    m_bHasComponents = false;
    m_components = nullptr;
    m_framesizes = nullptr;

    m_prevstate = AFK;
    m_state = AFK;

    currFrameX = 0;
    currFrameY = 0;
    currFrameW = 0;
    currFrameH = 0;
}

Sprite::~Sprite()
{
    if (m_parent == nullptr)
        delete this;
}

const int& Sprite::type() const
{
    return m_type;
}

void Sprite::setStatic(QPixmap *static_sprite)
{
    m_static_sprite = static_sprite;

    m_type = STATIC;
}

void Sprite::setDynamic(QPixmap *new_spritesheet, const float& framewidth, const float& frameheight)
{
    m_dynamic_sprite = new_spritesheet;

    currFrameX = 0;
    currFrameY = 0;
    currFrameW = framewidth;
    currFrameH = frameheight;

    m_type = DYNAMIC;
}

void Sprite::fillComponents(QVector<QPixmap*>* components, QVector<QPair<float,float> >* framesizes)
{
    m_components = components;
    m_framesizes = framesizes;
    m_bHasComponents = true;

    m_type = DYNAMIC;
}

void Sprite::drawStatic(QPainter *painter)
{
    if (painter && m_static_sprite)
        painter->drawPixmap(m_parent->boundingRect().toRect(), m_static_sprite->scaled(m_parent->boundingRect().width(), m_parent->boundingRect().height()));
}

void Sprite::drawDynamic(QPainter *painter)
{
    if (painter && m_dynamic_sprite)
    {
        QPixmap currFrame;
        if (state() == MOVING_LEFT || ((state() != MOVING_LEFT && state() != MOVING_RIGHT) && prevstate() == MOVING_LEFT))
            currFrame = m_dynamic_sprite->copy(currFrameX, currFrameY, currFrameW, currFrameH).transformed(QTransform().scale(0,-1));
        if (state() == MOVING_RIGHT || ((state() != MOVING_LEFT && state() != MOVING_RIGHT) && prevstate() == MOVING_RIGHT))
            currFrame = m_dynamic_sprite->copy(currFrameX, currFrameY, currFrameW, currFrameH);

        painter->drawPixmap(m_parent->boundingRect().toRect(),currFrame);
    }
}

void Sprite::nextFrame()
{
    if (m_dynamic_sprite && (currFrameW != 0 || currFrameH != 0))
    {
        currFrameX += currFrameW;
        if (currFrameX >= m_dynamic_sprite->width())
        {
            currFrameX = 0;
            currFrameY += currFrameH;
            if (currFrameY >= m_dynamic_sprite->height())
                currFrameY = 0;
        }
    }
}

void Sprite::setState(const int& new_state)
{
    if (m_state != new_state)
    {
        if (m_state == MOVING_LEFT || m_state == MOVING_RIGHT)
            m_prevstate = m_state;
        m_state = new_state;

        if (m_bHasComponents)
        {
            switch (m_state)
            {
            case AFK: default:
                setDynamic(m_components->at(0), m_framesizes->at(0).first, m_framesizes->at(0).second);
                break;

            case MOVING_LEFT: case MOVING_RIGHT:
                setDynamic(m_components->at(1), m_framesizes->at(1).first, m_framesizes->at(1).second);
                break;

            case JUMPING:
                setDynamic(m_components->at(2), m_framesizes->at(2).first, m_framesizes->at(2).second);
                break;

            case ATTACKING:
                setDynamic(m_components->at(3), m_framesizes->at(3).first, m_framesizes->at(3).second);
                break;

            case DEFENDING:
                setDynamic(m_components->at(4), m_framesizes->at(4).first, m_framesizes->at(4).second);
                break;

            case CASTING:
                setDynamic(m_components->at(5), m_framesizes->at(5).first, m_framesizes->at(5).second);
                break;

            case DYING:
                setDynamic(m_components->at(6), m_framesizes->at(6).first, m_framesizes->at(6).second);
                break;            
            }
        }
    }
}

const int& Sprite::prevstate() const
{
    return m_prevstate;
}

const int& Sprite::state() const
{
    return m_state;
}
