#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QFrame>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QTimer>

#include "categorieswidget.h"
#include "itemswidget.h"
#include "financewidget.h"


class MainWindow : public QFrame
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void init();
    void loadStylesheet(const QString& path);

    void updatePriceChecker ();
    void updateItem (int index);

    // scroll areas for widgets that need them
    QScrollArea *sa_categories;
    QScrollArea *sa_items;

    // widgets controlling categories, items and finance functionalities
    CategoriesWidget *categories;
    ItemsWidget *items;
    FinanceWidget *finance;

    // layout variables
    QHBoxLayout *layout_top;
    QVBoxLayout *layout;

    // for testing purposes
    // updates stylesheet every second
    QTimer *timer;

public slots:
    void grabData();
    void update();
    void onTimer();

    void onAddItemClicked();
    void onItemUpdate (int index);
    void onItemDelete (int index);

    void onAddCategoryClicked();
    void onCategoryDelete (int index);
    void onCategoryClicked(const QString& name);    
    void onCategoryChanged(const QString& from, const QString& to);
};

#endif // MAINWINDOW_H
