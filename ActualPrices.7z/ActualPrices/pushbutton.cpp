#include "pushbutton.h"

#include <QKeyEvent>

PushButton::PushButton(QWidget* parent) : QPushButton(parent)
{

}

void PushButton::mousePressEvent(QMouseEvent *ev)
{
    if (ev->modifiers() & Qt::ControlModifier)
        emit sure();
    else
        emit clicked();
    ev->accept();
}

void PushButton::mouseDoubleClickEvent(QMouseEvent *ev)
{
    emit doubleClicked();
    ev->accept();
}
