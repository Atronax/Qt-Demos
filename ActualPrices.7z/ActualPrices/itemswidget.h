#ifndef ITEMSWIDGET_H
#define ITEMSWIDGET_H

#include <QFrame>
#include <QVBoxLayout>

#include "items.h"
#include "itemwidgetheader.h"
#include "itemwidgetfooter.h"


class ItemsWidget : public QFrame
{
    Q_OBJECT
public:
    ItemsWidget(QWidget *parent = nullptr);
    ~ItemsWidget();

    QPushButton* countButton();
    QPushButton* addButton();    
    const QStringList& getUniqueCategories();

    int getWidth();
    int getHeight();

    bool isEmpty();
    int getSize();

    Item* getCurrent();
    Item* getItemAt(int index);
    ItemView* getItemViewAt(int index);

    void removeItemAt (int index);
    void removeItemViewAt (int index);

    void removeOneItem (Item* item);
    void removeOneItemView (ItemView* view);

    void createItem (const Category& category, const QString& code, const QString& name, const Currency& baseUSD, int vat, int charge);
    void createItem (const Item& item);

    void save(const QString& filename);
    void load(const QString& filename);

private:
    void init();
    void makeGUI();

    Items* items;
    Item* current;

    ItemWidgetHeader* header;
    ItemWidgetFooter* footer;
    QVBoxLayout *layout;

    int def_width;

signals:
    void itemUpdate (int index);
    void itemDelete (int index);

public slots:
    void onGenerateLabel (Item* item);
    void onItemUpdate (Item* item);
    void onItemDelete (Item* item);    
};

#endif // ITEMSWIDGET_H
