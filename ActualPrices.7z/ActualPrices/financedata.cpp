#include "financedata.h"

#include <QDataStream>
#include <QFile>

FinanceData::FinanceData()
{
    datetime = QDateTime::currentDateTime();
    buying_price = Currency("UAH", 0, 0);
    selling_price = Currency("UAH", 0, 0);

    fillPrices();
}

FinanceData::FinanceData(const QDateTime& dt, Currency bp, Currency sp)
{
    datetime = dt;
    buying_price = bp;
    selling_price = sp;

    fillPrices();
}

const QDateTime &FinanceData::getDatetime()
{
    return datetime;
}

void FinanceData::setDatetime(const QDateTime &input)
{
    datetime = input;
}

Currency FinanceData::getBuyingPrice()
{
    return buying_price;
}

void FinanceData::setBuyingPrice(Currency input)
{
    buying_price = input;
}

Currency FinanceData::getSellingPrice()
{
    return selling_price;
}

void FinanceData::setSellingPrice(Currency input)
{
    selling_price = input;
}

Currency FinanceData::getCurrentPrice()
{
    return current_price;
}

void FinanceData::setCurrentPrice(Currency input)
{
    current_price = input;
}

const QStringList &FinanceData::getBanks()
{
    return banks;
}

void FinanceData::addBank(const QString &new_bank)
{
    if (!banks.contains(new_bank))
        banks.append(new_bank);
}

const QStringList &FinanceData::getPrices()
{
    return prices;
}

void FinanceData::addPrice(const QString &new_price)
{
    if (!prices.contains(new_price))
        prices.append(new_price);
}

Currency FinanceData::getDefaultPrice()
{
    return Currency("UAH", 0, 0);
}

QString FinanceData::getDefaultBank()
{
    return "ПриватБанк";
}

const QString &FinanceData::getBank()
{
    return bank;
}

void FinanceData::setBank(const QString &input)
{
    bank = input;
}

const QString &FinanceData::getPreviousBank()
{
    return prev_bank;
}

void FinanceData::storePreviousBank()
{
    prev_bank = bank;
}

void FinanceData::fillPrices()
{
    addPrice("Selling");
    addPrice("Medium");
    addPrice("Buying");
}

// input-output
QDataStream& operator<< (QDataStream &out, const FinanceData& from)
{    
    out << from.datetime << from.buying_price << from.selling_price << from.current_price << from.bank;

    return out;
}

QDataStream& operator>> (QDataStream &in, FinanceData& to)
{
    QDateTime dt;
    Currency bp;
    Currency sp;
    Currency p;
    QString b;

    in >> dt >> bp >> sp >> p >> b;

    to.setDatetime(dt);
    to.setBuyingPrice(bp);
    to.setSellingPrice(sp);
    to.setCurrentPrice(p);
    to.setBank(b);

    return in;
}
