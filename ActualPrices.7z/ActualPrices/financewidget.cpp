#include "financewidget.h"

FinanceWidget::FinanceWidget(QWidget *parent) : QFrame(parent)
{
    makeGUI();
}

FinanceWidget::~FinanceWidget()
{
    // delete standard buttons
    pb_priceUSD->deleteLater();
    pb_grabData->deleteLater();

    // delete all the actions and clear their lists
    clearActions("banks");
    clearActions("prices");

    // delete menus and toolbutton
    mn_bank->deleteLater();
    mn_price->deleteLater();
    mn_setup->deleteLater();
    tb_setup->deleteLater();
}

QPushButton *FinanceWidget::priceButton()
{
    return pb_priceUSD;
}

QPushButton *FinanceWidget::grabButton()
{
    return pb_grabData;
}

void FinanceWidget::updateData()
{
    finance.update();

    updateGUI();
}

void FinanceWidget::updateGUI()
{
    clearActions("banks");
    clearActions("prices");

    QStringList banks = finance.getBanks();
    for (int i = 0; i < banks.size(); ++i)
    {
        QAction *action = new QAction(banks.at(i), this);
        connect (action, SIGNAL(triggered()), this, SLOT(onBankTriggered()));
        l_banks.append(action);
    }

    mn_bank->clear();
    mn_bank->addActions(l_banks);

    QStringList prices = finance.getPrices();
    for (int i = 0; i < prices.size(); ++i)
    {
        QAction *action = new QAction(prices.at(i), this);
        connect (action, SIGNAL(triggered()), this, SLOT(onPriceTriggered()));
        l_prices.append(action);
    }

    mn_price->clear();
    mn_price->addActions(l_prices);
}

const QString &FinanceWidget::getBank()
{
    return finance.getBank();
}

void FinanceWidget::setCurrentPrice(PriceType type)
{
    finance.setCurrentPrice(type);
}

Currency FinanceWidget::getPrice(PriceType type)
{
    return finance.getPrice(type);
}

void FinanceWidget::makeGUI()
{
    pb_priceUSD = new QPushButton();
    pb_priceUSD->setFixedSize(QSize(256,32));

    pb_grabData = new QPushButton("Grab Data");
    pb_grabData->setFixedSize(QSize(128,32));

    tb_setup = new QToolButton();
    tb_setup->setFixedSize(QSize(64, 32));
    tb_setup->setPopupMode(QToolButton::MenuButtonPopup);
    tb_setup->setText("Setup");

    mn_bank = new QMenu("Banks", this);
    mn_price = new QMenu("Price", this);
    mn_setup = new QMenu("Setup", this);
    mn_setup->addMenu(mn_bank);
    mn_setup->addMenu(mn_price);
    tb_setup->setMenu(mn_setup);

    layout = new QHBoxLayout (this);
    layout->addWidget(pb_priceUSD);
    layout->addStretch(1);
    layout->addWidget(tb_setup);
    layout->addWidget(pb_grabData);
    setLayout(layout);
}

void FinanceWidget::clearActions(const QString &what_actions)
{
    if (what_actions == "banks")
    {
        foreach (QAction* action, l_banks)
        {
            disconnect (action, SIGNAL(triggered()), this, SLOT(onBankTriggered()));
            action->deleteLater();
        }

        l_banks.clear();
    }

    if (what_actions == "prices")
    {
        foreach (QAction* action, l_prices)
        {
            disconnect (action, SIGNAL(triggered()), this, SLOT(onPriceTriggered()));
            action->deleteLater();
        }

        l_prices.clear();
    }
}

void FinanceWidget::onBankTriggered()
{
    QAction* action = static_cast<QAction*>(sender());
    QString bank = action->text();

    finance.setBank(bank);
    finance.setCurrentPrice(PriceType::Default);

    emit needsUpdate();

    qDebug() << bank << " triggered";

}

void FinanceWidget::onPriceTriggered()
{
    QAction* action = static_cast<QAction*>(sender());
    QString price = action->text();

    if (price == "Selling")
        finance.setCurrentPrice(PriceType::Selling);
    else if (price == "Medium")
        finance.setCurrentPrice(PriceType::Medium);
    else if (price == "Buying")
        finance.setCurrentPrice(PriceType::Buying);

    emit needsUpdate();

    qDebug() << price << " triggered";
}
