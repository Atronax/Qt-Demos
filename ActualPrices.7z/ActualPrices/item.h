#ifndef ITEM_H
#define ITEM_H

#include <QString>

#include "currency.h"
#include "category.h"

class Item
{
public:
    Item();
    Item(const Category& category, const QString& code, const QString& name, const Currency& baseUSD, int vat, int charge);

    Category getCategory() const;
    const QString& getCode() const;
    const QString& getName() const;
    Currency getBaseUSD();
    Currency getBaseUAH();
    Currency getWithVATPrice();
    Currency getActualPrice();
    int getVAT();
    int getCharge();

    void setCategory (const Category&);
    void setCode (const QString&);
    void setName (const QString&);
    void setBaseUSD (const Currency&);
    void setVAT(int);
    void setCharge (int);

    void calculateBaseUAH (const Currency& priceUSD);
    void calculateWithVATPrice ();
    void calculateActualPrice ();

    bool isEmpty();
    QString toString();

    Item operator= (const Item& rhs);
    bool operator== (const Item& rhs);
    bool operator!= (const Item& rhs);
    bool operator<  (const Item& rhs);

    friend QDataStream& operator<< (QDataStream&, const Item&);
    friend QDataStream& operator>> (QDataStream&, Item&);

private:
    Category category;
    QString code;
    QString name;
    Currency baseUSD;
    Currency baseUAH;    
    Currency withVATPrice;
    Currency actualPrice;
    int vat;
    int charge;
};

#endif // ITEM_H
