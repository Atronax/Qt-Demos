#ifndef ITEMVIEW_H
#define ITEMVIEW_H

#include "item.h"
#include "pushbutton.h"
#include "enums.h"

#include <QFrame>
#include <QLineEdit>
#include <QHBoxLayout>

class ItemView : public QFrame
{
    Q_OBJECT

public:
    ItemView(Item *item, QWidget *parent = nullptr);
    ~ItemView();

    void keyPressEvent (QKeyEvent* ev);

    PushButton* vatButton();
    PushButton* withVatButton();

    void updateView();

private:
    void makeGUI();
    void editCanceled(EditableElement element);

    Item* item;

    PushButton *pb_code;
    PushButton *pb_name;
    PushButton *pb_baseUSD;
    PushButton *pb_baseUAH;
    PushButton *pb_vat;
    PushButton *pb_withVATPrice;
    PushButton *pb_charge;
    PushButton *pb_actualPrice;
    PushButton *pb_generateLabel;
    PushButton *pb_delete;
    QHBoxLayout *layout;

    QLineEdit *le_code;
    QLineEdit *le_name;
    QLineEdit *le_baseUSD;
    QLineEdit *le_vat;
    QLineEdit *le_charge;

signals:
    void generateLabel (Item* item);
    void itemUpdate (Item* item);
    void itemDelete (Item* item);

public slots:
    void onCodeDoubleClicked();
    void onNameDoubleClicked();
    void onBaseUSDDoubleClicked();
    void onVatDoubleClicked();
    void onChargeDoubleClicked();

    void onCodeChanged();
    void onNameChanged();
    void onBaseUSDChanged();
    void onVatChanged();
    void onChargeChanged();

    void onItemDelete();
    void onGenerateLabel();

};

#endif // ITEMVIEW_H
