#include "finance.h"

#include <QDataStream>

Finance::Finance()
{        
    manager = new QNetworkAccessManager (this);
    url = QUrl("http://resources.finance.ua/ua/public/currency-cash.xml");    
    data.setBank(data.getDefaultBank()); // установить "ПриватБанк", "А-Банк"

    getXML();
}

Finance::~Finance()
{
    SaveData("usdvalue.dat");

    file->deleteLater();
    reply->deleteLater();
    manager->deleteLater();
}

void Finance::getXML()
{
    QNetworkRequest request (url);
    reply = manager->get(request);
    if (reply->error() == QNetworkReply::HostNotFoundError) // TODO: + other problems with reply
        LoadData("usdvalue.txt");

    connect (manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(onFinished(QNetworkReply*)));
}

void Finance::update()
{
     if (isValid() && needsUpdate())
     {
         qDebug() << "update scheduled";
         grabData();
     }
}


void Finance::SaveData(const QString &filename)
{
    QFile file (filename);
    if (file.open(QIODevice::WriteOnly))
    {
        QDataStream stream (&file);
        stream << data;

        file.close();
    }
}

void Finance::LoadData(const QString &filename)
{
    if (QFileInfo::exists(filename))
    {
        QFile file (filename);
        if (file.open(QIODevice::ReadOnly))
        {
            QDataStream stream (&file);
            stream >> data;

            qDebug() << "LOAD: " << data.getDatetime().toString() << " : " << data.getBuyingPrice().toString() << " : " << data.getSellingPrice().toString();

            file.close();
        }
    }
}

const QString &Finance::getBank()
{
    return data.getBank();
}

const QStringList &Finance::getBanks()
{
    return data.getBanks();
}

const QStringList &Finance::getPrices()
{
    return data.getPrices();
}

Currency Finance::getPrice(PriceType price)
{
    Currency result;

    qDebug() << "in getPrice";

    if (isValid())
    {
        switch (price)
        {
            case PriceType::Current:
                result = data.getCurrentPrice();
                break;

            case PriceType::Buying:
                result = data.getBuyingPrice();
                break;

            case PriceType::Selling:
                result = data.getSellingPrice();
                break;

            case PriceType::Medium:
                result = (data.getBuyingPrice() + data.getSellingPrice()) / 2;
                break;

            case PriceType::Default:
                result = data.getDefaultPrice();
                break;
        }
    }

    return result;
}

void Finance::setCurrentPrice(PriceType price)
{
    switch (price)
    {
        case PriceType::Current:
            break;

        case PriceType::Buying:
            data.setCurrentPrice(data.getBuyingPrice());
            qDebug() << "current price is set to buying price";
            break;

        case PriceType::Selling:
            data.setCurrentPrice(data.getSellingPrice());
            break;

        case PriceType::Medium:
            data.setCurrentPrice((data.getBuyingPrice() + data.getSellingPrice()) / 2);
            break;

        case PriceType::Default:
            data.setCurrentPrice(data.getDefaultPrice());
            break;
    }
}

void Finance::setBank(const QString &new_bank)
{
    data.storePreviousBank();
    data.setBank(new_bank);
}

bool Finance::isValid()
{
    return valid;
}

QString Finance::getFilename (const QUrl& url)
{
    QString filename = QFileInfo(url.path()).fileName();
    if (filename.isEmpty())
        filename = "temp";

    return filename;
}

bool Finance::isRedirect(QNetworkReply *reply)
{
    int statusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();

    if (statusCode == 301 || statusCode == 302 || statusCode == 303 || statusCode == 305 || statusCode == 307 || statusCode == 308)
        return true;
    else
        return false;
}

QFile* Finance::grabFile (QNetworkReply* reply)
{
    qDebug() << "in Finance::grabFile";
    if (reply->error() || isRedirect(reply))
    {
        qDebug() << "Some error";
        return nullptr; // return saved data
    }
    else
    {
        QFile* file = new QFile(getFilename(url));
        if (!file->open(QIODevice::WriteOnly))
        {
            qDebug() << "Cannot open file";
            return nullptr; // return saved data
        }

        file->write(reply->readAll());
        file->close();

        return file;
    }
}

bool Finance::needsUpdate()
{
    bool needsUpdate = false;

    // we need to update data block
    // if grabbed information is more current to date
    QDomNodeList source = document.elementsByTagName("source");
    if (!source.isEmpty())
    {
       QDomElement date_element = source.at(0).toElement();
       QString date_string = date_element.attribute("date");
       date_string.chop(6); // leave timezone information behind

       QDateTime new_datetime = QDateTime::fromString(date_string, "yyyy-MM-ddTHH:mm:ss");
       if (data.getDatetime() > new_datetime)
       {
           data.setDatetime(new_datetime);
           needsUpdate = true;
       }
    }

    // or if we changed the bank: so we get new data block and new prices
    if (!data.getPreviousBank().isEmpty() && data.getPreviousBank() != data.getBank())
        needsUpdate = true;

    return needsUpdate;
}


void Finance::grabData()
{
    // Выписать узлы с данными об организациях
    QDomElement pb;
    QDomNodeList organizations = document.elementsByTagName("organization");
    for (int i = 0; i < organizations.size(); ++i)
    {
        QDomNode organization = organizations.at(i);
        QDomElement title = organization.firstChild().toElement();
        QString bank = title.attribute("value");

        data.addBank(bank); // store bank name for future use
        if (bank == data.getBank())
             pb = organization.toElement();
    }

    // Для каждой из организаций выписать доступные валюты для обмена
    QDomNodeList currencies;
    for (QDomNode node = pb.firstChild(); !node.isNull(); node = node.nextSibling())
        if (node.toElement().tagName() == "currencies")
            currencies = node.toElement().elementsByTagName("c");

    // Найти элемент с аттрибутом "id", значение которого равно "USD"
    for (int j = 0; j < currencies.size(); ++j)
    {
        QDomElement curr = currencies.at(j).toElement();
        if (curr.attribute("id") == "USD")
        {
            QStringList br = QString(curr.attribute("br")).split(".");
            QStringList ar = QString(curr.attribute("ar")).split(".");

            int br_up = br.at(0).toInt();
            int br_lp = br.at(1).chopped(2).toInt(); // convert from 0000 to 00

            int ar_up = ar.at(0).toInt();
            int ar_lp = ar.at(1).chopped(2).toInt(); // convert from 0000 to 00

            data.setBuyingPrice(Currency("UAH", br_up, br_lp));
            data.setSellingPrice(Currency("UAH", ar_up, ar_lp));
            // data.setCurrentPrice(data.getSellingPrice());

            // qDebug() << "UPDATE: " << "Покупка: " << data.getBuyingPrice().toString() << " : " << "Продажа: " << data.getSellingPrice().toString() << "\n";
        }
    }

}

void Finance::onFinished(QNetworkReply *reply)
{
    qDebug() << "in onFinished";

    file = grabFile(reply);
    if (file->open(QIODevice::ReadOnly))    
        document.setContent(file->readAll());

    file->close();
    valid = true;
}
