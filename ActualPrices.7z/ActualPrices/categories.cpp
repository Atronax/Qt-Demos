#include "categories.h"

#include <QFile>
#include <QFileInfo>

#include <QDebug>

Categories::Categories()
{
}

Categories::~Categories()
{
    qDebug() << "in Categories destructor";

    if (!categories.isEmpty())
    {
        for (int i = 0; i < views.size(); ++i)
            views.at(i)->deleteLater();

        categories.clear();
        views.clear();
    }

    qDebug() << "after Categories desctructor";
}

Category *Categories::createCategory(const QString &name)
{
    Category* category = new Category(name);

    addCategory(category);
    return category;
}

Category *Categories::createCategory(const Category &rhs)
{
    Category* category = new Category (rhs);

    addCategory(category);
    return category;
}

int Categories::getSize()
{
    return categories.size();
}

bool Categories::isEmpty()
{
    return categories.isEmpty();
}

int Categories::indexOf(Category *category)
{
    return categories.indexOf(category);
}

Category *Categories::getCategoryAt(int index)
{
    if (index >= 0 && index < categories.size())
        return categories.at(index);
    else
        return nullptr;
}

CategoryView *Categories::getCategoryViewAt(int index)
{
    if (index >= 0 && index < views.size())
        return views.at(index);
    else
        return nullptr;
}

Category *Categories::getCategoryByName(const QString &name)
{
    Category *result = nullptr;

    for (int i = 0; i < categories.size(); ++i)
    {
        Category *current = categories.at(i);
        if (current->getName() == name)
            result = current;
    }

    return result;
}

void Categories::replaceCategoryAt(int index, Category *category)
{
    if (index >= 0 && index < categories.size())
    {
        Category* old_category = categories.at(index);

        categories.replace(index, category);
        delete old_category;
    }
}

void Categories::removeOneCategory(Category *category)
{
    if (categories.removeOne(category))
        delete category;
}

void Categories::removeCategoryAt(int index)
{
    if (index >= 0 && index < categories.size())
        categories.removeAt(index);
}

void Categories::replaceCategoryViewAt(int index, CategoryView *view)
{
    if (index >= 0 && index < views.size())
        views.replace(index, view);
}

void Categories::removeOneCategoryView(CategoryView *view)
{
    views.removeOne(view);
}

void Categories::removeCategoryViewAt(int index)
{
    if (index >= 0 && index < views.size())
        views.removeAt(index);
}

void Categories::addCategory(Category *category)
{
    bool available = false;
    for (int i = 0; i < categories.size(); ++i)
        if (*categories.at(i) == *category)
            available = true;

    if (category->isEmpty() || !available)
    {
        categories.append(category);
        views.append(new CategoryView(category));
    }
}
