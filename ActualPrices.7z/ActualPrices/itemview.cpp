#include "itemview.h"

#include <QRegExp>
#include <QDebug>

ItemView::ItemView(Item *item, QWidget *parent) : QFrame(parent)
{
    this->item = item;
    makeGUI();
}

ItemView::~ItemView()
{
    pb_code->deleteLater();
    pb_name->deleteLater();
    pb_baseUSD->deleteLater();
    pb_baseUAH->deleteLater();
    pb_vat->deleteLater();
    pb_withVATPrice->deleteLater();
    pb_charge->deleteLater();
    pb_actualPrice->deleteLater();
    pb_generateLabel->deleteLater();
    pb_delete->deleteLater();
    layout->deleteLater();

    le_code->deleteLater();
    le_name->deleteLater();
    le_baseUSD->deleteLater();
    le_vat->deleteLater();
    le_charge->deleteLater();

    delete item;
}

void ItemView::keyPressEvent(QKeyEvent *ev)
{
     if (ev->key() == Qt::Key_Escape)
     {
         if (le_code->isVisible())
             editCanceled(EditableElement::Code);

         if (le_name->isVisible())
             editCanceled(EditableElement::Name);

         if (le_baseUSD->isVisible())
             editCanceled(EditableElement::BaseUSD);

         if (le_vat->isVisible())
             editCanceled(EditableElement::VAT);

         if (le_charge->isVisible())
             editCanceled(EditableElement::Charge);
     }
     else
         QFrame::keyPressEvent(ev);
}

PushButton *ItemView::vatButton()
{
    return pb_vat;
}

PushButton *ItemView::withVatButton()
{
    return pb_withVATPrice;
}

void ItemView::updateView()
{
    pb_code->setText(item->getCode());
    le_code->setText(item->getCode());
    pb_name->setText(item->getName());
    le_name->setText(item->getName());
    pb_baseUSD->setText(item->getBaseUSD().toString());
    le_baseUSD->setText(item->getBaseUSD().toString());
    pb_baseUAH->setText(item->getBaseUAH().toString());
    pb_vat->setText(QString("%1%").arg(item->getVAT()));
    le_vat->setText(QString("%1%").arg(item->getVAT()));
    pb_withVATPrice->setText(item->getWithVATPrice().toString());
    pb_charge->setText(QString("%1%").arg(item->getCharge()));
    le_charge->setText(QString("%1%").arg(item->getCharge()));
    pb_actualPrice->setText(item->getActualPrice().toString());
    pb_delete->setText("-");
}

void ItemView::makeGUI()
{
    pb_code = new PushButton (this);
    pb_name = new PushButton (this);   
    pb_baseUSD = new PushButton (this);
    pb_baseUAH = new PushButton (this);
    pb_vat = new PushButton (this);
    pb_withVATPrice = new PushButton (this);    
    pb_charge = new PushButton (this);
    pb_actualPrice = new PushButton (this);
    pb_generateLabel = new PushButton (this);
    pb_generateLabel->setText("#");
    pb_generateLabel->setFixedSize(24, 24);
    pb_delete = new PushButton (this);
    pb_delete->setFixedSize(24, 24);

    pb_code->setObjectName("Editable");
    pb_name->setObjectName("Name");
    pb_baseUSD->setObjectName("Editable");
    pb_baseUAH->setObjectName("Calculated");
    pb_vat->setObjectName("Editable");
    pb_withVATPrice->setObjectName("Calculated");
    pb_charge->setObjectName("Editable");
    pb_actualPrice->setObjectName("Calculated");
    pb_generateLabel->setObjectName("Image");
    pb_delete->setObjectName("Delete");

    connect(pb_code, SIGNAL(doubleClicked()), this, SLOT(onCodeDoubleClicked()));
    connect(pb_name, SIGNAL(doubleClicked()), this, SLOT(onNameDoubleClicked()));
    connect(pb_baseUSD, SIGNAL(doubleClicked()), this, SLOT(onBaseUSDDoubleClicked()));
    connect(pb_vat, SIGNAL(doubleClicked()), this, SLOT(onVatDoubleClicked()));
    connect(pb_charge, SIGNAL(doubleClicked()), this, SLOT(onChargeDoubleClicked()));
    connect(pb_generateLabel, SIGNAL(sure()), this, SLOT(onGenerateLabel()));
    connect(pb_delete, SIGNAL(sure()), this, SLOT(onItemDelete()));

    le_code = new QLineEdit (this);
    le_name = new QLineEdit (this);
    le_baseUSD = new QLineEdit (this);
    le_vat = new QLineEdit (this);
    le_charge = new QLineEdit (this);

    le_code->setFixedSize(pb_code->size());
    le_name->setFixedSize(pb_name->size());
    le_baseUSD->setFixedSize(pb_baseUSD->size());
    le_vat->setFixedSize(pb_vat->size());
    le_charge->setFixedSize(pb_charge->size());

    connect(le_code, SIGNAL(returnPressed()), this, SLOT(onCodeChanged()));
    connect(le_name, SIGNAL(returnPressed()), this, SLOT(onNameChanged()));
    connect(le_baseUSD, SIGNAL(returnPressed()), this, SLOT(onBaseUSDChanged()));
    connect(le_vat, SIGNAL(returnPressed()), this, SLOT(onVatChanged()));
    connect(le_charge, SIGNAL(returnPressed()), this, SLOT(onChargeChanged()));

    le_code->hide();
    le_name->hide();
    le_baseUSD->hide();
    le_vat->hide();
    le_charge->hide();

    updateView();

    layout = new QHBoxLayout (this);
    layout->addWidget(pb_code);
    layout->addWidget(pb_name);
    layout->addWidget(pb_baseUSD);
    layout->addWidget(pb_baseUAH);
    layout->addWidget(pb_vat);
    layout->addWidget(pb_withVATPrice);
    layout->addWidget(pb_charge);    
    layout->addWidget(pb_actualPrice);
    layout->addWidget(pb_generateLabel);
    layout->addWidget(pb_delete);
    setLayout(layout);
}

void ItemView::editCanceled(EditableElement element)
{
    switch(element)
    {
        case EditableElement::Code:
            le_code->setText(pb_code->text());

            layout->replaceWidget(le_code, pb_code);

            le_code->hide();
            pb_code->show();

            pb_code->setFocus();
            break;

        case EditableElement::Name:
            le_name->setText(pb_name->text());

            layout->replaceWidget(le_name, pb_name);

            le_name->hide();
            pb_name->show();

            pb_name->setFocus();
            break;

        case EditableElement::BaseUSD:
            le_baseUSD->setText(pb_baseUSD->text());

            layout->replaceWidget(le_baseUSD, pb_baseUSD);

            le_baseUSD->hide();
            pb_baseUSD->show();

            pb_baseUSD->setFocus();
            break;

        case EditableElement::VAT:
            le_vat->setText(pb_vat->text());

            layout->replaceWidget(le_vat, pb_vat);

            le_vat->hide();
            pb_vat->show();

            pb_vat->setFocus();
            break;

        case EditableElement::Charge:
            le_charge->setText(pb_charge->text());

            layout->replaceWidget(le_charge, pb_charge);

            le_charge->hide();
            pb_charge->show();

            pb_charge->setFocus();
            break;

        case EditableElement::Default:
            break;
    }
}

void ItemView::onCodeDoubleClicked()
{
    layout->replaceWidget(pb_code, le_code);

    pb_code->hide();
    le_code->show();
}

void ItemView::onNameDoubleClicked()
{
    layout->replaceWidget(pb_name, le_name);

    pb_name->hide();
    le_name->show();
}

void ItemView::onBaseUSDDoubleClicked()
{
    layout->replaceWidget(pb_baseUSD, le_baseUSD);

    pb_baseUSD->hide();
    le_baseUSD->show();
}

void ItemView::onVatDoubleClicked()
{
    layout->replaceWidget(pb_vat, le_vat);

    pb_vat->hide();
    le_vat->show();
}

void ItemView::onChargeDoubleClicked()
{
    layout->replaceWidget(pb_charge, le_charge);

    pb_charge->hide();
    le_charge->show();
}

void ItemView::onCodeChanged()
{
    QString old_code = pb_code->text();
    QString new_code = le_code->text();

    if (new_code != "" && new_code != old_code)
    {
        item->setCode(new_code);
        pb_code->setText(item->getCode());
    }

    layout->replaceWidget(le_code, pb_code);

    le_code->hide();
    pb_code->show();

    pb_code->setFocus();
}

void ItemView::onNameChanged()
{
    QString old_name = pb_name->text();
    QString new_name = le_name->text();

    if (new_name != "" && new_name != old_name)
    {
        item->setName(new_name);
        pb_name->setText(item->getName());
    }

    layout->replaceWidget(le_name, pb_name);

    le_name->hide();
    pb_name->show();

    pb_name->setFocus();
}

void ItemView::onBaseUSDChanged()
{
    QString old_price = pb_baseUSD->text();
    QString new_price = le_baseUSD->text();

    if (new_price != "" && new_price != old_price)
    {
        QRegExp re ("[0-9]{1,9}[.][0-9]{2,2}USD");
        if (re.exactMatch(new_price))
        {
            qDebug() << new_price << ": regex " << re.pattern() << "exact match";

            new_price.chop(3); // without USD part
            QStringList parts = new_price.split(".");

            Currency currency;
            currency.setName("USD");
            currency.setUpperPart(parts.at(0).toInt());
            currency.setLowerPart(parts.at(1).toInt());

            item->setBaseUSD(currency);
            pb_baseUSD->setText(item->getBaseUSD().toString());

            emit itemUpdate(item);
            // pb_baseUAH->setText("0.0UAH");
            // pb_withVATPrice->setText("0.0UAH");
            // pb_actualPrice->setText("0.0UAH");
        }
        else
        {
            // TO DO: warn the user to write using the given pattern
            qDebug() << new_price << ": regex " << re.pattern() << "have no matches";

            le_baseUSD->setText(item->getBaseUSD().toString());
        }
    }

    layout->replaceWidget(le_baseUSD, pb_baseUSD);

    le_baseUSD->hide();
    pb_baseUSD->show();

    pb_baseUSD->setFocus();
}

void ItemView::onVatChanged()
{
    QString old_vat = pb_vat->text();
    QString new_vat = le_vat->text();

    if (new_vat != "" && new_vat != old_vat)
    {
        QRegExp re ("[0-9]{1,9}%");
        if (re.exactMatch(new_vat))
        {
            qDebug() << new_vat << ": regex " << re.pattern() << "exact match";

            new_vat.chop(1); // without % part

            int vat = new_vat.toInt();

            item->setVAT(vat);

            pb_vat->setText(QString("%1%").arg(item->getVAT()));

            emit itemUpdate(item);
            // pb_withVATPrice->setText("0.0UAH");
            // pb_actualPrice->setText("0.0UAH");
        }
        else
        {
            // TO DO: warn the user to write using the given pattern
            qDebug() << new_vat << ": regex " << re.pattern() << "have no matches";

            le_vat->setText(QString("%1%").arg(item->getVAT()));
        }
    }

    layout->replaceWidget(le_vat, pb_vat);

    le_vat->hide();
    pb_vat->show();

    pb_vat->setFocus();
}

void ItemView::onChargeChanged()
{
    QString old_percentage = pb_charge->text();
    QString new_percentage = le_charge->text();

    if (new_percentage != "" && new_percentage != old_percentage)
    {
        QRegExp re ("[0-9]{1,9}%");
        if (re.exactMatch(new_percentage))
        {
            qDebug() << new_percentage << ": regex " << re.pattern() << "exact match";

            new_percentage.chop(1); // without % part

            int percentage = new_percentage.toInt();

            item->setCharge(percentage);

            pb_charge->setText(QString("%1%").arg(item->getCharge()));

            emit itemUpdate(item);
            // pb_actualPrice->setText("0.0UAH");
        }
        else
        {
            // TO DO: warn the user to write using the given pattern
            qDebug() << new_percentage << ": regex " << re.pattern() << "have no matches";

            le_charge->setText(QString("%1%").arg(item->getCharge()));
        }
    }

    layout->replaceWidget(le_charge, pb_charge);

    le_charge->hide();
    pb_charge->show();

    pb_charge->setFocus();
}

void ItemView::onItemDelete()
{
    qDebug() << "in ItemView::onItemDelete()";
    emit itemDelete(item);
}

void ItemView::onGenerateLabel()
{
    qDebug() << "in ItemView::onGenerateLabel";

    bool hasCode = !item->getCode().isEmpty();
    bool hasName = !item->getName().isEmpty();
    bool hasPrice = (item->getActualPrice() != Currency("UAH", 0, 0));

    if (hasCode && hasName && hasPrice)
        emit generateLabel(item);
}
