#ifndef CATEGORYVIEW_H
#define CATEGORYVIEW_H

#include "category.h"
#include "pushbutton.h"
#include "enums.h"

#include <QFrame>
#include <QLineEdit>
#include <QHBoxLayout>


class CategoryView : public QFrame
{
    Q_OBJECT

public:
    CategoryView(Category *category, QWidget *parent = nullptr);
    ~CategoryView();

    void setActive();
    void updateData();

    void keyPressEvent (QKeyEvent* ev);

private:
    void makeGUI();
    void editCanceled(EditableElement element);

    Category* category;

    PushButton *pb_name;
    PushButton *pb_delete;
    QHBoxLayout *layout;

    QLineEdit *le_name;

signals:
    void categoryDelete(Category *category);

    void categoryClicked(const QString& name);    
    void categoryChanged(const QString& from, const QString& to);

public slots:
    void onNameDoubleClicked();
    void onNameChanged();

    void onCategoryDelete();
    void onCategoryClicked();


};

#endif // CATEGORYVIEW_H
