#ifndef FINANCEWIDGET_H
#define FINANCEWIDGET_H

#include <QFrame>

#include <QMenu>
#include <QPushButton>
#include <QToolButton>
#include <QHBoxLayout>

#include "finance.h"

class FinanceWidget : public QFrame
{
    Q_OBJECT

public:
    FinanceWidget(QWidget *parent = nullptr);
    ~FinanceWidget();

    QPushButton* priceButton();
    QPushButton* grabButton();

    void updateData();
    void updateGUI();

    const QString& getBank ();    

    void setCurrentPrice(PriceType type);
    Currency getPrice (PriceType type);

private:
    void makeGUI();

    void clearActions(const QString& what_actions);

    Finance finance;

    QPushButton *pb_priceUSD;
    QPushButton *pb_grabData;
    QToolButton *tb_setup;
    QMenu *mn_setup, *mn_bank, *mn_price;
    QList<QAction*> l_banks, l_prices;
    QHBoxLayout *layout;

signals:
    void needsUpdate();

public slots:
    void onBankTriggered();
    void onPriceTriggered();
};

#endif // FINANCEWIDGET_H
