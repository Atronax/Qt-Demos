#include "mainwindow.h"

#include <qrandom.h>
#include <QDir>

MainWindow::MainWindow(QWidget *parent) : QFrame(parent)
{    
    init();
}

MainWindow::~MainWindow()
{
    qDebug() << "in MainWindow destructor";
    timer->deleteLater();

    sa_categories->deleteLater();
    sa_items->deleteLater();

    items->deleteLater();
    categories->deleteLater();
    finance->deleteLater();

    layout_top->deleteLater();
    layout->deleteLater();
    qDebug() << "after MainWindow destructor";
}

void MainWindow::init()
{
    // make all the neccessary directories;
    QDir file_system;
    if (!QFileInfo("labels").exists())
        file_system.mkdir("labels");

    // initialize items widget
    items = new ItemsWidget(this);
    items->createItem(Category("Мониторы"), "1", "LG 21'", Currency("USD", 114, 22), 20, 14);
    items->createItem(Category("Клавиатуры"), "2", "Genius'", Currency("USD", 6, 81), 20, 22);
    items->createItem(Category("Клавиатуры"), "3", "SimpleKB", Currency("USD", 4, 62), 20, 38);
    items->createItem(Category("Модемы"), "4", "Lego", Currency("USD", 63, 31), 20, 18);
    connect(items->addButton(), SIGNAL(clicked()), this, SLOT(onAddItemClicked()));
    connect(items, SIGNAL(itemUpdate(int)), this, SLOT(onItemUpdate(int)));
    connect(items, SIGNAL(itemDelete(int)), this, SLOT(onItemDelete(int)));

    // initialize categories widget
    categories = new CategoriesWidget(items->getUniqueCategories(), this);
    connect(categories->addButton(), SIGNAL(clicked()), this, SLOT(onAddCategoryClicked()));
    connect(categories, SIGNAL(categoryClicked(const QString&)), this, SLOT(onCategoryClicked(const QString&)));
    connect(categories, SIGNAL(categoryChanged(const QString&, const QString&)), this, SLOT(onCategoryChanged(const QString&, const QString&)));
    connect(categories, SIGNAL(categoryDelete (int)), this, SLOT(onCategoryDelete (int)));
    categories->getCategoryViewAt(0)->setActive();

    // initialize finance widget
    finance = new FinanceWidget();
    connect (finance->grabButton(), SIGNAL(clicked()), this, SLOT(grabData()));
    connect (finance, SIGNAL(needsUpdate()), this, SLOT(update()));

    sa_categories = new QScrollArea;
    sa_categories->setWidget(categories);
    sa_categories->setWidgetResizable(true);
    sa_categories->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    sa_categories->setFixedWidth(categories->getWidth() + 20);
    sa_categories->setBackgroundRole(QPalette::Dark);

    sa_items = new QScrollArea;
    sa_items->setWidget(items);
    sa_items->setWidgetResizable(true);
    sa_items->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    sa_items->setFixedWidth(items->getWidth() + 20);
    sa_items->setBackgroundRole(QPalette::Dark);

    layout_top = new QHBoxLayout;
    layout_top->addWidget(sa_categories);
    layout_top->addSpacerItem(new QSpacerItem(20, 1));
    layout_top->addWidget(sa_items);

    layout = new QVBoxLayout (this);
    layout->addSpacerItem(new QSpacerItem(1, 10));
    layout->addLayout(layout_top);
    layout->addWidget(finance);
    setLayout(layout);

    // for testing purposes
    timer = new QTimer(this);
    connect (timer, SIGNAL(timeout()), this, SLOT(onTimer()));
    timer->start(1000);

    // setMouseTracking(true);
    // loadStylesheet("stylesheets\\default.qss");

}

void MainWindow::loadStylesheet(const QString& path)
{
    QFile file (path);

    if (file.open(QIODevice::ReadOnly))
    {
        QString stylesheet = file.readAll();
        setStyleSheet(stylesheet);

        file.close();
    }
}

void MainWindow::updateItem(int index)
{
    // update item
    Item *item = items->getItemAt(index);
    item->calculateBaseUAH(finance->getPrice(PriceType::Current));
    item->calculateWithVATPrice();
    item->calculateActualPrice();

    // update view
    ItemView *view = items->getItemViewAt(index);
    view->updateView();
}

void MainWindow::updatePriceChecker()
{
    finance->priceButton()->setText("1USD = " + finance->getPrice(PriceType::Current).toString() + " " + "(" + finance->getBank() + ")");
}

void MainWindow::grabData()
{
    finance->updateData();
}

void MainWindow::update()
{
    grabData();

    for (int i = 0; i < items->getSize(); ++i)
        updateItem(i);

    updatePriceChecker();
}

void MainWindow::onTimer()
{
    loadStylesheet("stylesheets\\default.qss");
}

void MainWindow::onAddItemClicked()
{
    Category *current = categories->getCurrent();
    if (current != nullptr && current->getName() != "Всё")
        items->createItem(*current, "default code", "default name", Currency("USD", 0, 0), 20, 0);
}

void MainWindow::onItemUpdate(int index)
{
    updateItem(index);
}

void MainWindow::onItemDelete(int index)
{
    // store category
    Category category = items->getItemAt(index)->getCategory();

    // remove item view and item itself
    items->removeItemAt(index);
    items->removeItemViewAt(index);

    // check count of other items with the same category
    int matches = 0;
    for (int i = 0; i < items->getSize(); ++i)
    {
        if (category == items->getItemAt(i)->getCategory())
            ++matches;
    }

    // if there isn't even a single item left, delete the category
    if (matches == 0)
    {
        for (int i = 0; i < categories->getSize(); ++i)
        {
            if (category.getName() == categories->getCategoryAt(i)->getName())
            {
                // remove category and its view
                categories->removeCategoryAt(i);
                categories->removeCategoryViewAt(i);

                // set basic category as active one
                categories->getCategoryViewAt(0)->setActive();
            }
        }
    }
}

void MainWindow::onAddCategoryClicked()
{
    categories->createCategory("");
}

void MainWindow::onCategoryDelete(int index)
{
    Category* to_delete = categories->getCategoryAt(index);

    // remove all items of the category
    for (int i = 0; i < items->getSize(); ++i)
    {
        Category category = items->getItemAt(i)->getCategory();

        if (to_delete->getName() == category.getName())
        {
            items->removeItemAt(i);
            items->removeItemViewAt(i);
            --i; // position of next element (i+1) changes to (i)
        }
    }

    // remove category itself
    categories->removeCategoryAt(index);
    categories->removeCategoryViewAt(index);

    // set basic category as active one
    categories->getCategoryViewAt(0)->setActive();
}

void MainWindow::onCategoryClicked(const QString& name)
{
    // futher dev: get separate selection of items and show only this selection
    if (name == "Всё")
    {
        for (int i = 0; i < items->getSize(); ++i)
            items->getItemViewAt(i)->show();

        items->countButton()->setText(QString("Count: %1").arg(items->getSize()));
        items->addButton()->setEnabled(false);
    }
    else
    {
        int count = 0;
        for (int i = 0; i < items->getSize(); ++i)
        {
            Category category = items->getItemAt(i)->getCategory();
            if (name == category.getName())
            {
                ++count;
                items->getItemViewAt(i)->show();
            }
            else
                items->getItemViewAt(i)->hide();
        }

        items->countButton()->setText(QString("Count: %1").arg(count));
        items->addButton()->setEnabled(true);
    }
}

void MainWindow::onCategoryChanged(const QString &from, const QString &to)
{
    for (int i = 0; i < items->getSize(); ++i)
    {
        Item *item = items->getItemAt(i);

        Category category = item->getCategory();
        if (category.getName() == from)
            item->setCategory(to);
    }
}
