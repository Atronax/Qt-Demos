#ifndef CATEGORY_H
#define CATEGORY_H

#include <QString>

class Category
{
public:
    Category();
    Category(const QString& name);

    const QString& getName();
    void setName (const QString&);

    bool isEmpty();
    const QString& toString();

    Category operator= (const Category& rhs);
    bool operator== (const Category& rhs);
    bool operator!= (const Category& rhs);
    bool operator<  (const Category& rhs);

    friend QDataStream& operator<< (QDataStream&, const Category&);
    friend QDataStream& operator>> (QDataStream&, Category&);

private:
    QString name;
};

#endif // CATEGORY_H
