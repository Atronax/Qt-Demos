#include "itemwidgetheader.h"

#include <QStyleOption>
#include <QPainter>

ItemWidgetHeader::ItemWidgetHeader(QWidget *parent) : QFrame(parent)
{
    makeGUI();
}

ItemWidgetHeader::~ItemWidgetHeader()
{
    pb_code->deleteLater();
    pb_name->deleteLater();
    pb_baseUSD->deleteLater();
    pb_baseUAH->deleteLater();
    pb_VAT->deleteLater();
    pb_VATprice->deleteLater();
    pb_charge->deleteLater();
    pb_ACTprice->deleteLater();
    pb_blank1->deleteLater();
    pb_blank2->deleteLater();

    layout->deleteLater();
}

QPushButton *ItemWidgetHeader::vatButton()
{
    return pb_VAT;
}

QPushButton *ItemWidgetHeader::withVatButton()
{
    return pb_VATprice;
}

void ItemWidgetHeader::makeGUI()
{
    pb_code = new QPushButton ("Code");
    pb_name = new QPushButton ("Name");
    pb_baseUSD = new QPushButton ("Base USD");
    pb_baseUAH = new QPushButton ("Base UAH");
    pb_VAT = new QPushButton ("VAT");
    pb_VATprice = new QPushButton ("With VAT");
    pb_charge = new QPushButton ("Extra Charge");
    pb_ACTprice = new QPushButton ("Actual Price");
    pb_blank1 = new QPushButton ("img");
    pb_blank2 = new QPushButton ("del");

    pb_blank1->setFixedSize(24, 24);
    pb_blank2->setFixedSize(24, 24);

    layout = new QHBoxLayout (this);
    layout->addWidget(pb_code);
    layout->addWidget(pb_name);
    layout->addWidget(pb_baseUSD);
    layout->addWidget(pb_baseUAH);
    layout->addWidget(pb_VAT);
    layout->addWidget(pb_VATprice);
    layout->addWidget(pb_charge);
    layout->addWidget(pb_ACTprice);
    layout->addWidget(pb_blank1);
    layout->addWidget(pb_blank2);

    setLayout(layout);
}
