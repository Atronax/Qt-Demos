#ifndef ITEMWIDGETFOOTER_H
#define ITEMWIDGETFOOTER_H

#include <QFrame>
#include <QPushButton>
#include <QHBoxLayout>

class ItemWidgetFooter : public QFrame
{
    Q_OBJECT
public:
    ItemWidgetFooter(QWidget *parent = nullptr);
    ~ItemWidgetFooter();

    QPushButton* countButton();
    QPushButton* addButton();

private:
    void makeGUI();

    QPushButton *pb_count;
    QPushButton *pb_add;

    QHBoxLayout *layout;

signals:

public slots:
};

#endif // ITEMWIDGETFOOTER_H
