#ifndef CURRENCY_H
#define CURRENCY_H

#include <QString>

class Currency
{
public:
    Currency();
    Currency(const QString& name, int upperPart, int lowerPart);

    int getUpperPart();
    int getLowerPart();
    const QString& getName();

    void setUpperPart(int upperPart);
    void setLowerPart(int lowerPart);
    void setName (const QString& name);

    Currency operator= (const Currency& rhs);
    Currency operator+ (const Currency& rhs);
    Currency operator+= (const Currency& rhs);
    Currency operator- (const Currency& rhs);
    Currency operator* (const Currency& rhs);
    Currency operator* (int percentage);
    Currency operator/ (const Currency& rhs);
    Currency operator/ (int divisor);

    bool operator== (const Currency& rhs);
    bool operator!= (const Currency& rhs);
    bool operator<  (const Currency& rhs);

    friend QDataStream& operator<< (QDataStream&, const Currency&);
    friend QDataStream& operator>> (QDataStream&, Currency&);

    int asLowerPart();
    QString toString();

private:
    void calculateFromLP(int& upperPart, int& lowerPart);
    void calculateFromUP(int& upperPart, int& lowerPart);

    QString name;
    int upperPart;
    int lowerPart;
};

#endif // CURRENCY_H
