#include "itemwidgetfooter.h"

ItemWidgetFooter::ItemWidgetFooter(QWidget *parent) : QFrame(parent)
{
    makeGUI();
}

ItemWidgetFooter::~ItemWidgetFooter()
{
    pb_count->deleteLater();
    pb_add->deleteLater();
}

QPushButton *ItemWidgetFooter::countButton()
{
    return pb_count;
}

QPushButton *ItemWidgetFooter::addButton()
{
    return pb_add;
}

void ItemWidgetFooter::makeGUI()
{
    pb_count = new QPushButton ("Count: ");
    pb_count->setFixedSize(64, 32);

    pb_add = new QPushButton ("+");
    pb_add->setObjectName("Add");
    pb_add->setFixedSize(32, 32);
    pb_add->setEnabled(false);

    layout = new QHBoxLayout (this);
    layout->addStretch(1);
    layout->addWidget(pb_count);
    layout->addWidget(pb_add);
    setLayout(layout);
}
