#include "itemswidget.h"

#include <QFile>
#include <QFileInfo>
#include <QDataStream>

#include <QImage>
#include <QPainter>

#include <QDebug>

ItemsWidget::ItemsWidget(QWidget *parent) : QFrame(parent)
{
    init();
    makeGUI();
    load("items.dat");
}

ItemsWidget::~ItemsWidget()
{
    qDebug() << "in ItemsWidget destr";
    if (!items->isEmpty())
        save("items.dat");

    delete items;

    header->deleteLater();
    footer->deleteLater();
    layout->deleteLater();
    qDebug() << "after ItemsWidget destr";
}

QPushButton *ItemsWidget::countButton()
{
    return footer->countButton();
}

QPushButton *ItemsWidget::addButton()
{
    return footer->addButton();
}

const QStringList& ItemsWidget::getUniqueCategories()
{
    return items->getUniqueCategories();
}

int ItemsWidget::getWidth()
{
    return layout->geometry().width();
}

int ItemsWidget::getHeight()
{
    return layout->geometry().height();
}

int ItemsWidget::getSize()
{
    return items->getSize();
}

bool ItemsWidget::isEmpty()
{
    return items->isEmpty();
}

Item *ItemsWidget::getCurrent()
{
    return current;
}

Item *ItemsWidget::getItemAt(int index)
{
    return items->getItemAt(index);
}

ItemView *ItemsWidget::getItemViewAt(int index)
{
    return items->getItemViewAt(index);
}

void ItemsWidget::removeItemAt(int index)
{
    items->removeItemAt(index);
}

void ItemsWidget::removeItemViewAt(int index)
{
    QWidget *widget = items->getItemViewAt(index);
    items->removeItemViewAt(index);
    layout->removeWidget(widget);
    widget->deleteLater();
}

void ItemsWidget::removeOneItem(Item *item)
{
    items->removeOneItem(item);
}

void ItemsWidget::removeOneItemView(ItemView *view)
{
    items->removeOneItemView(view);
}

void ItemsWidget::createItem(const Category &category, const QString &code, const QString &name, const Currency &baseUSD, int vat, int charge)
{
    Item* item = items->createItem(category, code, name, baseUSD, vat, charge);
    if (item != nullptr)
    {
        ItemView* view = items->getItemViewAt(items->indexOf(item));
        connect (view, SIGNAL(generateLabel(Item*)), this, SLOT(onGenerateLabel(Item*)));
        connect (view, SIGNAL(itemUpdate(Item*)), this, SLOT(onItemUpdate(Item*)));
        connect (view, SIGNAL(itemDelete(Item*)), this, SLOT(onItemDelete(Item*)));

        // item->setVAT(0);
        // view->vatButton()->hide();
        // view->withVatButton()->hide();

        // insert itemView as a last widget to layout
        int position = layout->indexOf(footer);
        layout->insertWidget(position, items->getItemViewAt(items->indexOf(item)));
    }
}

void ItemsWidget::createItem(const Item &rhs)
{
    Item* item = items->createItem(rhs);
    if (item != nullptr)
    {
        ItemView* view = items->getItemViewAt(items->indexOf(item));
        connect (view, SIGNAL(generateLabel(Item*)), this, SLOT(onGenerateLabel(Item*)));
        connect (view, SIGNAL(itemUpdate(Item*)), this, SLOT(onItemUpdate(Item*)));
        connect (view, SIGNAL(itemDelete(Item*)), this, SLOT(onItemDelete(Item*)));

        // item->setVAT(0);
        // view->vatButton()->hide();
        // view->withVatButton()->hide();

        // insert itemView as a last widget to layout
        int position = layout->indexOf(footer);
        layout->insertWidget(position, items->getItemViewAt(items->indexOf(item)));
    }
}

void ItemsWidget::makeGUI()
{
    header = new ItemWidgetHeader;
    footer = new ItemWidgetFooter;

    layout = new QVBoxLayout (this);    
    layout->addWidget(header);
    layout->addSpacing(5);

    for (int i = 0; i < items->getSize(); ++i)
        layout->addWidget(items->getItemViewAt(i));

    layout->addWidget(footer);
    layout->addStretch(1);
    setLayout(layout);
}

void ItemsWidget::onGenerateLabel(Item *item)
{
    qDebug() << "label image is generating";
    QImage image (512, 128, QImage::Format_ARGB32_Premultiplied);
    QPainter painter (&image);

    QFont categoryFont = QFont("Times New Roman", 8, false);
    QFont nameFont = QFont("Times New Roman", 32, true);
    QFont codeFont = QFont("Times New Roman", 8, false);
    QFont priceFont = QFont("Times New Roman", 16, true);

    QRectF blockRect = QRectF(QRect(1, 1, 510, 126));
    QRectF categoryRect = QRectF(QRect(32, 8, 144, 28));
    QRectF nameRect = QRectF(QRect(32, 8, 288, 112));
    QRectF codeRect = QRectF(QRect(352, 8, 128, 16));
    QRectF priceRect = QRectF(QRect(352, 32, 128, 88));

    painter.setPen(Qt::DashLine);
    painter.drawRect(blockRect);
    painter.setPen(Qt::SolidLine);

    painter.setFont(categoryFont);
    painter.drawText(categoryRect, item->getCategory().toString(), QTextOption(Qt::AlignCenter));

    painter.drawRect(nameRect);
    painter.setFont(nameFont);
    painter.drawText(nameRect, item->getName(), QTextOption(Qt::AlignCenter));

    painter.drawRect(codeRect);
    painter.setFont(codeFont);
    painter.drawText(codeRect, item->getCode(), QTextOption(Qt::AlignCenter));

    painter.drawRect(priceRect);
    painter.setFont(priceFont);
    painter.drawText(priceRect, item->getActualPrice().toString(), QTextOption(Qt::AlignCenter));

    QString filepath = "labels\\" + QString("%1 - %2.png").arg(item->getCategory().toString()).arg(item->getName());
    image.save(filepath, "png");

    qDebug() << "label image saved to " + filepath;
}

void ItemsWidget::onItemUpdate(Item *item)
{
    qDebug() << "in ItemsWidget::onItemUpdate()";
    emit itemUpdate(items->indexOf(item));
}

void ItemsWidget::onItemDelete(Item *item)
{
    qDebug() << "in ItemsWidget::onItemDelete()";
    emit itemDelete(items->indexOf(item));
}

// SAVE AND LOAD
void ItemsWidget::save(const QString& filename)
{
    QFile file (filename);
    if (file.open(QIODevice::WriteOnly))
    {
        // save
        QDataStream stream (&file);

        stream << items->getSize();
        qDebug() << "saving item: " << items->getSize();
        for (int i = 0; i < items->getSize(); ++i)
            stream << *items->getItemAt(i);

        file.close();
    }
}

void ItemsWidget::load(const QString& filename)
{
    if (QFileInfo::exists(filename))
    {
        QFile file (filename);
        if (file.open(QIODevice::ReadOnly))
        {
            // load
            int size;
            QDataStream stream (&file);

            stream >> size;
            for (int i = 0; i < size; ++i)
            {
                Item item;
                stream >> item;

                qDebug() << "loaded item: " << item.toString();
                createItem(item);
                qDebug() << "created item: " << item.toString();
            }

            file.close();
        }
    }
}

void ItemsWidget::init()
{
    items = new Items();
}
