#include "category.h"

#include <QDataStream>

Category::Category()
{
    name = "";
}

Category::Category(const QString &name)
{
    this->name = name;
}

const QString &Category::getName()
{
    return name;
}

void Category::setName(const QString &name)
{
    this->name = name;
}

bool Category::isEmpty()
{
    bool result = false;

    if (name == "")
        result = true;

    return result;
}

const QString &Category::toString()
{
    return name;
}

Category Category::operator=(const Category &rhs)
{
    this->name = rhs.name;

    return *this;
}

bool Category::operator==(const Category &rhs)
{
    bool result = false;

    if (this->name == rhs.name)
        result = true;

    return result;
}

bool Category::operator!=(const Category &rhs)
{
    bool result = false;

    if (this->name != rhs.name)
        result = true;

    return result;
}

bool Category::operator<(const Category &rhs)
{
    bool result = false;

    if (this->name < rhs.name)
        result = true;

    return result;
}

QDataStream& operator<<(QDataStream &out, const Category &from)
{
    out << from.name;

    return out;
}

QDataStream& operator>>(QDataStream &in, Category &to)
{
    QString name;
    in >> name;

    to.setName(name);

    return in;
}
