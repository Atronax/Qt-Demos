#ifndef CATEGORIES_H
#define CATEGORIES_H

#include "category.h"
#include "categoryview.h"

class Categories
{
public:
    Categories();
    ~Categories();

    Category* createCategory(const QString& name);
    Category* createCategory(const Category& rhs);

    int getSize ();
    bool isEmpty ();

    int indexOf (Category* category);
    Category *getCategoryAt (int index);
    CategoryView *getCategoryViewAt (int index);

    void removeCategoryAt (int index);
    void removeCategoryViewAt (int index);

    Category *getCategoryByName (const QString& name);

private:
    void replaceCategoryAt (int index, Category* category);
    void replaceCategoryViewAt (int index, CategoryView* view);

    void removeOneCategory (Category* category);
    void removeOneCategoryView (CategoryView* view);

    void addCategory (Category* category);

    QList<Category*> categories;
    QList<CategoryView*> views;
};

#endif // CATEGORIES_H
