#ifndef ENUMS_H
#define ENUMS_H

enum class EditableElement
{
    Default = 0,
    Code = 1,
    Name = 2,
    BaseUSD = 3,
    VAT = 4,
    Charge = 5
};

#endif // ENUMS_H
