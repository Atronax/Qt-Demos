#include "categorieswidget.h"

#include <QDebug>

CategoriesWidget::CategoriesWidget(const QStringList& input, QWidget *parent) : QFrame(parent)
{
    initGUI();
    initCategories(input);
}

CategoriesWidget::~CategoriesWidget()
{
    delete categories;

    pb_add->deleteLater();    
    layout->deleteLater();
}

QPushButton *CategoriesWidget::addButton()
{
    return pb_add;
}

int CategoriesWidget::getWidth()
{
    return layout->geometry().width();
}

int CategoriesWidget::getHeight()
{
    return layout->geometry().height();
}

bool CategoriesWidget::isEmpty()
{
    return categories->isEmpty();
}

int CategoriesWidget::getSize()
{
    return categories->getSize();
}

Category *CategoriesWidget::getCurrent()
{
    return current;
}

Category *CategoriesWidget::getCategoryAt(int index)
{
    return categories->getCategoryAt(index);
}

CategoryView *CategoriesWidget::getCategoryViewAt(int index)
{
    return categories->getCategoryViewAt(index);
}

void CategoriesWidget::removeCategoryAt(int index)
{
    categories->removeCategoryAt(index);
}

void CategoriesWidget::removeCategoryViewAt(int index)
{
    QWidget* widget = categories->getCategoryViewAt(index);
    categories->removeCategoryViewAt(index);
    layout->removeWidget(widget);
    widget->deleteLater();
}

void CategoriesWidget::createCategory(const QString &name)
{
    Category* category = categories->createCategory(name);
    CategoryView* view = categories->getCategoryViewAt(categories->indexOf(category));
    connect (view, SIGNAL(categoryClicked(const QString&)), this, SLOT(onCategoryClicked(const QString&)));
    connect (view, SIGNAL(categoryDelete (Category*)), this, SLOT(onCategoryDelete (Category*)));
    connect (view, SIGNAL(categoryChanged(const QString&, const QString&)), this, SLOT(onCategoryChanged(const QString&, const QString&)));

    int position = layout->indexOf(pb_add);
    layout->insertWidget(position, view);
}

void CategoriesWidget::createCategory(const Category &rhs)
{
    Category* category = categories->createCategory(rhs);
    CategoryView* view = categories->getCategoryViewAt(categories->indexOf(category));
    connect (view, SIGNAL(categoryClicked(const QString&)), this, SLOT(onCategoryClicked(const QString&)));
    connect (view, SIGNAL(categoryDelete(Category*)), this, SLOT(onCategoryDelete(Category*)));
    connect (view, SIGNAL(categoryChanged(const QString&, const QString&)), this, SLOT(onCategoryChanged(const QString&, const QString&)));

    int position = layout->indexOf(pb_add);
    layout->insertWidget(position, view);
}

void CategoriesWidget::initCategories(const QStringList& input)
{
    categories = new Categories;

    QStringList names = input;
    for (int i = 0; i < names.size(); ++i)
        createCategory(names.at(i));
}

void CategoriesWidget::initGUI()
{
    pb_add = new QPushButton("+");
    pb_add->setObjectName("Add");
    pb_add->setFixedSize(32, 32);

    layout = new QVBoxLayout (this);
    layout->addWidget(pb_add, 0, Qt::AlignRight);
    layout->addStretch(1);
    setLayout(layout);
}

void CategoriesWidget::onCategoryClicked(const QString& name)
{
    for (int i = 0; i < categories->getSize(); ++i)
    {
        Category *category = categories->getCategoryAt(i);
        if (category->getName() == name)
        {
            current = category;
            emit categoryClicked(name);
        }
    }
}

void CategoriesWidget::onCategoryDelete(Category *category)
{
    qDebug() << "in CategoriesWidget::onCategoryDelete";
    emit categoryDelete(categories->indexOf(category));
}

void CategoriesWidget::onCategoryChanged(const QString &from, const QString &to)
{
    emit categoryChanged(from, to);
}
