#ifndef CATEGORIESWIDGET_H
#define CATEGORIESWIDGET_H

#include <QFrame>

#include "categories.h"

class CategoriesWidget : public QFrame
{
    Q_OBJECT
public:
    CategoriesWidget(const QStringList& categories, QWidget *parent = nullptr);
    ~CategoriesWidget();

    QPushButton* addButton();

    int getWidth();
    int getHeight();

    bool isEmpty();
    int getSize();    


    Category *getCurrent();
    Category *getCategoryAt(int index);
    CategoryView *getCategoryViewAt(int index);

    void removeCategoryAt (int index);
    void removeCategoryViewAt (int index);

    void createCategory (const QString& name);
    void createCategory (const Category& rhs);

private:
    void initCategories(const QStringList& names);
    void initGUI();

    Categories *categories;
    Category *current;

    QPushButton *pb_add;
    QVBoxLayout *layout;

signals:
    void categoryDelete (int index);

    void categoryClicked(const QString& name);    
    void categoryChanged(const QString& from, const QString& to);

public slots:
    void onCategoryDelete (Category *category);

    void onCategoryClicked(const QString& name);    
    void onCategoryChanged(const QString& from, const QString& to);
};

#endif // CATEGORIESWIDGET_H
