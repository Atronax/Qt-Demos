#include "categoryview.h"

#include <QDebug>

CategoryView::CategoryView(Category *category, QWidget *parent) : QFrame(parent)
{
    this->category = category;
    makeGUI();
}

CategoryView::~CategoryView()
{
    pb_name->deleteLater();
    le_name->deleteLater();
    pb_delete->deleteLater();
    layout->deleteLater();

    if (category != nullptr)
        delete category;
}

void CategoryView::setActive()
{
    setFocus();
    pb_name->click();
}

void CategoryView::updateData()
{
    pb_name->setText(category->getName());
    le_name->setText(category->getName());
    pb_delete->setText(("-"));
}

void CategoryView::keyPressEvent(QKeyEvent *ev)
{
    if (ev->key() == Qt::Key_Escape)
    {
        if (le_name->isVisible())
            editCanceled(EditableElement::Name);
    }
    else
        QFrame::keyPressEvent(ev);
}

void CategoryView::makeGUI()
{
    pb_name = new PushButton (this);
    pb_name->setObjectName("Category");
    connect(pb_name, SIGNAL(clicked()), this, SLOT(onCategoryClicked()));
    connect(pb_name, SIGNAL(doubleClicked()), this, SLOT(onNameDoubleClicked()));

    le_name = new QLineEdit (this);
    le_name->setObjectName("Edit");
    connect(le_name, SIGNAL(returnPressed()), this, SLOT(onNameChanged()));
    le_name->hide();

    pb_delete = new PushButton (this);
    pb_delete->setObjectName("Delete");
    pb_delete->setFixedSize(24, 24);
    connect(pb_delete, SIGNAL(sure()), this, SLOT(onCategoryDelete()));

    updateData();

    layout = new QHBoxLayout (this);
    layout->addWidget(pb_name);
    layout->addWidget(pb_delete);
    setLayout(layout);
}

void CategoryView::editCanceled(EditableElement element)
{
    switch(element)
    {
        case EditableElement::Name:
            le_name->setText(pb_name->text());

            layout->replaceWidget(le_name, pb_name);

            le_name->hide();
            pb_name->show();

            pb_name->setFocus();
            break;

        case EditableElement::Code:
        case EditableElement::BaseUSD:
        case EditableElement::VAT:
        case EditableElement::Charge:
        case EditableElement::Default:
            break;
    }

}

void CategoryView::onCategoryClicked()
{
    emit categoryClicked(pb_name->text());
}

void CategoryView::onNameDoubleClicked()
{
    layout->replaceWidget(pb_name, le_name);

    pb_name->hide();
    le_name->show();

    le_name->setFocus();
}

void CategoryView::onNameChanged()
{
    QString old_name = pb_name->text();
    QString new_name = le_name->text();

    if (new_name != "" && new_name != old_name)
    {
        emit categoryChanged(pb_name->text(), le_name->text());

        category->setName(new_name);
        pb_name->setText(category->getName());
    }

    layout->replaceWidget(le_name, pb_name);

    le_name->hide();
    pb_name->show();

    pb_name->setFocus();
}

void CategoryView::onCategoryDelete()
{
    qDebug() << "in CategoryView::onCategoryDelete";

    emit categoryDelete(category);

    qDebug() << "after CategoryView::onCategoryDelete";
}
