#ifndef FINANCEDATA_H
#define FINANCEDATA_H

#include <QDateTime>

#include "currency.h"

class FinanceData
{
public:
    FinanceData();
    FinanceData(const QDateTime&, Currency, Currency);

    // shows when this block of data was grabbed
    const QDateTime& getDatetime();
    void setDatetime (const QDateTime&);

    // allows to set and get any type of prices
    Currency getBuyingPrice();
    void setBuyingPrice(Currency);

    Currency getSellingPrice();
    void setSellingPrice(Currency);

    Currency getCurrentPrice();
    void setCurrentPrice(Currency);

    // allows to store and get available banks or prices types
    const QStringList& getBanks();
    void addBank(const QString&);

    const QStringList& getPrices();
    void addPrice(const QString&);

    // helper functions that allow to update the data appropriately
    Currency getDefaultPrice();
    QString getDefaultBank();

    const QString& getBank();
    void setBank (const QString&);

    const QString& getPreviousBank();
    void storePreviousBank ();

    friend QDataStream& operator<< (QDataStream&, const FinanceData&);
    friend QDataStream& operator>> (QDataStream&, FinanceData&);

private:
    void fillPrices();

    QDateTime datetime;
    Currency buying_price;
    Currency selling_price;
    Currency current_price;
    QString bank, prev_bank;
    QStringList banks, prices;
};



#endif // FINANCEDATA_H
