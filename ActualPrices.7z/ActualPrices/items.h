#ifndef ITEMS_H
#define ITEMS_H

#include "item.h"
#include "itemview.h"
#include "categories.h"
#include "category.h"
#include "currency.h"

#include <QList>

class Items
{
public:
    Items();
    ~Items();

    Item* createItem(const Category& category, const QString& code, const QString& name, const Currency& baseUSD, int vat, int charge);
    Item* createItem(const Item& rhs);

    int getSize ();
    bool isEmpty ();

    const QStringList& getUniqueCategories();

    int indexOf (Item* item);
    Item *getItemAt (int index);
    ItemView *getItemViewAt (int index);

    void removeItemAt (int index);
    void removeItemViewAt (int index);

    void removeOneItem (Item* item);
    void removeOneItemView (ItemView* view);

private:
    void replaceItemAt (int index, Item* item);
    void replaceItemViewAt (int index, ItemView* view);    

    bool addItem (Item* item);

    QList<Item*> items;
    QList<ItemView*> views;
    QStringList categories;
};

#endif // ITEMS_H
