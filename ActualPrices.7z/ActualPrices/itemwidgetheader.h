#ifndef ITEMWIDGETHEADER_H
#define ITEMWIDGETHEADER_H

#include <QFrame>
#include <QPushButton>
#include <QHBoxLayout>

class ItemWidgetHeader : public QFrame
{
    Q_OBJECT
public:
    ItemWidgetHeader(QWidget *parent = nullptr);
    ~ItemWidgetHeader();

    QPushButton *vatButton();
    QPushButton *withVatButton();

private:
    void makeGUI();

    QPushButton *pb_code;
    QPushButton *pb_name;
    QPushButton *pb_baseUSD;
    QPushButton *pb_baseUAH;
    QPushButton *pb_VAT;
    QPushButton *pb_VATprice;
    QPushButton *pb_charge;
    QPushButton *pb_ACTprice;
    QPushButton *pb_blank1;
    QPushButton *pb_blank2;

    QHBoxLayout* layout;

signals:

public slots:

};

#endif // ITEMWIDGETHEADER_H
