﻿#ifndef FINANCE_H
#define FINANCE_H

// to download the xml file from web repository
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>

// to work with files
#include <QFile>
#include <QFileInfo>

// to work with XML
#include <QtXml/QDomDocument>
#include <QtXml/QDomNodeList>
#include <QtXml/QDomNode>

// data
#include "currency.h"
#include "financedata.h"

enum PriceType
{
    Current = 0,
    Buying = 1,
    Selling = 2,
    Medium = 3,
    Default = 4
};

class Finance : public QObject
{
    Q_OBJECT

public:
    Finance();
    ~Finance();

    void getXML();
    void update();

    void SaveData(const QString& filename);
    void LoadData(const QString& filename);        

    const QStringList& getBanks ();
    const QStringList& getPrices ();

    const QString& getBank ();
    void setBank(const QString&);

    Currency getPrice(PriceType price);
    void setCurrentPrice(PriceType price);

private:
    QString getFilename (const QUrl&);
    QFile* grabFile (QNetworkReply*);
    bool isRedirect (QNetworkReply*);

    bool needsUpdate();
    void grabData();

    bool isValid();

    // to grab data from network page
    QNetworkAccessManager *manager;
    QNetworkReply *reply;
    QUrl url;

    // for save-load functions
    QFile *file;

    // to save grabbed data and to parse the document
    QDomDocument document; 
    FinanceData data;
    bool valid;

public slots:
    void onFinished(QNetworkReply*);
};

#endif // FINANCE_H
