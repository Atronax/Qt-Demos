#include "currency.h"

#include <QDataStream>
#include <QDebug>

Currency::Currency()
{
    name = "";
    upperPart = 0;
    lowerPart = 0;
}

Currency::Currency(const QString& name, int upperPart, int lowerPart)
{
    if (upperPart >= 0 && lowerPart >= 0)
    {
        this->name = name;
        this->upperPart = upperPart;
        this->lowerPart = lowerPart;
        calculateFromLP(this->upperPart, this->lowerPart);
    }
    else
        qDebug("Currency constructor error");
}

int Currency::getUpperPart()
{
    return upperPart;
}

int Currency::getLowerPart()
{
    return lowerPart;
}

const QString &Currency::getName()
{
    return name;
}

void Currency::setUpperPart(int upperPart)
{
    this->upperPart = upperPart;
    if (upperPart < 0)
        name += " - debt";
}

void Currency::setLowerPart(int lowerPart)
{
    this->lowerPart = lowerPart;
    if (lowerPart >= 100 || lowerPart <= -100)
        calculateFromLP(this->upperPart, this->lowerPart);

    if (lowerPart < 0)
        name += " - debt";

}

void Currency::setName(const QString &name)
{
    this->name = name;
    qDebug() << name;
}

Currency Currency::operator=(const Currency &rhs)
{
    this->name = rhs.name;
    this->upperPart = rhs.upperPart;
    this->lowerPart = rhs.lowerPart;

    return *this;
}

Currency Currency::operator+(const Currency &rhs)
{
    Currency result;

    if (name == rhs.name)
    {
        int up = this->upperPart + rhs.upperPart;
        int lp = this->lowerPart + rhs.lowerPart;

        result.setUpperPart(up);
        result.setLowerPart(lp);
        result.setName(name);
    }

    return result;
}

Currency Currency::operator+=(const Currency &rhs)
{
    Currency result = *this + rhs;

    return result;
}

Currency Currency::operator-(const Currency &rhs)
{
    Currency result;

    if (name == rhs.name)
    {
        int up = this->upperPart - rhs.upperPart;
        int lp = this->lowerPart - rhs.lowerPart;

        result.setUpperPart(up);
        result.setLowerPart(lp);
        result.setName(name);
    }

    return result;
}

Currency Currency::operator*(const Currency &rhs)
{
    Currency result;
    Currency rhs_cp = rhs;

    int lp = this->asLowerPart() * rhs_cp.asLowerPart() / 100;
    result.setLowerPart(lp);
    result.setName(rhs.name);
    qDebug() << rhs.name << ":" << result.getName();

    return result;
}

Currency Currency::operator*(int percentage)
{
    Currency result;

    int lp = this->asLowerPart();
    lp *= percentage / 100.0f;
    result.setLowerPart((lp));
    result.setName(name);

    return result;
}

Currency Currency::operator/(const Currency &rhs)
{
    Currency result;
    Currency rhs_cp = rhs;

    int lp_lhs = this->asLowerPart();
    int lp_rhs = rhs_cp.asLowerPart();
    int lp_res = lp_lhs / lp_rhs;
    result.setLowerPart(lp_res);
    result.setName("*");

    return result;
}

Currency Currency::operator/(int divisor)
{
    Currency result;

    int lp_lhs = this->asLowerPart();
    int lp_rhs = divisor;
    int lp_res = lp_lhs / lp_rhs;
    result.setLowerPart(lp_res);
    result.setName(name);

    return result;
}

bool Currency::operator==(const Currency &rhs)
{
    bool result = false;

    if (this->upperPart == rhs.upperPart && this->lowerPart == rhs.lowerPart)
        result = true;

    return result;
}

bool Currency::operator!=(const Currency &rhs)
{
    bool result = false;

    if (this->upperPart != rhs.upperPart || this->lowerPart != rhs.lowerPart)
        result = true;

    return result;
}

bool Currency::operator<(const Currency &rhs)
{
    bool result = false;

    if (this->upperPart < rhs.upperPart || (this->upperPart == rhs.upperPart && this->lowerPart < rhs.lowerPart))
        result = true;

    return result;
}

int Currency::asLowerPart()
{
    return upperPart * 100 + lowerPart;
}

QString Currency::toString()
{
    QString result = QString::number(upperPart) + ".";
    if (lowerPart < 10)
        result += "0" + QString::number(lowerPart);
    else
        result += QString::number(lowerPart);
    result += name;

    return result;
}

void Currency::calculateFromLP(int& upperPart, int& lowerPart)
{
    if (lowerPart >= 100)
    {
        int toAdd = lowerPart / 100;
        lowerPart %= 100;
        setUpperPart(upperPart + toAdd);
    }
    else if (lowerPart <= -100)
    {
        lowerPart = abs(lowerPart);
        int toSubstract = lowerPart / 100;
        lowerPart %= 100;
        setUpperPart(upperPart - toSubstract);
    }
}

void Currency::calculateFromUP(int &upperPart, int &lowerPart)
{
    lowerPart += upperPart * 100;
}

// input-output
QDataStream& operator<< (QDataStream &out, const Currency& from)
{
    out << from.name << from.upperPart << from.lowerPart;

    return out;
}

QDataStream& operator>> (QDataStream &in, Currency& to)
{
    QString name;
    int up;
    int lp;

    in >> name >> up >> lp;
    to.setName(name);
    to.setUpperPart(up);
    to.setLowerPart(lp);

    return in;
}
