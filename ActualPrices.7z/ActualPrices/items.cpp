#include "items.h"

#include <QDebug>

Items::Items()
{
    categories.append("Всё");    
}

Items::~Items()
{
    qDebug() << "in Items destructor";

    if (!items.isEmpty())
    {
        for (int i = 0; i < items.size(); ++i)
            views.at(i)->deleteLater();        

        items.clear();
        views.clear();
    }

    qDebug() << "after Items destructor";
}

Item* Items::createItem(const Category &category, const QString &code, const QString &name, const Currency &baseUSD, int vat, int charge)
{
    Item *item = new Item(category, code, name, baseUSD, vat, charge);

    bool success = addItem(item);
    if (!success)
    {
        delete item;
        item = nullptr;
    }

    qDebug() << "item is nullptr (COPY)";

    return item;
}

Item* Items::createItem(const Item &rhs)
{
    Item *item = new Item(rhs);

    bool success = addItem(item);
    if (!success)
    {
        delete item;
        item = nullptr;
    }

    return item;
}

int Items::getSize()
{
    return items.size();
}

bool Items::isEmpty()
{
    return items.isEmpty();
}

int Items::indexOf(Item *item)
{
    return items.indexOf(item);
}

Item *Items::getItemAt(int index)
{
    if (index >= 0 && index < items.size())
        return items.at(index);
    else
        return nullptr;
}

ItemView *Items::getItemViewAt(int index)
{
    if (index >= 0 && index < views.size())
        return views.at(index);
    else
        return nullptr;
}

const QStringList& Items::getUniqueCategories()
{
    return categories;
}

void Items::removeOneItem(Item *item)
{
    items.removeOne(item);
}

void Items::removeOneItemView(ItemView *view)
{
    views.removeOne(view);
}

void Items::removeItemAt(int index)
{
    if (index >= 0 && index < items.size())
        items.removeAt(index);
}

void Items::removeItemViewAt(int index)
{
    if (index >= 0 && index < views.size())
        views.removeAt(index);
}

void Items::replaceItemAt(int index, Item *new_item)
{
    if (index >= 0 && index < items.size())
        items.replace(index, new_item);
}

void Items::replaceItemViewAt(int index, ItemView *new_view)
{
    if (index >= 0 && index < views.size())
        views.replace(index, new_view);
}

bool Items::addItem(Item *item)
{
    bool result = false;

    // check if this item is unique
    bool itemUnique = true;
    for (int i = 0; i < items.size(); ++i)
        if (*items.at(i) == *item)
            itemUnique = false;

    // check if corresponding category is unique
    bool categoryUnique = true;
    Category category = item->getCategory();
    for (int j = 0; j < categories.size(); ++j)
        if (categories.at(j) == category.getName())
            categoryUnique = false;


    // if we have blank item or it is unique - add item and its view to lists
    if (item->isEmpty() || itemUnique)
    {        
        ItemView* view = new ItemView(item);

        items.append(item);
        views.append(view);

        // store unique category names
        if (categoryUnique)
            categories.append(category.getName());

        // we have added new item successfully, so the result is true
        result = true;
    }

    return result;
}
