#include "item.h"

#include <QDebug>
#include <QDataStream>

Item::Item()
{
    category = Category();
    code = "default code";
    name = "default name";
    baseUSD = Currency("USD", 0, 0);
    baseUAH = Currency("UAH", 0, 0);
    vat = 0;
    withVATPrice = Currency("UAH", 0, 0);
    charge = 0.0f;
    actualPrice = Currency("UAH", 0, 0);
}

Item::Item(const Category &category, const QString &code, const QString &name, const Currency& baseUSD, int vat, int percentage)
{
    this->category = category;
    this->code = code;
    this->name = name;
    this->baseUSD = baseUSD;
    this->baseUAH = Currency("UAH", 0, 0);
    this->vat = vat;
    this->withVATPrice = Currency("UAH", 0, 0);
    this->charge = percentage;
    this->actualPrice = Currency("UAH", 0, 0);
}

Category Item::getCategory() const
{
    return category;
}

const QString &Item::getCode() const
{
    return code;
}

const QString &Item::getName() const
{
    return name;
}

Currency Item::getBaseUSD()
{
    return baseUSD;
}

Currency Item::getBaseUAH()
{
    return baseUAH;
}

Currency Item::getWithVATPrice()
{
    return withVATPrice;
}

Currency Item::getActualPrice()
{
    return actualPrice;
}

int Item::getVAT()
{
    return vat;
}

int Item::getCharge()
{
    return charge;
}

void Item::setCategory(const Category &input)
{
    category = input;
}

void Item::setCode(const QString &input)
{
    code = input;
}

void Item::setName(const QString &input)
{
    name = input;
}

void Item::setBaseUSD(const Currency& input)
{
    baseUSD = input;
}

void Item::setVAT(int input)
{
    if (input >= 0)
        vat = input;
}

void Item::setCharge(int input)
{
    charge = input;
    if (charge < 0)
        name += " - Discount";
}

void Item::calculateBaseUAH(const Currency& priceUSD)
{
    baseUAH = baseUSD * priceUSD;
}

void Item::calculateWithVATPrice()
{
    withVATPrice = baseUAH + baseUAH * vat;
}

void Item::calculateActualPrice()
{
    // ?? уточнить: наценка идет от *базовой цены* или от *базовой цены + ПДВ* ??
    actualPrice = withVATPrice + withVATPrice * charge;
}

bool Item::isEmpty()
{
    bool result = false;

    if (code == "default code" && name == "default name" && baseUSD == Currency("USD", 0, 0) && charge == 0)
        result = true;

    return result;
}

QString Item::toString()
{
    QString result = category.toString() + "-" +
                     code + "-" +
                     name + "-" +
                     baseUSD.toString() + "-" +
                     baseUAH.toString() + "-" +
                     QString::number(vat) + "%" + "-" +
                     QString::number(charge) + "%" + "-" +
                     actualPrice.toString();

    return result;
}

Item Item::operator=(const Item &rhs)
{
    this->category = rhs.category;
    this->code = rhs.code;
    this->name = rhs.name;
    this->baseUSD = rhs.baseUSD;
    this->baseUAH = rhs.baseUAH;
    this->vat = rhs.vat;
    this->charge = rhs.charge;
    this->actualPrice = rhs.actualPrice;

    return *this;
}

bool Item::operator==(const Item &rhs)
{
    if (this->code == rhs.code && this->name == rhs.name)
        return true;
    else
        return false;
}

bool Item::operator!=(const Item &rhs)
{
    if (this->code != rhs.code && this->name != rhs.name)
        return true;
    else
        return false;
}

bool Item::operator<(const Item &rhs)
{
    if (this->name < rhs.name)
        return true;
    else
        return false;
}

// input-output
QDataStream& operator<< (QDataStream &out, const Item& from)
{
    qDebug() << "Saving: " << from.name;

    out << from.category << from.code << from.name << from.baseUSD << from.vat << from.charge;

    return out;
}

QDataStream& operator>> (QDataStream &in, Item& to)
{
    Category category;
    QString code;
    QString name;
    Currency baseUSD;
    int vat;
    int percentage;

    in >> category >> code >> name >> baseUSD >> vat >> percentage;

    to.setCategory(category);
    to.setCode(code);
    to.setName(name);
    to.setBaseUSD(baseUSD);
    to.setVAT(vat);
    to.setCharge(percentage);

    return in;
}
