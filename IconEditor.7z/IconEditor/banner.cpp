// LOGIC
#include <QPainter>
#include <QTimerEvent>

#include "banner.h"

void Banner::setText(const QString &new_text)
{
    current_text = new_text;

    update();
    updateGeometry();
}

QString Banner::getText() const
{
    return current_text;
}

void Banner::changeFont(const QFont &new_font, const QBrush &new_font_color)
{
    if (font() != new_font)
        setFont(new_font);

    if (palette().foreground() != new_font_color)
    {
        QPalette pal = palette();
        pal.setBrush(QPalette::Foreground, new_font_color);
        setPalette(pal);
    }
}

void Banner::changeBackground(const QBrush &new_background)
{
    if (palette().background() != new_background)
    {
        QPalette pal = palette();
        pal.setBrush(QPalette::Background, new_background);
        setPalette(pal);
    }
}

QSize Banner::sizeHint() const
{
    return fontMetrics().size(0, getText()); // returns size of the text in the widget
}

void Banner::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED(ev);

    QPainter painter(this);

    int text_width = fontMetrics().width(getText());
    if (text_width < 1)
        return;

    int x = -offset;
    while (x < width())
    {
        painter.drawText(x, 0, text_width, height(), Qt::AlignLeft | Qt::AlignVCenter, getText());
        x += text_width;
    }
}

void Banner::showEvent(QShowEvent *ev)
{
    Q_UNUSED(ev);

    timerID = startTimer(30);
}

void Banner::timerEvent(QTimerEvent *ev)
{
    if (ev->timerId() == timerID)
    {
        ++offset;
        if (offset >= fontMetrics().width(getText()))
            offset = 0;
        scroll(-1, 0);
    }
    else
        QWidget::timerEvent(ev);
}

void Banner::hideEvent(QHideEvent *ev)
{
    Q_UNUSED(ev);

    killTimer(timerID);
    timerID = 0;
}
