// LOGIC
#include <QtMath>

#include "plotsettings.h"

void PlotSettings::scroll(int dx, int dy)
{
    double stepX = spanX() / ticksX;
    minX += dx*stepX;
    maxX += dx*stepX;

    double stepY = spanY() / ticksY;
    minY += dy*stepY;
    maxY += dy*stepY;
}

void PlotSettings::adjust()
{
    adjustAxis(minX, maxX, ticksX);
    adjustAxis(minY, maxY, ticksY);
}

void PlotSettings::adjustAxis(double &min_value, double &max_value, int &num_ticks)
{
    const int min_ticks = 4;
    double gross_step = (max_value - min_value) / min_ticks;
    double step = std::pow(10.0, std::floor(std::log10(gross_step)));

    if (5*step < gross_step)
        step *= 5;
    else if (2*step < gross_step)
        step *= 2;

    num_ticks = int (std::ceil(max_value/step) - std::floor(min_value/step));
    if (num_ticks < min_ticks)
        num_ticks = min_ticks;

    min_value = std::floor(min_value/step)*step;
    max_value = std::ceil(max_value/step)*step;
}

double PlotSettings::spanX() const
{
    return maxX - minX;
}

double PlotSettings::spanY() const
{
    return maxY - minY;
}
