#ifndef PLOTSETTINGS_H
#define PLOTSETTINGS_H

class PlotSettings
{
public:
    PlotSettings()
    {
        minX = minY = -10.0f;
        maxX = maxY =  10.0f;
        ticksX = ticksY = 20;
    }

    ~PlotSettings()
    {

    }

    void scroll (int dx, int dy);
    void adjust ();

    double spanX() const;
    double spanY() const;

    double minX, maxX, minY, maxY;
    int ticksX, ticksY;

private:
    static void adjustAxis (double &min_value, double &max_value, int &num_ticks);
};

#endif // PLOTSETTINGS_H
