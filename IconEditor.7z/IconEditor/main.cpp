#include <QApplication>

#include "drawint.h"
#include "plotter.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);
    app.setWindowIcon(QIcon(":/images/icon.png"));

    Drawint* drawint = new Drawint;
    drawint->show();


    QVector<QPointF> curve1, curve2, curve3, curve4, curve5;

    for (float x = -10.0; x < 10.0; x += 0.1)
    {
        curve1.append(QPointF(x, std::sin(x)));
        curve2.append(QPointF(x, std::cos(x)));
        curve3.append(QPointF(x, std::pow(x,3)));
        curve4.append(QPointF(x, std::pow(x,2)));
        curve5.append(QPointF(x, std::sqrt(100 - x*x)));

    }

    Plotter plotter;
    plotter.setCurveData(1, curve1);
    plotter.setCurveData(2, curve2);
    plotter.setCurveData(3, curve3);
    plotter.setCurveData(4, curve4);
    plotter.setCurveData(5, curve5);
    plotter.show();


    return app.exec();
}
