#ifndef DRAWINT_H
#define DRAWINT_H

// LOGIC
#include <QAction>
#include <QColor>
#include <QKeyEvent>
#include <QScrollArea>
#include <QFileDialog>
#include <QFormLayout>
#include <QRegExpValidator>

// WIDGETS
#include <QMainWindow>
#include <QColorDialog>
#include <QDialog>
#include <QMenuBar>
#include <QMenu>
#include <QStatusBar>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QLineEdit>

#include "banner.h"

#include "picture_editor.h"

class Drawint : public QMainWindow
{
    Q_OBJECT
public:
    explicit Drawint(QWidget *parent = 0)
        : QMainWindow (parent)
    {
        createCentralWidget();
        createActions();
        createMenus();
        createStatusbar();
    }

    virtual ~Drawint()
    {

    }

protected:
    virtual void keyPressEvent(QKeyEvent* ev);

private:
    void createCentralWidget();
    void createActions();
    void createMenus();
    void createStatusbar();

    QScrollArea *sa_pic_editor;
    PictureEditor *pic_editor;

    // Help menu
    QMenu *menu_help;
    QAction *act_help;

    // Status bar
    QLabel *lbl_imagesize, *lbl_zoomfactor;

signals:

public slots:
    void onHelp ();
    void updateZoomfactorLabel (const int&);
    void updateImagesizeLabel (const QSize&);
};

#endif // DRAWINT_H
