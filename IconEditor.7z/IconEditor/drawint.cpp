#include "drawint.h"

void Drawint::createCentralWidget()
{
    pic_editor = new PictureEditor;
    sa_pic_editor = new QScrollArea;
    sa_pic_editor->setWidget(pic_editor);
    sa_pic_editor->setWidgetResizable(true); // allows inner widget to call resize event handler
    sa_pic_editor->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    sa_pic_editor->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    setCentralWidget(sa_pic_editor);
}

void Drawint::createActions()
{
    act_help = new QAction (tr("Команды для управления программой"), this);
    act_help->setIcon(QIcon(":/images/help.png"));
    act_help->setShortcut(tr("Ctrl+H"));
    act_help->setStatusTip(tr("Узнать наборы быстрых клавиш для управления программой"));
    connect(act_help, SIGNAL(triggered()), this, SLOT(onHelp()));
}

void Drawint::createMenus()
{
    menu_help = menuBar()->addMenu(tr("Помощь"));
    menu_help->addAction(act_help);
}

void Drawint::createStatusbar()
{
    lbl_imagesize = new QLabel(tr("Ширина: 30. Высота: 30."));
    connect (pic_editor, SIGNAL(signalImageSizeChanged(const QSize&)), this, SLOT(updateImagesizeLabel(const QSize&)));

    lbl_zoomfactor = new QLabel(tr("Уровень приближения: 100%."));
    connect (pic_editor, SIGNAL(signalZoomFactorChanged(const int&)), this, SLOT(updateZoomfactorLabel(const int&)));

    Banner *RSS = new Banner ("*  Drawint - исскуство своими руками  *", this);
    RSS->changeFont(QFont("Arial", 20, 10, true), QBrush(Qt::darkMagenta));
    // RSS->changeBackground(QBrush(Qt::black, Qt::Dense4Pattern));

    statusBar()->addWidget(lbl_imagesize);
    statusBar()->addWidget(lbl_zoomfactor);
    statusBar()->addWidget(RSS);
}

void Drawint::updateImagesizeLabel(const QSize &new_size)
{
    lbl_imagesize->setText("Ширина: " + QString::number(new_size.width()) + ". Высота: " + QString::number(new_size.height()) + ".");
    statusBar()->update();
}

void Drawint::updateZoomfactorLabel(const int &new_value)
{
    lbl_zoomfactor->setText("Уровень приближения: " + QString::number(new_value*100) + "%.");
    statusBar()->update();
}

// EVENTS
void Drawint::keyPressEvent(QKeyEvent *ev)
{
    if (ev->modifiers() & Qt::ShiftModifier)
    {
        if (ev->key() == Qt::Key_Plus)
            pic_editor->setImageSize(QSize(pic_editor->getImageSize().width() + 1, pic_editor->getImageSize().height()));

        if (ev->key() == Qt::Key_Minus && pic_editor->getImageSize().width() > 1)
            pic_editor->setImageSize(QSize(pic_editor->getImageSize().width() - 1, pic_editor->getImageSize().height()));
    }
    else if (ev->modifiers() & Qt::ControlModifier)
    {
        if (ev->key() == Qt::Key_Plus)
            pic_editor->setImageSize(QSize(pic_editor->getImageSize().width(), pic_editor->getImageSize().height() + 1));

        if (ev->key() == Qt::Key_Minus && pic_editor->getImageSize().height() > 1)
            pic_editor->setImageSize(QSize(pic_editor->getImageSize().width(), pic_editor->getImageSize().height() - 1));

        if (ev->key() == Qt::Key_S)
        {
            QString filename = QFileDialog::getSaveFileName(this, QString(), QString(), tr("Портативная сетевая графика (*.png)"));
            pic_editor->getImage().save(filename);
        }

        if (ev->key() == Qt::Key_L)
        {
            QString filename = QFileDialog::getOpenFileName(this, QString(), QString(), tr("Все графические форматы (*.jpg *.png)"));
            pic_editor->setImage(QImage(filename));
        }
    }
    else // if (ev->modifiers() == Qt::NoModifier)
    {
        if (ev->key() == Qt::Key_Plus)
            pic_editor->setZoomFactor(pic_editor->getZoomFactor() + 1);

        if (ev->key() == Qt::Key_Minus)
            pic_editor->setZoomFactor(pic_editor->getZoomFactor() - 1);

        if (ev->key() == Qt::Key_C)
            pic_editor->setPenColor(QColorDialog::getColor());

        if (ev->key() == Qt::Key_G)
            pic_editor->toggleGrid();
    }
}

// SLOTS
void Drawint::onHelp()
{
    QMessageBox::information(this,
                             tr("Команды управления Drawint: \n\n"),
                             tr("2. Изменение масштаба - '+' и '-'. \n" \
                                "3. Управление размерами изображения: \n" \
                                "  a) Изменение ширины - '+' и '-' с модификатором Shift \n" \
                                "  б) Изменение высоты - '+' и '-' с модификатором Control \n" \
                                "4. Выбор цвета - 'c' \n" \
                                "5. Изменение режима отображения сетки - 'g' \n" \
                                "6. Управление файлами изображений: \n" \
                                "  а) Сохранение изображения - 'Ctrl+S' \n" \
                                "  б) Загрузка изображения - 'Ctrl+L' \n"),
                             QMessageBox::Ok);
}
