#ifndef BANNER_H
#define BANNER_H

#include <QWidget>

class Banner : public QWidget
{
    Q_OBJECT

    Q_PROPERTY (QString text READ getText WRITE setText NOTIFY signalTextChanged)
public:
    explicit Banner(const QString& initial_string, QWidget *parent = 0)
        : QWidget (parent),
          current_text (initial_string)
    {
        offset = 0;
        timerID = 0;
    }

    ~Banner()
    {

    }

    // 1. Text Manipulation
    QString getText () const;
    void setText (const QString& new_text);

    // 2. View Manipulation
    void changeFont (const QFont &new_font, const QBrush &new_font_color);
    void changeBackground (const QBrush &new_background);



protected:
    QSize sizeHint() const;

    void showEvent(QShowEvent *ev);
    void hideEvent(QHideEvent *ev);
    void paintEvent(QPaintEvent *ev);
    void timerEvent(QTimerEvent *ev);

private:
    QString current_text;
    int offset;
    int timerID;

signals:
    void signalTextChanged(const QString& new_string);

public slots:
};

#endif // BANNER_H
