// LOGIC
#include <QPaintEvent>
#include <QPainter>

#include <QMouseEvent>
#include <QKeyEvent>

// WIDGETS
#include <QDialog>
#include <QLineEdit>

#include "picture_editor.h"

// GETTERS and SETTERS
QColor PictureEditor::getPenColor() const
{
    return current_color;
}

QImage PictureEditor::getImage() const
{
    return current_image;
}

QSize PictureEditor::getImageSize() const
{
    return current_image_size;
}


int PictureEditor::getZoomFactor() const
{
    return current_zoom_factor;
}

void PictureEditor::setPenColor(const QColor &what)
{
    current_color = what;
}

void PictureEditor::setImage(const QImage &what)
{
    if (current_image != what)
    {        
        current_image = what.convertToFormat(QImage::Format_ARGB32);

        update();
        updateGeometry();

        current_image_size = what.size();
        emit signalImageSizeChanged(what.size());
    }
}

void PictureEditor::setImageSize(const QSize &what)
{
    if (current_image_size != what)
    {
        current_image_size = what;
        current_image = current_image.scaled(current_image_size);

        update();
        updateGeometry();

        emit signalImageSizeChanged(what);
    }
}

void PictureEditor::setZoomFactor(int what)
{
    if (what < 1)
        what = 1;

    if (current_zoom_factor != what)
    {
        current_zoom_factor = what;

        update();
        updateGeometry();
    }

    emit signalZoomFactorChanged(what);
}

void PictureEditor::toggleGrid()
{
    show_grid = !show_grid;

    update();
    updateGeometry();
}

// OVERRIDES
QSize PictureEditor::sizeHint() const
{
    return current_zoom_factor * current_image.size();
}

void PictureEditor::paintEvent(QPaintEvent *ev)
{
    QPainter painter (this);

    if (show_grid && current_zoom_factor >= 3)
    {
        painter.setPen(palette().foreground().color());

        for (int i = 0; i <= current_image.width(); ++i)
            painter.drawLine(current_zoom_factor * i, 0,
                             current_zoom_factor * i, current_zoom_factor * current_image.height());

        for (int j = 0; j <= current_image.height(); ++j)
            painter.drawLine(0, current_zoom_factor * j,
                             current_zoom_factor * current_image.width(), current_zoom_factor * j);
    }

    for (int i = 0; i < current_image.width(); ++i)
        for (int j = 0; j < current_image.height(); ++j)
        {
            QRect rect = pixelRect(i, j);

            if (ev->region().intersects(rect))
            {
                QColor color = QColor::fromRgba(current_image.pixel(i, j));

                if (color.alpha() < 255)
                    painter.fillRect(rect, Qt::white);

                painter.fillRect(rect, color);
            }
        }
}

void PictureEditor::mousePressEvent(QMouseEvent *ev)
{
    if (ev->button() == Qt::LeftButton)
        setImagePixel(ev->pos(), true);

    if (ev->button() == Qt::RightButton)
        setImagePixel(ev->pos(), false);
}

void PictureEditor::mouseMoveEvent(QMouseEvent *ev)
{
    if (ev->buttons() & Qt::LeftButton)
        setImagePixel(ev->pos(), true);

    if (ev->buttons() & Qt::RightButton)
        setImagePixel(ev->pos(), false);
}

// PRIVATE FUNCTIONS
QRect PictureEditor::pixelRect(int i, int j) const
{
    if (current_zoom_factor >= 3)
        return QRect (current_zoom_factor * i + 1, current_zoom_factor * j + 1,
                      current_zoom_factor - 1, current_zoom_factor - 1);
    else
        return QRect (current_zoom_factor * i, current_zoom_factor * j,
                      current_zoom_factor, current_zoom_factor);
}

void PictureEditor::setImagePixel(const QPoint &ptPosition, bool bOpaque)
{
    int i = ptPosition.x() / current_zoom_factor;
    int j = ptPosition.y() / current_zoom_factor;

    if (current_image.rect().contains(i, j))
    {
        if (bOpaque)
            current_image.setPixel(i, j, getPenColor().rgba());
        else
            current_image.setPixel(i, j, qRgba(0, 0, 0, 0));
    }

    update (pixelRect(i, j));
}
