#ifndef PLOTTER_H
#define PLOTTER_H

#include <QMap>
#include <QPixmap>
#include <QVector>
#include <QWidget>
#include <QScrollArea>

#include "plotsettings.h"

class QToolButton;

class Plotter : public QWidget
{
    Q_OBJECT
public:
    explicit Plotter(QWidget *parent = 0)
        :QWidget(parent)
    {
        adjustWindow();
        initUserInterface();
        initPlotterSettings();
    }

    ~Plotter()
    {

    }

    void setPlotSettings (const PlotSettings& settings); // strategy pattern
    void setCurveData (int id, const QVector<QPointF>& data);
    void clearCurve (int id);

    QSize minimumSizeHint() const;
    QSize sizeHint() const;

protected:
    void paintEvent(QPaintEvent *ev);
    void resizeEvent(QResizeEvent *ev);

    void keyPressEvent(QKeyEvent *ev);
    void mousePressEvent(QMouseEvent *ev);
    void mouseMoveEvent(QMouseEvent *ev);
    void mouseReleaseEvent(QMouseEvent *ev);
    void wheelEvent(QWheelEvent *ev);

private:
    void adjustWindow ();
    void initPlotterSettings ();
    void initUserInterface ();

    void drawGrid (QPainter* painter);
    void drawCurves (QPainter* painter);
    void updateRubberBandRegion ();
    void refreshPixmap ();

    enum class Constants {Margin = 50, ZoomoutFactor = 2};

    QPixmap pixmap;
    QMap<int, QVector<QPointF>> curves;
    QVector<PlotSettings> zoom_stack;
    int current_zoom;

    bool rubberband_isShown;
    QRect rubberband_rect;

    QToolButton *tb_zoomIn, *tb_zoomOut;

signals:

public slots:
    void zoomIn();
    void zoomOut();
};

#endif // PLOTTER_H
