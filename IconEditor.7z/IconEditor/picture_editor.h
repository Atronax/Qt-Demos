#ifndef PICTUREEDITOR_H
#define PICTUREEDITOR_H

#include <QColor>
#include <QImage>
#include <QWidget>

class PictureEditor : public QWidget
{
    Q_OBJECT

    Q_PROPERTY(QColor PenColor READ getPenColor WRITE setPenColor NOTIFY signalPenColorChanged)
    Q_PROPERTY(QImage Image READ getImage WRITE setImage NOTIFY signalImageChanged)
    Q_PROPERTY(int iZoomFactor READ getZoomFactor WRITE setZoomFactor NOTIFY signalZoomFactorChanged)
    Q_PROPERTY(QSize ImageSize READ getImageSize WRITE setImageSize NOTIFY signalImageSizeChanged)

public:
    explicit PictureEditor(QWidget *parent = 0) : QWidget (parent)
    {
        setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        setAttribute(Qt::WA_StaticContents);

        current_color = Qt::red;
        current_image_size = QSize (30, 30);
        current_image = QImage(current_image_size, QImage::Format_ARGB32);
        current_zoom_factor = 5;
        show_grid = true;
    }

    virtual ~PictureEditor()
    {

    }

    // functions to read from and write to properties
    // 1. Pen Color:
    QColor getPenColor () const;
    void setPenColor (const QColor& what);

    // 2. Image:
    QImage getImage () const;
    void setImage (const QImage& what);

    // 3. Icon Image Size:
    QSize getImageSize () const;
    void setImageSize (const QSize& what);

    // 4. Zoom Factor:
    int getZoomFactor () const;
    void setZoomFactor (int what);

    // 5. Grid Control:
    void toggleGrid ();

protected:
    virtual QSize sizeHint () const;

    virtual void paintEvent (QPaintEvent *ev);

    virtual void mouseMoveEvent(QMouseEvent* ev);
    virtual void mousePressEvent(QMouseEvent* ev);

private:
    void setImagePixel (const QPoint& ptPosition, bool bOpaque);
    QRect pixelRect (int i, int j) const;

    QColor current_color;
    QImage current_image;
    QSize current_image_size;
    int current_zoom_factor;

    bool show_grid;

signals:
    void signalPenColorChanged (const QColor&);
    void signalImageChanged (const QImage&);
    void signalZoomFactorChanged (const int&);
    void signalImageSizeChanged (const QSize&);

public slots:

};

#endif // PICTUREEDITOR_H
