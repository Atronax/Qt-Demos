// LOGIC
#include <QStylePainter>
#include <QStyleOptionFocusRect>
#include <QKeyEvent>
#include <QMouseEvent>

// WIDGETS
#include <QToolBar>
#include <QToolButton>

#include "plotter.h"

void Plotter::adjustWindow()
{
    setBackgroundRole(QPalette::Dark);
    setAutoFillBackground(true);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setFocusPolicy(Qt::StrongFocus);
}

void Plotter::initPlotterSettings()
{
    rubberband_isShown = false;
    setPlotSettings(PlotSettings());
}

void Plotter::initUserInterface()
{
    tb_zoomIn = new QToolButton (this);
    tb_zoomIn->setIcon(QIcon(":/images/zoom_in.png"));
    tb_zoomIn->adjustSize();
    connect (tb_zoomIn, SIGNAL(clicked()), this, SLOT(zoomIn()));

    tb_zoomOut = new QToolButton (this);
    tb_zoomOut->setIcon(QIcon(":/images/zoom_out.png"));
    tb_zoomOut->adjustSize();
    connect (tb_zoomOut, SIGNAL(clicked()), this, SLOT(zoomOut()));
}

void Plotter::setPlotSettings(const PlotSettings &settings)
{
    zoom_stack.clear();
    zoom_stack.append(settings);

    current_zoom = 0;
    tb_zoomIn->hide();
    tb_zoomOut->hide();
    refreshPixmap();
}

void Plotter::setCurveData(int id, const QVector<QPointF> &data)
{
    curves[id] = data;

    refreshPixmap();
}

void Plotter::clearCurve(int id)
{
    curves.remove(id);

    refreshPixmap();
}

// INPUT EVENTS
void Plotter::mousePressEvent(QMouseEvent *ev)
{
    QRect rect((int)Constants::Margin, (int)Constants::Margin, width() - 2*(int)Constants::Margin, height() - 2*(int)Constants::Margin);

    if (ev->button() == Qt::LeftButton)
    {
        if (rect.contains(ev->pos()))
        {
            rubberband_isShown = true;
            rubberband_rect.setTopLeft(ev->pos());
            rubberband_rect.setBottomRight(ev->pos());
            updateRubberBandRegion();

            setCursor(Qt::CrossCursor);
        }
    }
}

void Plotter::mouseMoveEvent(QMouseEvent *ev)
{
    if (rubberband_isShown)
    {
        updateRubberBandRegion();
            rubberband_rect.setBottomRight(ev->pos());
        updateRubberBandRegion();
    }
}

void Plotter::mouseReleaseEvent(QMouseEvent *ev)
{
    if (rubberband_isShown)
    {
        rubberband_isShown = false;
        updateRubberBandRegion();
        unsetCursor();

        QRect rect = rubberband_rect.normalized();
        if (rect.width() < 4 || rect.height() < 4)
            return;
        rect.translate(-(int)Constants::Margin, -(int)Constants::Margin);

        PlotSettings previous_settings = zoom_stack[current_zoom];
        PlotSettings current_settings;

        if (ev->button() == Qt::LeftButton)
        {
            double dx = previous_settings.spanX() / (width() - 2*(int)Constants::Margin);
            double dy = previous_settings.spanY() / (height() - 2*(int)Constants::Margin);

            current_settings.minX = previous_settings.minX + dx*rect.left();
            current_settings.maxX = previous_settings.minX + dx*rect.right();
            current_settings.minY = previous_settings.maxY - dy*rect.bottom();
            current_settings.maxY = previous_settings.maxY - dy*rect.top();
        }
        else if (ev->button() == Qt::RightButton)
        {
            current_settings.minX = previous_settings.minX - (int)Constants::ZoomoutFactor;
            current_settings.maxX = previous_settings.maxX + (int)Constants::ZoomoutFactor;
            current_settings.minY = previous_settings.minY - (int)Constants::ZoomoutFactor;
            current_settings.maxY = previous_settings.maxY + (int)Constants::ZoomoutFactor;
        }

        current_settings.adjust();

        zoom_stack.resize(current_zoom + 1);
        zoom_stack.append(current_settings);
        zoomIn();
    }
}

void Plotter::wheelEvent(QWheelEvent *ev)
{
    if (ev->orientation() == Qt::Horizontal)
        zoom_stack[current_zoom].scroll(ev->delta()/120, 0); // delta() / 8 (8th pieces of degree) / 15 (mouse job step)
    else
        zoom_stack[current_zoom].scroll(0, ev->delta()/120);

    refreshPixmap();
}

void Plotter::keyPressEvent(QKeyEvent *ev)
{
    switch (ev->key())
    {
        case Qt::Key_Plus:
            zoomIn();
            break;

        case Qt::Key_Minus:
            zoomOut();
            break;

        case Qt::Key_Left:
            zoom_stack[current_zoom].scroll(-1, 0);
            refreshPixmap();
            break;

        case Qt::Key_Right:
            zoom_stack[current_zoom].scroll(+1, 0);
            refreshPixmap();
            break;

        case Qt::Key_Up:
            zoom_stack[current_zoom].scroll(0, +1);
            refreshPixmap();
            break;

        case Qt::Key_Down:
            zoom_stack[current_zoom].scroll(0, -1);
            refreshPixmap();
            break;

        default:
            QWidget::keyPressEvent(ev);
    }
}

// PAINT EVENTS
void Plotter::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED (ev);

    QStylePainter painter (this);
    painter.drawPixmap(0, 0, pixmap);

    if (rubberband_isShown)
    {
        painter.setPen(palette().light().color());
        painter.drawRect(rubberband_rect.normalized().adjusted(0, 0, -1, -1));
    }

    if (hasFocus())
    {
        QStyleOptionFocusRect focus_opt;
        focus_opt.initFrom(this);
        focus_opt.backgroundColor = palette().dark().color();
        painter.drawPrimitive(QStyle::PE_FrameFocusRect, focus_opt);
    }
}

void Plotter::resizeEvent(QResizeEvent *ev)
{
    Q_UNUSED(ev);

    int x = width() - (tb_zoomIn->width() + tb_zoomOut->width() + 10);

    tb_zoomIn->move(x, 5);
    tb_zoomOut->move(x + tb_zoomIn->width() + 5, 5);

    refreshPixmap();
}

// SIZE HINTS
QSize Plotter::minimumSizeHint() const
{
    return QSize(6*(int)Constants::Margin, 4*(int)Constants::Margin); // scoped enum use
}

QSize Plotter::sizeHint() const
{
    return QSize(12*(int)Constants::Margin, 8*(int)Constants::Margin);
}

// SLOTS
void Plotter::zoomIn()
{
    if (current_zoom < zoom_stack.count() - 1)
    {
        ++current_zoom;

        tb_zoomIn->setEnabled(current_zoom < zoom_stack.count() - 1);
        tb_zoomOut->setEnabled(true);
        tb_zoomOut->show();

        refreshPixmap();
    }
}

void Plotter::zoomOut()
{
    if (current_zoom > 0)
    {
        --current_zoom;

        tb_zoomOut->setEnabled(current_zoom > 0);
        tb_zoomIn->setEnabled(true);
        tb_zoomIn->show();

        refreshPixmap();
    }
}

// PRIVATE FUNCS
void Plotter::updateRubberBandRegion() // draws sides of rubberband rect
{
    QRect rect = rubberband_rect.normalized();

    update (rect.left(), rect.top(), rect.width(), 1);
    update (rect.left(), rect.top(), 1, rect.height());
    update (rect.left(), rect.bottom(), rect.width(), 1);
    update (rect.right(), rect.top(), 1, rect.height());
}

void Plotter::refreshPixmap()
{
    pixmap = QPixmap(size());
    // pixmap.fill(this, 0, 0);

    QPainter painter (&pixmap);
    painter.initFrom(this);

    drawGrid(&painter); // visitor pattern use
    drawCurves(&painter);

    update();
}

void Plotter::drawGrid(QPainter *painter)
{
    QRect rect ((int)Constants::Margin, (int)Constants::Margin, width() - 2*(int)Constants::Margin, height() - 2*(int)Constants::Margin);
    if (!rect.isValid())
        return;

    PlotSettings settings = zoom_stack[current_zoom];

    QPen dark_pen = QPen("#222222"); // palette().dark().color().light();
    QPen light_pen = QPen("#AAAA00"); // palette().light().color();

    for (int i = 0; i <= settings.ticksX; ++i)
    {
        int x = rect.left() + i*(rect.width() - 1) / settings.ticksX;
        double label = settings.minX + i*settings.spanX() / settings.ticksX;

        painter->setPen(dark_pen);
        painter->drawLine(x, rect.top(), x, rect.bottom());
        painter->setPen(light_pen);
        painter->drawLine(x, rect.bottom(), x, rect.bottom() + 5);
        painter->drawText(x - 50, rect.bottom() + 5, 100, 20, Qt::AlignHCenter | Qt::AlignTop, QString::number(label));
    }

    for (int j = 0; j <= settings.ticksY; ++j)
    {
        int y = rect.bottom() - j*(rect.height() - 1) / settings.ticksY;
        double label = settings.minY + j*settings.spanY() / settings.ticksY;

        painter->setPen(dark_pen);
        painter->drawLine(rect.left(), y, rect.right(), y);
        painter->setPen(light_pen);
        painter->drawLine(rect.left() - 5, y, rect.left(), y);
        painter->drawText(rect.left() - (int)Constants::Margin, y - 10, (int)Constants::Margin - 5, 20, Qt::AlignRight | Qt::AlignVCenter, QString::number(label));
    }

    painter->drawRect(rect.adjusted(0, 0, -1, -1));
}

void Plotter::drawCurves(QPainter *painter)
{
    static const QColor colorsForCurves[6] = {Qt::red, Qt::green, Qt::blue, Qt::cyan, Qt::magenta, Qt::yellow};

    QRect rect ((int)Constants::Margin, (int)Constants::Margin, width() - 2*(int)Constants::Margin, height() - 2*(int)Constants::Margin);
    if (!rect.isValid())
        return;

    painter->setClipRect(rect.adjusted(1, 1, -1, -1));
    painter->setRenderHint(QPainter::Antialiasing, true);

    PlotSettings settings = zoom_stack[current_zoom];
    QMapIterator<int, QVector<QPointF> > curves_it(curves); // map iterator
    while (curves_it.hasNext())
    {
        curves_it.next();

        int ID = curves_it.key();
        QVector<QPointF> data = curves_it.value();
        QPolygonF spline = QPolygonF(data.count());

        for (int pt = 0; pt < data.count(); ++pt)
        {
            double dx = data[pt].x() - settings.minX;
            double dy = data[pt].y() - settings.minY;

            double x = rect.left() + dx*(rect.width() - 1) / settings.spanX();
            double y = rect.bottom() - dy*(rect.height() - 1) / settings.spanY();

            spline[pt] = QPointF(x,y);
        }


        painter->setPen(colorsForCurves[ID%6]);
        painter->drawPolyline(spline);
    }
}
