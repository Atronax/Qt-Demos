#include "tile.h"

#include <QDebug>

Tile::Tile(QWidget *parent, const TileType& t) : QPushButton(parent), type(t)
{
    init();
}

Tile::~Tile()
{

}

bool Tile::isTracable()
{
    return tracable;
}

int Tile::getCost()
{
    return cost;
}

void Tile::init()
{
    setFixedSize(32, 32);

    QString baseColor = "grey";
    QString hoverColor = "grey";
    switch (type)
    {
        case TileType::Grass:
        baseColor = "#00ff00";
        hoverColor = "#00aa00";
        tracable = true;
        cost = 1;
        break;

        case TileType::Mountain:
        baseColor = "#ffff00";
        hoverColor = "#aaaa00";
        tracable = true;
        cost = 3;
        break;

        case TileType::River:
        baseColor = "#0000ff";
        hoverColor = "#0000aa";
        tracable = false;
        cost = 999;
        break;
    }

    setStyleSheet(QString("QWidget {background: " + baseColor + ";} \
                           QWidget::hover {background: " + hoverColor + ";}"));
}
