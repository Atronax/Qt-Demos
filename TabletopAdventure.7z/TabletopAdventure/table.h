#ifndef TABLE_H
#define TABLE_H

#include <QWidget>
#include <QLayout>
#include <QKeyEvent>

#include "world.h"

class Table : public QWidget
{
    Q_OBJECT
public:
    explicit Table(QWidget *parent = nullptr);
    ~Table();

    virtual void keyPressEvent(QKeyEvent *ev);

private:
    void makeGUI();

    World *world;    

    QGridLayout *layout;

signals:

public slots:
};

#endif // TABLE_H
