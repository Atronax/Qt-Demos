#include "world.h"

#include <QDebug>
#include <QString>

World::World(QWidget *parent) : QWidget(parent)
{

}

World::~World()
{
    player->deleteLater();
    pb_movePts->deleteLater();

    foreach (Tile* tile, tiles)
        tile->deleteLater();    
    tiles.clear();
}

void World::keyPressEvent(QKeyEvent *ev)
{
    player->keyPressEvent(ev);
}

void World::testWorld()
{
    int width = 5;
    int height = 5;
    size = QSize(width, height);

    layout = new QGridLayout(this);
    layout->setSpacing(1);

    for (int i = 0 ; i < width; ++i)
    {
        for (int j = 0; j < height; ++j)
        {
            Tile *tile = nullptr;
            if (i == 3 && j == 3)
                tile = new Tile(this, Tile::Mountain);
            else if (i == 0 && j == 0)
                tile = new Tile(this, Tile::River);
            else
                tile = new Tile(this, Tile::Grass);
            layout->addWidget(tile, i, j);
            tiles << tile;
        }
    }

    player = new Player (this);
    player->setPosition(rand()%width, rand()%height);
    connect (player, SIGNAL(makeMove(const QString&)), this, SLOT(onMakeMove(const QString&)));

    pb_movePts = new QPushButton(QString("Move Points: %1").arg(player->getMovePoints()), this);
    pb_movePts->setEnabled(false);

    pb_nextTurn = new QPushButton(QString("Turn"));
    pb_nextTurn->setFixedSize(32, 32);
    pb_nextTurn->setEnabled(false);
    connect (pb_nextTurn, SIGNAL(clicked()), this, SLOT(onNextTurn()));

    // here posX is column on map and posY is row
    layout->addWidget(player, player->getPosition().posY(), player->getPosition().posX());
    layout->addWidget(pb_movePts, height, 0, 1, width - 1);
    layout->addWidget(pb_nextTurn, height, width - 1, 1, 1);
    setLayout(layout);
}

Tile *World::tileAt(int x, int y)
{
    qDebug() << "in tileAt: " << x + size.width() * y;
    return tiles.at(x + size.width()*y);
}

bool World::moveIsValid(const QString &where)
{
    bool result = true;

    int x = player->getPosition().posX();
    int y = player->getPosition().posY();
    int movePts = player->getMovePoints();

    // 1. check if move is in ranges {0, width - 1} and {0, height - 1}
    // 2. check if the next tile is tracable based on its boolean variable
    // 3. check if there is enough move points to reach the target
    if (where == "left")
    {
        if (x - 1 < 0)
        {
            result = false;
            qDebug() << "cannot move left because you have reached the left border of the map";
        }
        else if (!tileAt(x-1, y)->isTracable())
        {
            result = false;
            qDebug() << "the tile on the left side is not tracable";
        }
        else if (movePts - tileAt(x-1, y)->getCost() < 0)
        {
            result = false;
            qDebug() << QString("you have no enough move points to move left: you have %1 and need %2").arg(movePts).arg(tileAt(x-1,y)->getCost());
        }

    }
    else if (where == "right")
    {
        if (x + 1 > size.width() - 1)
        {
            result = false;
            qDebug() << "cannot move right because you have reached the right border of the map";
        }
        else if (!tileAt(x+1, y)->isTracable())
        {
            result = false;
            qDebug() << "the tile on the right side is not tracable";
        }
        else if (movePts - tileAt(x+1, y)->getCost() < 0)
        {
            result = false;
            qDebug() << QString("you have no enough move points to move right: you have %1 and need %2").arg(movePts).arg(tileAt(x+1,y)->getCost());
        }
    }
    else if (where == "up")
    {
        if (y - 1 < 0)
        {
            result = false;
            qDebug() << "cannot move up because you have reached the top border of the map";
        }
        else if (!tileAt(x, y-1)->isTracable())
        {
            result = false;
            qDebug() << "the tile on the top is not tracable";
        }
        else if (movePts - tileAt(x, y-1)->getCost() < 0)
        {
            result = false;
            qDebug() << QString("you have no enough move points to move up: you have %1 and need %2").arg(movePts).arg(tileAt(x,y-1)->getCost());
        }
    }
    else if (where == "down")
    {
        if (y + 1 > size.height() - 1)
        {
            result = false;
            qDebug() << "cannot move down because you have reached the bottom border of the map";
        }
        else if (!tileAt(x, y+1)->isTracable())
        {
            result = false;
            qDebug() << "the tile on the bottom is not tracable";
        }
        else if (movePts - tileAt(x, y+1)->getCost() < 0)
        {
            result = false;
            qDebug() << QString("you have no enough move points to move down: you have %1 and need %2").arg(movePts).arg(tileAt(x,y+1)->getCost());
        }
    }

    return result;
}

void World::onMakeMove(const QString &where)
{
    if (!moveIsValid(where))
        return;

    int x = player->getPosition().posX();
    int y = player->getPosition().posY();
    int movePts = player->getMovePoints();

    if (where == "left")
    {
        player->setPosition(x - 1, y);
        player->setMovePoints(movePts - tileAt(x - 1, y)->getCost());
    }
    else if (where == "up")
    {
        player->setPosition(x, y - 1);
        player->setMovePoints(movePts - tileAt(x, y - 1)->getCost());
    }
    else if (where == "right")
    {
        player->setPosition(x + 1, y);
        player->setMovePoints(movePts - tileAt(x + 1, y)->getCost());
    }
    else if (where == "down")
    {
        player->setPosition(x, y + 1);
        player->setMovePoints(movePts - tileAt(x, y + 1)->getCost());
    }

    qDebug() << QString("players position: %1 - %2 ").arg(player->getPosition().posX()).arg(player->getPosition().posY());

    pb_movePts->setText(QString("Move points: %1").arg(player->getMovePoints()));
    if (player->getMovePoints() == 0)
        pb_nextTurn->setEnabled(true);

    layout->removeWidget(player);
    layout->addWidget(player, player->getPosition().posY(), player->getPosition().posX());
}

void World::onNextTurn()
{
    // everything that needs to be done between the turns
    // for example: moves of enemies, growth of resources, researches and other stuff
    // for now we just refresh the move points of player and grey out the button "next turn"
    player->setMovePoints(10);
    pb_movePts->setText(QString("Move points: %1").arg(player->getMovePoints()));
    pb_nextTurn->setEnabled(false);
}
