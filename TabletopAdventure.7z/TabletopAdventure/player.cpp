#include "player.h"

Player::Player(QWidget *parent) : QPushButton(parent)
{
    init();
}

void Player::setPosition(int x, int y)
{
    position.setX(x);
    position.setY(y);
}

Position Player::getPosition()
{
    return position;
}

void Player::setMovePoints(int value)
{
    movePoints = value;
}

int Player::getMovePoints()
{
    return movePoints;
}

void Player::keyPressEvent(QKeyEvent *ev)
{
    switch (ev->key())
    {
        case Qt::Key_Left:
        emit makeMove("left");
        break;

        case Qt::Key_Up:
        emit makeMove("up");
        break;

        case Qt::Key_Right:
        emit makeMove("right");
        break;

        case Qt::Key_Down:
        emit makeMove("down");
        break;
    }
}

void Player::init()
{
    // graphics
    setFixedSize(32, 32);
    setText("P1");
    setFocus();

    // stats
    movePoints = 10;
}
