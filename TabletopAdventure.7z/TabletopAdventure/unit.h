#ifndef UNIT_H
#define UNIT_H

#include <QWidget>

class Unit : public QWidget
{
    Q_OBJECT
public:
    explicit Unit(QWidget *parent = nullptr);
    ~Unit();

    // virtual void attack(Unit* other);

private:
    QString name;
    QString desc;

signals:

public slots:
};

#endif // UNIT_H
