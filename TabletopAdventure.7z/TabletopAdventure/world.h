#ifndef WORLD_H
#define WORLD_H

#include <QWidget>
#include <QPushButton>
#include <QLayout>

#include "tile.h"
#include "player.h"

class World : public QWidget
{
    Q_OBJECT
public:
    explicit World(QWidget *parent = nullptr);
    ~World();

    virtual void keyPressEvent(QKeyEvent* ev);

    void testWorld();

private:
    Tile* tileAt (int x, int y);
    bool moveIsValid(const QString& where);

    QVector<Tile*> tiles;
    Player *player;

    QSize size;

    QPushButton* pb_movePts;
    QPushButton* pb_nextTurn;
    QGridLayout* layout;

signals:

public slots:
    void onMakeMove(const QString& where);
    void onNextTurn();
};

#endif // WORLD_H
