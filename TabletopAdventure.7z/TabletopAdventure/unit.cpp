#include "unit.h"

Unit::Unit(QWidget *parent) : QWidget(parent)
{

}

Unit::~Unit()
{

}
