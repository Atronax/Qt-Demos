#ifndef PLAYER_H
#define PLAYER_H

#include <QPushButton>
#include <QKeyEvent>

#include "stats.h"

struct Position
{
    void setX(int val) { x = val; }
    void setY(int val) { y = val; }

    int posX() { return x; }
    int posY() { return y; }

    int x;
    int y;
};

class Player : public QPushButton
{
    Q_OBJECT
public:
    explicit Player(QWidget *parent = nullptr);

    void setPosition(int x, int y);
    Position getPosition();

    void setMovePoints (int value);
    int getMovePoints();

    virtual void keyPressEvent(QKeyEvent* ev);

private:
    void init();

    // variables to store the position of the player and left moves for this turn
    Position position;
    int movePoints;

    Stats stats;

signals:
    void makeMove(const QString& where);

public slots:
};

#endif // PLAYER_H
