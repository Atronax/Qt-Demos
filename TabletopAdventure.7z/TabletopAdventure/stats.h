#ifndef STATS_H
#define STATS_H


class Stats
{
public:
    Stats();

private:
    int healthBase, healthMax, healthBonus;
    int attackBase, attackBonus;
    int defenceBase, defenceBonus;

};

#endif // STATS_H
