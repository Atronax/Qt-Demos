#include "table.h"

Table::Table(QWidget *parent) : QWidget(parent)
{
    world = new World(this);
    world->testWorld();

    makeGUI();
}

Table::~Table()
{
    world->deleteLater();
    layout->deleteLater();
}

void Table::keyPressEvent(QKeyEvent *ev)
{
    world->keyPressEvent(ev);
}

void Table::makeGUI()
{
    layout = new QGridLayout(this);
    layout->addWidget(world, 0, 0);
    setLayout(layout);
}
