#ifndef TILE_H
#define TILE_H

#include <QPushButton>

class Tile : public QPushButton
{
    Q_OBJECT
public:
    enum TileType {Grass, River, Mountain};
    explicit Tile(QWidget *parent = nullptr, const TileType& t = TileType::Grass);
    ~Tile();

    bool isTracable();
    int getCost();

    // virtual void applyEffect(Unit* unit);

private:
    void init();

    TileType type;
    bool tracable;
    int  cost;

signals:

public slots:
};

#endif // TILE_H
