#include "bmpimage.h"

#include <QFile>

BMPImage::BMPImage()
{

}

void BMPImage::LoadFromImage(const QImage& image)
{
    QImage image_16b = image.convertToFormat(QImage::Format_RGB16).mirrored();

    data_size = image_16b.byteCount();
    data_ptr = image_16b.constBits();

    file_header.type = 0x4d42; // little endian form of 'BM'
    file_header.size = sizeof(file_header) + sizeof(info_header) + data_size;
    file_header.reserved1 = 0;
    file_header.reserved2 = 0;
    file_header.offsetToBits = sizeof(file_header) + sizeof(info_header);

    info_header.size = sizeof(info_header);
    info_header.width = image_16b.width();
    info_header.height = image_16b.height();
    info_header.planes = 1;
    info_header.bitCount = 16;
    info_header.compression = 0;
    info_header.sizeImage = 0;
    info_header.XPixelsPerMeter = image_16b.dotsPerMeterX();
    info_header.YPixelsPerMeter = image_16b.dotsPerMeterY();
    info_header.colorsUsed = 0;
    info_header.colorsImportant = 0;
}

void BMPImage::SaveToFile(const QString &filename)
{
    QFile file (filename);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate))
    {
        file.write(reinterpret_cast<const char*>(&file_header), sizeof(file_header));
        file.write(reinterpret_cast<const char*>(&info_header), sizeof(info_header));
        file.write(reinterpret_cast<const char*>(data_ptr), data_size);
    }
    file.close();
}

void BMPImage::LoadFromFile(const QString &filename)
{
    Q_UNUSED(filename);
}



