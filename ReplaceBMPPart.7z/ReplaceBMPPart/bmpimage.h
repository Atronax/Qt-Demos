#ifndef BMPIMAGE_H
#define BMPIMAGE_H

#include <QImage>

#pragma pack(push,1)
typedef struct tagBITMAPFILEHEADER
{
    ushort type; // 'BM' = 0x4d42 in little endian or 0x442d in big endian
    uint size; // sizeof(struct)
    ushort reserved1; // 0
    ushort reserved2; // 0
    uint offsetToBits; // offset to pixel data

} BITMAPFILEHEADER;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct tagBITMAPINFOHEADER
{
    uint size; // sizeof(struct)
    uint width; // width of bitmap
    uint height; // height of bitmap
    ushort planes; // number of planes, usually 1
    ushort bitCount; // bits per pixel, may be 1, 4, 8, 16, 24, 32
    uint compression; // RLE compression, may be 0, 1, 2
    uint sizeImage; // size of pixel data
    uint XPixelsPerMeter; // pixels per meter x resolution
    uint YPixelsPerMeter; // pixels per meter y resolution
    uint colorsUsed; // number of used colors
    uint colorsImportant; // number of important colors
} BITMAPINFOHEADER;
#pragma pack(pop)

class BMPImage
{
public:
    BMPImage();

    void SaveToFile (const QString& filename);    
    void LoadFromFile (const QString& filename);
    void LoadFromImage (const QImage& image);

private:
    int data_size;
    const uchar* data_ptr;
    BITMAPFILEHEADER file_header;
    BITMAPINFOHEADER info_header;    
};

#endif // BMPIMAGE_H
