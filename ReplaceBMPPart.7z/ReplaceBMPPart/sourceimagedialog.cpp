#include "sourceimagedialog.h"

#include <QFileDialog>
#include <QRegExpValidator>

SourceImageDialog::SourceImageDialog(QWidget* parent) : QDialog(parent)
{
    GenerateGui();
}

const QString &SourceImageDialog::getFilename() const
{
    return filename;
}

const QPoint &SourceImageDialog::getPosition() const
{
    return position;
}

void SourceImageDialog::GenerateGui()
{
    // lineedits
    pFilename = new QLineEdit("Путь");
    pXPosition = new QLineEdit("Коорд. х");
    pYPosition = new QLineEdit("Коорд. у");

    // number validators
    pXPosition->setValidator(new QRegExpValidator(QRegExp("[0-9]{1,3}")));
    pYPosition->setValidator(new QRegExpValidator(QRegExp("[0-9]{1,3}")));

    // buttons
    pFilenameButton = new QPushButton(">>0<<");
    connect (pFilenameButton, SIGNAL(clicked(bool)), this, SLOT(onFilenameButtonClicked()));

    pAcceptButton = new QPushButton("Применить");
    connect(pAcceptButton, SIGNAL(clicked(bool)), this, SLOT(onAcceptButtonClicked()));

    pDeclineButton = new QPushButton("Отменить");
    connect(pDeclineButton, SIGNAL(clicked(bool)), this, SLOT(onDeclineButtonClicked()));

    // layout
    pLayout = new QGridLayout;    
    pLayout->setSizeConstraint(QGridLayout::SetFixedSize);
    pLayout->addWidget(pFilename, 0, 0, 1, 9);
    pLayout->addWidget(pFilenameButton, 0, 9, 1, 1);
    pLayout->addWidget(pXPosition, 1, 0, 1, 5);
    pLayout->addWidget(pYPosition, 1, 5, 1, 5);    
    pLayout->addWidget(pAcceptButton, 2, 0, 1, 5);
    pLayout->addWidget(pDeclineButton, 2, 5, 1, 5);
    setLayout(pLayout);
}

void SourceImageDialog::onFilenameButtonClicked()
{
    QString filename = QFileDialog::getOpenFileName(nullptr, "Укажите путь к исх. изобр.", QString(), "*.bmp");
    pFilename->setText(filename);
}

void SourceImageDialog::onAcceptButtonClicked()
{
    filename = pFilename->text();
    position = QPoint(pXPosition->text().toInt(), pYPosition->text().toInt());

    if (!filename.isEmpty())
        accept();
}

void SourceImageDialog::onDeclineButtonClicked()
{
    reject();
}
