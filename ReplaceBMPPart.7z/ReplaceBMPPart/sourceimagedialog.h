#ifndef SOURCEIMAGEDIALOG_H
#define SOURCEIMAGEDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class SourceImageDialog : public QDialog
{
    Q_OBJECT
public:
    SourceImageDialog(QWidget* parent = nullptr);

    const QString& getFilename() const;
    const QPoint& getPosition() const;

private:
    void GenerateGui();

    QGridLayout *pLayout;
    QLineEdit *pFilename;
    QLineEdit *pXPosition;
    QLineEdit *pYPosition;

    QPushButton *pFilenameButton;
    QPushButton *pAcceptButton;
    QPushButton *pDeclineButton;

    QString filename;
    QPoint position;

public slots:
    void onFilenameButtonClicked();
    void onAcceptButtonClicked();
    void onDeclineButtonClicked();

};

#endif // SOURCEIMAGEDIALOG_H
