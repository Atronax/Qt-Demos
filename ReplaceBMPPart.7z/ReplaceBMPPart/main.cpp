#include <QApplication>

#include "bmppartreplacer.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    BMPPartReplacer gui;
    gui.show();

    return app.exec();
}
