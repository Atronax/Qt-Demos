#ifndef BMPPARTREPLACER_H
#define BMPPARTREPLACER_H

#include <QWidget>

#include <QList>

#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class BMPPartReplacer : public QWidget
{
    Q_OBJECT
public:
    explicit BMPPartReplacer(QWidget *parent = 0);

    void SetImagesDirectory(const QString& path);
    void SetSourceImageFilename(const QString& filename);
    void SetSourceImagePosition(const QPoint& position);
    void SetFont(const QFont& font);
    void EditImage(int index);

private:
    void GenerateGUI();

    void BlockGUI();
    void UnblockGUI();

    void UpdatePreviews();
    void UpdateStatistics();
    void UpdateTranslation();

    QGridLayout *pLayout;
    QLabel *pImageSource;   
    QLabel *pImageStatistics;
    QLabel *pImageToChangeLabel;
    QLabel *pImageToChange;
    QLabel *pImageResultPreviewLabel;
    QLabel *pImageResultPreview;
    QLabel *pImageResultTranslatePreviewLabel;
    QLabel *pImageResultTranslatePreview;

    QPushButton *pChangeImageSourceButton;
    QPushButton *pFindImagesDirectoryButton;
    QPushButton *pSaveChangesAndGoNextButton;
    QLineEdit *pTranslation;

    QStringList imageFilenames; // what images we will edit
    int imageCurrentIndex; // what image we edit now
    int imageTotalCount; // how many images we have to edit

    QFont font; // what font we use
    QString imageSourceFilename; // what image we will use as source
    QPoint imageSourcePosition; // where we will place imageSource
    QImage imageSource; // what we change
    QImage imageToEdit; // where we change
    QImage imageResult; // what we get after replace
    QImage imageResultTranslate; // what we get after translate
    QString imageResultTranslateFilename; // filename of translated image

signals:

public slots:
    void onImageSourceButtonClicked();
    void onFindImagesDirectoryButtonClicked();
    void onSaveChangesAndGoNextButtonClicked();
    void onTranslationTextChanged(const QString&);
    void onTranslationReturnPressed();
};

#endif // BMPPARTREPLACER_H
