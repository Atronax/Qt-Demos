#include "bmppartreplacer.h"
#include "sourceimagedialog.h"
#include "bmpimage.h"

#include <QFileDialog>
#include <QFileInfo>

#include <QImage>
#include <QPainter>
#include <QFontDialog>

BMPPartReplacer::BMPPartReplacer(QWidget *parent) : QWidget(parent)
{    
    GenerateGUI();
    SetSourceImageFilename("source.bmp");
    SetSourceImagePosition(QPoint(4, 136)); // специфика для HQ
    SetFont(QFont("galaktika", 18));
    BlockGUI();
}

void BMPPartReplacer::GenerateGUI()
{
    pImageSource = new QLabel;
    pImageStatistics = new QLabel;
    pImageToChange = new QLabel;
    pImageToChangeLabel = new QLabel("Исходный");
    pImageResultPreview = new QLabel;
    pImageResultPreviewLabel = new QLabel("Обработанный");
    pImageResultTranslatePreview = new QLabel;
    pImageResultTranslatePreviewLabel = new QLabel ("Переведённый");

    pChangeImageSourceButton = new QPushButton ("Выбор исходного изобр.");
    connect (pChangeImageSourceButton, SIGNAL(clicked(bool)), this, SLOT(onImageSourceButtonClicked()));

    pFindImagesDirectoryButton = new QPushButton ("Выбор папки");
    connect (pFindImagesDirectoryButton, SIGNAL(clicked(bool)), this, SLOT(onFindImagesDirectoryButtonClicked()));

    pSaveChangesAndGoNextButton = new QPushButton ("Сохр. и след. изображение");
    connect (pSaveChangesAndGoNextButton, SIGNAL(clicked(bool)), this, SLOT(onSaveChangesAndGoNextButtonClicked()));

    pTranslation = new QLineEdit ("Имя");
    connect (pTranslation, SIGNAL(textChanged(QString)), this, SLOT(onTranslationTextChanged(QString)));
    connect (pTranslation, SIGNAL(returnPressed()), this, SLOT(onTranslationReturnPressed()));

    pLayout = new QGridLayout (this);
    pLayout->setSizeConstraint(QGridLayout::SetFixedSize);
    pLayout->addWidget(pImageSource, 0, 0, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pChangeImageSourceButton, 0, 1, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageStatistics, 0, 2, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageToChangeLabel, 1, 0, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageResultPreviewLabel, 1, 1, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageResultTranslatePreviewLabel, 1, 2, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageToChange, 2, 0, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageResultPreview, 2, 1, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pImageResultTranslatePreview, 2, 2, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pTranslation, 3, 0, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pFindImagesDirectoryButton, 3, 1, 1, 1, Qt::AlignCenter);
    pLayout->addWidget(pSaveChangesAndGoNextButton, 3, 2, 1, 1, Qt::AlignCenter);
    setLayout(pLayout);
}

void BMPPartReplacer::BlockGUI()
{
    pChangeImageSourceButton->setEnabled(false);
    pSaveChangesAndGoNextButton->setEnabled(false);
    pTranslation->setEnabled(false);
}

void BMPPartReplacer::UnblockGUI()
{
    pChangeImageSourceButton->setEnabled(true);
    pSaveChangesAndGoNextButton->setEnabled(true);
    pTranslation->setEnabled(true);
}

void BMPPartReplacer::SetImagesDirectory(const QString& path)
{
    if (!path.isEmpty())
    {
        // очищаем список изображений для обработки
        imageFilenames.clear();

        // наполняем список путей к файлам изображений
        QDir imagesDirectory = QDir(path);
        QFileInfoList imagesFileInfo = imagesDirectory.entryInfoList(QDir::Files);
        foreach (QFileInfo imageFileInfo, imagesFileInfo)
            imageFilenames.append(imageFileInfo.absoluteFilePath());

        // открываем первое изображение для редактирования
        imageCurrentIndex = 0;
        imageTotalCount = imageFilenames.size();
        EditImage(imageCurrentIndex);
        UpdateStatistics();

        // позволяем юзеру работать с программой
        UnblockGUI();
    }
}

void BMPPartReplacer::SetSourceImageFilename(const QString &filename)
{
    imageSourceFilename = filename;
    imageSource = QImage(filename);
}

void BMPPartReplacer::SetSourceImagePosition(const QPoint &position)
{
    imageSourcePosition = position;
}

void BMPPartReplacer::SetFont(const QFont &font)
{
    this->font = font;
}

void BMPPartReplacer::EditImage(int index)
{
    QString imageToEditFilename = imageFilenames.at(index);

    if (!imageToEditFilename.isEmpty())
    {
        // сохранить имя изображения для редактирования
        imageResultTranslateFilename = QFileInfo(imageToEditFilename).baseName();

        // обновить обьекты изображений (исходник и результат)
        imageToEdit = QImage(imageToEditFilename);
        imageResult = QImage(imageToEdit);

        // обработать результат
        QPainter painter;
        painter.begin(&imageResult);
             painter.drawImage(imageSourcePosition.x(), imageSourcePosition.y(), imageSource);
        painter.end();

        // обновить обьект изображения с переводом
        imageResultTranslate = QImage(imageResult);

        // отобразить результат на гуи
        onTranslationTextChanged("");
        UpdatePreviews();
    }
}

void BMPPartReplacer::UpdatePreviews()
{
    pImageSource->setPixmap(QPixmap::fromImage(imageSource));
    pImageToChange->setPixmap(QPixmap::fromImage(imageToEdit));
    pImageResultPreview->setPixmap(QPixmap::fromImage(imageResult));
    pImageResultTranslatePreview->setPixmap(QPixmap::fromImage(imageResultTranslate));
}

void BMPPartReplacer::UpdateStatistics()
{
    if (imageCurrentIndex + 1 > imageTotalCount)
        pImageStatistics->setText("Все изображения обработаны");
    else
        pImageStatistics->setText("Обрабатывается изображение " + QString::number(imageCurrentIndex + 1) + " из " + QString::number(imageTotalCount));
}

void BMPPartReplacer::UpdateTranslation()
{
    imageResultTranslate = QImage(imageResult);

    QPainter painter;
    painter.begin(&imageResultTranslate);
        painter.setFont(font);
        painter.drawText(QRect(imageSourcePosition.x(), imageSourcePosition.y(), imageSource.width(), imageSource.height()), pTranslation->text(), QTextOption(Qt::AlignCenter));
    painter.end();

    UpdatePreviews();
}

void BMPPartReplacer::onImageSourceButtonClicked()
{
    SourceImageDialog sourceDialog;
    if (sourceDialog.exec() == SourceImageDialog::Accepted)
    {
        SetSourceImageFilename(sourceDialog.getFilename());
        SetSourceImagePosition(sourceDialog.getPosition());

        EditImage(imageCurrentIndex);
        UpdatePreviews();
    }
}

void BMPPartReplacer::onFindImagesDirectoryButtonClicked()
{
    QString directory_path = QFileDialog::getExistingDirectory(nullptr, "Set Images Directory");
    SetImagesDirectory(directory_path);
}

void BMPPartReplacer::onSaveChangesAndGoNextButtonClicked()
{
    if (!imageResultTranslate.isNull() && !imageResultTranslateFilename.isEmpty())
    {
        BlockGUI();

            // save current image
            BMPImage imageResultTranslateBMP;
            imageResultTranslateBMP.LoadFromImage(imageResultTranslate);
            imageResultTranslateBMP.SaveToFile(imageResultTranslateFilename + ".bmp");

            // open next image
            ++imageCurrentIndex;
            if (imageCurrentIndex < imageFilenames.size())
                EditImage(imageCurrentIndex);

            UpdateStatistics();

        UnblockGUI();
    }
}

void BMPPartReplacer::onTranslationTextChanged(const QString&)
{
    UpdateTranslation();
}

void BMPPartReplacer::onTranslationReturnPressed()
{
    SetFont(QFontDialog::getFont(nullptr, font));
    UpdateTranslation();
}
