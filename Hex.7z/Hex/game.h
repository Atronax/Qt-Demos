#ifndef GAME_H
#define GAME_H

class Hex;
class HexBoard;

#include <QGraphicsScene>
#include <QGraphicsView>
class Game : public QGraphicsView
{
    Q_OBJECT

public:
    explicit Game(QWidget *parent = nullptr);
    ~Game();

    QGraphicsScene *getScene() const;

    const QPair<QString, QString>& player_names() const;
    void setPlayer_names(const QPair<QString, QString> &player_names);

    const QString& whosTurn() const;
    void setWhosTurn(const QString &whosTurn);

    void pickUpCard(Hex* card);
    void replaceCard(Hex* card);

    void mainMenu();

protected:
    void mousePressEvent(QMouseEvent *ev);
    void mouseMoveEvent(QMouseEvent *ev);

private:    
    void drawPanel(const QPoint& position, const QSize& size, const QBrush &brush, const QString &caption);    

    void gameWindow();
    void optionsWindow();
    void gameoverWindow(const QString& message);

    void removeHexFromScene (Hex* hex);
    void removeHexFromDeck (Hex* hex);    
    void deleteAllItemsFromScene();

    void nextPlayerTurn(const QString& player);
    void createCard(const QString& player);
    void createStartingCards();
    void drawCards();

    // GUI
    static constexpr int panel_width = 250;
    HexBoard *hexboard;

    // TURN control
    Hex *m_cardToPlace;
    QPointF m_cardToPlace_origin;

    QPair<QString,QString> m_player_names;
    QList<Hex*> m_player1_cards, m_player2_cards;
    QGraphicsSimpleTextItem *m_whosTurnItem;
    QString m_whosTurn;

    // END control
    int m_placed_cards;

public slots:
    void start();
    void options();
    void options_back();
    void restart();
    void gameover();

    void changePlayerName();

};

#endif // GAME_H
