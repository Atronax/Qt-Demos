#ifndef HEX_H
#define HEX_H

class Game;

#include <QGraphicsPolygonItem>
class Hex : public QGraphicsPolygonItem
{
public:
    explicit Hex(QGraphicsItem *parent = nullptr, Game *manager = nullptr);
    ~Hex();

    Game *manager() const;
    void setManager(Game *manager);

    const QString& owner() const;
    void setOwner(const QString& owner);

    bool isPlaced() const;
    void setIsPlaced(bool value);

    int attackOf (const int& side);
    void setAttackOf (const int& side, const int& value);

    void findNeighbours();
    void captureNeighbours();
    void switchOwner();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *ev);

private:
    void initSideattack();
    void initDetectors();
    void initNeighbours();

    Game *m_manager;

    // owner realization
    QString m_owner;
    bool m_isPlaced;

    // attack realization
    Hex* m_neighbours[6];
    QGraphicsLineItem* m_line_item[6];
    QGraphicsSimpleTextItem *m_sideattack_item[6];
    int m_sideattack [6];
};

#endif // HEX_H
