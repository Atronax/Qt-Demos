// logic
#include <QVector>
#include <QPointF>
#include <QString>
#include <QtMath>

// painting
#include <QBrush>
#include <QPen>

#include "game.h"
#include "hex.h"
Hex::Hex(QGraphicsItem *parent, Game *manager)
{
    // set parents
    setParentItem(parent);
    setManager(manager);

    // specify the polygon
    QVector<QPointF> points;
    points << QPointF(1.0,0.0) << QPointF (2.0,0.0) << QPointF(3.0,1.0) <<
              QPointF(2.0,2.0) << QPointF (1.0,2.0) << QPointF(0.0,1.0);

    int SCALE_FACTOR = 30;
    for (int i = 0; i < points.size(); ++i)
        points[i] *= SCALE_FACTOR;

    setPolygon(QPolygonF(points));

    // initialize variables
    setIsPlaced(false);
    initSideattack();
    initDetectors();
    initNeighbours();
}

Hex::~Hex()
{
    for (int i = 0; i < 6; ++i)
    {
        delete m_line_item[i];
        delete m_sideattack_item[i];
        delete m_neighbours[i];
    }
}

// initialization
void Hex::initSideattack()
{
    for (int i = 0; i < 6; ++i)
    {
        m_sideattack[i] = 0;
        m_sideattack_item[i] = new QGraphicsSimpleTextItem(QString::number(m_sideattack[i]), this);
        m_sideattack_item[i]->setPen(QPen(Qt::darkBlue));
        m_sideattack_item[i]->setVisible(false);
    }

    m_sideattack_item[0]->setPos(boundingRect().width()/2.0, 0);
    m_sideattack_item[1]->setPos(boundingRect().width()/4.0, 15);
    m_sideattack_item[2]->setPos(boundingRect().width()/4.0, boundingRect().height() - 15 - 15);
    m_sideattack_item[3]->setPos(boundingRect().width()/2.0, boundingRect().height() - 15);
    m_sideattack_item[4]->setPos(boundingRect().width() - boundingRect().width()/4.0, boundingRect().height() - 15 - 15);
    m_sideattack_item[5]->setPos(boundingRect().width() - boundingRect().width()/4.0, 15);
}

void Hex::initDetectors()
{
    QPointF first = pos() + boundingRect().center(); // hex center point
    QPointF second = QPointF(first.x(), first.y() - boundingRect().height()/2.0 - 5); // 5px upper from the center point
    QLineF base_line (first, second);

    // 6 lines and their graphics, we will use them to detect this hexes' neighbours
    for (int i = 0; i < 6; ++i)
    {
        QLineF line (base_line);
        line.setAngle(90 + 60*i);

        m_line_item[i] = new QGraphicsLineItem (line, this);
        m_line_item[i]->setVisible(false);
    }
}

void Hex::initNeighbours()
{
    for (int i = 0; i < 6; ++i)
        m_neighbours[i] = nullptr;
}

// setters && getters
Game *Hex::manager() const
{
    return m_manager;
}

void Hex::setManager(Game *manager)
{
    m_manager = manager;
}

const QString &Hex::owner() const
{
    return m_owner;
}

void Hex::setOwner(const QString &owner)
{
    m_owner = owner;

    // change the color
    if (manager())
    {
        if (m_owner == "")
            setBrush(Qt::lightGray);
        if (m_owner == manager()->player_names().first)
            setBrush(QColor("#4682B4"));
        if (m_owner == manager()->player_names().second)
            setBrush(QColor("#FFFACD"));
    }
}

bool Hex::isPlaced() const
{
    return m_isPlaced;
}

void Hex::setIsPlaced(bool value)
{
    m_isPlaced = value;
}

int Hex::attackOf(const int &side)
{
    return m_sideattack[side];
}

void Hex::setAttackOf(const int &side, const int &value)
{
    m_sideattack[side] = value;
    m_sideattack_item[side]->setText(QString::number(m_sideattack[side]));
    m_sideattack_item[side]->setVisible(true);
}

// events
void Hex::mousePressEvent(QGraphicsSceneMouseEvent *)
{
    if (!isPlaced()) // if is not placed, then it is a card - pick it up
        m_manager->pickUpCard(this);
    else // if is placed (on the board), then replace it
        m_manager->replaceCard(this);
}

// detecting neighbours and neighbouring attack values
void Hex::findNeighbours()
{
    for (int i = 0; i < 6; ++i)
    {        
        QList<QGraphicsItem*> colliding = m_line_item[i]->collidingItems();
        foreach (QGraphicsItem* item, colliding)
        {
            Hex* hex = dynamic_cast<Hex*>(item);
            if (hex && hex != this)
                m_neighbours[i] = hex;
        }
    }
}

void Hex::captureNeighbours()
{
    for (int i = 0; i < 6; ++i)
    {
        if (m_neighbours[i] != nullptr)
        {
            bool isEnemy = (m_neighbours[i]->owner() != owner());
            bool isNotNeutral = (m_neighbours[i]->owner() != "");

            if (isEnemy && isNotNeutral)
            {               
                int this_side = i;
                int neighbour_side = (i+3<6) ? i+3 : i-3;

                int this_attack = attackOf(this_side);
                int neighbours_attack = m_neighbours[i]->attackOf(neighbour_side);               

                if (this_attack > neighbours_attack)
                    m_neighbours[i]->switchOwner();
            }
        }
    }
}

void Hex::switchOwner()
{
    if (owner() == manager()->player_names().first)
        setOwner(manager()->player_names().second);
    else if (owner() == manager()->player_names().second)
        setOwner(manager()->player_names().first);
}
