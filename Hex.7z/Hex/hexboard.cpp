#include "hexboard.h"
HexBoard::HexBoard(Game *manager)
{
    m_manager = manager;
    calcHexSize();
}

HexBoard::~HexBoard()
{

}

QRectF HexBoard::calcBoundingRectFor(const QSize &hex_count)
{
    qreal total_width = m_hex_size.width() + (hex_count.width()-1)*(2.0/3.0*m_hex_size.width());
    qreal total_height = hex_count.height()*m_hex_size.height();

    return QRectF(0, 0, total_width, total_height);
}

void HexBoard::calcHexSize()
{
    Hex *hex = new Hex;
    m_hex_size.setWidth(hex->boundingRect().width());
    m_hex_size.setHeight(hex->boundingRect().height());
    delete hex;
}

void HexBoard::placeHexes(const QPoint& position, const QSize& size)
{
    for (int i = 0; i < size.width(); ++i)
    {
        bool isEven = i%2;
        if (!isEven)
            placeColumn(position.x() + i*(2.0/3.0*m_hex_size.width()), position.y(), size.height());
        else
            placeColumn(position.x() + i*(2.0/3.0*m_hex_size.width()), position.y() + 1.0/2.0*m_hex_size.height(), size.height());
    }
}

void HexBoard::placeColumn(int x, int y, int size)
{
    for (int i = 0; i < size; ++i)
    {
        Hex *hex = new Hex (nullptr, m_manager);
        hex->setPos(x, y+i*m_hex_size.height());
        hex->setPen(QPen(Qt::darkGreen, 2));
        hex->setIsPlaced(true);
        hex->setOwner("");

        m_hexes.append(hex);
        m_manager->getScene()->addItem(hex);
    }
}
