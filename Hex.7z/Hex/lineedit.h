#ifndef LINEEDIT_H
#define LINEEDIT_H

#include <QGraphicsTextItem>
class LineEdit : public QGraphicsTextItem
{
    Q_OBJECT
public:
    explicit LineEdit(const QString& text, QGraphicsItem *parent = nullptr);
    ~LineEdit();

    QRectF boundingRect() const;

protected:
    void focusOutEvent(QFocusEvent *ev);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    void setAlignment(Qt::Alignment alignment);

signals:
    void focusOut();
};

#endif // LINEEDIT_H
