#ifndef HEXBOARD_H
#define HEXBOARD_H

class QRectF;
class QPoint;
class QSize;

// items
#include <QList>
#include "game.h"
#include "hex.h"

class HexBoard
{
public:
    explicit HexBoard(Game *manager);
    ~HexBoard();

    QRectF calcBoundingRectFor(const QSize& hex_count);
    void placeHexes(const QPoint& position, const QSize& size);
    QList<Hex*> m_hexes;

private:
    void placeColumn(int x, int y, int size);
    void calcHexSize();

    Game *m_manager;
    QSize m_hex_size;
};

#endif // HEXBOARD_H
