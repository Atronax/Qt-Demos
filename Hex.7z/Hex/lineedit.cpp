#include <QPainter>
#include <QKeyEvent>
#include <QTextCursor>

#include "lineedit.h"
LineEdit::LineEdit(const QString& text, QGraphicsItem *parent)
    : QGraphicsTextItem (text, parent)
{    
    setTextInteractionFlags(Qt::TextEditable);
    setFont(QFont("Deutsch Gothic", 20, 20));
    setTextWidth(boundingRect().width());
    setAlignment(Qt::AlignCenter);

}

LineEdit::~LineEdit()
{

}

// setters and gettets
QRectF LineEdit::boundingRect() const
{
    return QRectF(0,0,400,80);
}

// events
void LineEdit::focusOutEvent(QFocusEvent *ev)
{
    emit focusOut();

    QGraphicsTextItem::focusOutEvent(ev);
}

void LineEdit::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawRoundedRect(boundingRect(), 30, 30);

    QGraphicsTextItem::paint(painter, option, widget);
}

void LineEdit::setAlignment(Qt::Alignment alignment)
{
    QTextBlockFormat format;
    format.setAlignment(alignment);

    QTextCursor cursor = textCursor();
    cursor.select(QTextCursor::Document);
    cursor.mergeBlockFormat(format);
    cursor.clearSelection();

    setTextCursor(cursor);
}
