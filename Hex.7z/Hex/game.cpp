// logic
#include <QApplication>
#include <QDesktopWidget>
#include <QLinearGradient>

// events
#include <QMouseEvent>

// items
#include "hex.h"
#include "hexboard.h"

#include "button.h"
#include "lineedit.h"
#include "animgraphicsitem.h"
#include <QGraphicsDropShadowEffect>

#include "game.h"
Game::Game(QWidget *parent)
{
    setParent(parent);        

    // set up the view
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFocusPolicy(Qt::ClickFocus);
    setFixedSize(1024,768);

    // set up the scene
    setScene(new QGraphicsScene(rect(), this));

    // initialize variables
    m_player_names = QPair<QString,QString>("Player 1", "Player 2"); // to do setters
    m_cardToPlace = nullptr;
}

Game::~Game()
{

}

QGraphicsScene *Game::getScene() const
{
    return scene();
}

const QString& Game::whosTurn() const
{
    return m_whosTurn;
}

void Game::setWhosTurn(const QString &whosTurn)
{
    m_whosTurn = whosTurn;
    m_whosTurnItem->setText(tr("Ходит: %1").arg(m_whosTurn));
}

const QPair<QString, QString>& Game::player_names() const
{
    return m_player_names;
}

void Game::setPlayer_names(const QPair<QString, QString> &player_names)
{
    m_player_names = player_names;
}

// events
void Game::mousePressEvent(QMouseEvent *ev)
{
    if (m_cardToPlace)
    {
        if (ev->button() == Qt::RightButton)
        {
            m_cardToPlace->setPos(m_cardToPlace_origin);
            m_cardToPlace->setGraphicsEffect(nullptr);
            m_cardToPlace = nullptr;
        }
    }

    QGraphicsView::mousePressEvent(ev);
}

void Game::mouseMoveEvent(QMouseEvent *ev)
{
    if (m_cardToPlace)
        m_cardToPlace->setPos(ev->pos());

    QGraphicsView::mouseMoveEvent(ev);
}

// user interface
void Game::drawPanel(const QPoint &position, const QSize &size, const QBrush &brush, const QString& caption)
{
    QGraphicsRectItem *panel = new QGraphicsRectItem (QRectF(position,size));
    panel->setBrush(brush);
    scene()->addItem(panel);

    QGraphicsSimpleTextItem *panel_text = new QGraphicsSimpleTextItem (caption);
    panel_text->setPen(QPen(Qt::yellow));
    panel_text->setFont(QFont("Stylo", 14));
    panel_text->setPos(position.x() + panel->boundingRect().width()/2.0 - panel_text->boundingRect().width()/2.0, 20 + position.y());
    scene()->addItem(panel_text);
}

void Game::mainMenu()
{
    setBackgroundBrush(QBrush(QPixmap(":/images/mainmenu_background.png").scaled(rect().size())));

    AnimGraphicsItem *title = new AnimGraphicsItem(":/images/animation_shish.png", QSize(300,300), nullptr, this);
    title->setPos(100 + width()/2.0 - title->boundingRect().width()/2, 100);
    scene()->addItem(title);

    Button *play_button = new Button(tr("Играть"));
    play_button->setPos(width()/2.0 - play_button->boundingRect().width()/2, 300);
    connect (play_button, SIGNAL(clicked()), this, SLOT(start()));
    scene()->addItem(play_button);

    Button *options_button = new Button(tr("Настройки"));
    options_button->setPos(width()/2.0 - options_button->boundingRect().width()/2, 400);
    connect (options_button, SIGNAL(clicked()), this, SLOT(options()));
    scene()->addItem(options_button);

    Button *quit_button = new Button(tr("Выход"));
    quit_button->setPos(width()/2.0 - quit_button->boundingRect().width()/2, 500);
    connect (quit_button, SIGNAL(clicked()), this, SLOT(close()));
    scene()->addItem(quit_button);
}

void Game::gameWindow()
{
    // left panel
    drawPanel(QPoint(0,0), QSize(panel_width,rect().height()), QColor(0,0,255,10), tr("Карты игрока %1").arg(m_player_names.first));

    // central panel
    drawPanel(QPoint(panel_width,0), QSize(rect().width()-2*panel_width,rect().height()), QColor(0,0,255,5), "");

        // whos turn label
    m_whosTurnItem = new QGraphicsSimpleTextItem(tr("Ходит: "));
    m_whosTurnItem->setPen(QPen(Qt::yellow));
    m_whosTurnItem->setFont(QFont("Stylo", 20));
    m_whosTurnItem->setPos(panel_width + (rect().width() - 2*panel_width)/2.0 - m_whosTurnItem->boundingRect().width()/2.0, 0);
    setWhosTurn(m_player_names.first);
    scene()->addItem(m_whosTurnItem);

        // hexboard
    hexboard = new HexBoard (this);
    QRectF hexboard_boundingRect = hexboard->calcBoundingRectFor(QSize(8,8));
    hexboard->placeHexes(QPoint(panel_width + (rect().width() - 2*panel_width)/2.0 - hexboard_boundingRect.width()/2.0,150), QSize(8,8));

    // right panel
    drawPanel(QPoint(rect().width()-panel_width, 0), QSize(panel_width,rect().height()), QColor(0,0,255,10), tr("Карты игрока %1").arg(m_player_names.second));
}

void Game::optionsWindow()
{
    // disable all scene items
    foreach (QGraphicsItem *item, scene()->items())
        item->setEnabled(false);

    // show panel
    QRectF bRect (0, 0, rect().width(), 600); // bounding rect of the window
    drawPanel(QPoint(0,0), rect().size(), QBrush(QColor(0,0,0,200)), tr(""));
    drawPanel(QPoint(rect().width()/2.0 - bRect.width()/2.0, rect().height()/2.0 - bRect.height()/2.0), bRect.size().toSize(), QBrush(QColor(255,255,0,200)), tr("Настройки:"));

    LineEdit *p1name_edit = new LineEdit(player_names().first);
    p1name_edit->setObjectName("P1Name");
    p1name_edit->setPos(rect().width()/2.0 - p1name_edit->boundingRect().width()/2.0, 300);
    connect (p1name_edit, SIGNAL(focusOut()), this, SLOT(changePlayerName()));
    scene()->addItem(p1name_edit);

    LineEdit *p2name_edit = new LineEdit (player_names().second);
    p2name_edit->setObjectName("P2Name");
    p2name_edit->setPos(rect().width()/2.0 - p2name_edit->boundingRect().width()/2.0, 400);
    connect (p2name_edit, SIGNAL(focusOut()), this, SLOT(changePlayerName()));
    scene()->addItem(p2name_edit);

    Button *leave_button = new Button (tr("В меню"));
    leave_button->setPos(rect().width()/2.0 - leave_button->boundingRect().width()/2.0, 500);
    connect (leave_button, SIGNAL(clicked()), this, SLOT(options_back()));
    scene()->addItem(leave_button);
}

void Game::gameoverWindow(const QString &message)
{
    // disable all scene items
    foreach (QGraphicsItem *item, scene()->items())
        item->setEnabled(false);

    // show transparent panel
    drawPanel(QPoint(0,0), rect().size(), QBrush(QColor(0,0,0,200)), tr("Игра окончена"));

    // show window with buttons and result message over transparent panel
    QRectF bRect (0, 0, rect().width(), 400);
    drawPanel(QPoint(rect().width()/2.0 - bRect.width()/2.0, rect().height()/2.0 - bRect.height()/2.0), bRect.size().toSize(), QBrush(QColor(255,255,0,200)), tr("Результаты:"));

    QGraphicsSimpleTextItem *t_message = new QGraphicsSimpleTextItem(message);
    t_message->setFont(QFont("Deutsch Gothic", 20));
    t_message->setPos(rect().width()/2.0 - t_message->boundingRect().width()/2.0, 250);
    scene()->addItem(t_message);

    Button *b_playAgain = new Button (tr("Играть снова"));
    b_playAgain->setPos(rect().width()/2.0 - b_playAgain->boundingRect().width()/2.0, 350);
    connect (b_playAgain, SIGNAL(clicked()), this, SLOT(restart()));
    scene()->addItem(b_playAgain);

    Button *b_quit = new Button (tr("Покинуть игру"));
    b_quit->setPos(rect().width()/2.0 - b_playAgain->boundingRect().width()/2.0, 450);
    connect (b_quit, SIGNAL(clicked()), this, SLOT(close()));
    scene()->addItem(b_quit);
}

void Game::drawCards()
{
    // clean the cards on the scene
    foreach (Hex* hex, m_player1_cards)
        removeHexFromScene(hex);

    foreach (Hex* hex, m_player2_cards)
        removeHexFromScene(hex);

    // draw cards
    for (int i = 0; i < m_player1_cards.size(); ++i)
    {
        Hex *card = m_player1_cards.at(i);
        if (i%2)
            card->setPos(20+card->boundingRect().width(),100+i*card->boundingRect().height());
        else
            card->setPos(20,100+i*card->boundingRect().height());
        scene()->addItem(card);
    }

    for (int i = 0; i < m_player2_cards.size(); ++i)
    {
        Hex *card = m_player2_cards.at(i);
        if (i%2)
            card->setPos((rect().width()-panel_width),100+i*card->boundingRect().height());
        else
            card->setPos((rect().width()-panel_width)+card->boundingRect().width(),100+i*card->boundingRect().height());
        scene()->addItem(card);
    }
}

// game logic
void Game::createCard(const QString &player)
{
    if (player == m_player_names.first || player == m_player_names.second)
    {
        Hex *card = new Hex(nullptr, this);
        card->setOwner(player);
        for (int i = 0; i < 6; ++i)
            card->setAttackOf(i, 1 + rand()%6);

        if (player == m_player_names.first)
            m_player1_cards.append(card);

        if (player == m_player_names.second)
            m_player2_cards.append(card);

        drawCards();
    }
}

void Game::createStartingCards()
{
    // player 1's cards
    for (int i = 0; i < 5; ++i)
        createCard(m_player_names.first);

    // player 1's cards
    for (int i = 0; i < 5; ++i)
        createCard(m_player_names.second);
}

void Game::nextPlayerTurn(const QString &player)
{
    if (player == m_player_names.first)
        setWhosTurn(m_player_names.second);

    if (player == m_player_names.second)
        setWhosTurn(m_player_names.first);
}

void Game::pickUpCard(Hex *card)
{
    if (!m_cardToPlace && card->owner() == whosTurn())
    {
        QGraphicsDropShadowEffect *effect = new QGraphicsDropShadowEffect;
        effect->setOffset(10,10);
        effect->setBlurRadius(20);

        m_cardToPlace = card;
        m_cardToPlace->setGraphicsEffect(effect);
        m_cardToPlace_origin = m_cardToPlace->pos();
    }
}

void Game::replaceCard(Hex *card)
{
    if (m_cardToPlace && card->owner() != player_names().first && card->owner() != player_names().second)
    {
        // replace card and remove it from the scene
        m_cardToPlace->setPos(card->pos());        
        hexboard->m_hexes.removeOne(card);
        hexboard->m_hexes.append(m_cardToPlace);
        m_cardToPlace->setIsPlaced(true);
        removeHexFromDeck(m_cardToPlace);
        removeHexFromScene(card);

        // find and capture neighbours
        m_cardToPlace->findNeighbours();
        m_cardToPlace->captureNeighbours();

        // replace the placed card with a new one and make turn
        createCard(whosTurn());
        nextPlayerTurn(m_cardToPlace->owner());

        // nullify picking up
        m_cardToPlace->setGraphicsEffect(nullptr);
        m_cardToPlace = nullptr;

        // track count of placed card compared to total hexboard's count
        qDebug(QString(QString::number(m_placed_cards) + "-" + QString::number(hexboard->m_hexes.size())).toUtf8());
        if (++m_placed_cards >= hexboard->m_hexes.size())
            gameover();
    }
}

void Game::removeHexFromScene(Hex *hex)
{
    foreach (QGraphicsItem* item, scene()->items())
    {
        if (hex == dynamic_cast<Hex*>(item))
            scene()->removeItem(item);
    }
}

void Game::removeHexFromDeck(Hex *hex)
{
    if (hex->owner() == player_names().first)
        m_player1_cards.removeOne(hex);
    else if (hex->owner() == player_names().second)
        m_player2_cards.removeOne(hex);
}

void Game::deleteAllItemsFromScene()
{
    foreach (QGraphicsItem *item, scene()->items())
    {
        scene()->removeItem(item);
        delete item;
    }
}

// slots
void Game::start()
{
    // initialize variables
    m_cardToPlace = nullptr;
    m_placed_cards = 0;

    // clear the scene
    setBackgroundBrush(QBrush());
    scene()->clear();

    // draw GUI
    gameWindow();
    createStartingCards();
}

void Game::options()
{
    deleteAllItemsFromScene();
    optionsWindow(); // to do
}

void Game::options_back()
{
    deleteAllItemsFromScene();
    mainMenu();
}

void Game::restart()
{
    m_player1_cards.clear();
    m_player2_cards.clear();
    hexboard->m_hexes.clear();
    deleteAllItemsFromScene();

    start();
}

void Game::gameover()
{
    int total_p1_hexes = 0;
    int total_p2_hexes = 0;
    foreach (Hex *hex, hexboard->m_hexes)
    {
        if (hex->owner() == player_names().first)
            ++total_p1_hexes;
        if (hex->owner() == player_names().second)
            ++total_p2_hexes;
    }

    QString game_result_message;
    if (total_p1_hexes > total_p2_hexes)
        game_result_message = QString("Игрок %1 победил игрока %2 со счетом %3:%4").arg(player_names().first).arg(player_names().second).arg(total_p1_hexes).arg(total_p2_hexes);
    if (total_p1_hexes < total_p2_hexes)
        game_result_message = QString("Игрок %1 победил игрока %2 со счетом %3:%4").arg(player_names().second).arg(player_names().first).arg(total_p2_hexes).arg(total_p1_hexes);
    if (total_p1_hexes == total_p2_hexes)
        game_result_message = QString("Ничья: %1:%2").arg(total_p1_hexes).arg(total_p2_hexes);

    gameoverWindow(game_result_message);
}

void Game::changePlayerName()
{
    qDebug ("in changeplayername");
    LineEdit *item = static_cast<LineEdit*>(sender());
    if (item->objectName() == "P1Name")
        setPlayer_names(QPair<QString,QString>(item->toPlainText(), player_names().second));
    if (item->objectName() == "P2Name")
        setPlayer_names(QPair<QString,QString>(player_names().first, item->toPlainText()));
}
