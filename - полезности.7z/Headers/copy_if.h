// ����������� � STL �������� copy_if

template <typename InputIterator, typename OutputIterator, typename Predicate>
OutputIterator copy_if (InputIterator iter_begin, InputIterator iter_end,
			OutputIterator iter_dest_begin,
			Predicate p)
{
	while (iter_begin != iter_end)
	{
		if (p (*iter_begin))
			*iter_dest_begin++ = *iter_begin;
		++iter_begin;
	}

	return iter_dest_begin;
};