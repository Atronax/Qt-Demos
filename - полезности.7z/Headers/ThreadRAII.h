// ����� ��� ������ � �������� �++11\�++14 ��� � RAII ���������

class ThreadRAII
{
	public:
		using actionRAII = void (std::thread::*) (); // alias declaration
		
		ThreadRAII (std::thread&& t, actionRAII act): // constructor takes an rvalue ref and pointer to an action
				   action (act),
				   thread (std::move(t)) // t is an rvalue, so we can move it to a data member
		{

		}

		~ThreadRAII ()
		{
			if (thread.joinable())
				thread.(*action)();
		}

		// explicit declarations of move constructor and move operator are needed
		ThreadRAII (ThreadRAII&&) = default; // compiler generated

		ThreadRAII& operator = (ThreadRAII&&) = default; // compiler generated

		std::thread& get()
		{
			return thread;
		}

	private:
		actionRAII action;
		std::thread thread;
};