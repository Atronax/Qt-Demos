#include <QThread>

class Thread: public QThread
{
	Q_OBJECT

	public:
		void run (void)
		{
			exec();
		}
}

Thread my_thread;
my_thread.start(QThread::TimeCriticalPriority);

QMutex
QMutexLocker
QSemaphore
QSemaphoreLocker
QWaitableTimer
