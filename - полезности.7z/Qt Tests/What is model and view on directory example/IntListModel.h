#ifndef INTLISTMODEL_H
#define INTLISTMODEL_H

#include <QAbstractListModel>
#include <QList>

class IntListModel : public QAbstractListModel
{
    Q_OBJECT

public:
    IntListModel (const QList<int> &lst, QObject *parent = 0);

    QVariant data (const QModelIndex &index, int role) const;
    bool setData (const QModelIndex &index, const QVariant &value, int role);
    int rowCount (const QModelIndex &parent) const;
    QVariant headerData (int section, Qt::Orientation orientation, int role) const;
    Qt::ItemFlags flags (const QModelIndex &index) const;

private:
    QList<int> list;
};

#endif // INTLISTMODEL_H
