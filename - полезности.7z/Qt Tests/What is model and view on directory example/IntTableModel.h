#ifndef INTTABLEMODEL_H
#define INTTABLEMODEL_H

#include <QAbstractTableModel>
#include <QList>

class IntTableModel : public QAbstractTableModel
{
public:
    IntTableModel(int rows, int columns, QObject *parent = 0) : QAbstractTableModel(parent), iRows(rows), iColumns(columns){}

    QVariant data(const QModelIndex &index, int role) const;
    bool setData(const QModelIndex &index, const QVariant &value, int role);
    int rowCount(const QModelIndex &parent) const;
    int columnCount(const QModelIndex &parent) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;


private:
    int iRows;
    int iColumns;
    QHash<QModelIndex,QVariant> hHash;
};

#endif // INTTABLEMODEL_H
