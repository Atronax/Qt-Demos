#include <QApplication>
#include <QtWidgets>

#include "SimpleDelegate.h"
#include "IntListModel.h"
#include "IntTableModel.h"

#define TABLE_SIZE 256

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    QWidget mainwidget;

    QDirModel filesystem;
    QItemSelectionModel ism (&filesystem);

    IntListModel *intlistmodel = new IntListModel(QList<int>()<<432145<<5324<<423142);
    IntTableModel *inttablemodel = new IntTableModel (200, 200);


    // Модель списка
    QListView *plistview = new QListView;
    plistview->setModel(inttablemodel);
    plistview->setItemDelegate(new SimpleDelegate(plistview));
    plistview->viewport()->setAttribute(Qt::WA_Hover);

    // Модель иерархического списка
    QTreeView *ptreeview = new QTreeView;
    ptreeview->setModel (&filesystem);
    ptreeview->setSelectionModel(&ism);
    ptreeview->setItemDelegate(new SimpleDelegate(ptreeview));
    ptreeview->viewport()->setAttribute(Qt::WA_Hover);

    // Модель таблицы
    QTableView *ptableview = new QTableView;
    ptableview->setModel(inttablemodel);
    ptableview->setItemDelegate(new SimpleDelegate(ptableview));
    ptableview->viewport()->setAttribute(Qt::WA_Hover);

    QHBoxLayout *phboxlayout = new QHBoxLayout;
    phboxlayout->addWidget(plistview);
    phboxlayout->addWidget(ptreeview);
    phboxlayout->addWidget(ptableview);
    mainwidget.setLayout(phboxlayout);
    mainwidget.show();

    return app.exec();
}


/*
 * QListWidget listwgt;

 * QListWidgetItem *plistwgtitem = 0;
 * listwgt.setIconSize(QSize(64,64));

 * foreach (QString str, strlistmodel)
 * {
 *     plistwgtitem = new QListWidgetItem(str, &listwgt);
 *     plistwgtitem-> setIcon(QPixmap("d:\\" + str + ".jpg"));
 *     plistwgtitem-> setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled);
 * }

 * listwgt.resize(200,200);
 * listwgt.sortItems(Qt::DescendingOrder);
 * listwgt.setViewMode(QListView::IconMode);

 * listwgt.show();
 */

/*
 * QTreeWidget treewgt;

 * QStringList strtree;
 * strtree << "Папки" << "Использованное пространство";

 * QTreeWidgetItem *ptreewgtitem = new QTreeWidgetItem (&treewgt);
 * ptreewgtitem->setText(0, "Локальный диск (С)");
 * ptreewgtitem->setIcon(0, QPixmap("drive.bmp"));

 * QTreeWidgetItem *ptreewgtitemDir = 0;
 * for (int i = 1; i < 20; ++i)
 * {
 *     ptreewgtitemDir = new QTreeWidgetItem(ptreewgtitem);
 *     ptreewgtitemDir->setText(0, "Dir" + QString::number(i));
 *     ptreewgtitemDir->setText(1, QString::number(i) + "MB");
 *     ptreewgtitemDir->setIcon(0, QPixmap("folder.bmp"));
 *     ptreewgtitemDir->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsDragEnabled);
 * }


 * treewgt.setHeaderLabels(strtree);
 * treewgt.setSortingEnabled(true);
 * treewgt.resize(300,300);
 * treewgt.show();
 */

/*
 * QTableWidget tablewgt (TABLE_SIZE,TABLE_SIZE);
 * QTableWidgetItem *ptablewgtitem = 0;

 * for (int i = 0; i < TABLE_SIZE; ++i)
 *     for (int j = 0; j < TABLE_SIZE; ++j)
 *     {
 *         ptablewgtitem = new QTableWidgetItem(QString("Координаты: %1,%2").arg(i).arg(j));
 *         tablewgt.setItem(i,j,ptablewgtitem);
 *     }

 * tablewgt.show();
 */

/*
 * QComboBox comboboxwgt;

 * comboboxwgt.addItems(strlistmodel.stringList());
 * comboboxwgt.setEditable(true);
 */

/*
 * QTabWidget tabwgt (&mainwidget);
 * foreach (QString str, strlistmodel.stringList())
 *     tabwgt.addTab(new QLabel (str, &tabwgt), QPixmap("d:\\" + str + ".jpg"), str);
 */

/*
 * QToolBox toolboxwgt(&mainwidget);
 * foreach (QString str, strlistmodel.stringList())
 *     toolboxwgt.addItem(new QLabel (str, &toolboxwgt), QPixmap("D:\\" + str + ".jpg"), str);
 */
