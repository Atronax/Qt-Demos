#include "IntTableModel.h"

QVariant IntTableModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    QString str = QString ("%1, %2").arg(index.row()+1).arg(index.column()+1);
    if (role == Qt::DisplayRole || role == Qt::EditRole)
        return hHash.value(index, QVariant(str));
    else
        return QVariant();
}

bool IntTableModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (index.isValid() && role == Qt::EditRole)
    {
        hHash[index] = value.toInt();
        emit dataChanged(index, index);
        return true;
    }
    else
        return false;
}

int IntTableModel::rowCount(const QModelIndex &) const
{
    return iRows;
}

int IntTableModel::columnCount(const QModelIndex &) const
{
    return iColumns;
}

Qt::ItemFlags IntTableModel::flags (const QModelIndex &index) const
{
    Qt::ItemFlags flags = QAbstractTableModel::flags(index);

    if (index.isValid())
        return flags | Qt::ItemIsEditable;
    else
        return flags;
}
