#include "IntListModel.h"

IntListModel::IntListModel (const QList<int> &lst, QObject *parent) : QAbstractListModel(parent), list(lst) {}

QVariant IntListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();
    else if (role == Qt::DisplayRole || role == Qt::EditRole)
        return list.at(index.row());
    else
        return QVariant();
}

bool IntListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (index.isValid() && role == Qt::EditRole)
    {
        list.replace(index.row(), value.value<int>());
        emit dataChanged(index, index);
        return true;
    }
    else
        return false;
}

int IntListModel::rowCount(const QModelIndex &parent) const
{
    return list.size();
}

QVariant IntListModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role != Qt::DisplayRole)
        return QVariant();
    else if (orientation == Qt::Horizontal)
        return QString ("Число");
    else
        return QString::number(section);

}

Qt::ItemFlags IntListModel::flags(const QModelIndex &index) const
{
    Qt::ItemFlags flags = QAbstractListModel::flags(index);

    if (index.isValid())
        return flags | Qt::ItemIsEditable;
    else
        return flags;
}
