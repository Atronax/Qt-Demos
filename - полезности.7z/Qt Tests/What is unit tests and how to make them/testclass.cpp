#include "testclass.h"

const int& TestClass::min(const int &lhs, const int &rhs)
{
    return (lhs < rhs) ? lhs : rhs;
}

const int& TestClass::max(const int &lhs, const int &rhs)
{
    return (lhs > rhs) ? lhs : rhs;
}
