#ifndef TESTCLASS_H
#define TESTCLASS_H

#include <QObject>

class TestClass : public QObject
{
    Q_OBJECT
public:
    explicit TestClass(QObject *parent = 0) : QObject (parent)
    {

    }

    const int& min (const int& lhs, const int& rhs);
    const int& max (const int& lhs, const int& rhs);

signals:

public slots:

};

#endif // TESTCLASS_H
