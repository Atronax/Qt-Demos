#include "test_testclass.h"

// SLOTS
void Test_TestClass::min_data()
{
    using namespace QTest;
    addColumn<int> ("arg1");
    addColumn<int> ("arg2");
    addColumn<int> ("res");

    newRow("min_test1") <<   25 <<    0 <<    0;
    newRow("min_test2") <<  -12 <<   -5 <<  -12;
    newRow("min_test3") << 2007 << 2007 << 2007;
    newRow("min_test4") <<  -12 <<    5 <<  -12;

}

void Test_TestClass::min()
{
    TestClass testclass_min;

    QFETCH (int, arg1);
    QFETCH (int, arg2);
    QFETCH (int, res);
    QCOMPARE (testclass_min.min(arg1, arg2), res);
}

void Test_TestClass::max_data()
{
    using namespace QTest;
    addColumn<int> ("arg1");
    addColumn<int> ("arg2");
    addColumn<int> ("res");

    newRow("max_test1") <<   25 <<    0 <<   25;
    newRow("max_test2") <<  -12 <<   -5 <<   -5;
    newRow("max_test3") << 2007 << 2007 << 2007;
    newRow("max_test4") <<  -12 <<    5 <<    5;
}

void Test_TestClass::max()
{
    TestClass testclass_max;

    QFETCH (int, arg1);
    QFETCH (int, arg2);
    QFETCH (int, res);
    QCOMPARE (testclass_max.max(arg1, arg2), res);
}

/* another variant
void Test_TestClass::min()
{
    TestClass testclass_min;
    QCOMPARE (testclass_min.min(25,0), 0);
    QCOMPARE (testclass_min.min(-12,-5), -12);
    QCOMPARE (testclass_min.min(2007,2007), 2007);
    QCOMPARE (testclass_min.min(-12,5), -12);
}
*/

/* another variant
void Test_TestClass::max()
{
    TestClass testclass_max;
    QCOMPARE (testclass_max.max(25,0), 25);
    QCOMPARE (testclass_max.max(-12,-5), -5);
    QCOMPARE (testclass_max.max(2007,2007), 2007);
    QCOMPARE (testclass_max.max(-12,5), 5);
}
*/
