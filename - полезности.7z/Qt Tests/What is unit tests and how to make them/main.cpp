#include <QApplication>
#include "test_testclass.h"

QTEST_MAIN (Test_TestClass)
