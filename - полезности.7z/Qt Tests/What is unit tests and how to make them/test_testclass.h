#ifndef TEST_TESTCLASS_H
#define TEST_TESTCLASS_H

#include <QObject>

#include <QtTest/QtTest>
#include "TestClass.h"

class Test_TestClass : public QObject // UNIT TEST CASE FOR "TESTCLASS"
{
    Q_OBJECT
public:
    explicit Test_TestClass(QObject *parent = 0) : QObject (parent)
    {

    }

private slots:
    void min_data ();
    void min ();

    void max_data ();
    void max ();

};

#endif // TEST_TESTCLASS_H
