#include <QtGui>

#include <QApplication>
#include <QLabel>
#include <QPushButton>

#include "Counter.h"

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    QLabel lbl ("0");
    lbl.show();

    QPushButton button_Add ("Бросить кость!");
    button_Add.show();

    Counter counter;

    QObject::connect (&button_Add, SIGNAL(clicked()), &counter, SLOT(slotInc()));
    QObject::connect (&counter, SIGNAL(counterChanged(int)), &lbl, SLOT(setNum(int)));
    QObject::connect (&counter, SIGNAL(goodbye()), &app, SLOT(quit()));

    return app.exec();
}
