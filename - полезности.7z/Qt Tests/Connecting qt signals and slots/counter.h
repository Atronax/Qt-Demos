#ifndef COUNTER_H
#define COUNTER_H

#include <QObject>

class Counter : public QObject
{
    Q_OBJECT

public:
    Counter ();

private:
    int iValue;

signals:
    void goodbye ();
    void counterChanged (int);

public slots:
    void slotInc ();
};

#endif // COUNTER_H
