#include <QtCore/QtMath>
#include "counter.h"

Counter::Counter() : QObject(), iValue(0)
{
}

void Counter::slotInc()
{
    emit counterChanged(iValue = 1+qrand()%6);
    // if (iValue == 6)
    //    emit goodbye();
}
