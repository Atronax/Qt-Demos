#include <QApplication>
#include <QtWidgets>

#include "mylabel.h"
#include "mywidget.h"
#include "mypushbutton.h"

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    QLineEdit lineedit("Пользовательский ввод: ");
    lineedit.resize(280,20);
    lineedit.show();

    for (int i = Qt::Key_A; i <= Qt::Key_Z; ++i)
    {
        QKeyEvent *ev = new QKeyEvent (QEvent::KeyPress, i, Qt::NoModifier, QChar (i));
        QApplication::postEvent(&lineedit, ev);
    }

    MyWidget wgt;
    wgt.show();

    MyPushButton pb;
    pb.show();

    MyLabel window;
    QPixmap pixmap ("d:/mickey.png");

    window.setPixmap(pixmap);
    window.setMask(pixmap.mask());
    window.show();

    app.exec();
}
