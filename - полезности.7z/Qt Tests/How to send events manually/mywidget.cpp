#include "mywidget.h"

void MyWidget::paintEvent(QPaintEvent *ev)
{
    QLinearGradient gradient (0,0,this->width(), this->height());
    gradient.setColorAt(0, Qt::red);
    gradient.setColorAt(0.5, Qt::green);
    gradient.setColorAt(1, Qt::blue);

    int width = this->width();
    int height = this->height();

    // QRadialGradient gradient (width/2, height/2, width < height ? width : height);
    // gradient.setColorAt(0, Qt::darkMagenta);
    // gradient.setColorAt(0.5, Qt::cyan);
    // gradient.setColorAt(1, Qt::black);

    QPainter painter (this);
    painter.setBrush(gradient);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.drawEllipse(this->rect());

    painter.drawPolyline(pic);
    this->update();
}

void MyWidget::mousePressEvent(QMouseEvent *ev)
{
    pt1 = ev->pos();
    pic.append(pt1);
}

void MyWidget::mouseMoveEvent(QMouseEvent *ev)
{
    pt2 = ev->pos();
    pic.append(pt2);
}

void MyWidget::mouseReleaseEvent(QMouseEvent *ev)
{
    pic.append(pt2);
}
