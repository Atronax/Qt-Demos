#include "mylabel.h"

void MyLabel::mousePressEvent(QMouseEvent *ev)
{
    current_position = ev->pos();
}

void MyLabel::mouseMoveEvent(QMouseEvent *ev)
{
    move(ev->globalPos() - current_position);
}
