#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H

#include <QPushButton>

#include <QPainter>

class MyPushButton : public QPushButton
{
    Q_OBJECT
public:
    MyPushButton (QWidget *parent = 0) : QPushButton (parent) {}

    virtual void paintEvent(QPaintEvent* ev);

signals:

public slots:

};

#endif // MYPUSHBUTTON_H
