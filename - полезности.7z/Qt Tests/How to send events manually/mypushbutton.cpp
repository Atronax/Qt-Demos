#include "mypushbutton.h"

void MyPushButton::paintEvent(QPaintEvent *ev)
{

    QPainter painter (this);
    QImage img ("d:/A.jpg");
    QImage img2 ("d:/stone.jpg");

    if (this->width() < 500)
        painter.setBrush(QBrush(img));
    else
        painter.setBrush(QBrush(img2));
    painter.drawEllipse(this->width()/2, this->height()/2, 100, 100);

}
