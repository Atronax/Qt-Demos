#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>

#include <QMouseEvent>
#include <QPainter>
#include <QPoint>

class MyWidget : public QWidget
{
    Q_OBJECT

public:
    MyWidget (QWidget *parent = 0) : QWidget (parent) {}
protected:
    virtual void paintEvent (QPaintEvent *ev);

    virtual void mousePressEvent (QMouseEvent *ev);
    virtual void mouseMoveEvent (QMouseEvent *ev);
    virtual void mouseReleaseEvent (QMouseEvent *ev);

private:
    QVector<QPoint> pic;
    QPoint pt1, pt2;

signals:

public slots:

};

#endif // MYWIDGET_H
