#include "qtwinapitest.h"

QPaintEngine* QtWinapiTest::paintEngine() const
{
    return NULL;
}

bool QtWinapiTest::nativeEvent(const QByteArray &eventType, void *message, long *result)
{
    Q_UNUSED (eventType);
    Q_UNUSED (result);

    MSG *msg = static_cast <MSG*> (message); // cast (void *) to (MSG *)

    QString str_1 = "Windows ver." + QString::number(QSysInfo::WindowsVersion);
    QString str_2 = "Windows msg.";

    if (msg->message == WM_RBUTTONDOWN)
    {
        MessageBox ( msg->hwnd, // winID() returns handle to current window
                   (const WCHAR*) (str_1.utf16()), // text in window
                   (const WCHAR*) (str_2.utf16()), // text in caption
                    MB_OK | MB_ICONEXCLAMATION); // standard buttons in window
    }

    if (msg->message == WM_LBUTTONDBLCLK)
    {
        PlaySound (L"d:/button_clicked.wav", GetModuleHandle(NULL), SND_FILENAME | SND_ASYNC);
    }

    if (msg->message == WM_LBUTTONDOWN)
    {
        PlaySound (L"d:/music.wav", GetModuleHandle(NULL), SND_FILENAME | SND_ASYNC);
    }

    if (msg->message == WM_PAINT)
    {
        QString str = "WinGDI *** WinGDI *** WinGDI";

        BeginPaint(hWND, &PS);
            hBRUSH = CreateSolidBrush(RGB(155, 200, 0));
            hPEN = CreatePen(PS_DASHDOTDOT, 3, RGB(0, 0, 255));
            TEXTMETRIC tmTEXT;

            GetTextMetrics(hDC, &tmTEXT); // get metrics of currently used text
            SelectObject(hDC, hBRUSH);
            SelectObject(hDC, hPEN);

            // SetBkMode(hDC, OPAQUE);

            Ellipse(hDC, 0, 0, width(), height());
            TextOut(hDC,
                    width() / 2.0 - (tmTEXT.tmAveCharWidth * str.length() / 2.0), (height() - tmTEXT.tmHeight) / 2.0,
                    (LPCWSTR) (str.utf16()),
                    str.length());
        EndPaint(hWND, &PS);

        // InvalidateRect(hWND, NULL, TRUE);
    }

    if (msg->message == WM_DESTROY)
    {
        DeleteObject(hBRUSH);
        DeleteObject(hPEN);
        ReleaseDC(hWND, hDC);
    }

    return false;
}
