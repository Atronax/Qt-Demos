#include <QApplication>
#include "qtwinapitest.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    QtWinapiTest winapi_in_qt;
    winapi_in_qt.show();    



    return app.exec();
}
