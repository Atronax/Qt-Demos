#ifndef QTWINAPITEST_H
#define QTWINAPITEST_H

#include <QWidget>

#include <qt_windows.h>

class QtWinapiTest : public QWidget
{
    Q_OBJECT
public:
    explicit QtWinapiTest(QWidget *parent = 0)
        : QWidget (parent)
    {
        setAttribute(Qt::WA_PaintOnScreen, true);
        setAttribute(Qt::WA_OpaquePaintEvent, true);

        hWND = (HWND) winId();
        hDC = GetDC (hWND);
    }

protected:
    virtual QPaintEngine* paintEngine() const; // for wingdi to draw correctly
    virtual bool nativeEvent(const QByteArray &eventType, void *message, long *result); // windows messages loop manager

private:
    HWND hWND;
    HDC hDC;

    PAINTSTRUCT PS;
    HBRUSH hBRUSH;
    HPEN hPEN;

signals:

public slots:

};

#endif // QTWINAPITEST_H
