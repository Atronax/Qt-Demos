#ifndef DYNAMICLIBRARY_H
#define DYNAMICLIBRARY_H

#include <QString>

// Экспортируем прототипы функций для их дальнейшего использования

extern "C" // компилятор не прикрепляет информацию о типе к символьной сигнатуре функции
{
    QString oddUpper (const QString& string);
}

// Для загрузки библиотеки используем обьекты класса QLibrary

#endif // DYNAMICLIBRARY_H
