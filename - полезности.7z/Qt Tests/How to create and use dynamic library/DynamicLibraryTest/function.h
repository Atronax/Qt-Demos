#ifndef FUNCTION_H
#define FUNCTION_H

#include <functional>
#include <memory>

template <typename UnusedType>
class function; // forwarding declaration

template <typename ReturnType, typename ... ArgumentTypes>
class function <ReturnType (ArgumentTypes ...)>
{
public:
    function ()
        : invoker()
    {
    }

    template <typename FunctionT>
    function (FunctionT f)
        : invoker (new free_function_holder<FunctionT> (f))
    {
    }

    ReturnType operator() (ArgumentTypes ... args)
    {
        return invoker->invoke (args ...);
    }

    function (const function& rhs)
        : invoker (rhs.invoker->clone())
    {
    }

    function& operator= (const function& rhs)
    {
        invoker = rhs.invoker->clone();
    }

private:
    class function_holder_base
    {
    public:
        function_holder_base ()
        {
        }
        virtual ~function_holder_base ()
        {
        }

        virtual ReturnType invoke (ArgumentTypes ... args) = 0;
        virtual std::auto_ptr<function_holder_base> clone () = 0;

    private:
        function_holder_base (const function_holder_base& rhs);
        void operator= (const function_holder_base& rhs);
    };

    typedef std::auto_ptr<function_holder_base> invoker_t; // auto ptr - говно

    template <typename FunctionT>
    class free_function_holder : public function_holder_base
    {
    public:
        free_function_holder (FunctionT func)
            : function_holder_base(),
              cur_function (func)
        {
        }

        virtual ReturnType invoke (ArgumentTypes ... args)
        {
            return cur_function (args ...);
        }

        virtual invoker_t clone ()
        {
            return invoker_t (new free_function_holder<FunctionT>(cur_function));
        }

    private:
        FunctionT cur_function;
    };


    invoker_t invoker;
};



#endif // FUNCTION_H
