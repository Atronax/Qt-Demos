#include <QApplication>

#include <QLibrary>
#include <QLabel>

#include "DynamicLibrary.h"
// #include <tr1/functional>
#include "function.h"

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    QString test_string ("тестовая строка");
    QString test_result_string = oddUpper(test_string);

    QLabel test_label_1 (test_string);
    QLabel test_label_2 (test_result_string);
    QLabel test_label_3 ("0");

            QLibrary lib ("D:/QtProjects/dynamic_library/DynamicLibrary.dll");
            function<QString (const QString&)> toUpper = (QString (*) (const QString&))(lib.resolve("oddUpper"));
            test_label_3.setText(toUpper(test_string));

            // QString (*toUpper) (const QString&) = (QString (*) (const QString&))(lib.resolve("oddUpper"));
            // std::tr1::function<QString (const QString&)> toUpper = (QString (*) (const QString&))(lib.resolve("oddUpper"));

    test_label_1.show();
    test_label_2.show();
    test_label_3.show();

    return app.exec();
}
