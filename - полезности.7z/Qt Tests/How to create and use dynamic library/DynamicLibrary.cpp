#include "DynamicLibrary.h"

// Пример экспортируемой функции (возвращает значение временной переменной - строки,
// подменяющей каждую вторую букву строки - параметра на большое значение.
QString oddUpper(const QString &string)
{
    QString temp = "";

    for (int i = 0; i < string.length(); ++i)
        temp += (i % 2 == 0) ? string.at(i) : string.at(i).toUpper();

    return temp;
}
