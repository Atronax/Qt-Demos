/********************************************************************************
** Form generated from reading UI file 'TestApp.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTAPP_H
#define UI_TESTAPP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtDesignerTestapp
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLCDNumber *lcdNumber;
    QHBoxLayout *horizontalLayout;
    QPushButton *pbQuit;
    QSlider *slFortest;
    QPushButton *pbReset;

    void setupUi(QWidget *QtDesignerTestapp)
    {
        if (QtDesignerTestapp->objectName().isEmpty())
            QtDesignerTestapp->setObjectName(QStringLiteral("QtDesignerTestapp"));
        QtDesignerTestapp->resize(400, 100);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(QtDesignerTestapp->sizePolicy().hasHeightForWidth());
        QtDesignerTestapp->setSizePolicy(sizePolicy);
        QtDesignerTestapp->setMinimumSize(QSize(400, 100));
        QtDesignerTestapp->setMaximumSize(QSize(400, 100));
        QFont font;
        font.setItalic(false);
        font.setUnderline(false);
        font.setStrikeOut(false);
        QtDesignerTestapp->setFont(font);
        QtDesignerTestapp->setWindowOpacity(1);
        QtDesignerTestapp->setAutoFillBackground(false);
        layoutWidget = new QWidget(QtDesignerTestapp);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 10, 361, 81));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        lcdNumber = new QLCDNumber(layoutWidget);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));

        verticalLayout->addWidget(lcdNumber);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pbQuit = new QPushButton(layoutWidget);
        pbQuit->setObjectName(QStringLiteral("pbQuit"));

        horizontalLayout->addWidget(pbQuit);

        slFortest = new QSlider(layoutWidget);
        slFortest->setObjectName(QStringLiteral("slFortest"));
        slFortest->setOrientation(Qt::Horizontal);

        horizontalLayout->addWidget(slFortest);

        pbReset = new QPushButton(layoutWidget);
        pbReset->setObjectName(QStringLiteral("pbReset"));

        horizontalLayout->addWidget(pbReset);


        verticalLayout->addLayout(horizontalLayout);

        QWidget::setTabOrder(slFortest, pbReset);
        QWidget::setTabOrder(pbReset, pbQuit);

        retranslateUi(QtDesignerTestapp);
        QObject::connect(slFortest, SIGNAL(valueChanged(int)), lcdNumber, SLOT(display(int)));
        QObject::connect(pbQuit, SIGNAL(clicked()), QtDesignerTestapp, SLOT(close()));

        QMetaObject::connectSlotsByName(QtDesignerTestapp);
    } // setupUi

    void retranslateUi(QWidget *QtDesignerTestapp)
    {
        QtDesignerTestapp->setWindowTitle(QApplication::translate("QtDesignerTestapp", "QtDesigner Test Application", 0));
        pbQuit->setText(QApplication::translate("QtDesignerTestapp", "&\320\227\320\260\320\262\320\265\321\200\321\210\320\270\321\202\321\214", 0));
        pbReset->setText(QApplication::translate("QtDesignerTestapp", "&\320\241\320\261\321\200\320\276\321\201\320\270\321\202\321\214", 0));
    } // retranslateUi

};

namespace Ui {
    class QtDesignerTestapp: public Ui_QtDesignerTestapp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTAPP_H
