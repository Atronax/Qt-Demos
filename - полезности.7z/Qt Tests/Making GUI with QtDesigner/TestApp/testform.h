#ifndef TESTFORM_H
#define TESTFORM_H

#include <QWidget>

#include "ui_TestApp.h"

class TestForm : public QWidget
{
    Q_OBJECT

public:
    TestForm (QWidget* parent = 0) : QWidget (parent)
    {
        ui.setupUi(this);

        connect (ui.pbReset, SIGNAL(clicked()), this, SLOT(slotReset()));
    }

private:
    Ui::QtDesignerTestapp ui;

public slots:
    void slotReset();
};


#endif // TESTFORM_H
