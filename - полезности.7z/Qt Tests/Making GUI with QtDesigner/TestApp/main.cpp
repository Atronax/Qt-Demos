#include <QApplication>
#include "testform.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    TestForm* my_form = new TestForm;
    my_form->show();

    return app.exec();
}

