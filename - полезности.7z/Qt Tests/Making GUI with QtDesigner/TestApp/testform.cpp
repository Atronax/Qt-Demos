#include "testform.h"

// SLOTS
void TestForm::slotReset()
{
    ui.slFortest->setValue(0);
    ui.lcdNumber->display(0);
}
