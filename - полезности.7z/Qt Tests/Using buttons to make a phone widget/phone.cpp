#include <QApplication>

#include <QWidget>
#include <QPushButton>
#include <QLayout>

using namespace Qt;

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    QWidget *wgt = new QWidget;
    QPalette pal;
    pal.setBrush(wgt->backgroundRole(), QBrush(QPixmap("d:\\snow.gif")));

    QPushButton *pb1 = new QPushButton ("1");
    QPushButton *pb2 = new QPushButton ("2");
    QPushButton *pb3 = new QPushButton ("3");
    QPushButton *pb4 = new QPushButton ("4");
    QPushButton *pb5 = new QPushButton ("5");
    QPushButton *pb6 = new QPushButton ("6");
    QPushButton *pb7 = new QPushButton ("7");
    QPushButton *pb8 = new QPushButton ("8");
    QPushButton *pb9 = new QPushButton ("9");
    QPushButton *pbs = new QPushButton ("*");
    QPushButton *pb0 = new QPushButton ("0");
    QPushButton *pbh = new QPushButton ("#");


    QVBoxLayout *vbl = new QVBoxLayout (wgt);
    QHBoxLayout *hbl1 = new QHBoxLayout;
    QHBoxLayout *hbl2 = new QHBoxLayout;
    QHBoxLayout *hbl3 = new QHBoxLayout;
    QHBoxLayout *hbl4 = new QHBoxLayout;

    hbl1->setMargin(15);
    hbl1->setSpacing(20);
    hbl1->addWidget(pb1);
    hbl1->addWidget(pb2);
    hbl1->addWidget(pb3);

    hbl2->setMargin(15);
    hbl2->setSpacing(20);
    hbl2->addWidget(pb4);
    hbl2->addWidget(pb5);
    hbl2->addWidget(pb6);

    hbl3->setMargin(15);
    hbl3->setSpacing(20);
    hbl3->addWidget(pb7);
    hbl3->addWidget(pb8);
    hbl3->addWidget(pb9);

    hbl4->setMargin(15);
    hbl4->setSpacing(20);
    hbl4->addWidget(pbs);
    hbl4->addWidget(pb0);
    hbl4->addWidget(pbh);

    vbl->setMargin(15);
    vbl->setSpacing(20);
    vbl->addLayout(hbl1);
    vbl->addLayout(hbl2);
    vbl->addLayout(hbl3);
    vbl->addLayout(hbl4);

    wgt->resize(70,70);
    wgt->setPalette(pal);
    wgt->show();

    app.exec();
}
