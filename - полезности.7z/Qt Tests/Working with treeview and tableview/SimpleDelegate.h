#ifndef SIMPLEDELEGATE_H
#define SIMPLEDELEGATE_H

#include <QItemDelegate>
#include <QPainter>

class SimpleDelegate: public QItemDelegate
{
public:
    SimpleDelegate (QObject *parent) : QItemDelegate (parent) {}

    virtual void paint (QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
};

#endif // SIMPLEDELEGATE_H
