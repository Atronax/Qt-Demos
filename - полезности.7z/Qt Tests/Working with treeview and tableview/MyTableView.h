#ifndef MYTABLEVIEW_H
#define MYTABLEVIEW_H

#include <QProcess>
#include <QDirModel>
#include <QKeyEvent>
#include <QTableView>

class MyTableView : public QTableView
{
    Q_OBJECT

public:
    MyTableView () : QTableView (0){}
    MyTableView (QWidget *parent) : QTableView (parent){}

    void keyPressEvent(QKeyEvent *pe);

signals:
    void signalRunFile ();

public slots:
    void slotExecuteFile (QModelIndex);
};

#endif // MYTABLEVIEW_H
