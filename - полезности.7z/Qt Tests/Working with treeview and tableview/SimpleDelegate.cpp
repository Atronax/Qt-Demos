#include "SimpleDelegate.h"

void SimpleDelegate::paint (QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    if (option.state & QStyle::State_MouseOver)
    {
        QRect rect = option.rect;
        QLinearGradient gradient (0, 0, rect.width(), rect.height());

        gradient.setColorAt(0, "#294CFF");
        gradient.setColorAt(0.5, "#294CFF");
        gradient.setColorAt(1, "#EF8E56");

        painter->setBrush(gradient);
        painter->drawRect(rect);
    }

    QItemDelegate::paint(painter, option, index);
}
