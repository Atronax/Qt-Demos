#include <QFileSystemModel>
#include <QLabel>
#include "MyTableView.h"

QDirModel filesys;

void MyTableView::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Asterisk)
        this->selectAll();
    else
       QTableView::keyPressEvent(event);
}

void MyTableView::slotExecuteFile(QModelIndex currentindex)
{

    QString path = filesys.filePath(currentindex);
    QProcess::startDetached("\""+path+"\"");
}
