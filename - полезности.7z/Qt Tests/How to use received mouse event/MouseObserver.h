#ifndef MOUSEOBSERVER_H
#define MOUSEOBSERVER_H

#include <QtWidgets>

class MouseObserver : public QLabel
{
public:
    MouseObserver (QWidget *parent = 0);

protected:
    virtual void mousePressEvent   (QMouseEvent *ev);
    virtual void mouseMoveEvent    (QMouseEvent *ev);
    virtual void mouseReleaseEvent (QMouseEvent *ev);

    virtual void dragEnterEvent (QDragEnterEvent *ev);
    virtual void dragMoveEvent (QDragMoveEvent *ev);
    virtual void dragLeaveEvent (QDragLeaveEvent *ev);
    virtual void dropEvent (QDropEvent *ev);

    virtual void wheelEvent (QWheelEvent *ev);

    virtual void enterEvent (QEvent *ev);
    virtual void leaveEvent (QEvent *ev);

    void dumpEvent (QMouseEvent *ev, const QString &message);
    QString infoModifiers (QMouseEvent *ev);
    QString infoButtons (QMouseEvent *ev);

private:
    int current_photo;
};

#endif // MOUSEOBSERVER_H
