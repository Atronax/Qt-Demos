#include <QApplication>
#include <QtWidgets>

#include "MouseObserver.h"

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);
    MouseObserver mo;

    mo.show();
    return app.exec();
}
