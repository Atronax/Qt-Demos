#include "MouseObserver.h"

MouseObserver::MouseObserver(QWidget *parent) : QLabel(parent)
{
    setAlignment(Qt::AlignCenter);
    setText("Действия с мышью:");
    current_photo = 0;
}

void MouseObserver::mousePressEvent(QMouseEvent *ev)
{
    dumpEvent (ev, "Мышь нажата");
}

void MouseObserver::mouseMoveEvent(QMouseEvent *ev)
{
    dumpEvent (ev, "Курсор мыши перемещается");
}

void MouseObserver::mouseReleaseEvent(QMouseEvent *ev)
{
    dumpEvent (ev, "Мышь отпущена");
}

void MouseObserver::dumpEvent(QMouseEvent *ev, const QString &message)
{
    setText (
                message +
                "\n Нажатые кнопки мыши: " + infoButtons(ev) +
                "\n Нажатые модификаторы: " + infoModifiers(ev) +
                "\n Локальная координата х: " + QString::number(ev->x()) +
                "\n Локальная координата у: " + QString::number(ev->y()) +
                "\n Глобальная координата х: " + QString::number(ev->globalX()) +
                "\n Глобальная координата y: " + QString::number(ev->globalY())
            );
}

QString MouseObserver::infoButtons(QMouseEvent *ev)
{
    QString message;

    if (ev->buttons() & Qt::LeftButton)
        message += "ЛКМ ";

    if (ev->buttons() & Qt::RightButton)
        message += "ПКМ ";

    if (ev->buttons() & Qt::MiddleButton)
        message += "CКМ";

    return message;
}

QString MouseObserver::infoModifiers(QMouseEvent *ev)
{
    QString message;

    if (ev->modifiers() & Qt::ShiftModifier)
        message += "Shift ";

    if (ev->modifiers() & Qt::ControlModifier)
        message += "Ctrl ";

    if (ev->modifiers() & Qt::AltModifier)
        message += "Alt";

    return message;
}

void MouseObserver::wheelEvent(QWheelEvent *ev)
{
   /*
    QColor current_color = this->palette().color(backgroundRole());
    int red = current_color.red();

    if (ev->delta() > 0) // вверх
    {
        red++;
        if (red > 0 && red < 256)
        {
            current_color.setRed(red);
            QPalette pal;
            pal.setColor(backgroundRole(), current_color);
            this->setPalette(pal);
        }
    }

    if (ev->delta() < 0) // вниз
    {
        red--;
        if (red > 0 && red < 256)
        {
            current_color.setRed(red);
            QPalette pal;
            pal.setColor(backgroundRole(), current_color);
            this->setPalette(pal);
        }
    }
    */

    if (ev->delta() > 0) // вверх
    {
        current_photo++;

        if (current_photo > 0 && current_photo < 81)
        {
            QPalette pal;
            QPixmap *pixmap = new QPixmap ("e:\\Arxon\\Фотоальбом\\2006-12-02\\A " + QString::number(current_photo) + ".jpg");
            *pixmap = pixmap->scaled(1280,1024);

            pal.setBrush(backgroundRole(), QBrush(QPixmap(*pixmap)));

            this->setMaximumSize(pixmap->width(),pixmap->height());
            this->setPalette(pal);
        }
        else if (current_photo > 80)
            current_photo = 80;
    }

    if (ev->delta() < 0) // вниз
    {
        current_photo--;

        if (current_photo > 0 && current_photo < 81)
        {
            QPalette pal;
            QPixmap *pixmap = new QPixmap ("e:\\Фотоальбом\\2006-12-02\\A " + QString::number(current_photo) + ".jpg");
            *pixmap = pixmap->scaled(1280,1024);

            pal.setBrush(backgroundRole(), QBrush(QPixmap(*pixmap)));

            this->setMaximumSize(pixmap->width(),pixmap->height());
            this->setPalette(pal);
        }
        else if (current_photo < 0)
            current_photo = 0;
    }
}


void MouseObserver::enterEvent(QEvent *ev)
{
    QPalette pal;
    pal.setColor(backgroundRole(), QColor(Qt::green));

    this->setCursor(QPixmap("d:\\snow.gif"));
    this->setPalette(pal);
}

void MouseObserver::leaveEvent(QEvent *ev)
{
    QPalette pal;
    pal.setColor(backgroundRole(), QColor(Qt::red));

    this->setCursor(QPixmap("d:\\snow.gif"));
    this->setPalette(pal);
}

void MouseObserver::dragEnterEvent(QDragEnterEvent *ev)
{
}

void MouseObserver::dragMoveEvent(QDragMoveEvent *ev)
{
    this->rect().setWidth(ev->pos().x());
}

void MouseObserver::dragLeaveEvent(QDragLeaveEvent *ev)
{
}

void MouseObserver::dropEvent(QDropEvent *ev)
{
}
