#include <QApplication>
#include <QScrollArea>
#include <QPixmap>
#include <QLabel>


int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    QLabel *label = new QLabel;
    label->setPixmap(QPixmap(argv[1]));
    label->setFixedSize(QPixmap(argv[1]).size());

    QScrollArea *sa = new QScrollArea;
    sa->setWidget(label);

    sa->show();

    return app.exec();
}

