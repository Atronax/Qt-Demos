#include <QApplication>

#include "blinkinglabel.h"

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    BlinkingLabel blinking_label ("<CENTER>ALARM!!! ALARM!!! Загроза вибуху на ядерному реакторі! </CENTER>", 100);
    blinking_label.setFont(QFont("Xiomara", 30, true, true));
    blinking_label.changeColorTo(true, Qt::red);
    blinking_label.changeColorTo(false, Qt::black);
    blinking_label.setGeometry(300, 300, 300, 300);
    blinking_label.show();

    return app.exec();
}
