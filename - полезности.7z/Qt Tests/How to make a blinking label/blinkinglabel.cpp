#include "blinkinglabel.h"

void BlinkingLabel::changeColorTo(bool isForeground, const QColor& whatColor)
{
    QPalette pal = this->palette();
    if (isForeground)
        pal.setColor(QPalette::Foreground, whatColor);
    else
        pal.setColor(QPalette::Background, whatColor);
    this->setPalette(pal);
}

void BlinkingLabel::timerEvent(QTimerEvent *ev)
{
    Q_UNUSED(ev);
    bBlink = !bBlink;
    setText (bBlink ? sText : "");
}
