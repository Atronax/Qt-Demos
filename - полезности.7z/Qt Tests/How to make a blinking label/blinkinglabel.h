#ifndef BLINKINGLABEL_H
#define BLINKINGLABEL_H

#include <QTimer>
#include <QTimerEvent>

#include <QLabel>
#include <QPalette>

class BlinkingLabel : public QLabel
{
    Q_OBJECT
public:
    explicit BlinkingLabel(const QString& text, int iInterval = 200, QWidget *parent = 0) :
             QLabel (text, parent),
             sText (text),
             bBlink (true)
    {
        startTimer(iInterval);
    }

    void changeColorTo (bool isForeground, const QColor& whatColor);

protected:
    virtual void timerEvent(QTimerEvent *ev);

private:
    QString sText;
    bool bBlink;


signals:

public slots:

};

#endif // BLINKINGLABEL_H
