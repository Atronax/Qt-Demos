#include "qtscript.h"

// SLOTS
bool QtScript::slotIsReadOnly() const
{
    return bReadOnly;
}

void QtScript::slotSetReadOnly(bool read_only)
{
    bReadOnly = read_only;
    emit signalReadOnlyStateChanged();
}
