#ifndef QTSCRIPT_H
#define QTSCRIPT_H

#include <QObject>

class QtScript : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool ReadOnly READ slotIsReadOnly WRITE slotSetReadOnly NOTIFY signalReadOnlyStateChanged)
public:
    explicit QtScript(QObject *parent = 0)
        : QObject (parent),
          bReadOnly (false)
    {

    }

private:
    bool bReadOnly;

signals:
    void signalReadOnlyStateChanged ();

public slots:
    void slotSetReadOnly (bool read_only);
    bool slotIsReadOnly  () const;

};

#endif // QTSCRIPT_H
