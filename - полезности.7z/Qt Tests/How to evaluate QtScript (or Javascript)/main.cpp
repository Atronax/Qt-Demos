#include <QApplication>

#include <QWidget>
#include <QLabel>

#include <QtScript>

QScriptValue getWidgetByName(QScriptContext *pScriptContext, QScriptEngine *pScriptEngine)
{
    QString name = pScriptContext->argument(0).toString();

    QObject *pObject = nullptr;
    foreach (QWidget* pWidget, QApplication::topLevelWidgets())
    {
        if (name == pWidget->objectName() || pWidget->findChild<QObject*>(name))
            pObject = pWidget;
    }

    return pScriptEngine->newQObject(pObject);
}

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);    

    QScriptEngine script_engine;

    QLabel test_label; // pass to javascript value
    QScriptValue script_label = script_engine.newQObject(&test_label);
    script_engine.globalObject().setProperty("test_label", script_label);
    script_engine.evaluate("test_label.text = 'HW!'");
    script_engine.evaluate("test_label.show()");

    QScriptValue script_getwidget_func = script_engine.newFunction(getWidgetByName);
    script_engine.globalObject().setProperty("getWidgetByName", script_getwidget_func);

    return app.exec();
}
