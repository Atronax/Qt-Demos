#ifndef WEBBROWSER_H
#define WEBBROWSER_H

#include <QWidget>

#include <QtWebKit>
#include <QtWebKitWidgets>

#include <QLineEdit>
#include <QPushButton>
#include <QProgressBar>

#include <QPointer>




class WebBrowser : public QWidget
{
    Q_OBJECT
public:
    explicit WebBrowser(QWidget *parent = 0) : QWidget (parent)
    {
        createGUI ();
        initAdblock();
        slotOnBrowse();
    }

private:
    void createGUI (void);
    void initBackButton (void);
    void initForwardButton (void);
    void initRefreshButton (void);
    void initLoadingProgressbar (void);
    void initNavigationEdit (void);
    void initWebView (void);
    void initSSConnections (void);
    void initLayout (void);

    void initAdblock (void);

    QWebView* web_view;

    QLineEdit* leNavigation;
    QPushButton *pbBack, *pbForward, *pbRefresh; // navigation buttons
    QProgressBar *prbLoading;

    QString strAdblock;

signals:

public slots:
    void slotOnBrowse (void);
    void slotOnFinished (bool);

};

#endif // WEBBROWSER_H
