#include <QApplication>
#include "webbrowser.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    WebBrowser web_browser;
    web_browser.show();

    return app.exec();
}
