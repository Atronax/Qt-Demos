#include "webbrowser.h"

// INIT FUNCTIONS
void WebBrowser::createGUI()
{
    initBackButton();
    initForwardButton();
    initRefreshButton();
    initLoadingProgressbar();
    initNavigationEdit();
    initWebView();
    initSSConnections();

    initLayout();
}

void WebBrowser::initBackButton()
{
    pbBack = QPointer<QPushButton> (new QPushButton (tr("Назад")));
    pbBack->setEnabled(false);
}

void WebBrowser::initForwardButton()
{
    pbForward = QPointer<QPushButton> (new QPushButton (tr("Вперед")));
    pbForward->setEnabled(false);
}

void WebBrowser::initRefreshButton()
{
    pbRefresh = QPointer<QPushButton> (new QPushButton (tr("Обновить")));
}

void WebBrowser::initLoadingProgressbar()
{
    prbLoading = QPointer<QProgressBar> (new QProgressBar);
}

void WebBrowser::initNavigationEdit()
{
    leNavigation = QPointer<QLineEdit> (new QLineEdit);
    leNavigation->setText("google.ua");
}

void WebBrowser::initWebView()
{
    web_view = QPointer<QWebView> (new QWebView);
    web_view->load(QUrl(leNavigation->text()));
    web_view->settings()->setAttribute(QWebSettings::PluginsEnabled, true);
    web_view->settings()->setAttribute(QWebSettings::JavascriptEnabled, true);
}

void WebBrowser::initLayout()
{
    QHBoxLayout* hbl = QPointer<QHBoxLayout> (new QHBoxLayout);
    hbl->addWidget(pbRefresh);
    hbl->addWidget(pbBack);
    hbl->addWidget(leNavigation);
    hbl->addWidget(pbForward);

    QVBoxLayout* res = QPointer<QVBoxLayout> (new QVBoxLayout);
    res->addLayout(hbl);
    res->addWidget(prbLoading);
    res->addWidget(web_view);

    setLayout(res);
}

void WebBrowser::initSSConnections()
{
    connect (pbBack, SIGNAL(clicked()), web_view, SLOT(back()));
    connect (pbForward, SIGNAL(clicked()), web_view, SLOT(forward()));
    connect (pbRefresh, SIGNAL(clicked()), web_view, SLOT(reload()));
    connect (leNavigation, SIGNAL(returnPressed()), this, SLOT(slotOnBrowse()));
    connect (web_view, SIGNAL(loadProgress(int)), prbLoading, SLOT(setValue(int)));
    connect (web_view, SIGNAL(loadFinished(bool)), this, SLOT(slotOnFinished(bool)));
}

void WebBrowser::initAdblock()
{
    QFile file;
    file.setFileName("c:/adblock/adblock_start_common.js");
    file.open(QIODevice::ReadOnly);
    strAdblock = file.readAll();
    // strAdblock.append("\n var qt = { 'strAdblock' : strAdblock.noConflict (true) };");
    file.close();

    web_view->page()->mainFrame()->evaluateJavaScript(strAdblock);
    qDebug (strAdblock.toUtf8());
}

// SLOTS
void WebBrowser::slotOnBrowse()
{
    if (!leNavigation->text().startsWith("ftp://") || !leNavigation->text().startsWith("http://"))
        leNavigation->setText("http://" + leNavigation->text());

    web_view->load(QUrl(leNavigation->text()));
}

void WebBrowser::slotOnFinished(bool bOK)
{
    if (!bOK)
        web_view->setHtml("<B><i><color = red> Ошибка при попытке загрузки страницы" \
                          + web_view->url().toString() \
                          + "</color></i></B>");

    leNavigation->setText(web_view->url().toString());

    pbBack->setEnabled(web_view->page()->history()->canGoBack());
    pbForward->setEnabled(web_view->page()->history()->canGoForward());
}
