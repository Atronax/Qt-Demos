#include <QApplication>
#include <QMainWindow>
#include "calc.h"

int main (int argc, char *argv[])
{
    QApplication app (argc, argv);

    Calculator *calc = new Calculator;
    calc->setWindowTitle ("Калькулятор");
    calc->resize(230,200);
    calc->show();

    QMainWindow main;
    main.menuBar()->addAction("Экшон");

    QDockWidget *dockl = new QDockWidget ("DOCK", &main);
    main.addDockWidget(Qt::LeftDockWidgetArea, dockl);

    QDockWidget *dockr = new QDockWidget ("DOCK2", &main);
    main.addDockWidget(Qt::RightDockWidgetArea, dockr);

    main.show();

    return app.exec();
}
