#ifndef CALCBACKGROUNDCOLOR_H
#define CALCBACKGROUNDCOLOR_H

#include <QWidget>
#include <QSlider>
#include <QLayout>

class CalcBackgroundColor : public QWidget
{
    Q_OBJECT
public:
    CalcBackgroundColor(QWidget *parent = 0) : QWidget(parent)
    {

    }

private:
    QSlider *red_slider, *green_slider, *blue_slider;
    QVBoxLayout *pvboxlayout;

signals:
    void signalChangeBkColor (int);

public slots:
    void slotChangeBkColor (int);

};

#endif // CALCBACKGROUNDCOLOR_H
