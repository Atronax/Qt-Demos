#include "calcbackgroundcolor.h"

void CalcBackgroundColor::slotChangeBkColor(int value)
{
    emit signalChangeBkColor(value);
}
