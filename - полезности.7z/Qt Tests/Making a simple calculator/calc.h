#ifndef CALC_H
#define CALC_H

#include <QtWidgets>

class QLCDNumber;
class QPushButton;

class Calculator : public QWidget
{
    Q_OBJECT

public:
    Calculator (QWidget *parent = 0) : QWidget (parent), dialogBackground (NULL)
    {
        plcdn = new QLCDNumber (20);
        plcdn->setStyleSheet("*{border: 2px solid black; border-top-color: red; border-bottom-color: red; background: #FFF8DC; border-radius: 10;} \
                              *:hover{border: 2px solid red; border-radius:5px; opacity:0.2;}");
        plcdn->setSegmentStyle (QLCDNumber::Flat);
        plcdn->setFixedHeight(50);

        plbl = new QLabel ("ЗАМАНулятор!");
        plbl->setAlignment(Qt::AlignCenter);
        plbl->setFont(QFont("mister bold", 14, false, true));
        plbl->setFrameShape(QFrame::Box);

        QChar chButtons[6][4] = {
                                 {'7','8','9','/'},
                                 {'4','5','6','x'},
                                 {'1','2','3','-'},
                                 {'.','0','=','+'},
                                 {'K','C','%','S'},
                                 {'B','O','D','H'}
                                };

        QGridLayout *pgridlayout = new QGridLayout (this);
        pgridlayout->addWidget(plcdn, 0, 0, 1, 4);
        pgridlayout->addWidget(CreateButton("CE"), 1, 3);
        pgridlayout->addWidget(plbl, 1, 0, 1, 3);

        for (int i = 0; i < 6; ++i)
            for (int j = 0; j < 4; ++j)
                pgridlayout->addWidget(CreateButton(chButtons[i][j]),i+2,j);

        setLayout(pgridlayout);
    }

    QPushButton *CreateButton (const QString &str);
    void Calculate ();

private:
    QStack<QString> strstck;
    QString strdisplay;

    QLCDNumber *plcdn;
    QMenu *pmenu;
    QLabel *plbl;

    QDialog *dialogBackground;

public slots:
    void slotDialogBackground (void);
    void slotChangeBkColor(int value);
    void slotButtonClicked();
    void slotButtonReleased();
};

#endif // CALC_H
