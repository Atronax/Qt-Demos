#include "calc.h"

void Calculator::slotButtonClicked()
{
    QString str = ((QPushButton *)sender())->text(); // принимаем текст кнопки в качестве str

    if (str == "CE")
    {
        strstck.clear();
        strdisplay = "";
        plcdn->display("0");
        return;
    }

    if (str.contains(QRegExp("[0-9]")))
    {
        strdisplay += str;
        plcdn->display(strdisplay.toDouble());
    }
    else if (str == ".")
    {
        strdisplay += str;
        plcdn->display(strdisplay);
    }
    else
    {
        if (strstck.count() < 2)
        {
            strstck.push(QString().setNum(plcdn->value()));
            strstck.push(str);

            strdisplay = "";
        }
        else
        {
            strstck.push(QString().setNum(plcdn->value()));
            Calculate();
            strstck.clear();
            strstck.push(QString().setNum(plcdn->value()));

            if (str != "=")
                strstck.push(str);
        }
    }
}

void Calculator::slotButtonReleased()
{
    QString str = ((QPushButton *)sender())->text();
}

QPushButton* Calculator::CreateButton(const QString &str)
{
    QPushButton *ppb = new QPushButton (str);

    ppb->setMinimumSize(36,36);

    connect(ppb, SIGNAL(clicked()), SLOT(slotButtonClicked()));
    connect(ppb, SIGNAL(released()), SLOT(slotButtonReleased()));

    if (str == "S")
    {
        pmenu = new QMenu(ppb);
        pmenu->addAction ("Цвет фона", this, SLOT(slotDialogBackground()));
        pmenu->addAction ("Выход", qApp, SLOT(quit()));

        ppb->setMenu(pmenu);
    }

    if (str == "B")
        connect (ppb, SIGNAL(clicked()), plcdn, SLOT(setBinMode()));
    if (str == "O")
        connect (ppb, SIGNAL(clicked()), plcdn, SLOT(setOctMode()));
    if (str == "D")
        connect (ppb, SIGNAL(clicked()), plcdn, SLOT(setDecMode()));
    if (str == "H")
        connect (ppb, SIGNAL(clicked()), plcdn, SLOT(setHexMode()));

    if (str.contains(QRegExp("[0-9.CE]")))
        ppb->setStyleSheet("*{background: #FFF8DC; border: 2px solid black;} \
                            *:hover{background: #FFFCFC; border: 3px double red; border-radius:10px;}");

    if (str.contains(QRegExp("[BODH]")))
        ppb->setStyleSheet("*{background: #E6DFC6; border: 2px solid black; border-radius: 5px} \
                            *:hover{background: #777777; border: 3px double red; border-radius:10px;}");

    if (str == "/" || str == "x" || str == "-" || str == "+" || str == "S" || str == "%" || str == "K" || str == "C")
    {
        if (str == "%")
            ppb->setToolTip("Процент n (1оп.) от числа m (2оп.).");

        if (str == "K")
            ppb->setToolTip("Корень степеня n (1оп.) из числа m (2оп.).");

        if (str == "C")
            ppb->setToolTip("Степень n (2оп.) из числа m (1оп.).");

        ppb->setStyleSheet("*{background: #FFA584; border: 2px solid black; border-radius: 5px} \
                            *:hover{background: #FF8C62; border: 3px double red; border-radius:10px;}");
    }

    if (str == "=")
        ppb->setStyleSheet("*{background: #B0C4DE; border: 2px solid black; border-radius: 5px} \
                            *:hover{background: #F0F8FF; border: 3px double red; border-radius:10px;}");
    return ppb;
}

void Calculator::Calculate()
{
    double dOperand2 = strstck.pop().toDouble();
    QString strOperator = strstck.pop();
    double dOperand1 = strstck.pop().toDouble();
    double dResult = 0;

    if (strOperator == "+")
        dResult = dOperand1 + dOperand2;

    if (strOperator == "-")
        dResult = dOperand1 - dOperand2;

    if (strOperator == "x")
        dResult = dOperand1 * dOperand2;

    if (strOperator == "/")
        dResult = dOperand1 / dOperand2;

    if (strOperator == "K")
        dResult = pow (dOperand2, 1.0/dOperand1);

    if (strOperator == "C")
        dResult = pow (dOperand1, dOperand2);

    if (strOperator == "%")
        if (dOperand1 >= 0 && dOperand1 < 100)
            dResult = (dOperand1/100.0)*dOperand2;

    plcdn->display(dResult);
    strdisplay = "";
}

void Calculator::slotDialogBackground()
{
    if (!dialogBackground)
    {
        dialogBackground = new QDialog();

        QSlider *red_slider = new QSlider (Qt::Horizontal);
        red_slider->setRange (0, 255);
        red_slider->setTickPosition(QSlider::TicksBelow);
        red_slider->setValue(palette().background().color().red());
        red_slider->connect(red_slider, SIGNAL(valueChanged(int)), this, SLOT(slotChangeBkColor(int)));
        red_slider->setObjectName("RedSlider");

        QSlider *green_slider = new QSlider (Qt::Horizontal);
        green_slider->setRange (0, 255);
        green_slider->setTickPosition(QSlider::TicksBelow);
        green_slider->setValue(palette().background().color().green());
        green_slider->connect(green_slider, SIGNAL(valueChanged(int)), this, SLOT(slotChangeBkColor(int)));
        green_slider->setObjectName("GreenSlider");

        QSlider *blue_slider = new QSlider (Qt::Horizontal);
        blue_slider->setRange (0, 255);
        blue_slider->setTickPosition(QSlider::TicksBelow);
        blue_slider->setValue(palette().background().color().blue());
        blue_slider->connect(blue_slider, SIGNAL(valueChanged(int)), this, SLOT(slotChangeBkColor(int)));
        blue_slider->setObjectName("BlueSlider");

        QSlider *brush_style_slider = new QSlider (Qt::Horizontal);
        brush_style_slider->setRange(0, 14);
        brush_style_slider->setTickPosition(QSlider::TicksBelow);
        brush_style_slider->connect(brush_style_slider, SIGNAL(valueChanged(int)), this, SLOT(slotChangeBkColor(int)));
        brush_style_slider->setObjectName("BrushStyleSlider");

        QPushButton *pb_close = new QPushButton ("Закрыть");
        pb_close->connect(pb_close, SIGNAL(clicked()), dialogBackground, SLOT(hide()));

        QFormLayout *pformlayout = new QFormLayout (dialogBackground);
        pformlayout->addRow ("Красная компонента", red_slider);
        pformlayout->addRow ("Зеленая компонента", green_slider);
        pformlayout->addRow ("Синяя компонента", blue_slider);
        pformlayout->addRow ("Паттерн кисти", brush_style_slider);
        pformlayout->addWidget (pb_close);
        pformlayout->setAlignment(pb_close, Qt::AlignCenter);

        dialogBackground->setLayout(pformlayout);
        dialogBackground->setMinimumWidth(300);
        dialogBackground->show();
    }
    dialogBackground->show();
}

void Calculator::slotChangeBkColor(int value)
{
    QPalette pal = palette();
    QColor cur_color = palette().color(backgroundRole());

    int r = cur_color.red();
    int g = cur_color.green();
    int b = cur_color.blue();
    Qt::BrushStyle br_style = pal.brush(backgroundRole()).style();

    if (sender()->objectName() == "RedSlider")
        r = value;

    if (sender()->objectName() == "GreenSlider")
        g = value;

    if (sender()->objectName() == "BlueSlider")
        b = value;

    if (sender()->objectName() == "BrushStyleSlider")
        br_style = Qt::BrushStyle(value);

    pal.setBrush(backgroundRole(),QBrush(QColor(r,g,b), br_style));
    setPalette(pal);
}
