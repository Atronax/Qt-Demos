class Tree;

class Graph{
public:
    std::vector<Edge> outgoingEdges(const Node& from) const;
    std::vector<Edge> incomingEdges(const Node& to) const;
    std::vector<Node> outgoingNodes(const Node& from) const; // all ADJACENT nodes this node can go to
    std::vector<Node> incomingNodes(const Node& to) const; // all ADJACENT nodes that can come to this node
    bool contains(const Node& node) const;
    bool contains(const Edge& edge) const;
    std::vector<Node> shortestPath(const Node& from, const Node& to) const;
    Tree spt(const Node& source) const;

private:
    std::unordered_map<Node,Edge> updatedEdge_;

    // helper functions
    Edge edge(const Node& from, const Node& to) const;
    void unpickAll();
    void initializeNodeWeights(const Node& source);
    bool hasUnpickedNode() const;
    Node lightestUnpickedNode() const;
    void pickConnetedEdge(const Node& of);
    std::vector<Node> unpickedNeighbors(const Node& of) const;
    void updateNeighborWeights(const Node& of);

};

#endif // GRAPH_H