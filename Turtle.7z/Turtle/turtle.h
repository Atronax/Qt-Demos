#ifndef TURTLE_H
#define TURTLE_H

#include <QWidget>

#include <QPixmap>
#include <QBitmap>
#include <QPainter>

#include <QImage>
#include <QImageWriter>
#include <QDateTime>

class Turtle : public QWidget
{
    Q_OBJECT
public:
    explicit Turtle(QWidget *parent = 0)
        : QWidget (parent),
          pixmap (1000, 1000),
          painter (&pixmap)
    {
        setFixedSize(pixmap.size());
        initialize ();
    }

protected:
    virtual void paintEvent (QPaintEvent *ev);

    void initialize (void);

private:
    QPixmap pixmap;
    QPainter painter;

signals:

public slots:
    void slotForward (int iPixels);
    void slotBackward (int iPixels);
    void slotTurnLeft (int iAngle);
    void slotTurnRight (int iAngle);
    void slotReset (void);

    void slotSave (void);

};

#endif // TURTLE_H
