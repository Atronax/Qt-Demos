#include <QApplication>

#include "turtleplayground.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    TurtlePlayground turtle;
    turtle.show();

    return app.exec();
}
