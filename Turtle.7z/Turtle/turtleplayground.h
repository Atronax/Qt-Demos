#ifndef TURTLEPLAYGROUND_H
#define TURTLEPLAYGROUND_H

#include <QPointer>
#include <QThread>

#include <QWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include <QGridLayout>
#include <QMessageBox>

#include <QScriptEngine>

#include "turtle.h"

// styles
#define NICKOLAUS 0
#define CURLY 1
#define CIRCLE 2
#define FANTASY 3

class TurtlePlayground : public QWidget
{
    Q_OBJECT
public:
    explicit TurtlePlayground(QWidget *parent = 0) : QWidget (parent)
    {
        initTurtle();
        initInterpreterTextedit();
        initStylesCombobox();
        initEvaluateButton();
        initSaveButton();
        initStopButton();
        initLayout();
    }

private:
    void initTurtle (void);
    void initInterpreterTextedit (void);
    void initStylesCombobox (void);
    void initEvaluateButton (void);
    void initSaveButton (void);
    void initStopButton (void);
    void initLayout (void);

    QScriptEngine javascript;

    Turtle* turtle;
    QTextEdit* interpreter;
    QComboBox* styles;
    QPushButton *pbEvaluate, *pbSave, *pbStop;

signals:

public slots:
    void slotEvaluate (void);
    void slotStopEvaluating (void);
    void slotApplyCode (int);
};

#endif // TURTLEPLAYGROUND_H
