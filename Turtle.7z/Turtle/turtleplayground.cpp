#include "turtleplayground.h"

// HELPER FUNCTIONS
void TurtlePlayground::initTurtle()
{
    turtle = QPointer<Turtle>(new Turtle);

    QScriptValue script_turtle = javascript.newQObject(turtle);
    javascript.globalObject().setProperty("turtle", script_turtle);
}

void TurtlePlayground::initInterpreterTextedit()
{
    interpreter = QPointer<QTextEdit>(new QTextEdit);
}

void TurtlePlayground::initStylesCombobox()
{
    styles = QPointer<QComboBox>(new QComboBox);
    QStringList list_of_styles (QStringList() << "Haus vom Nikolaus"
                                              << "Curly"
                                              << "Circle"
                                              << "Fantasy");
    styles->addItems(list_of_styles);
    connect (styles, SIGNAL(activated(int)), this, SLOT(slotApplyCode(int)));

    slotApplyCode(NICKOLAUS);
}

void TurtlePlayground::initEvaluateButton()
{
    pbEvaluate = QPointer<QPushButton>(new QPushButton (tr("Исполнить")));
    connect (pbEvaluate, SIGNAL(clicked()), this, SLOT(slotEvaluate()));
}

void TurtlePlayground::initSaveButton()
{
    pbSave = QPointer<QPushButton>(new QPushButton (tr("Сохранить")));
    pbSave->setIcon(QIcon("e:/emblem.png"));
    pbSave->setIconSize(QSize(30, 30));
    connect (pbSave, SIGNAL(clicked()), turtle, SLOT(slotSave()));
}

void TurtlePlayground::initStopButton()
{
    pbStop = QPointer<QPushButton>(new QPushButton (tr("Остановить")));
    connect (pbStop, SIGNAL(clicked()), this, SLOT(slotStopEvaluating()));
}

void TurtlePlayground::initLayout()
{
    QGridLayout* layout = QPointer<QGridLayout>(new QGridLayout);
    layout->addWidget(styles, 0, 0);
    layout->addWidget(interpreter, 1, 0);
    layout->addWidget(turtle, 0, 1, 2, 1);
    layout->addWidget(pbEvaluate, 2, 0, 1, 1);
    layout->addWidget(pbSave, 3, 0, 1, 1);
    layout->addWidget(pbStop, 4, 0, 1, 1);

    setLayout(layout);
}

// SLOTS
void TurtlePlayground::slotApplyCode(int iStyle)
{
    QString code;

    switch (iStyle)
    {
    case NICKOLAUS:
        code = "var distance = 100; \n"
               "turtle.slotReset(); \n"
               "turtle.slotTurnRight(90); \n"
               "turtle.slotBackward(-distance); \n"
               "turtle.slotTurnLeft(90); \n"
               "turtle.slotForward(distance); \n"
               "turtle.slotTurnLeft(30); \n"
               "turtle.slotForward(distance); \n"
               "turtle.slotTurnLeft(120); \n"
               "turtle.slotForward(distance); \n"
               "turtle.slotTurnLeft(30); \n"
               "turtle.slotForward(distance); \n"
               "turtle.slotTurnLeft(135); \n"
               "turtle.slotForward(Math.sqrt(2)*distance); \n"
               "turtle.slotTurnLeft(135); \n"
               "turtle.slotForward(distance); \n"
               "turtle.slotTurnLeft(135); \n"
               "turtle.slotForward(Math.sqrt(2)*distance); \n";
        break;

    case CURLY:
        code = "turtle.slotReset(); \n"
               "for (i = 0; i < 2; ++i) \n"
               "{ \n"
               "    for (j = 0; j < 100; ++j) \n"
               "    { \n"
               "        turtle.slotForward (15); \n"
               "        turtle.slotTurnLeft (100 - j); \n"
               "    } \n"
               "    turtle.slotTurnRight (180); \n"
               "} \n";
        break;

    case CIRCLE:
        code = "turtle.slotReset(); \n"
               "for (i = 0; i < 360; ++i) \n"
               "{ \n"
               "    turtle.slotForward(1); \n"
               "    turtle.slotTurnLeft(1); \n"
               "} \n";
        break;

    case FANTASY: default:
        code = "turtle.slotReset(); \n"
               "for (i = 0; i < 200; ++i) \n"
               "{ \n"
               "    turtle.slotForward (2*i); \n"
               "    turtle.slotTurnLeft (91); \n"
               "} \n";
        break;
    }

    interpreter->setPlainText(code);
}

void TurtlePlayground::slotEvaluate()
{
    QScriptValue result = javascript.evaluate(interpreter->toPlainText());    

    if (result.isError())
        QMessageBox::critical(this, tr("Ошибка исполнения Javascript-кода"), result.toString(), QMessageBox::Yes);
}

void TurtlePlayground::slotStopEvaluating()
{
    QMessageBox::warning(this, tr("На этапе разработки"), tr("Кнопка \"Стоп\" еще не запрограммирована. \
                                                             Нужно исполнять код javascript в отдельном потоке."));
    // javascript.abortEvaluation();
}
