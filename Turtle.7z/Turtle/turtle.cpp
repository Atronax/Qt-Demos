#include "turtle.h"

void Turtle::initialize()
{
    pixmap.fill( QColor::fromRgb(240, 248, 255) );
    painter.translate(rect().center());
    painter.rotate(-90.0);
}

void Turtle::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED (ev);

    QPainter main_painter (this);
    main_painter.drawPixmap(rect(), pixmap);
}

// SLOTS

void Turtle::slotForward(int iPixels)
{
    // painter.drawLine(0, 0, iPixels, 0);
    painter.drawPixmap(0, 0, 10, 10, QPixmap("d:/a" + QString::number(1 + rand()%5) + ".jpg"));
    // painter.drawPixmap(0, 0, 100, 100, QPixmap("e:/Arxon/Фотоальбом/2012-11-24/IMG_" + QString::number(4413 + rand()%55) + ".JPG"));
    painter.translate(iPixels, 0);

    repaint();
}

void Turtle::slotBackward(int iPixels)
{
    // painter.drawLine(0, 0, -iPixels, 0);
    painter.drawPixmap(0, 0, 10, 10, QPixmap("d:/a" + QString::number(1 + rand()%5) + ".jpg"));
    // painter.drawPixmap(0, 0, 100, 100, QPixmap("e:/Arxon/Фотоальбом/2012-11-24/IMG_" + QString::number(4413 + rand()%55) + ".JPG"));
    painter.translate(-iPixels, 0);

    repaint();
}

void Turtle::slotTurnLeft(int iAngle)
{
    painter.rotate(-iAngle);
}

void Turtle::slotTurnRight(int iAngle)
{
    painter.rotate(iAngle);
}

void Turtle::slotReset()
{
    painter.resetMatrix();
    initialize();

    repaint();
}

void Turtle::slotSave(void)
{
    // QList<QByteArray> supported_formats = QImageWriter::supportedImageFormats();
    // foreach (QByteArray format, supported_formats)
    //    qDebug (format);

    QBitmap mask = pixmap.createMaskFromColor(QColor::fromRgb(240, 248, 255));
    QPixmap to_save = pixmap.copy(0, 0, pixmap.width(), pixmap.height());
    to_save.setMask(mask);
    to_save.save("Turtle_pixmap" + QDateTime::currentDateTime().toString("(dd.MM.yy-HH.mm.ss)") + ".png", "png", 100);
}
