#ifndef FACTORY3DMODEL_H
#define FACTORY3DMODEL_H

#include "abstract3dmodel.h"

#include "obj.h"
//#include "3ds.h"
//#include "fbx.h"

class Factory3DModel
{
public:
    Abstract3DModel* create_obj_model ();
    // Abstract3DModel* create_3ds_model ();
    // Abstract3DModel* create_fbx_model ();
};

#endif // FACTORY3DMODEL_H
