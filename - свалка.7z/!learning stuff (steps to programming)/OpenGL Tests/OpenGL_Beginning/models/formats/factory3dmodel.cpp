#include "factory3dmodel.h"

Abstract3DModel* Factory3DModel::create_obj_model()
{
    return new Obj ();
}
