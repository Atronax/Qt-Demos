#ifndef OBJ_H
#define OBJ_H

#include "abstract3dmodel.h"
#include <QGLFunctions>

class Obj : public Abstract3DModel, private QGLFunctions
{
public:
    explicit Obj();
    ~Obj();

    bool loadModelMesh (const QString& filepath);
    bool loadModelMaterial (const QString& filepath);
    void renderModel();
    void releaseModel();

private:
    Vertex parseVertexData (const QString& string);
    Normal parseNormalData (const QString& string);
    Texcoord parseTexcoordData (const QString& string);    

    GLuint uiVBOVertices, uiVBONormals, uiVBOTexcoords;
    GLint iVerticesCount, iVerticesInFaceCount;

    GLuint uiTextureAmbient;
};

#endif // OBJ_H
