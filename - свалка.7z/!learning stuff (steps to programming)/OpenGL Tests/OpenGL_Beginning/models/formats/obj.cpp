// LOGIC
#include <QFile>
#include <QVector>

#include "obj.h"

Obj::Obj()
{
    initializeGLFunctions();
}

Obj::~Obj()
{

}

bool Obj::loadModelMesh(const QString& filepath)
{
    QFile file(filepath);
    if (file.exists())
    {
        file.open(QFile::ReadOnly | QFile::Text);

        QVector<Vertex> vTempVertices, vVertices;
        QVector<Normal> vTempNormals, vNormals;
        QVector<Texcoord> vTempTexcoords, vTexcoords;

        QVector<GLuint> vVerticesIndices, vNormalsIndices, vTexcoordsIndices;

        while (!file.atEnd())
        {
            QString strCurrentLine = file.readLine();

            if (strCurrentLine.at(0) == "#") // commentaries
                continue;
            else if (strCurrentLine.at(0) == "v" && strCurrentLine.at(1) == " ") // vertices
                vTempVertices.push_back(parseVertexData(strCurrentLine));
            else if (strCurrentLine.at(0) == "v" && strCurrentLine.at(1) == "t") // texcoords
                vTempTexcoords.push_back(parseTexcoordData(strCurrentLine));
            else if (strCurrentLine.at(0) == "v" && strCurrentLine.at(1) == "n") // normals
                vTempNormals.push_back(parseNormalData(strCurrentLine));
            else if (strCurrentLine.at(0) == "f") // face indicies
            {
                GLint iCounter = 0;

                QStringList slCurrentLine = strCurrentLine.split(" ", QString::SkipEmptyParts);
                iVerticesInFaceCount = slCurrentLine.size() - 2;

                GLuint *uiVertexIndex = new GLuint [iVerticesInFaceCount];
                GLuint *uiTexcoordIndex = new GLuint [iVerticesInFaceCount];
                GLuint *uiNormalIndex = new GLuint [iVerticesInFaceCount];

                foreach (QString elem, slCurrentLine)
                {
                    if (elem.contains(QRegExp("[0-9]{1,5}/[0-9]{1,5}/[0-9]{1,5}"))) // up to 99999 vertexes
                    {
                        QStringList slCurrentElem = elem.split("/", QString::SkipEmptyParts);

                        uiVertexIndex[iCounter] = slCurrentElem.at(0).toInt(); // vertex index
                        uiTexcoordIndex[iCounter] = slCurrentElem.at(1).toInt(); // texcoord index
                        uiNormalIndex[iCounter] = slCurrentElem.at(2).toInt(); // normal index

                        iCounter++;
                    }
                }

                for (GLint i = 0; i < iVerticesInFaceCount; ++i)
                {
                    vVerticesIndices.push_back(uiVertexIndex[i]);
                    vTexcoordsIndices.push_back(uiTexcoordIndex[i]);
                    vNormalsIndices.push_back(uiNormalIndex[i]);
                }

               delete [] uiVertexIndex;
               uiVertexIndex = NULL;

               delete [] uiTexcoordIndex;
               uiTexcoordIndex = NULL;

               delete [] uiNormalIndex;
               uiNormalIndex = NULL;
            }
        }

        file.close();

        // placing vertices, normals, texcoords in order
        for (GLint i = 0; i < vVerticesIndices.size(); ++i)
        {
            Vertex CurrentVertex = vTempVertices[vVerticesIndices[i] - 1];
            vVertices.push_back(CurrentVertex);
        }

        for (GLint i = 0; i < vNormalsIndices.size(); ++i)
        {
            Normal CurrentNormal = vTempNormals[vNormalsIndices[i] - 1];
            vNormals.push_back(CurrentNormal);
        }

        for (GLint i = 0; i < vTexcoordsIndices.size(); ++i)
        {
            Texcoord CurrentTexcoord = vTempTexcoords[vTexcoordsIndices[i] - 1];
            vTexcoords.push_back(CurrentTexcoord);
        }

        iVerticesCount = vVertices.length();

        glGenBuffers(1, &uiVBOVertices);
        glBindBuffer(GL_ARRAY_BUFFER, uiVBOVertices);
        glBufferData(GL_ARRAY_BUFFER, iVerticesCount * 3 * sizeof(GLfloat), &vVertices[0], GL_STATIC_DRAW);

        glGenBuffers(1, &uiVBONormals);
        glBindBuffer(GL_ARRAY_BUFFER, uiVBONormals);
        glBufferData(GL_ARRAY_BUFFER, iVerticesCount * 3 * sizeof(GLfloat), &vNormals[0], GL_STATIC_DRAW);

        glGenBuffers(1, &uiVBOTexcoords);
        glBindBuffer(GL_ARRAY_BUFFER, uiVBOTexcoords);
        glBufferData(GL_ARRAY_BUFFER, iVerticesCount * 2 * sizeof(GLfloat), &vTexcoords[0], GL_STATIC_DRAW);

        return true;
    }
    else
    {
        file.close();
        return false;
    }

}

Vertex Obj::parseVertexData (const QString& strCurrent)
{
    GLfloat fTempBuffer[3] = {0};
    GLint iCounter = 0;

    // отсекаем пустЫе строки во избежание появления дополнительных нулей
    QStringList slCurrentLine = strCurrent.split(" ", QString::SkipEmptyParts);
    foreach (QString elem, slCurrentLine)
    {
        if (!elem.contains(QRegExp("v")))
            fTempBuffer[iCounter++] = elem.toFloat();
    }

    Vertex vCurrentVertex;
    vCurrentVertex.x = fTempBuffer[0];
    vCurrentVertex.y = fTempBuffer[1];
    vCurrentVertex.z = fTempBuffer[2];

    return vCurrentVertex;
}

Texcoord Obj::parseTexcoordData (const QString& strCurrent)
{
    GLfloat fTempBuffer[3] = {0};
    GLint iCounter = 0;

    QStringList slCurrentLine = strCurrent.split(" ", QString::SkipEmptyParts);
    foreach (QString elem, slCurrentLine)
    {
        if (!elem.contains(QRegExp("vt")))
            fTempBuffer[iCounter++] = elem.toFloat();
    }

    Texcoord vCurrentTexcoord;
    vCurrentTexcoord.u = fTempBuffer[0];
    vCurrentTexcoord.v = fTempBuffer[1];

    return vCurrentTexcoord;
}

Normal Obj::parseNormalData (const QString& strCurrent)
{
    GLfloat fTempBuffer[3] = {0};
    GLint iCounter = 0;

    QStringList slCurrentLine = strCurrent.split(" ", QString::SkipEmptyParts);
    foreach (QString elem, slCurrentLine)
    {
        if (!elem.contains(QRegExp("vn")))
            fTempBuffer[iCounter++] = elem.toFloat();
    }

    Normal vCurrentNormal;
    vCurrentNormal.nx = fTempBuffer[0];
    vCurrentNormal.ny = fTempBuffer[1];
    vCurrentNormal.nz = fTempBuffer[2];

    return vCurrentNormal;
}

bool Obj::loadModelMaterial (const QString& filepath) // TO DO
{
    QFile file(filepath);
    if (file.exists())
    {
        file.open(QFile::ReadOnly | QFile::Text);
        while (!file.atEnd())
        {
            QString strCurrentLine = file.readLine();

            if (strCurrentLine.at(0) == "#") // commentaries
                continue;
            else if (strCurrentLine.at(0) == "\t" && strCurrentLine.at(1) == "m") // all maps
            {
                qDebug (strCurrentLine.toUtf8());

                QStringList slCurrentLine = strCurrentLine.split(" ", QString::SkipEmptyParts);
                if (slCurrentLine.at(0) == "\tmap_Ka")
                {
                    QString strAmbientTextureFilepath = slCurrentLine.at(1);
                    QImage amb_texture = QGLWidget::convertToGLFormat(QImage(strAmbientTextureFilepath));

                    Q_ASSERT(!amb_texture.isNull());

                    glGenTextures (1, &uiTextureAmbient);
                    glBindTexture (GL_TEXTURE_2D, uiTextureAmbient);
                    glTexImage2D  (GL_TEXTURE_2D, 0, 3,  GLsizei (amb_texture.width()), GLsizei (amb_texture.height()),
                                   0, GL_RGBA, GL_UNSIGNED_BYTE, amb_texture.bits());

                    // настройка дополнительных параметров текстурных обьектов
                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

                    glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
                }
            }
        }

        file.close();
    }
    else
    {
        file.close();
        return false;
    }
    return true;
}

void Obj::renderModel()
{
    glPushMatrix();
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
            glBindBuffer(GL_ARRAY_BUFFER, uiVBOTexcoords);
            // glBindTexture(GL_TEXTURE_2D, uiTextureAmbient);

            glTexCoordPointer(2, GL_FLOAT, 0, NULL);

            glEnableClientState(GL_NORMAL_ARRAY);
            glBindBuffer(GL_ARRAY_BUFFER, uiVBONormals);
            glNormalPointer(GL_FLOAT, 0, NULL);

                glEnableClientState(GL_VERTEX_ARRAY);
                    glBindBuffer (GL_ARRAY_BUFFER, uiVBOVertices);
                    glVertexPointer(3, GL_FLOAT, 0, NULL);

                    glPushMatrix();
                        if (iVerticesInFaceCount == 3)
                            glDrawArrays(GL_TRIANGLES, 0, iVerticesCount);
                        else if (iVerticesInFaceCount == 4)
                            glDrawArrays(GL_QUADS, 0, iVerticesCount);
                    glPopMatrix();

                    /*
                    glPointSize (4.0f);
                    glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
                    glDisable (GL_LIGHTING);
                    glDisable (GL_TEXTURE_2D);
                        glPushMatrix();
                            glDrawArrays(GL_POINTS, 0, iVerticesCount);
                        glPopMatrix();
                    glEnable (GL_TEXTURE_2D);
                    glEnable (GL_LIGHTING);
                    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    */

                glDisableClientState(GL_VERTEX_ARRAY);

            glDisable (GL_NORMAL_ARRAY);
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glPopMatrix();
}

void Obj::releaseModel()
{
    glDeleteTextures(1, &uiTextureAmbient);
    glDeleteBuffers(1, &uiVBOVertices);
    glDeleteBuffers(1, &uiVBONormals);
    glDeleteBuffers(1, &uiVBOTexcoords);
}
