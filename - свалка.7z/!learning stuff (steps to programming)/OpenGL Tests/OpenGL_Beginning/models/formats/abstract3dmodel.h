#ifndef ABSTRACT3DMODEL_H
#define ABSTRACT3DMODEL_H

#include <QtOpenGL>

class QString;

typedef struct TAG_VERTEX
{
    GLfloat x;
    GLfloat y;
    GLfloat z;
} Vertex;

typedef struct TAG_NORMAL
{
    GLfloat nx;
    GLfloat ny;
    GLfloat nz;
} Normal;

typedef struct TAG_TEXCOORD
{
    GLfloat u;
    GLfloat v;
} Texcoord;

class Abstract3DModel
{
public:
    virtual bool loadModelMesh (const QString& filepath) = 0;
    virtual bool loadModelMaterial (const QString& filepath) = 0;
    virtual void renderModel() = 0;
    virtual void releaseModel() = 0;
};

#endif // ABSTRACT3DMODEL_H
