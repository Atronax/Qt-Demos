﻿// logic
#include <QTimer>
#include <QVector3D>

#include "models/formats/factory3dmodel.h"
#include "models/formats/abstract3dmodel.h"
#include "models/formats/obj.h"

// events
#include <QMouseEvent>

#include "scene.h"

Scene::Scene(QWidget* parent, const QGLWidget *share, Qt::WindowFlags flags)
    : QGLWidget(parent, share, flags)
{
    context()->makeCurrent();
    initializeGLFunctions(context());
    glInit();

    initUpdater();
    initCamera();
    initModels();

}

Scene::~Scene()
{
    model_boxes->releaseModel();
    delete model_boxes;
    delete model_factory;
    delete updater;
    if (parent() == nullptr)
        delete this;
}

// helping functions
void Scene::initUpdater()
{
    updater = new QTimer(this);
    updater->setInterval(1000/40);
    connect(updater, SIGNAL(timeout()), this, SLOT(updateGL()));

    updater->start();
}

void Scene::initCamera()
{
    eye_posX = eye_posY = eye_posZ = 0.0f;
    cam_angX = cam_angY = 0.0f;
    cam_height = 0.0f;
}

void Scene::initModels()
{
    selectedName = -1;

    model_factory = new Factory3DModel;
    model_boxes = model_factory->create_obj_model();
    model_boxes->loadModelMesh("D:/thor.obj");
}

// opengl trio
void Scene::initializeGL()
{
    qglClearColor(Qt::black);

    glEnable (GL_DEPTH_TEST);
    glEnable (GL_CULL_FACE);
    glFrontFace(GL_CCW);

    glEnable (GL_LIGHTING);

    // GLfloat fLightModel[] = {0.5f, 0.5f, 0.5f};
    // glLightModelfv(GL_AMBIENT, fLightModel);

    GLfloat fLight0Position[] = {0.0f, 50.0f, 0.0f};
    GLfloat fLight0Diffuse[]  = {0.8f, 0.7f, 0.7f};
    glLightfv (GL_LIGHT0, GL_DIFFUSE,  fLight0Diffuse);
    glLightfv (GL_LIGHT0, GL_POSITION, fLight0Position);
    glEnable (GL_LIGHT0);

    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glMaterialf(GL_FRONT, GL_SHININESS, 128.0f);
    glEnable(GL_COLOR_MATERIAL);
}

void Scene::resizeGL(int w, int h)
{
    if (h == 0)
        h = 1;

    GLfloat aspect_ratio = static_cast<GLfloat>(w)/static_cast<GLfloat>(h);

    glMatrixMode (GL_PROJECTION);
        glLoadIdentity();

        glViewport(0, 0, w, h);
        gluPerspective(60.0f, aspect_ratio, 0.01f, 500.0f);

    glMatrixMode (GL_MODELVIEW);
        glLoadIdentity();
}

void Scene::paintGL()
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushMatrix();
        gluLookAt( eye_posX, eye_posY + cam_height, eye_posZ,
                   eye_posX - sin(cam_angX/180*GLT_PI),
                   eye_posY + tan(cam_angY/180*GLT_PI),
                   eye_posZ - cos(cam_angX/180*GLT_PI),
                   0.0f, 1.0f, 0.0f);

        drawObjects();
    glPopMatrix();
}

void Scene::drawObjects()
{
    glInitNames();
    glPushName(DEFAULT_NAME);

    glPushMatrix();        
        if (selectedName == PLANE_NAME)
            glColor3f(0.0f, 0.0f, 1.0f);
        else
            glColor3f(1.0f, 0.0f, 0.0f);
        glLoadName(PLANE_NAME);
            drawPlane();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(30.0f, 4.9f, 0.0f);
        if (selectedName == BOX_NAME)
            glColor3f(0.0f, 0.0f, 1.0f);
        else
            glColor3f(0.0f, 1.0f, 0.0f);
        glLoadName(BOX_NAME);
            drawBox(5.0f);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.0f, 4.9f, 0.0f);
        if (selectedName == SPHERE_NAME)
        {
            glScalef(1.5f, 1.5f, 1.5f);
            glColor3f(0.0f, 0.0f, 1.0f);
        }
        else
            glColor3f(1.0f, 1.0f, 0.0f);
        glLoadName(SPHERE_NAME);
            drawSphere(5.0f);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-30.0f, 0.0f, 0.0f);
        glScalef(0.3f, 0.3f, 0.3f);
        if (selectedName == BOXES_NAME)
        {
            glScalef(1.5f, 1.5f, 1.5f);
            glColor3f(0.0f, 0.0f, 1.0f);
        }
        else
            glColor3f(0.0f, 1.0f, 1.0f);
        glLoadName(BOXES_NAME);
            model_boxes->renderModel();
    glPopMatrix();
}

// events
void Scene::keyPressEvent(QKeyEvent *ev)
{
    switch (ev->key())
    {
    case Qt::Key_W: case Qt::Key_Up:
        eye_posX -= (GLfloat) sin(cam_angX/180*GLT_PI)*CAM_SPEED;
        eye_posZ -= (GLfloat) cos(cam_angX/180*GLT_PI)*CAM_SPEED;
        break;

    case Qt::Key_A: case Qt::Key_Left:
        eye_posX += (GLfloat) sin((cam_angX - 90)/180*GLT_PI)*CAM_SPEED;
        eye_posZ += (GLfloat) cos((cam_angX - 90)/180*GLT_PI)*CAM_SPEED;
        break;

    case Qt::Key_S: case Qt::Key_Down:
        eye_posX += (GLfloat) sin(cam_angX/180*GLT_PI)*CAM_SPEED;
        eye_posZ += (GLfloat) cos(cam_angX/180*GLT_PI)*CAM_SPEED;
        break;

    case Qt::Key_D: case Qt::Key_Right:
        eye_posX += (GLfloat) sin((cam_angX + 90)/180*GLT_PI)*CAM_SPEED;
        eye_posZ += (GLfloat) cos((cam_angX + 90)/180*GLT_PI)*CAM_SPEED;
        break;

    case Qt::Key_Q: case Qt::Key_Plus:
        eye_posY += CAM_SPEED;
        break;

    case Qt::Key_E: case Qt::Key_Minus:
        eye_posY -= CAM_SPEED;
        break;

    default:
        break;
    }
}

void Scene::mousePressEvent(QMouseEvent *ev)
{
    if (ev->modifiers() == Qt::ShiftModifier)
    {
        if (ev->button() == Qt::LeftButton)
        {
            selectedName = selectItemAt(ev->localPos());
            qDebug(QString("selected name is " + QString::number(selectedName)).toUtf8());
            if (selectedName == PLANE_NAME)
                qDebug ("PLANE selected");
            else if (selectedName == BOX_NAME)
                qDebug ("BOX selected");
            else if (selectedName == BOXES_NAME)
                qDebug (QString("OBJ работать").toUtf8());
            else if (selectedName == SPHERE_NAME)
                qDebug ("SPHERE selected");            
        }
    }

    if (ev->button() == Qt::LeftButton)
        mouse_pos = ev->pos();
}

void Scene::mouseMoveEvent(QMouseEvent *ev)
{
    cam_angX += (mouse_pos.x()-ev->x())/MOUSE_SENSIVITY;
    cam_angY += (mouse_pos.y()-ev->y())/MOUSE_SENSIVITY;
    mouse_pos = ev->pos();

    if (cam_angY > 90.0f)
        cam_angY = 90.0f;

    if (cam_angY < -90.0f)
        cam_angY = -90.0f;
}


// models
void Scene::drawBox(const GLfloat& size)
{
    glBegin (GL_QUADS);
        // передняя грань
        glNormal3f (0.0f, 0.0f, 1.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (size, size, size);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (-size, size, size);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-size, -size, size);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (size, -size, size);

        // задняя грань
        glNormal3f (0.0f, 0.0f, -1.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (size, size, -size);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (size, -size, -size);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-size, -size, -size);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-size, size, -size);

        // верхняя грань
        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (size, size, -size);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (-size, size, -size);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-size, size, size);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (size, size, size);

        // нижняя грань
        glNormal3f (0.0f, -1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (size, -size, -size);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (size, -size, size);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-size, -size, size);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-size, -size, -size);

        // правая грань
        glNormal3f (1.0f, 0.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (size, size, size);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (size, -size, size);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (size, -size, -size);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (size, size, -size);

        // левая грань
        glNormal3f (-1.0f, 0.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-size, size, size);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-size, size, -size);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (-size, -size, -size);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (-size, -size, size);
    glEnd ();
}

void Scene::drawSphere (const GLfloat& radius)
{
    GLUquadricObj *pObject = gluNewQuadric();
        gluQuadricNormals (pObject, GLU_SMOOTH);
        gluSphere (pObject, radius, 30, 30);
    gluDeleteQuadric (pObject);
}

void Scene::drawPlane()
{
    glBegin (GL_QUADS);
        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-50.0f, -0.2f, -50.0f);

        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-50.0f, -0.2f, 50.0f);

        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (50.0f, -0.2f, 50.0f);

        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (50.0f, -0.2f, -50.0f);
    glEnd();
}

// 3d selection
int Scene::selectItemAt(const QPointF &pos)
{
    int result = -1;    

    const int max_size = 64;
    GLuint buffer [max_size] = {0};
    glSelectBuffer(max_size, buffer);

    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
        glRenderMode(GL_SELECT);
        glLoadIdentity();
        gluPickMatrix(pos.x(), viewport[3]-pos.y(), 2, 2, viewport);
        gluPerspective(60.0f, static_cast<GLfloat>(viewport[2])/viewport[3], 0.1f, 500.0f);
        //=отрисовка с точки зрения камеры и получение результатов выборки=//
        glMatrixMode(GL_MODELVIEW);
            glPushMatrix();
                gluLookAt( eye_posX, eye_posY + cam_height, eye_posZ,
                           eye_posX - sin(cam_angX/180*GLT_PI),
                           eye_posY + tan(cam_angY/180*GLT_PI),
                           eye_posZ - cos(cam_angX/180*GLT_PI),
                           0.0f, 1.0f, 0.0f);
                drawObjects();
                GLint hits = glRenderMode(GL_RENDER);
                if (hits == 1)
                    result = buffer[3];
                else if (hits != 0)
                {
                    for (int i = 0; i < max_size; ++i)
                    {
                        if (buffer[i] == 0)
                        {
                            result = buffer[i-1];
                            break;
                        }
                    }
                }
            glPopMatrix();
        glMatrixMode(GL_PROJECTION);
        //==================================================================//
    glPopMatrix();
    glMatrixMode (GL_MODELVIEW);    

    return result;
}

void Scene::calculateSelectionRay (const QPoint& mouse_pos, QVector3D& point1, QVector3D& point2)
{
    GLint viewport[4];
    GLdouble modelview_matrix[16], projection_matrix[16];
    GLdouble viewport_mouseX, viewport_mouseY, viewport_mouseZ;
    GLdouble world_mouseX, world_mouseY, world_mouseZ;

    glGetIntegerv(GL_VIEWPORT, viewport);
    glGetDoublev(GL_MODELVIEW_MATRIX, modelview_matrix);
    glGetDoublev(GL_PROJECTION_MATRIX, projection_matrix);

    // screen mouse pos -> viewport mouse pos
    viewport_mouseX = mouse_pos.x();
    viewport_mouseY = viewport[3] - mouse_pos.y() - 1;

    // ray near end
    viewport_mouseZ = -1.0;
    gluUnProject(viewport_mouseX, viewport_mouseY, viewport_mouseZ,
                 modelview_matrix, projection_matrix, viewport,
                 &world_mouseX, &world_mouseY, &world_mouseZ);
    point1 = QVector3D(world_mouseX, world_mouseY, world_mouseZ);

    // ray far end
    viewport_mouseZ = 1.0;
    gluUnProject(viewport_mouseX, viewport_mouseY, viewport_mouseZ,
                 modelview_matrix, projection_matrix, viewport,
                 &world_mouseX, &world_mouseY, &world_mouseZ);
    point2 = QVector3D(world_mouseX, world_mouseY, world_mouseZ);
}

// layout
QSize Scene::sizeHint() const
{
    return QSize (1000, 1000);
}

QSizePolicy Scene::sizePolicy() const
{
    return QSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
}
