#ifndef SCENE_H
#define SCENE_H

#include <QGLWidget>
#include <QGLFunctions>

#include "tools/GLTools.h" // desktop opengl and vector/matrix tools

class Factory3DModel;
class Abstract3DModel;
class Obj;

class Scene : public QGLWidget, private QGLFunctions
{
    Q_OBJECT

public:
    explicit Scene (QWidget* parent = 0, const QGLWidget* share = 0, Qt::WindowFlags flags = 0);
    ~Scene();

protected:
    void initializeGL();
    void resizeGL(int w, int h);
    void paintGL();

    void keyPressEvent(QKeyEvent *ev);
    void mousePressEvent(QMouseEvent *ev);
    void mouseMoveEvent(QMouseEvent *ev);

    QSize sizeHint() const;
    QSizePolicy sizePolicy() const;

private:
    void initUpdater();
    void initCamera();
    void initModels();

    void drawPlane ();
    void drawBox (const GLfloat& doubled_size);
    void drawSphere (const GLfloat& radius);
    void drawObjects ();

    // 3d selection
    int selectItemAt (const QPointF& pos);
    void calculateSelectionRay (const QPoint& mouse_pos, QVector3D& point1, QVector3D& point2);
    enum {DEFAULT_NAME = 0, PLANE_NAME = 1, BOX_NAME = 2, SPHERE_NAME = 3, BOXES_NAME = 4};
    GLint selectedName;

    // updater
    QTimer *updater;

    // camera
    enum {CAM_SPEED = 1, MOUSE_SENSIVITY = 2};
    GLfloat eye_posX, eye_posY, eye_posZ;
    GLfloat cam_angX, cam_angY;
    GLfloat cam_height;
    QPointF mouse_pos;

    // models
    Factory3DModel *model_factory;
    Abstract3DModel *model_boxes;


signals:

public slots:
};

#endif // SCENE_H
