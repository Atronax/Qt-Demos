#include "particlesystem.h"

void ParticleSystem::SetCurrentCameraPosition (GLdouble camera_xpos, GLdouble camera_ypos, GLdouble camera_zpos)
{
	fCamera_XPos = camera_xpos;
	fCamera_YPos = camera_ypos;
	fCamera_ZPos = camera_zpos;
}

void ParticleSystem::InitParticle (GLint iNumParticle)
{	
	storage[iNumParticle].fLifespan = 1.0f;			
	storage[iNumParticle].fFade = (1 + rand()%100)/1000.0f;

	storage[iNumParticle].fVelocity = 0.3f;

	storage[iNumParticle].fPosX = (GLfloat) (-3000 + 100*fCamera_XPos + rand()%6001)*0.01f;
	storage[iNumParticle].fPosY = (GLfloat) fCamera_YPos;
	storage[iNumParticle].fPosZ = (GLfloat) (-3000 + 100*fCamera_ZPos + rand()%6001)*0.01f;		
}

void ParticleSystem::DrawParticles (GLint iTypeParticle)
{
	glDisable (GL_LIGHTING);
	glEnable (GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glBindTexture (GL_TEXTURE_2D, NULL);	
    glColor4f (0.8f, 0.8f, 0.8f, 0.5f);

    for (GLint i = 0; i < NUM_OF_PARTICLES; i++)
	{
		switch (iTypeParticle)
		{
		case RAIN:
			glBegin (GL_LINES);
				glVertex3f (storage[i].fPosX, storage[i].fPosY, storage[i].fPosZ);
				glVertex3f (storage[i].fPosX, storage[i].fPosY - 0.01f*(1+rand()%3), storage[i].fPosZ + 0.01f*(1+rand()%3));
			glEnd ();

			storage[i].fPosY -= (storage[i].fVelocity) * cos (storage[i].fLifespan);
			storage[i].fPosZ += storage[i].fVelocity * sin (storage[i].fLifespan);
			storage[i].fLifespan -= storage[i].fFade;
			break;

		case BOXES:	
			glPushMatrix ();
				glTranslatef (storage[i].fPosX, storage[i].fPosY, storage[i].fPosZ);
                glVertex3f (storage[i].fPosX, storage[i].fPosY, storage[i].fPosZ);
                // DrawCube (0.01f); // TO DO
			glPopMatrix ();

			storage[i].fPosY -= (storage[i].fVelocity/2) * cos (storage[i].fLifespan);
			storage[i].fPosZ += storage[i].fVelocity/2 * sin (storage[i].fLifespan);
			storage[i].fLifespan -= storage[i].fFade;		
			break;

		case HAIL:
			glPushMatrix ();
				glTranslatef (storage[i].fPosX, storage[i].fPosY, storage[i].fPosZ);
				glPointSize (5.0f);
				glBegin (GL_POINTS);
					glVertex3f (storage[i].fPosX, storage[i].fPosY, storage[i].fPosZ);					
				glEnd ();
			glPopMatrix ();

			storage[i].fPosY -= (storage[i].fVelocity) * cos (storage[i].fLifespan);
			storage[i].fPosZ += storage[i].fVelocity * sin (storage[i].fLifespan);
			storage[i].fLifespan -= storage[i].fFade;
			break;
        }

		if (storage[i].fPosY <= -1.0f)
			storage[i].fLifespan = -1.0f;

        if (storage[i].fLifespan < 0.0f)
			InitParticle(i);
	}

	glDisable (GL_BLEND);
	glEnable (GL_LIGHTING);
}
