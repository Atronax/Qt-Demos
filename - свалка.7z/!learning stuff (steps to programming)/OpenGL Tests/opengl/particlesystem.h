#include <gl/glew.h>
#include <QWidget>
#include <QEvent>

// TYPES OF PARTICLES
#define NUM_OF_PARTICLES 10000
#define RAIN 1
#define BOXES 2
#define HAIL 3

typedef struct TAG_GLPARTICLESYSTEM
{
	GLfloat fLifespan, fFade;
	GLfloat fVelocity, fGravity;	
	GLfloat fPosX, fPosY, fPosZ;	
} GLparticles;

class ParticleSystem
{
public:
    ParticleSystem (GLdouble camera_xpos, GLdouble camera_ypos, GLdouble camera_zpos)
    {
        fCamera_XPos = camera_xpos;
        fCamera_YPos = camera_ypos;
        fCamera_ZPos = camera_zpos;
    }

    ~ParticleSystem ()
    {
        delete this;
    }

	void SetCurrentCameraPosition (GLdouble camera_xpos, GLdouble camera_ypos, GLdouble camera_zpos);
    void InitParticle (GLint iNumParticle);
	void DrawParticles (GLint iTypeParticle);

private:
	GLparticles storage [NUM_OF_PARTICLES];
    GLdouble fCamera_XPos, fCamera_YPos, fCamera_ZPos; // CAMERA POSITION
};

