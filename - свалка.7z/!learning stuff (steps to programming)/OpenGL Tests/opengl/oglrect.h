#ifndef OGLRECT_H
#define OGLRECT_H

#include <gl/glew.h>
#include <QGLWidget>
#include <QKeyEvent>
#include <QEvent>

#include <QTimer>

#include "drawableobjects.h"
#include "particlesystem.h"

#define COLOR_STEP 0.0039f

class OGLRect : public QGLWidget
{
    Q_OBJECT
public:
    OGLRect(QWidget *parent = 0) : QGLWidget (parent)
    {
        fTranslateX = fTranslateY = fTranslateZ = 0.0f;
        fRotateX = fRotateY = 0;

        fLight0Red = fLight0Green = fLight0Blue = 0.0f;

        fPlanetXRotation = fPlanetYRotation = fPlanetZRotation = 0.0f;
        fTorusXRotation = fTorusYRotation = fTorusZRotation = 0.0f;

        connect (&timer, SIGNAL(timeout()), this, SLOT(updateGL()));
        timer.setInterval(17);
        timer.start();
    }

    ~OGLRect ()
    {
        delete test_ps;

        if (parent() == NULL)
            delete this;
    }

    GLuint createBoxDL (GLfloat size);
    GLuint createPlaneDL ();

protected:
    virtual void initializeGL();
    virtual void resizeGL(int w, int h);
    virtual void paintGL();

    virtual void mousePressEvent(QMouseEvent *ev);
    virtual void mouseMoveEvent(QMouseEvent *ev);
    virtual void wheelEvent (QWheelEvent *ev);

    virtual QSize sizeHint() const;
    virtual QSizePolicy sizePolicy() const;

    virtual bool event(QEvent *ev);

private:
    QTimer timer;

    GLfloat fTranslateX, fTranslateY, fTranslateZ; // CAMERA TRANSLATION
    GLfloat fRotateX, fRotateY; // CAMERA ROTATION
    QPoint ptMousePosition; // CAMERA ROTATION

    GLfloat fLight0Red, fLight0Green, fLight0Blue;    

    QImage *box_texture; // BOX TEXTURE
    QImage *plane_texture; // GROUND TEXTURE
    QImage *sphere_texture; // SPHERE TEXTURE

    GLfloat fPlanetXRotation, fPlanetYRotation, fPlanetZRotation; // PLANET WITH TORUSES VARS
    GLfloat fTorusXRotation, fTorusYRotation, fTorusZRotation; // PLANET WITH TORUSES VARS

    GLuint uiBoxDL, uiGroundDL;

    ParticleSystem *test_ps;

signals:

public slots:

};

#endif // OGLRECT_H
