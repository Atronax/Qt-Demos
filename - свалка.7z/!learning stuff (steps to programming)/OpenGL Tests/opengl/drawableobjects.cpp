#include "drawableobjects.h"

void DrawableObjects::DrawBox(GLfloat fCubeSize)
{
    glBegin (GL_QUADS);
        // передняя грань
        glNormal3f (0.0f, 0.0f, 1.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, fCubeSize);

        // задняя грань
        glNormal3f (0.0f, 0.0f, -1.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, -fCubeSize);

        // верхняя грань
        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, -fCubeSize);

        // нижняя грань
        glNormal3f (0.0f, -1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, -fCubeSize, -fCubeSize);

        // правая грань
        glNormal3f (1.0f, 0.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, -fCubeSize);

        // левая грань
        glNormal3f (-1.0f, 0.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, -fCubeSize);
    glEnd ();
}

void DrawableObjects::DrawPlane()
{
    glBegin (GL_QUADS);
        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-20.0f, -0.5f, -20.0f);

        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-20.0f, -0.5f, 20.0f);

        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (20.0f, -0.5f, 20.0f);

        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (20.0f, -0.5f, -20.0f);
    glEnd();
}

void DrawableObjects::DrawGround()
{
    GLfloat fExtent = 60.0f;
    GLfloat fStep = 0.5f, fTexStep = 1.0f / (fExtent * 0.005f);
    GLfloat s = 0.0f, t = 0.0f;

    for (GLfloat iStrip = -fExtent; iStrip <= fExtent; iStrip += fStep)
    {
        t = 0.0f;
        glBegin (GL_TRIANGLE_STRIP);
            for (GLfloat iRun = fExtent; iRun >= -fExtent; iRun -= fStep)
            {
                glTexCoord2f (s, t);
                glNormal3f (0.0f, 1.0f, 0.0f);
                glVertex3f (iStrip, 0.5f*cos(iStrip)*sin(iRun), iRun);

                glTexCoord2f (s + fTexStep, t);
                glNormal3f (0.0f, 1.0f, 0.0f);
                glVertex3f (iStrip + fStep, 0.5f*cos(iStrip+fStep)*sin(iRun), iRun);

                t += fTexStep;
            }
        glEnd ();
        s += fTexStep;
    }
}

void DrawableObjects::DrawSphere(GLfloat fRadius, GLint iSlices, GLint iStacks)
{
    GLfloat drho = (GLfloat) GLT_PI / (GLfloat) iStacks;
    GLfloat dtheta = 2.0f * (GLfloat) GLT_PI / (GLfloat) iSlices;
    GLfloat ds = 1.0f / (GLfloat) iSlices, dt = 1.0f / (GLfloat) iStacks;
    GLfloat s = 0.0f, t = 1.0f;

    for (GLint i = 0; i < iStacks; i++)
    {
        GLfloat rho = (GLfloat)i * drho;
        GLfloat srho = (GLfloat)(sin(rho)), crho = (GLfloat)(cos(rho));
        GLfloat srhodrho = (GLfloat)(sin(rho + drho)), crhodrho = (GLfloat)(cos(rho + drho));

        glBegin(GL_TRIANGLE_STRIP);
            s = 0.0f;
            for (GLint j = 0; j <= iSlices; j++)
            {
                GLfloat theta = (j == iSlices) ? 0.0f : j * dtheta;
                GLfloat stheta = (GLfloat)(-sin(theta)), ctheta = (GLfloat)(cos(theta));

                GLfloat x = stheta * srho, y = ctheta * srho, z = crho;

                glTexCoord2f(s, t);
                glNormal3f(x, y, z);
                glVertex3f(x * fRadius, y * fRadius, z * fRadius);

                x = stheta * srhodrho;
                y = ctheta * srhodrho;
                z = crhodrho;

                glTexCoord2f(s, t - dt);
                glNormal3f(x, y, z);
                glVertex3f(x * fRadius, y * fRadius, z * fRadius);

                s += ds;
            }
        glEnd();
        t -= dt;
    }
}

void DrawableObjects::DrawSnowman()
{
    GLUquadricObj *pQuadricObj = gluNewQuadric ();
    gluQuadricDrawStyle (pQuadricObj, GLU_FILL);
    gluQuadricNormals (pQuadricObj, GLU_SMOOTH);
    gluQuadricOrientation (pQuadricObj, GLU_OUTSIDE);
    gluQuadricTexture (pQuadricObj, GL_FALSE);

    glPushMatrix ();
        // тело снеговика
        glColor3f (1.0f, 1.0f, 1.0f);
        gluSphere (pQuadricObj, 0.4f, 30, 15);
        glTranslatef (0.0f, 0.45f, 0.0f);
        gluSphere (pQuadricObj, 0.3f, 30, 15);
        glTranslatef (0.0f, 0.35f, 0.0f);
        gluSphere (pQuadricObj, 0.2f, 30, 15);

        // глаза
        glColor3f (0.0f, 0.0f, 0.0f);
        glTranslatef (0.08f, 0.12f, 0.14f);
        gluSphere (pQuadricObj, 0.02f, 15, 15);
        glTranslatef (-0.16f, 0.0f, 0.0f);
        gluSphere (pQuadricObj, 0.02f, 15, 15);

        // нос
        glColor3f (1.0f, 0.3f, 0.3f);
        glTranslatef (0.08f, -0.1f, 0.0f);
        gluCylinder (pQuadricObj, 0.04f, 0.0f, 0.3f, 20, 20);
    glPopMatrix ();

    glPushMatrix ();
        // шляпа
        glColor4f (0.0f, 0.0f, 0.0f, 1.0f);
        glTranslatef (0.0f, 0.935f, 0.0f);
        glRotatef (-90.0f, 1.0f, 0.0f, 0.0f);
        gluCylinder (pQuadricObj, 0.15f, 0.15f, 0.4f, 20, 20);
        gluDisk (pQuadricObj, 0.0f, 0.15f, 20, 20);

        glDisable (GL_CULL_FACE);
            gluDisk (pQuadricObj, 0.15f, 0.25f, 15, 10);
        glEnable (GL_CULL_FACE);

        glTranslatef(0.0f, 0.0f, 0.4f);
        gluDisk(pQuadricObj, 0.0f, 0.15f, 20, 20);
    glPopMatrix ();

}

void DrawableObjects::DrawJet()
{
    GLTVector3 vNormal;

    glBegin (GL_TRIANGLES);
        // передняя часть самолета
        glNormal3f (0.0f, -1.0f, 0.0f);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (0.0f, 0.0f, 60.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-15.0f, 0.0f, 30.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (15.0f, 0.0f, 30.0f);

        {
        GLTVector3 vPoints[3] = {{15.0f, 0.0f, 30.0f},
                                 {0.0f, 15.0f, 30.0f},
                                 {0.0f, 0.0f, 60.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, 0.0f, 60.0f},
                                 {0.0f, 15.0f, 30.0f},
                                 {-15.0f, 0.0f, 30.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        // тело угловатого самолета
        {
        GLTVector3 vPoints[3] = {{-15.0f, 0.0f, 30.0f},
                                 {0.0f, 15.0f, 30.0f},
                                 {0.0f, 0.0f, -56.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, 0.0f, -56.0f},
                                 {0.0f, 15.0f, 30.0f},
                                 {15.0f, 0.0f, 30.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{15.0f, 0.0f, 30.0f},
                                 {-15.0f, 0.0f, 30.0f},
                                 {0.0f, 0.0f, -56.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.5f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        // крылья
        {
        GLTVector3 vPoints[3] = {{0.0f, 2.0f, 27.0f},
                                 {-60.0f, 2.0f, -8.0f},
                                 {60.0f, 2.0f, -8.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (0.5f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{60.0f, 2.0f, -8.0f},
                                 {0.0f, 7.0f, -8.0f},
                                 {0.0f, 2.0f, 27.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.7f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{60.0f, 2.0f, -8.0f},
                                 {-60.0f, 2.0f, -8.0f},
                                 {0.0f, 7.0f, -8.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.5f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, 2.0f, 27.0f},
                                 {0.0f, 7.0f, -8.0f},
                                 {-60.0f, 2.0f, -8.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.5f, 1.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        // хвостовая секция
        {
        GLTVector3 vPoints[3] = {{-30.0f, -0.5f, -57.0f},
                                 {30.0f, -0.5f, -57.0f},
                                 {0.0f, -0.5f, -40.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.5f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, -0.5f, -40.0f},
                                 {30.0f, -0.5f, -57.0f},
                                 {0.0f, 4.0f, -57.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, 4.0f, -57.0f},
                                 {-30.0f, -0.5f, -57.0f},
                                 {0.0f, -0.5f, -40.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 0.5f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{30.0f, -0.5f, -57.0f},
                                 {-30.0f, -0.5f, -57.0f},
                                 {0.0f, 4.0f, -57.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.5f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, 0.5f, -40.0f},
                                 {3.0f, 0.5f, -57.0f},
                                 {0.0f, 25.0f, -65.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (0.0f, 0.2f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.7f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{0.0f, 25.0f, -65.0f},
                                 {-3.0f, 0.5f, -57.0f},
                                 {0.0f, 0.5f, -40.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.8f, 0.0f);
        glVertex3fv (vPoints[2]);
        }

        {
        GLTVector3 vPoints[3] = {{3.0f, 0.5f, -57.0f},
                                 {-3.0f, 0.5f, -57.0f},
                                 {0.0f, 25.0f, -65.0f}};
        gltGetNormalVector (vPoints[0], vPoints[1], vPoints[2], vNormal);
        glNormal3fv (vNormal);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3fv (vPoints[0]);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3fv (vPoints[1]);
        glTexCoord2f (0.5f, 1.0f);
        glVertex3fv (vPoints[2]);
        }
    glEnd ();
}

void DrawableObjects::DrawTorus(GLfloat fMajorCirclesRadius, GLfloat fMinorCirclesRadius,
                                GLint iMajorCirclesNum, GLint iMinorCirclesNum)
{
    GLTVector3 vNormal;
    GLdouble majorStep = 2.0f*GLT_PI / (GLfloat) iMajorCirclesNum;
    GLdouble minorStep = 2.0f*GLT_PI / (GLfloat) iMinorCirclesNum;

    for (GLint i = 0; i < iMajorCirclesNum; ++i)
    {
        double a0 = i * majorStep;
        double a1 = a0 + majorStep;
        GLfloat x0 = (GLfloat) cos(a0), y0 = (GLfloat) sin(a0);
        GLfloat x1 = (GLfloat) cos(a1), y1 = (GLfloat) sin(a1);

        glBegin(GL_TRIANGLE_STRIP);
            for (GLint j = 0; j <= iMinorCirclesNum; ++j)
            {
                double b = j * minorStep;
                GLfloat c = (GLfloat) cos(b);
                GLfloat r = fMinorCirclesRadius * c + fMajorCirclesRadius;
                GLfloat z = fMinorCirclesRadius * (GLfloat) sin(b);

                vNormal[0] = x0*c;
                vNormal[1] = y0*c;
                vNormal[2] = z/fMinorCirclesRadius;
                gltNormalizeVector(vNormal);

                glTexCoord2f((float)(i)/(float)(iMajorCirclesNum), (float)(j)/(float)(iMinorCirclesNum));
                glNormal3fv(vNormal);
                glVertex3f(x0*r, y0*r, z);

                vNormal[0] = x1*c;
                vNormal[1] = y1*c;
                vNormal[2] = z/fMinorCirclesRadius;
                gltNormalizeVector(vNormal);

                glTexCoord2f((float)(i+1)/(float)(iMajorCirclesNum), (float)(j)/(float)(iMinorCirclesNum));
                glNormal3fv(vNormal);
                glVertex3f(x1*r, y1*r, z);
            }
        glEnd();
    }
}

void DrawableObjects::DrawCompoundInitSpheres(GLTFrame frames_of_spheres[], GLint count_of_spheres)
{
    for (GLint iSphere = 0; iSphere < count_of_spheres; iSphere++)
        {
            gltInitFrame (&frames_of_spheres[iSphere]);

            frames_of_spheres[iSphere].vLocation[0] = (GLfloat) 0.1f * (-200 + rand() % 401);
            frames_of_spheres[iSphere].vLocation[1] = (GLfloat) 2 + rand() % 6;
            frames_of_spheres[iSphere].vLocation[2] = (GLfloat) 0.1f * (-200 + rand() % 401);
        }
}

void DrawableObjects::DrawCompoundDrawSpheres(GLTFrame frames_of_spheres[], GLint count_of_spheres)
{
    for (GLint i = 0; i < count_of_spheres; i++)
    {
        glPushMatrix ();
            gltApplyActorTransform (&frames_of_spheres [i]);

            glTranslatef (0.01f*(rand()%3), 0.01f*(rand()%3), 0.01f*(rand()%3));
            DrawSphere (0.01f*(15 + rand()%6), 18, 13);
        glPopMatrix ();
    }

}

void DrawableObjects::DrawCompoundPlanetWithToruses(GLfloat &fPlanetXRotation, GLfloat &fPlanetYRotation, GLfloat &fPlanetZRotation,
                                                    GLfloat &fTorusXRotation, GLfloat &fTorusYRotation, GLfloat &fTorusZRotation)
{
    glPushMatrix ();
        glRotatef (-fPlanetYRotation, 0.0f, 1.0f, 0.0f);
        glTranslatef (1.0f, 2.0f, 0.0f);
        DrawSphere (0.1f, 25, 25);
    glPopMatrix ();

    glPushMatrix ();
        glRotatef (fPlanetXRotation, 1.0f, 0.0f, 0.0f);
        glRotatef (fPlanetYRotation, 0.0f, 1.0f, 0.0f);
        glRotatef (fPlanetZRotation, 0.0f, 0.0f, 1.0f);
        DrawSphere (0.5f, 25, 25);
    glPopMatrix ();

    glPushMatrix ();
        glRotatef (fTorusXRotation, 1.0f, 0.0f, 0.0f);
        glRotatef (fTorusYRotation, 0.0f, 1.0f, 0.0f);
        glRotatef (fTorusZRotation, 0.0f, 0.0f, 1.0f);
        DrawTorus (0.9f, 0.02f, 60, 40);
    glPopMatrix ();

    glPushMatrix ();
        glRotatef (-fTorusXRotation, 1.0f, 0.0f, 0.0f);
        glRotatef (-fTorusYRotation, 0.0f, 1.0f, 0.0f);
        glRotatef (fTorusZRotation, 0.0f, 0.0f, 1.0f);
        DrawTorus (0.864f, 0.02f, 60, 40);
    glPopMatrix ();

    glPushMatrix ();
        glRotatef (fTorusXRotation, 1.0f, 0.0f, 0.0f);
        glRotatef (-fTorusYRotation, 0.0f, 1.0f, 0.0f);
        glRotatef (fTorusZRotation, 0.0f, 0.0f, 1.0f);
        DrawTorus (0.828f, 0.02f, 60, 40);
    glPopMatrix ();
}
