#include "oglrect.h"

void OGLRect::initializeGL()
{
    qglClearColor(Qt::black);
    glShadeModel(GL_SMOOTH);

    uiBoxDL = createBoxDL(0.5f);
    uiGroundDL = createPlaneDL ();

    sphere_texture = new QImage ("D:/sphere.jpg");

    test_ps = new ParticleSystem (0.0f, 4.0f, 0.0f);

    glEnable (GL_TEXTURE_2D);
    glEnable (GL_DEPTH_TEST);

    GLfloat fLight0Emmision[] = {1.0f, 0.0f, 0.0f};
    GLfloat fLight0Ambient[] = {1.0f, 1.0f, 1.0f};
    GLfloat fLight0Specular[] = {1.0f, 1.0f, 1.0f};
    GLfloat fLight0Position[] = {-1.0f, 1.0f, 1.0f};

    glLightfv (GL_LIGHT0, GL_EMISSION, fLight0Emmision);
    glLightfv (GL_LIGHT0, GL_AMBIENT,  fLight0Ambient);
    glLightfv (GL_LIGHT0, GL_SPECULAR, fLight0Specular);
    glLightfv (GL_LIGHT0, GL_POSITION, fLight0Position);
    glEnable (GL_LIGHT0);

    glEnable (GL_LIGHTING);
}

void OGLRect::resizeGL(int w, int h)
{
    if (h == 0)
        h = 1;

    glMatrixMode (GL_PROJECTION);
        glLoadIdentity ();

        glViewport (0, 0, w, h);
        GLfloat fAspectRatio = (GLfloat) w / (GLfloat) h;
        gluPerspective(45.0f, fAspectRatio, 0.1f, 40.0f);

    glMatrixMode (GL_MODELVIEW);
        glLoadIdentity ();

}

void OGLRect::paintGL()
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    GLfloat fLight0Diffuse[] = {fLight0Red, fLight0Green, fLight0Blue};
    glLightfv (GL_LIGHT0, GL_DIFFUSE, fLight0Diffuse);

    glPushMatrix();
        test_ps->DrawParticles(RAIN);

        glTranslatef (fTranslateX, fTranslateY, fTranslateZ);
        glRotatef (fRotateX, 1.0f, 0.0f, 0.0f);
        glRotatef (fRotateY, 0.0f, 1.0f, 0.0f);
            glCallList(uiBoxDL);
            glCallList(uiGroundDL);

        glPushMatrix();
            bindTexture(*sphere_texture);
            glTranslatef (0.0f, 1.5f, 0.0f);
            DrawableObjects::DrawCompoundPlanetWithToruses(fPlanetXRotation, fPlanetYRotation, fPlanetZRotation,
                                                           fTorusXRotation, fTorusYRotation, fTorusZRotation);

            fPlanetXRotation += 1.0f;
            fPlanetYRotation += 0.5f;
            fPlanetZRotation += 0.75f;

            fTorusXRotation += 1.2f;
            fTorusYRotation += 1.5f;
            fTorusZRotation += 1.0f;
        glPopMatrix();

   glPopMatrix();
}

bool OGLRect::event(QEvent *ev)
{
    if (ev->type() == QEvent::KeyPress)
    {
        QKeyEvent *keyev = static_cast<QKeyEvent*>(ev);

        switch (keyev->key())
        {
        case Qt::Key_Left: case Qt::Key_4:
            fTranslateX -= 0.1f;
            break;

        case Qt::Key_Right: case Qt::Key_6:
            fTranslateX += 0.1f;
            break;

        case Qt::Key_Up: case Qt::Key_8:
            fTranslateY += 0.1f;
            break;

        case Qt::Key_Down: case Qt::Key_2:
            fTranslateY -= 0.1f;
            break;

        default:
            break;
        }

        glDraw();
        return true;
    }
    else
        return QGLWidget::event(ev);
}

GLuint OGLRect::createBoxDL (GLfloat fSize)
{
    GLuint n = glGenLists(1);

    box_texture = new QImage("d:/mickey.png");
    glNewList (n, GL_COMPILE);        
        glPushMatrix ();
            bindTexture(*box_texture);
            DrawableObjects::DrawBox(fSize);
        glPopMatrix ();
        delete box_texture;
    glEndList();

    return n;
}

GLuint OGLRect::createPlaneDL ()
{
    GLuint n = glGenLists(1);

    plane_texture = new QImage ("d:/ground_15.jpg");
    glNewList(n, GL_COMPILE);
        glPushMatrix();
            bindTexture(*plane_texture);
            DrawableObjects::DrawPlane();
        glPopMatrix();
        delete plane_texture;
    glEndList();

    return n;
}

void OGLRect::mousePressEvent(QMouseEvent *ev)
{
    ptMousePosition = ev->pos();
}

void OGLRect::mouseMoveEvent(QMouseEvent *ev)
{
    fRotateX += 180*(GLfloat)(ev->y() - ptMousePosition.y()) / height();
    fRotateY += 180*(GLfloat)(ev->x() - ptMousePosition.x()) / width();
    ptMousePosition = ev->pos();

    updateGL();
}

void OGLRect::wheelEvent(QWheelEvent *ev)
{
    if (ev->modifiers() == Qt::ShiftModifier)
    {
        if (ev->delta() > 0 && fLight0Red >= 0.0f && fLight0Red <= 1.0f - COLOR_STEP)
            fLight0Red += COLOR_STEP;

        if (ev->delta() < 0 && fLight0Red >= 0.0f + COLOR_STEP && fLight0Red <= 1.0f)
            fLight0Red -= COLOR_STEP;
    }

    if (ev->modifiers() == Qt::ControlModifier)
    {
        if (ev->delta() > 0 && fLight0Green >= 0.0f && fLight0Green <= 1.0f - COLOR_STEP)
            fLight0Green += COLOR_STEP;

        if (ev->delta() < 0 && fLight0Green >= 0.0f + COLOR_STEP && fLight0Green <= 1.0f)
            fLight0Green -= COLOR_STEP;
    }

    if (ev->modifiers() == Qt::AltModifier)
    {
        if (ev->delta() > 0 && fLight0Blue >= 0.0f && fLight0Blue <= 1.0f - COLOR_STEP)
            fLight0Blue += COLOR_STEP;

        if (ev->delta() < 0 && fLight0Blue >= 0.0f + COLOR_STEP && fLight0Blue <= 1.0f)
            fLight0Blue -= COLOR_STEP;
    }

    if (ev->modifiers() == Qt::NoModifier)
    {
        if (ev->delta() > 0)
            fTranslateZ -= 0.1f;

        if (ev->delta() < 0)
            fTranslateZ += 0.1f;
    }

    updateGL();
}

QSize OGLRect::sizeHint() const
{
    return QSize(200,200);
}

QSizePolicy OGLRect::sizePolicy() const
{
    return QSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
}
