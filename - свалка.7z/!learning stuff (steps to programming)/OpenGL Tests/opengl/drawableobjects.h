#ifndef DRAWABLEOBJECTS_H
#define DRAWABLEOBJECTS_H

#include <gl/glew.h>
#include <QGLWidget>
#include "GLTools.h"
#include <QtMath>

class DrawableObjects
{
public:
    DrawableObjects() {}

    static void DrawBox (GLfloat fSize);
    static void DrawPlane ();
    static void DrawGround ();
    static void DrawSphere (GLfloat fRadius, GLint iSlices, GLint iStacks);
    static void DrawSnowman ();
    static void DrawJet ();
    static void DrawTorus (GLfloat fMajorCirclesRadius, GLfloat fMinorCirclesRadius,
                           GLint iMajorCirclesNum, GLint iMinorCirclesNum);

    static void DrawCompoundInitSpheres (GLTFrame frames_of_spheres[], GLint count_of_spheres);
    static void DrawCompoundDrawSpheres (GLTFrame frames_of_spheres[], GLint count_of_spheres);
    static void DrawCompoundPlanetWithToruses (GLfloat &fPlanetXRotation, GLfloat &fPlanetYRotation, GLfloat &fPlanetZRotation,
                                               GLfloat &fTorusXRotation, GLfloat &fTorusYRotation, GLfloat &fTorusZRotation);


};

#endif // DRAWABLEOBJECTS_H
