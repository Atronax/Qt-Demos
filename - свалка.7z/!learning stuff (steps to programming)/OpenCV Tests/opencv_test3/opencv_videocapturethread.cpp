// LOGIC
#include <QImage>
#include <QLineEdit>
#include <vector>

#include <opencv2/core/types_c.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/contrib/contrib.hpp>
#include "opencv_videocapturethread.h"

void OpenCV_VideoCaptureThread::initVariables()
{
    bAbortCapture = false;

    fKernel[KERNEL_SIZE] = {0.0};
    fKernel[5] = 1;

    iNoise = 100;

    blow = glow = rlow = 0;
    bhigh = ghigh = rhigh = 255;
}

void OpenCV_VideoCaptureThread::run ()
{
    cv::VideoCapture video (0);
    if (!video.isOpened())
    {
        video.release();
        return;
    }

    cv::Mat frame;
    while(!bAbortCapture)
    {        
        video >> frame;

        // 0. conversion to hsv
        // if (!frame.empty())
        //     cv::cvtColor(frame, frame, CV_BGR2HSV);

        // FRAME PROCESSING
            // 1. convolution filter        
        cv::Mat kernel_m = cv::Mat (3, 3, CV_32FC1, fKernel); // 32fc1
        cv::filter2D(frame, frame, 24, kernel_m, cvPoint(-1, -1));

            // 2. region of interest processing
        /*
        if (!frame.empty())
        {
            cv::Mat frame_ROI = frame(cv::Range(rand()%(frame.rows - 50), frame.rows), cv::Range(0, frame.cols));
            cv::Mat color = cv::Mat(frame_ROI.size(), frame_ROI.type(), cv::Scalar(200, 0, 0));            
            double dAlpha = 0.3;
            cv::addWeighted(color, dAlpha, frame_ROI, 1.0 - dAlpha, 0.0, frame_ROI); // adds transparency to frame
        }
        */

            // 3. morphology processing
        // cv::dilate(frame, frame, cv::Mat());
        // cv::morphologyEx(frame, frame, CV_MOP_GRADIENT, cv::Mat());

            // 4. threshold processing
        // cv::threshold(frame, frame, 50.0, 250.0, CV_THRESH_BINARY);
        // cv::adaptiveThreshold(frame, frame, 250.0, CV_ADAPTIVE_THRESH_GAUSSIAN_C, CV_THRESH_BINARY, 3, 1.0); // only grayscale

            // 5. color processing
        /*
        if (!frame.empty())
        {
            // qDebug(QString(QString::number(blow) + " " + QString::number(bhigh)).toUtf8());
            // qDebug(QString(QString::number(glow) + " " + QString::number(ghigh)).toUtf8());
            // qDebug(QString(QString::number(rlow) + " " + QString::number(rhigh) + "\n").toUtf8());

            std::vector<cv::Mat> layers;
            cv::split(frame, layers);

            cv::inRange(layers[0], cv::Scalar(blow), cv::Scalar(bhigh), layers[0]);
            cv::inRange(layers[1], cv::Scalar(glow), cv::Scalar(ghigh), layers[1]);
            cv::inRange(layers[2], cv::Scalar(rlow), cv::Scalar(rhigh), layers[2]);

            cv::merge(layers, frame);
        }        

            // 6. rand noise + pointer arithmetic
        for (int y = 0; y < frame.rows; ++y)
        {
            uchar* row_ptr = static_cast<uchar*>(frame.data + y*frame.step);
            for (int x = 0; x < frame.cols; ++x)
            {
                if (rand()%100 >= iNoise)
                {
                    row_ptr[3*x + 0] = rand()%255; // blue-row_ptr[3*x + 0] = 0;
                    row_ptr[3*x + 1] = rand()%255; // green-row_ptr[3*x + 1] = 0;
                    row_ptr[3*x + 2] = rand()%255; // red-row_ptr[3*x + 2] = 0;
                }
            }
        }        

        // if (!frame.empty())
        //     cv::cvtColor(frame, frame, CV_HSV2BGR);
        */

        QImage qtFrame = QImage(frame.data, frame.size().width, frame.size().height, frame.step, QImage::Format_RGB888);        
        emit sendImage(qtFrame);

        msleep(33);
    }

    video.release();
    frame.release();
}

void OpenCV_VideoCaptureThread::abortCapture()
{
    // не вызывается в closeevent, в деструкторах
    // чотакое нипанять
    qDebug("abortCapture called");
    bAbortCapture = true;
}

void OpenCV_VideoCaptureThread::onConvolutionFilterPressed()
{
    QString filter_str = static_cast<QLineEdit*>(sender())->text();
    QStringList kernel_values = filter_str.split(" ");
    if (kernel_values.size() == 9)
    {
        for (int i = 0; i < 9; ++i)
            fKernel[i] = kernel_values[i].toFloat();
    }
    else
        for (int i = 0; i < 9; ++i)
        {
            if (i == 5)
                fKernel[i] = 1;
            else
                fKernel[i] = 0;
        }
}

void OpenCV_VideoCaptureThread::onNoiseValueChanged(int new_val)
{
    iNoise = new_val;
}

void OpenCV_VideoCaptureThread::onColorChanged(int new_val)
{
    // qDebug (sender()->objectName().toUtf8());
    if (sender()->objectName() == "BMin")
        blow = new_val;
    if (sender()->objectName() == "BMax")
        bhigh = new_val;
    if (sender()->objectName() == "GMin")
        glow = new_val;
    if (sender()->objectName() == "GMax")
        ghigh = new_val;
    if (sender()->objectName() == "RMin")
        rlow = new_val;
    if (sender()->objectName() == "RMax")
        rhigh = new_val;
}

// float kernel[9] = {-0.1, 0.2, -0.1, 0.2,  3, 0.2, -0.1, 0.2, -0.1}; // яркость
// float kernel[9] = {-1, -2, -1, 0, 0, 0, 1, 2, 1}; // собель север
// float kernel[9] = {-1, 0, 1, -1, 0, 1, -1, 0, 1}; // рельеф
// float kernel[9] = {0, -2, 0, -2, 9, -2, 0, -2, 0}; // заострение
// float kernel[9] = {-2, -1, 0, -1, 1, 1, 0, 1, 2}; // выдавливание
