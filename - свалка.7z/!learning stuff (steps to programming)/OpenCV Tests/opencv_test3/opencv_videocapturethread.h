#ifndef OPENCV_VIDEOCAPTURETHREAD_H
#define OPENCV_VIDEOCAPTURETHREAD_H

#include <QImage>

#include <QVector>
#include <QThread>
#include <QMutexLocker>

#include <opencv2/opencv.hpp>

class OpenCV_VideoCaptureThread : public QThread
{
    Q_OBJECT

public:
    OpenCV_VideoCaptureThread(QObject *parent = 0)
        : QThread (parent)
    {
        initVariables();
    }

    virtual ~OpenCV_VideoCaptureThread()
    {
    }



protected:
    virtual void run ();

private:
    void initVariables ();

    volatile bool bAbortCapture; // unoptimized variable for stopping the thread

    enum kernel_enum {KERNEL_SIZE = 9}; // convolution filters data
    float fKernel[KERNEL_SIZE];

    int blow, glow, rlow; // color specific selection variables
    int bhigh, ghigh, rhigh;

    int iNoise; // noise control variable

signals:
    void sendImage (const QImage& image);

public slots:
    void abortCapture();

    void onConvolutionFilterPressed (void);
    void onNoiseValueChanged (int);
    void onColorChanged (int);
};

#endif // OPENCV_VIDEOCAPTURETHREAD_H

// QMutex mThreshold;
// double dThreshold;
