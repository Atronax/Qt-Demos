#ifndef OPENCVVIDEO_H
#define OPENCVVIDEO_H

#include <QApplication>
#include <QPushButton>
#include <QWidget>
#include <QLayout>

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace cv;

class OpenCVVideo : public QWidget
{
    Q_OBJECT
public:
    explicit OpenCVVideo(QWidget *parent = 0, const QString& filename = "d:/video.avi") :
        QWidget (parent),
        video (nullptr)
    {
        initializeOpenCVWindow(filename);

        bAbortCapture = false;

        QPushButton* pb_abort = new QPushButton ("Остановить просмотр");
        connect (pb_abort, SIGNAL(clicked()), this, SLOT(on_abort_clicked()));

        QHBoxLayout* layout = new QHBoxLayout;
        layout->addWidget(pb_abort);
        setLayout(layout);
    }

    ~OpenCVVideo()
    {

    }

    void playCapture (void);

protected:
    void cleanup ();
    void initializeOpenCVWindow (const QString& file);

private:
    CvCapture *video;
    cv::Mat frame;
    bool bAbortCapture;


signals:

public slots:
    void on_abort_clicked ();
};

#endif // OPENCVVIDEO_H
