// --------------------------------opencv learning
// --------------------------critical to cpu usage
// start only when no other cpu usage stuff opened

#include <QApplication>
#include "userinterface.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    UserInterface* ui = new UserInterface;
    ui->show();

    return app.exec();
}


