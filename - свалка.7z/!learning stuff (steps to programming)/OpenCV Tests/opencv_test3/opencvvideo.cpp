#include <string>

#include "opencvvideo.h"

void OpenCVVideo::initializeOpenCVWindow(const QString& file)
{
    namedWindow("original", CV_WINDOW_AUTOSIZE);
    video = cvCreateFileCapture(file.toStdString().data());
}


void OpenCVVideo::playCapture()
{
    while (!bAbortCapture)
    {
        frame = cv::Mat(cvQueryFrame(video));
        if (frame.empty())
        {
            cleanup();
            break;
        }

        // image processing

        imshow("original", frame);
        frame.release();

        waitKey(33);
    }
}

void OpenCVVideo::cleanup ()
{
    cvReleaseCapture(&video);
    cvDestroyWindow("original");
}

// SLOTS
void OpenCVVideo::on_abort_clicked()
{
    bAbortCapture = true;
}
