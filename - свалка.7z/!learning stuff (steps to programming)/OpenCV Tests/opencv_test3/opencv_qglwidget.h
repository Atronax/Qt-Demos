#ifndef OPENCV_QGLWIDGET_H_
#define OPENCV_QGLWIDGET_H_

#include <QtOpenGL/QtOpenGL>
#include <QtOpenGL/QGLWidget>

#include "opencv_videocapturethread.h"

#define CAM_SPEED_COEF 1.0f
#define MOUSE_SENSIVITY 2.0f
#define PI 3.1415926f

class OpenCV_QGLWidget: public QGLWidget
{
    Q_OBJECT

public:
    OpenCV_QGLWidget (QWidget *parent = 0, OpenCV_VideoCaptureThread* capture = 0, const QGLWidget *shareWidget = 0, Qt::WindowFlags f = 0)
        : QGLWidget (parent, shareWidget, f),
          video (capture)
    {
        setupWidget();
        initVariables();
        startCapturing();
    }

    virtual ~OpenCV_QGLWidget () // smth leaks, who knows what
    {

    }

protected:
    virtual void mousePressEvent(QMouseEvent *ev);
    virtual void mouseMoveEvent(QMouseEvent *ev);
    virtual void keyPressEvent(QKeyEvent *ev);    

    virtual void initializeGL();
    virtual void resizeGL(int width, int height);
    virtual void paintGL();

private:
    // opengl render functions
    void drawBox (const GLfloat&);
    void drawSphere (const GLfloat&, const GLint&, const GLint&);

    // functions for class use
    void setupWidget ();
    void initVariables ();
    void startCapturing ();

    OpenCV_VideoCaptureThread* video;
    QImage GLframe;

    bool isFirstTime; // text on frames vars
    int text_posx, text_posy;

    GLfloat fEyePosX, fEyePosY, fEyePosZ; // camera vars
    GLfloat fHeight;
    GLfloat fCamAngleX, fCamAngleY;
    QPoint mousePos;

    uint boxDL, sphereDL; // box display list and vars it needs
    GLfloat fRotationAngle;

public slots:
    void renderImage(const QImage& frame);
    void onSaveClicked ();    
};

#endif /* OPENCV_QGLWIDGET_H_ */
