#ifndef USERINTERFACE_H
#define USERINTERFACE_H

#include <QWidget>
#include <QSlider>
#include <QLineEdit>
#include <QDialog>
#include <QPushButton>
#include <QVBoxLayout>

#include "opencv_qglwidget.h"
#include "opencv_videocapturethread.h"

class UserInterface : public QWidget
{
    Q_OBJECT
public:
    explicit UserInterface(QWidget *parent = 0)
        :
        QWidget (parent),
        opencv (nullptr),
        capture (nullptr)
    {
        capture = new OpenCV_VideoCaptureThread (this);
        opencv = new OpenCV_QGLWidget (0, capture);

        convolution_filter = new QLineEdit;
        connect (convolution_filter, SIGNAL(returnPressed()), capture, SLOT(onConvolutionFilterPressed()));

        pb_save = new QPushButton(tr("Сохранить"));
        connect (pb_save, SIGNAL(clicked()), opencv, SLOT(onSaveClicked()));

        sl_noise = new QSlider(Qt::Horizontal);
        sl_noise->setRange(0, 100);
        sl_noise->setValue(100);
        connect (sl_noise, SIGNAL(valueChanged(int)), capture, SLOT(onNoiseValueChanged(int)));

        sl_color_bmin = new QSlider(Qt::Horizontal);
        sl_color_bmin->setObjectName("BMin");
        sl_color_bmin->setRange(0, 255);
        sl_color_bmin->setValue(0);
        connect (sl_color_bmin, SIGNAL(valueChanged(int)), capture, SLOT(onColorChanged(int)));

        sl_color_bmax = new QSlider(Qt::Horizontal);
        sl_color_bmax->setObjectName("BMax");
        sl_color_bmax->setRange(0, 255);
        sl_color_bmax->setValue(255);
        connect (sl_color_bmax, SIGNAL(valueChanged(int)), capture, SLOT(onColorChanged(int)));

        sl_color_gmin = new QSlider(Qt::Horizontal);
        sl_color_gmin->setObjectName("GMin");
        sl_color_gmin->setRange(0, 255);
        sl_color_gmin->setValue(0);
        connect (sl_color_gmin, SIGNAL(valueChanged(int)), capture, SLOT(onColorChanged(int)));

        sl_color_gmax = new QSlider(Qt::Horizontal);
        sl_color_gmax->setObjectName("GMax");
        sl_color_gmax->setRange(0, 255);
        sl_color_gmax->setValue(255);
        connect (sl_color_gmax, SIGNAL(valueChanged(int)), capture, SLOT(onColorChanged(int)));

        sl_color_rmin = new QSlider(Qt::Horizontal);
        sl_color_rmin->setObjectName("RMin");
        sl_color_rmin->setRange(0, 255);
        sl_color_rmin->setValue(0);
        connect (sl_color_rmin, SIGNAL(valueChanged(int)), capture, SLOT(onColorChanged(int)));

        sl_color_rmax = new QSlider(Qt::Horizontal);
        sl_color_rmax->setObjectName("RMax");
        sl_color_rmax->setRange(0, 255);
        sl_color_rmax->setValue(255);
        connect (sl_color_rmax, SIGNAL(valueChanged(int)), capture, SLOT(onColorChanged(int)));

        QHBoxLayout* colmin_layout = new QHBoxLayout;
        colmin_layout->addWidget(sl_color_bmin);
        colmin_layout->addWidget(sl_color_gmin);
        colmin_layout->addWidget(sl_color_rmin);

        QHBoxLayout* colmax_layout = new QHBoxLayout;
        colmax_layout->addWidget(sl_color_bmax);
        colmax_layout->addWidget(sl_color_gmax);
        colmax_layout->addWidget(sl_color_rmax);

        QVBoxLayout* layout = new QVBoxLayout;
        layout->addWidget(opencv);
        layout->addWidget(convolution_filter);        
        layout->addWidget(pb_save);
        layout->addWidget(sl_noise);
        layout->addLayout(colmin_layout);
        layout->addLayout(colmax_layout);
        setLayout(layout);
    }

    ~UserInterface()
    {
        capture->abortCapture();        
        if (capture->wait(5000))
        {
            qWarning("Thread deadlock detected");
            capture->terminate();
            capture->wait();
        }        
        delete opencv;
        delete capture;
        delete this;
    }

private:
    OpenCV_QGLWidget* opencv;
    OpenCV_VideoCaptureThread* capture;
    QLineEdit* convolution_filter;
    QPushButton *pb_save;
    QSlider* sl_noise;
    QSlider *sl_color_bmin, *sl_color_bmax, *sl_color_gmin, *sl_color_gmax, *sl_color_rmin, *sl_color_rmax;

signals:

public slots:
};

#endif // USERINTERFACE_H
