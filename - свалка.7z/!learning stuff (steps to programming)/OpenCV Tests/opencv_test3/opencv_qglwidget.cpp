// LOGIC
#include <QKeyEvent>
#include <QMouseEvent>
#include <QCloseEvent>

// GL
#include <gl/glu.h>

// HEADERREF
#include "opencv_qglwidget.h"

void OpenCV_QGLWidget::setupWidget()
{
    setMinimumSize(400, 400);
    setFocusPolicy(Qt::ClickFocus);
    setAttribute(Qt::WA_DeleteOnClose);
}

void OpenCV_QGLWidget::initVariables()
{
    text_posx = 0;
    text_posy = 0;

    isFirstTime = true;

    fEyePosX = 0.0f;
    fEyePosY = 0.0f;
    fEyePosZ = 0.0f;
    fHeight = 0.0f;
    fCamAngleX = 0.0f;
    fCamAngleY = 0.0f;

    fRotationAngle = 0.0f;
}

void OpenCV_QGLWidget::startCapturing()
{
    if (video)
    {        
        connect (video, SIGNAL(sendImage(const QImage&)), this, SLOT(renderImage(const QImage&)));
        video->start();
    }
}

void OpenCV_QGLWidget::initializeGL()
{
    glClearColor (0.0f, 0.0f, 0.0f, 1.0f);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);

    glEnable(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    boxDL = glGenLists(1);
    glNewList (boxDL, GL_COMPILE);
        glPushMatrix ();
            drawBox(25.0f);
        glPopMatrix ();
    glEndList();

    sphereDL = glGenLists(1);
    glNewList (sphereDL, GL_COMPILE);
        glPushMatrix ();
            drawSphere(25.0f, 30, 30);
        glPopMatrix ();
    glEndList();
}

void OpenCV_QGLWidget::resizeGL(int width, int height)
{
    if (height == 0)
        height = 1;

    glMatrixMode (GL_PROJECTION);
        glLoadIdentity();

        glViewport(0, 0, width, height);
        GLfloat fAspectRatio = (GLfloat) width / (GLfloat) height;
        gluPerspective(60.0f, fAspectRatio, 0.1f, 1500.0f);

    glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
}

void OpenCV_QGLWidget::paintGL()
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushMatrix();
        gluLookAt (fEyePosX, fEyePosY + fHeight, fEyePosZ,
                   fEyePosX - sin (fCamAngleX / 180*PI), fEyePosY + tan (fCamAngleY / 180*PI), fEyePosZ - cos (fCamAngleX / 180*PI),
                   0.0f, 1.0f, 0.0f);

        if (!GLframe.isNull())
        {
            GLframe = GLframe.scaled(size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);

            glTexImage2D (GL_TEXTURE_2D, 0, GL_RGBA, GLframe.width(), GLframe.height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, GLframe.bits());
            glPushMatrix();
                fRotationAngle += 0.25f;
                glRotatef(fRotationAngle, 1.0f, 1.0f, 1.0f);
                glCallList(sphereDL);
                // glCallList(boxDL);
            glPopMatrix();
        }
    glPopMatrix();
}

// SLOTS
void OpenCV_QGLWidget::renderImage(const QImage& frame)
{
    QImage received = frame;    
    if (!received.isNull())
    {
        if (isFirstTime)
        {
            text_posx = 0;
            text_posy = received.rect().height() - 15;
            isFirstTime = false;
        }

        QPainter text;
        text.begin(&received);
            text.setFont(QFont("Xiomara", 20));
            text.drawText(text_posx, text_posy, "канхветок");
            text.drawText(text_posx - 50, text_posy - 40, "купить");
            text.drawText(text_posx - 100, text_posy - 80, "нада");
        text.end();

        text_posx += 5;
        if (text_posx > received.width())
            text_posx = -120;
    }

    GLframe = received.mirrored();
    updateGL();
}

void OpenCV_QGLWidget::onSaveClicked()
{
    disconnect (video, SIGNAL(sendImage(const QImage&)), this, SLOT(renderImage(const QImage&)));
        QString filename = QFileDialog::getSaveFileName(0, QString(), QString(), "Png Screenshot (*.png)");
        GLframe.mirrored().save (filename, "png");
    connect (video, SIGNAL(sendImage(const QImage&)), this, SLOT(renderImage(const QImage&)));
}

// models
void OpenCV_QGLWidget::drawBox(const GLfloat& fCubeSize)
{
    glBegin (GL_QUADS);
        // передняя грань
        glNormal3f (0.0f, 0.0f, 1.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (-fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (fCubeSize, -fCubeSize, fCubeSize);

        // задняя грань
        glNormal3f (0.0f, 0.0f, -1.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, -fCubeSize);

        // верхняя грань
        glNormal3f (0.0f, 1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, fCubeSize, -fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, fCubeSize, -fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, fCubeSize);

        // нижняя грань
        glNormal3f (0.0f, -1.0f, 0.0f);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, -fCubeSize, -fCubeSize);

        // правая грань
        glNormal3f (1.0f, 0.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (fCubeSize, fCubeSize, -fCubeSize);

        // левая грань
        glNormal3f (-1.0f, 0.0f, 0.0f);
        glTexCoord2f (0.0f, 1.0f);
        glVertex3f (-fCubeSize, fCubeSize, fCubeSize);
        glTexCoord2f (0.0f, 0.0f);
        glVertex3f (-fCubeSize, fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 0.0f);
        glVertex3f (-fCubeSize, -fCubeSize, -fCubeSize);
        glTexCoord2f (1.0f, 1.0f);
        glVertex3f (-fCubeSize, -fCubeSize, fCubeSize);
    glEnd ();
}

void OpenCV_QGLWidget::drawSphere(const GLfloat& fRadius, const GLint& iSlices, const GLint& iStacks)
{
    GLfloat drho = (GLfloat) PI / (GLfloat) iStacks;
    GLfloat dtheta = 2.0f * (GLfloat) PI / (GLfloat) iSlices;
    GLfloat ds = 1.0f / (GLfloat) iSlices, dt = 1.0f / (GLfloat) iStacks;
    GLfloat s = 0.0f, t = 1.0f;

    for (GLint i = 0; i < iStacks; i++)
    {
        GLfloat rho = (GLfloat)i * drho;
        GLfloat srho = (GLfloat)(sin(rho)), crho = (GLfloat)(cos(rho));
        GLfloat srhodrho = (GLfloat)(sin(rho + drho)), crhodrho = (GLfloat)(cos(rho + drho));

        glBegin(GL_TRIANGLE_STRIP);
            s = 0.0f;
            for (GLint j = 0; j <= iSlices; j++)
            {
                GLfloat theta = (j == iSlices) ? 0.0f : j * dtheta;
                GLfloat stheta = (GLfloat)(-sin(theta)), ctheta = (GLfloat)(cos(theta));

                GLfloat x = stheta * srho, y = ctheta * srho, z = crho;

                glTexCoord2f(s, t);
                glNormal3f(x, y, z);
                glVertex3f(x * fRadius, y * fRadius, z * fRadius);

                x = stheta * srhodrho;
                y = ctheta * srhodrho;
                z = crhodrho;

                glTexCoord2f(s, t - dt);
                glNormal3f(x, y, z);
                glVertex3f(x * fRadius, y * fRadius, z * fRadius);

                s += ds;
            }
        glEnd();
        t -= dt;
    }
}

// EVENTS
void OpenCV_QGLWidget::keyPressEvent(QKeyEvent *ev)
{
    switch (ev->key())
    {
        case Qt::Key_W:
            fEyePosX -= (GLfloat) sin(fCamAngleX / 180*PI)*CAM_SPEED_COEF;
            fEyePosZ -= (GLfloat) cos(fCamAngleX / 180*PI)*CAM_SPEED_COEF;
            break;

        case Qt::Key_A:
            fEyePosX += (GLfloat) sin((fCamAngleX - 90) / 180*PI)*CAM_SPEED_COEF;
            fEyePosZ += (GLfloat) cos((fCamAngleX - 90) / 180*PI)*CAM_SPEED_COEF;
            break;

        case Qt::Key_S:
            fEyePosX += (GLfloat) sin(fCamAngleX / 180*PI)*CAM_SPEED_COEF;
            fEyePosZ += (GLfloat) cos(fCamAngleX / 180*PI)*CAM_SPEED_COEF;
            break;

        case Qt::Key_D:
            fEyePosX += (GLfloat) sin((fCamAngleX + 90) / 180*PI)*CAM_SPEED_COEF;
            fEyePosZ += (GLfloat) cos((fCamAngleX + 90) / 180*PI)*CAM_SPEED_COEF;
            break;

        case Qt::Key_F1:
            fEyePosY += CAM_SPEED_COEF;
            break;

        case Qt::Key_F2:
            fEyePosY -= CAM_SPEED_COEF;
            break;

        default:
            break;
    }

}

void OpenCV_QGLWidget::mousePressEvent(QMouseEvent *ev)
{
    mousePos = ev->pos();
}

void OpenCV_QGLWidget::mouseMoveEvent(QMouseEvent *ev)
{
    fCamAngleX += ((mousePos.x() - ev->x()) / MOUSE_SENSIVITY) * CAM_SPEED_COEF;
    fCamAngleY += ((mousePos.y() - ev->y()) / MOUSE_SENSIVITY) * CAM_SPEED_COEF;

    mousePos = ev->pos();

    if (fCamAngleY > 90.0f)
        fCamAngleY = 90.0f;

    if (fCamAngleY < -90.0f)
        fCamAngleY = - 90.0f;
}
