#include <QApplication>
#include <QWidget>
#include <Box2D/Box2D.h>

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    QWidget widget;
    widget.show();

    b2Vec2 gravity (0.0f, -9.8f);
    b2World world (gravity);

    b2BodyDef groundBodyDef;
    groundBodyDef.position.Set(0.0f, -10.0f);
    b2Body *groundBody = world.CreateBody(&groundBodyDef);
    b2PolygonShape groundShape;
    groundShape.SetAsBox(50.0f, 10.0f);
    groundBody->CreateFixture(&groundShape, 0.0f);    

    b2BodyDef dynamicBodyDef;
    dynamicBodyDef.type = b2_dynamicBody;
    dynamicBodyDef.position.Set(0.0f, 10.0f);    
    b2Body *dynamicBody = world.CreateBody(&dynamicBodyDef);
    b2PolygonShape dynamicShape;
    dynamicShape.SetAsBox(1.0f, 1.0f);
    b2FixtureDef dynamicFixtureDef;
    dynamicFixtureDef.shape = &dynamicShape;
    dynamicFixtureDef.density = 1.0f; // Set the box density to be non-zero, so it will be dynamic.
    dynamicFixtureDef.friction = 0.3f; // Override the default friction.
    dynamicBody->CreateFixture(&dynamicFixtureDef); // Add the shape to the body.

    float32 timestep = 1.0f/60.0f;
    int32 iterations = 10;

    for (int32 i = 0; i < 180; ++i)
    {
        world.Step(timestep, iterations, iterations);

        b2Vec2 position = dynamicBody->GetPosition();
        float32 angle = dynamicBody->GetAngle();
        qDebug("Временной шаг: %d. Позиция: %4.2f %4.2f. Угол: %4.2f", i, position.x, position.y, angle);
    }

    return app.exec();
}
