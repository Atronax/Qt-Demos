#ifndef _CLOUDSCENENODE_H
#define _CLOUDSCENENODE_H

#include "nodes.h"

namespace irr
{
    namespace scene
    {

    class CCloudSceneNode : public scene::ISceneNode
    {
    public:
        CCloudSceneNode(scene::ISceneNode* parent, scene::ISceneManager* mgr, s32 id = -1);
        virtual ~CCloudSceneNode();

        // ISceneNode overrides
        void OnRegisterSceneNode();
        scene::ESCENE_NODE_TYPE getType() const;
        ISceneNode* clone(scene::ISceneNode* newParent = 0, scene::ISceneManager* newManager = 0);

        const core::aabbox3d<f32>& getBoundingBox() const;
        video::SMaterial& getMaterial(u32 i);
        u32 getMaterialCount() const;

        void OnAnimate(u32 timeMs);
        void render();

        // serialization
        void serializeAttributes(io::IAttributes* out, io::SAttributeReadWriteOptions* options = 0) const;
        void deserializeAttributes(io::IAttributes* in,	io::SAttributeReadWriteOptions* options = 0);

        // accessors
        core::vector2d<f32>& getTranslation();
        void setTranslation(const core::vector2d<f32>& translation);

        f32 getTextureScale();
        void setTextureScale(f32 textureScale);

        f32 getInnerRadius();
        f32 getOuterRadius();
        void setCloudRadius(f32 innerRadius, f32 outerRadius);

        f32 getCenterHeight();
        f32 getInnerHeight();
        f32 getOuterHeight();
        void setCloudHeight(f32 centerHeight, f32 innerHeight, f32 outerHeight);

        video::SColor& getCenterColor();
        video::SColor& getInnerColor();
        video::SColor& getOuterColor();
        void setCloudColor(const video::SColor& centerColor = video::SColor(220,220,220,220), const video::SColor& innerColor = video::SColor(180,180,180,180), const video::SColor& outerColor = video::SColor(0,0,0,0));

    private:
        void createCloudLayer();

        // vertices and indices
        static constexpr int CLOUDSUBDIV = 16;
        video::S3DVertex InnerVertices[CLOUDSUBDIV+1];
        video::S3DVertex OuterVertices[CLOUDSUBDIV*2];
        u16 InnerIndices[CLOUDSUBDIV+2];
        u16 OuterIndices[CLOUDSUBDIV*2+2];

        // bounding box
        core::aabbox3d<f32> BBox;

        // size
        f32 TextureScale;
        f32 InnerRadius;
        f32 OuterRadius;

        // position
        f32 CenterHeight;
        f32 InnerHeight;
        f32 OuterHeight;

        // material
        video::SMaterial Material;
        video::SColor CenterColor;
        video::SColor InnerColor;
        video::SColor OuterColor;

        // animation (next translation step = current + elapsed time * Translation)
        core::vector2d<f32> Translation;
        core::vector2d<f32> CurrentTranslation;
        u32 LastUpdate;
    };

    }
}

#endif
