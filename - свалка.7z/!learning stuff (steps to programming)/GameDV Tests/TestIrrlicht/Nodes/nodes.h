#ifndef NODES
#define NODES

// IMPORTANT INCLUDES
#include <irrlicht.h>
#include <btBulletDynamicsCommon.h>

// LIST OF NODES
#include "cloudscenenode.h"

#endif // NODES

