#include <QApplication>
#include <QResizeEvent>

#include "engine.h"
Engine::Engine(QWidget *parent)
    : QWidget (parent),
      m_device(nullptr)
{
    // setAttribute(Qt::WA_StaticContents); // FOR Widgets on top of engine screen
    setAttribute(Qt::WA_PaintOnScreen);
    setAttribute(Qt::WA_OpaquePaintEvent);
    setFocusPolicy(Qt::StrongFocus);
    setAutoFillBackground(false);    

    initDevice();
    initWorld();        
}

Engine::~Engine()
{    
    cleanObjects();
    cleanIrrlicht();
    cleanBullet();
}

void Engine::initDevice()
{
    if (m_device)
        return;

    SIrrlichtCreationParameters parameters;
    parameters.Bits = 32; // color bitsize
    parameters.Doublebuffer = true; // double buffering
    parameters.DriverType = EDT_OPENGL; // what driver we will use
    parameters.DeviceType = EIDT_WIN32; // device type
    parameters.AntiAlias = 1; // use of antialiasing
    parameters.EventReceiver = 0; // object of type IEventReceiver or inherited
    parameters.Fullscreen = false; // is fullscreen
    parameters.HighPrecisionFPU = false;
    parameters.IgnoreInput = false;
    parameters.LoggingLevel = ELL_INFORMATION;
    parameters.Stencilbuffer = true;
    parameters.Stereobuffer = false;
    parameters.Vsync = true;    
    parameters.WindowId = reinterpret_cast<void*>(winId());
    parameters.WindowSize.Width = width();
    parameters.WindowSize.Height = height();
    parameters.WithAlphaChannel = false; // does window have an alpha channel
    parameters.ZBufferBits = 16;    

    m_device = createDeviceEx(parameters);       
}

void Engine::initWorld()
{
    // preparing collisions
    m_broadphaseAlgorithm = new btDbvtBroadphase;
    m_collisionConfig = new btDefaultCollisionConfiguration; // подробнее http://bulletphysics.org/mediawiki-1.5.8/index.php/Collision_Things
    m_collisionDispatcher = new btCollisionDispatcher (m_collisionConfig);
    btGImpactCollisionAlgorithm::registerAlgorithm(m_collisionDispatcher);
    m_constraintSolver = new btSequentialImpulseConstraintSolver;

    // making the world of physics bodies
    m_world = new btDiscreteDynamicsWorld (m_collisionDispatcher, m_broadphaseAlgorithm, m_constraintSolver, m_collisionConfig);
    m_world->setGravity(btVector3(0,-10,0));

    // start simulation
    startTimer(0);
}

void Engine::cleanObjects()
{
    // clear meshes
    foreach (btTriangleMesh* mesh, m_meshes)
        delete mesh;

    m_meshes.clear();

    // clear nodes
    foreach (ISceneNode* node, m_nodes)
        node->remove();

    m_nodes.clear();

    // clear bodies
    foreach (btRigidBody* body, m_bodies)
    {
        m_world->removeRigidBody(body);
        delete body->getMotionState();
        delete body->getCollisionShape();
        delete body;
    }

    m_bodies.clear();

    // clear shaders
    foreach (Terrain* terrain_object, m_terrain_objects)
        terrain_object->drop();

    foreach (ReflectingWater* reflecting_object, m_water_objects)
        reflecting_object->drop();

    foreach (Glass* glass_object, m_glass_objects)
        glass_object->drop();

    m_terrain_objects.clear();
    m_water_objects.clear();
    m_glass_objects.clear();

    // clear particle systems
    foreach (ParticleSystem* particle_object, m_particle_objects)
        delete particle_object;

    m_particle_objects.clear();    
}

void Engine::cleanIrrlicht()
{
    if (m_device)
    {
        m_device->closeDevice();
        m_device->drop();
    }
}

void Engine::cleanBullet()
{     
    delete m_world;
    delete m_constraintSolver;
    delete m_collisionDispatcher;
    delete m_collisionConfig;
    delete m_broadphaseAlgorithm;
}

IrrlichtDevice *Engine::device() const
{
    return m_device;
}

btDiscreteDynamicsWorld *Engine::world() const
{
    return m_world;
}

Terrain *Engine::terrainObjectByName(const QString &obj_name)
{
    Terrain *result = nullptr;

    foreach (Terrain *terrain_object, m_terrain_objects)
        if (terrain_object->name() == obj_name)
            result = terrain_object;

    return result;
}

ReflectingWater *Engine::waterObjectByName(const QString& obj_name)
{
    ReflectingWater *result = nullptr;

    foreach (ReflectingWater *water_object, m_water_objects)
        if (water_object->name() == obj_name)
            result = water_object;

    return result;
}

ParticleSystem *Engine::makeParticleSystem(const QString &name, const ParticleSystem::Type &type, ISceneNode *parent, bool isMesh)
{
    ParticleSystem *ps = new ParticleSystem(m_device, name, type, parent, isMesh);
    m_particle_objects.append(ps);

    return ps;
}

Miscellaneous* Engine::makeBox(const btVector3& position, const vector3df& scale, btScalar mass)
{
    // setup scenenode
    ISceneNode *object = m_device->getSceneManager()->addCubeSceneNode(1.0);
    object->setScale(scale);
    object->setMaterialFlag(EMF_LIGHTING, true);
    object->setMaterialFlag(EMF_NORMALIZE_NORMALS, true);
    // object->setMaterialFlag(EMF_FOG_ENABLE, true);
    object->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("textures/test.dds"));
    m_nodes.append(object);

    // m_device->getVideoDriver()->addOcclusionQuery(object, static_cast<IMeshSceneNode*>(object)->getMesh());

    // material
    // m_water_objects.push_back(new ReflectingWater("W", (IMeshSceneNode*)object, m_device, dimension2du(512,512)));
    // m_glass_objects.push_back(new Glass((IMeshSceneNode*) object, m_device, dimension2du(512,512)));

    // setup motion state
    btTransform transform;
    transform.setIdentity();
    transform.setOrigin(position);
    btDefaultMotionState *motion = new btDefaultMotionState (transform);

    // setup shape
    btVector3 halfExtents (scale.X*0.5f, scale.Y*0.5f, scale.Z*0.5f);
    btCollisionShape *shape = new btBoxShape(halfExtents);

    // calculate inertia
    btVector3 inertia;
    shape->calculateLocalInertia(mass, inertia);

    // make rigid body and attach user data
    btRigidBody *body = new btRigidBody (mass, motion, shape, inertia);

    // make entity
    Entity *entity = new Miscellaneous (body, object);
    body->setUserPointer(static_cast<void*>(entity));

    Miscellaneous *item = dynamic_cast<Miscellaneous*>(entity);
    item->setType(Miscellaneous::BOX);

    // add body to the world and to list of objects in order they become able to redraw    
    m_world->addRigidBody(body);    
    m_bodies.push_back(body);

    return item;
}

Miscellaneous* Engine::makeSphere(const btVector3 &position, const btScalar &radius, btScalar mass)
{
    // visuals
    ISceneNode *object = m_device->getSceneManager()->addSphereSceneNode(radius, 32);
    object->setMaterialFlag(EMF_LIGHTING, true);
    object->setMaterialFlag(EMF_NORMALIZE_NORMALS, true);
    // object->setMaterialFlag(EMF_FOG_ENABLE, true);
    object->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("textures/test2.jpg"));    
    m_nodes.append(object);

    // m_device->getVideoDriver()->addOcclusionQuery(object, static_cast<IMeshSceneNode*>(object)->getMesh());

    // material
    m_glass_objects.push_back(new Glass((IMeshSceneNode*) object, m_device, dimension2du(512,512)));

    // motion state
    btTransform transform;
    transform.setIdentity();
    transform.setOrigin(position);
    btDefaultMotionState *motion = new btDefaultMotionState (transform);

    // shape
    btCollisionShape *shape = new btSphereShape(radius);

    // inertia
    btVector3 inertia;
    shape->calculateLocalInertia(mass, inertia);

    // body
    btRigidBody *body = new btRigidBody (mass, motion, shape, inertia);

    // entity
    Entity *entity = new Miscellaneous (body, object);
    body->setUserPointer(static_cast<void*>(entity));

    Miscellaneous* item = dynamic_cast<Miscellaneous*>(entity);
    item->setType(Miscellaneous::SPHERE);

    // add
    m_world->addRigidBody(body);
    m_bodies.push_back(body);

    return item;
}

Miscellaneous *Engine::makeGround(const path& filename, const btVector3 &position, const vector3df &scale)
{
    // visuals
    ITexture *heightmap = m_device->getVideoDriver()->getTexture(filename);
    ITerrainSceneNode *object = m_device->getSceneManager()->addTerrainSceneNode(heightmap->getName());
    object->setPosition(vector3df(position.x(), position.y(), position.z()));        
    object->setScale(scale);
    m_nodes.append(object);

    object->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("textures/sand.jpg"));
    object->setMaterialTexture(1, m_device->getVideoDriver()->getTexture("textures/grass.jpg"));
    object->setMaterialTexture(2, m_device->getVideoDriver()->getTexture("textures/rock.jpg"));
    m_terrain_objects.append(new Terrain("Terrain", object, m_device));

    // m_device->getVideoDriver()->addOcclusionQuery(object, ((IMeshSceneNode*)object)->getMesh());

    // setup water    
    IAnimatedMesh *water_mesh = m_device->getSceneManager()->addHillPlaneMesh("ReflectingWater", dimension2df(10,10), dimension2du(40,40));
    IMeshSceneNode *ocean_object = m_device->getSceneManager()->addMeshSceneNode(water_mesh);
    ocean_object->setPosition(vector3df(0, 20, 0));
    ocean_object->setScale(scale);
    m_nodes.append(ocean_object);

    m_water_objects.push_back(new ReflectingWater("OceanWater", ocean_object, m_device, dimension2du(512,512)));


    // shape
    btVector3 vertices[3];
    btTriangleMesh *mesh = new btTriangleMesh;
    CDynamicMeshBuffer meshbuffer (EVT_STANDARD, EIT_32BIT);
    object->getMeshBufferForLOD(meshbuffer, 0);

    S3DVertex *mb_vertices = (S3DVertex*)meshbuffer.getVertexBuffer().getData();
    u16* mb_indices = meshbuffer.getIndices();

    for (size_t j = 0; j < meshbuffer.getIndexCount(); j += 3)
    {
        for (size_t k = 0; k < 3; ++k)
        {
            s32 index = mb_indices [j + k];
            vertices[k] = btVector3(mb_vertices[index].Pos.X * object->getScale().X,
                                    mb_vertices[index].Pos.Y * object->getScale().Y,
                                    mb_vertices[index].Pos.Z * object->getScale().Z);
        }

        mesh->addTriangle(vertices[0], vertices[1], vertices[2]);
    }
    btCollisionShape *shape = new btBvhTriangleMeshShape (mesh, true);

    // motion
    btTransform transform;
    transform.setIdentity();
    transform.setOrigin(position);
    btDefaultMotionState *motion = new btDefaultMotionState (transform);

    // make rigid body and attack user data            
    btRigidBody *body = new btRigidBody(btRigidBody::btRigidBodyConstructionInfo(0, motion, shape));

    // make entity
    Entity *entity = new Miscellaneous (body, object);
    body->setUserPointer(static_cast<void*>(entity));

    Miscellaneous *item = dynamic_cast<Miscellaneous*>(entity);
    item->setType(Miscellaneous::BASE);

    // add body to the world and to list of objects in order they become able to redraw
    m_world->addRigidBody(body);
    m_bodies.push_back(body);

    return item;
}

void Engine::makeClouds()
{
    CCloudSceneNode* cloudLayer1 = new CCloudSceneNode(m_device->getSceneManager()->getRootSceneNode(), m_device->getSceneManager());
    cloudLayer1->setTranslation(vector2df(0.008f, 0.0f));
    cloudLayer1->getMaterial(0).setTexture(0, m_device->getVideoDriver()->getTexture("textures/clouds/cloud01.png"));
    cloudLayer1->setCloudColor(SColor(255,0,255,0));
    cloudLayer1->setCloudHeight(0.5f, 0.1f, -0.05f);
    m_nodes.append(cloudLayer1);

    CCloudSceneNode* cloudLayer2 = new CCloudSceneNode(m_device->getSceneManager()->getRootSceneNode(), m_device->getSceneManager());
    cloudLayer2->setTranslation(vector2df(0.006f, 0.003f));
    cloudLayer2->getMaterial(0).setTexture(0, m_device->getVideoDriver()->getTexture("textures/clouds/cloud02.png"));
    cloudLayer2->setCloudColor(SColor(255,255,255,0));
    cloudLayer2->setCloudHeight(0.4f, 0.05f, -0.1f);
    cloudLayer2->setTextureScale(0.5f);
    m_nodes.append(cloudLayer2);

    CCloudSceneNode* cloudLayer3 = new CCloudSceneNode(m_device->getSceneManager()->getRootSceneNode(), m_device->getSceneManager());
    cloudLayer3->setTranslation(vector2df(0.006f, 0.003f));
    cloudLayer3->getMaterial(0).setTexture(0, m_device->getVideoDriver()->getTexture("textures/clouds/cloud03.png"));
    cloudLayer3->setCloudColor(SColor(255,255,0,0));
    cloudLayer3->setCloudHeight(0.35f, 0.0f, -0.15f);
    cloudLayer3->setTextureScale(0.4f);
    m_nodes.append(cloudLayer3);
}

Miscellaneous* Engine::makeConvex(const path& filename, bool isAnimated, const btVector3& position, const vector3df& scale, btScalar mass)
{
    ISceneManager *scene = m_device->getSceneManager();

    IAnimatedMesh *anim_mesh;
    ISceneNode *object;
    IMesh *mesh;

    if (isAnimated)
    {
        anim_mesh = scene->getMesh(filename);
        object = scene->addAnimatedMeshSceneNode(anim_mesh);
    }
    else
    {
        mesh = scene->getMesh(filename)->getMesh(0);
        object = scene->addMeshSceneNode(mesh);
    }
    object->setScale(scale);
    m_nodes.append(object);

    // m_device->getVideoDriver()->addOcclusionQuery(object, m);

    btTriangleMesh* trimesh;
    if (isAnimated)
        trimesh = convertIrrlichtMeshToBulletMesh(anim_mesh, scale);
    else
        trimesh = convertIrrlichtMeshToBulletMesh(mesh, scale);
    btConvexShape* shape = new btConvexTriangleMeshShape(trimesh);

    /*
    aabbox3d<f32> bbox = object->getBoundingBox();
    vector3df extents = bbox.getExtent();
    btCollisionShape* shape = new btBoxShape(btVector3(scale.X*extents.X/2.0, scale.Y*extents.Y/2.0, scale.Z*extents.Z/2.0));
    */

    btVector3 inertia;
    shape->calculateLocalInertia(mass, inertia);

    btTransform transform;
    transform.setIdentity();
    transform.setOrigin(position);
    btDefaultMotionState *motion = new btDefaultMotionState(transform);

    btRigidBody* body = new btRigidBody(mass, motion, shape, inertia);
    body->setActivationState(DISABLE_DEACTIVATION);

    Entity *entity = new Miscellaneous (body, object);
    body->setUserPointer(static_cast<void*>(entity));

    Miscellaneous *item = dynamic_cast<Miscellaneous*>(entity);
    item->setType(Miscellaneous::BASE);

    m_world->addRigidBody(body);
    m_bodies.push_back(body);

    return item;
}

Player *Engine::makePlayer(const btVector3 &position, const vector3df &scale, btScalar mass)
{    
    IrrAssimp assimp_manager = IrrAssimp(m_device->getSceneManager());
    // Assimp::Import assimp_importer = IrrAssimpImport(m_device->getSceneManager());
    //  assimp_manager.getMesh("models/ninja.b3d");

    std::string c_str;
    Assimp::Importer importer;
    importer.GetExtensionList(c_str);
    qDebug(QString::fromStdString(c_str).toUtf8());

    qDebug("before loading mesh");

    IAnimatedMesh *mesh = m_device->getSceneManager()->getMesh("models/sydney.md2");

    qDebug("after loading mesh");

    if (!mesh)
    {
        qDebug("no mesh: " + QString::fromStdString(assimp_manager.getError().c_str()).toUtf8());
        return nullptr;
    }

    qDebug("mesh loaded");

    IAnimatedMeshSceneNode *object = m_device->getSceneManager()->addAnimatedMeshSceneNode(mesh);
    object->setAnimationSpeed(mesh->getAnimationSpeed());
    object->setFrameLoop(1, 20);
    object->setScale(scale);
    object->setMaterialFlag(EMF_LIGHTING, true);
    object->setMaterialFlag(EMF_NORMALIZE_NORMALS, true);
    object->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("models/sydney.bmp"));
    m_nodes.append(object);

    // setup motion state
    btTransform transform;
    transform.setIdentity();
    transform.setOrigin(position);
    // transform.setRotation(btQuaternion(btVector3(0,0,1), 90));
    btDefaultMotionState *motion = new btDefaultMotionState (transform);    

    // setup shape. TO DO: посмотреть, как сделать меш-коллизии.s
    btTriangleMesh* trimesh = convertIrrlichtMeshToBulletMesh(mesh, scale);
    btConvexShape* shape = new btConvexTriangleMeshShape(trimesh);
    m_meshes.append(trimesh);

    // calculate inertia
    btVector3 inertia;
    shape->calculateLocalInertia(mass, inertia);

    // make rigid body
    btRigidBody *body = new btRigidBody (mass, motion, shape, inertia);   
    body->setActivationState(DISABLE_DEACTIVATION); // start simulation once the object appears
    body->setAngularFactor(0); // is rotatable and how much
    body->setFriction(1.0f);

    // make entity
    Entity *entity = new Player (body, object);
    body->setUserPointer(static_cast<void*>(entity));

    Player *player = dynamic_cast<Player*>(entity);
    connect (player, SIGNAL(broken(Miscellaneous*)), this, SLOT(onBroken(Miscellaneous*)));
    connect (player, SIGNAL(changeSphereTexture(Miscellaneous*)), this, SLOT(onChangeSphereTexture(Miscellaneous*)));

    // add body to the world and to list of objects in order they become able to redraw
    m_world->addRigidBody(body);
    m_bodies.push_back(body);

    return player;
}

btTriangleMesh* Engine::convertIrrlichtMeshToBulletMesh(IMesh* mesh, const vector3df& scale)
{
    btTriangleMesh *result = new btTriangleMesh;
    m_meshes.push_back(result);

    btVector3 vertices[3];

    for (size_t i = 0; i < mesh->getMeshBufferCount(); ++i)
    {
        IMeshBuffer* mb = mesh->getMeshBuffer(i);
        u16* mb_indices = mb->getIndices();

        u32 numVertices = mb->getVertexCount();
        u32 numIndices = mb->getIndexCount();
        s32 index = 0;

        if (mb->getVertexType() == EVT_STANDARD)
        {
            S3DVertex* mb_vertices = reinterpret_cast<S3DVertex*>(mb->getVertices());
            for (size_t j = 0; j < numIndices; j += 3)
            {
                for (size_t k = 0; k < 3; ++k)
                {
                    index = mb_indices[j+k];
                    vertices[k] = btVector3(mb_vertices[index].Pos.X*scale.X,
                                            mb_vertices[index].Pos.Y*scale.Y,
                                            mb_vertices[index].Pos.Z*scale.Z);
                }

                result->addTriangle(vertices[0], vertices[1], vertices[2]);
            }
        }
        else if (mb->getVertexType() == EVT_2TCOORDS)
        {
            S3DVertex2TCoords* mb_vertices = reinterpret_cast<S3DVertex2TCoords*>(mb->getVertices());
            for (size_t j = 0; j < numIndices; j += 3)
            {
                for (size_t k = 0; k < 3; ++k)
                {
                    index = mb_indices[j+k];
                    vertices[k] = btVector3(mb_vertices[index].Pos.X*scale.X,
                                            mb_vertices[index].Pos.Y*scale.Y,
                                            mb_vertices[index].Pos.Z*scale.Z);
                }

                result->addTriangle(vertices[0], vertices[1], vertices[2]);
            }
        }
    }

    return result;
}

void Engine::resizeEvent(QResizeEvent *ev)
{
    if (m_device)
    {
        dimension2d<u32> widgetsize;
        widgetsize.Width = ev->size().width();
        widgetsize.Height = ev->size().height();

        m_device->getVideoDriver()->OnResize(widgetsize);
        m_device->getSceneManager()->getActiveCamera()->setAspectRatio((f32)widgetsize.Width/widgetsize.Height);
    }

    QWidget::resizeEvent(ev);
}

// update render and physics state
void Engine::timerEvent(QTimerEvent *)
{
    updateEngineState();
}

void Engine::checkCollisions()
{    
    int total_manifolds = m_collisionDispatcher->getNumManifolds();
    for (int i = 0; i < total_manifolds; ++i)
    {
        btPersistentManifold *contact = m_collisionDispatcher->getManifoldByIndexInternal(i);
        Entity* entityA = reinterpret_cast<Entity*>(contact->getBody0()->getUserPointer());
        Entity* entityB = reinterpret_cast<Entity*>(contact->getBody1()->getUserPointer());

        if (dynamic_cast<Player*>(entityA) || dynamic_cast<Player*>(entityB))
        {
            entityA->resolveCollisions(entityB);
            entityB->resolveCollisions(entityA);
        }

    }
}

void Engine::updateEngineState()
{   
    if (m_device)
    {
        m_world->stepSimulation(1000/m_FPS, 10); // ???
        foreach (btRigidBody* object, m_bodies)
            updateRenderState(object);

        // other stuff
        foreach (ReflectingWater* reflecting_object, m_water_objects)
            reflecting_object->updateRendertarget();

        foreach (Glass* glass_object, m_glass_objects)
            glass_object->updateRendertarget();

        checkCollisions();        
        // end other stuff        

        m_device->getTimer()->tick();
        m_device->getVideoDriver()->beginScene(true, true, video::SColor(255,0,0,0));        
            /*
            if (m_device->getTimer()->getTime() % 100)
            {
                m_device->getVideoDriver()->runAllOcclusionQueries(false);
                m_device->getVideoDriver()->updateAllOcclusionQueries();
            }
            */
            m_device->getSceneManager()->drawAll();
        m_device->getVideoDriver()->endScene();
        m_device->yield();
    }
}

void Engine::updateRenderState(btRigidBody *object)
{
    // Получаем указатель из физического описания на графическое представление (узел).
    Entity *object_entity = reinterpret_cast<Entity*>(object->getUserPointer());
    ISceneNode *object_node = object_entity->node();

    // Найдем из физического описания позицию обьекта и установим эту позицию визуальному представлению.
    btVector3 position = object->getCenterOfMassPosition();
    object_node->setPosition(vector3df(position.x(), position.y(), position.z()));

    // Найдем из физического описания поворот обьекта и установим этот поворот визуальному представлению.
    vector3df euler_angles;
    btQuaternion q = object->getOrientation();
    quaternion(q.getX(),q.getY(),q.getZ(),q.getW()).toEuler(euler_angles);
    euler_angles *= RADTODEG;
    object_node->setRotation(euler_angles);
}

// GAMELOGIC
void Engine::destroyObject(Entity *entity)
{
    m_bodies.removeOne(entity->body());
    m_world->removeRigidBody(entity->body());

    entity->deleteLater();
}

void Engine::onBroken(Miscellaneous *object)
{
    destroyObject(object);
}

void Engine::onChangeSphereTexture(Miscellaneous *sphere)
{
    // ISceneNode* node = sphere->node();
    // node->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("D:/apple.jpg"));

}
