#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// LOGIC
#include "engine.h"

// WIDGETS
#include <QSlider>

#include <QWidget>
class MainWindow : public QWidget
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void keyPressEvent(QKeyEvent *ev);
    void wheelEvent(QWheelEvent *ev);

private:
    void setupUserInterface();
    void prepareScene();
    void setupLayout();

    Engine *m_engine;
    Player *m_player;
    Camera *m_camera;

    // objects with controls initialization
    void makeTerrainAndWater();
    void makePlayerAndCamera();

    QSlider *m_OceanColor_R, *m_OceanColor_G, *m_OceanColor_B;
    QSlider *m_TerrainLevel_1, *m_TerrainLevel_2, *m_TerrainLevel_3, *m_TerrainLevel_4;

public slots:
    void setOceanColor(int value);
    void setTerrainLevel(int value);
};

#endif // MAINWINDOW_H
