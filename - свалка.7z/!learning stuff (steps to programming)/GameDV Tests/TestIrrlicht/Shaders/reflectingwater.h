#ifndef REFLECTINGWATER_H
#define REFLECTINGWATER_H

#include "shaders.h"

// Reflecting Water.
// Based on .NET code by DeusXL (Irrlicht forum)
class ReflectingWater : public IShaderConstantSetCallBack
{
public:
    ReflectingWater(const QString& name, IMeshSceneNode* node, IrrlichtDevice *device, const dimension2du& reflectionTexSize);
    ~ReflectingWater();

    void updateRendertarget(); // updates reflection texture

    const SColorf& addedColor();
    void setAddedColor(const SColorf& color);

    const QString& name() const;
    void setName(const QString &name);

    virtual void OnSetConstants(video::IMaterialRendererServices* services, s32);

private:
   QString         m_name;
   ISceneNode     *m_waternode;
   IrrlichtDevice *m_device;
   ISceneManager  *m_smgr;

   ICameraSceneNode *m_watercam;
   ITexture *m_ReflectionTexture;

   SColorf m_AddedColor;
   SColorf m_MultiColor;
   f32 m_WaveHeight;
   f32 m_WaveLength;
   f32 m_WaveSpeed;
   f32 m_WaveDisplacement;
   f32 m_WaveRepetition;
   f32 m_RefractionFactor;
};

#endif // REFLECTINGWATER_H
