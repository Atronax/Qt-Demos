#ifndef SHADERS_H
#define SHADERS_H

// IMPORTANT INCLUDES
#include <irrlicht.h>
using namespace irr;
using namespace core;
using namespace scene;
using namespace video;

#include <QString>

// LIST OF SHADERS
#include "reflectingwater.h"
#include "glass.h"
#include "terrain.h"

#endif // SHADERS_H
