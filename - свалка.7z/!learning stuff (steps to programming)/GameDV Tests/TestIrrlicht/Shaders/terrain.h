#ifndef TERRAIN_H
#define TERRAIN_H

#include "shaders.h"

class Terrain : public IShaderConstantSetCallBack
{
public:
    Terrain(const QString& name, ITerrainSceneNode* node, IrrlichtDevice *device);
    ~Terrain();

    virtual void OnSetConstants(video::IMaterialRendererServices* services, s32);

    const QString& name() const;
    void setName(const QString &name);

    const f32& level(int num) const;
    void setLevel(int num, const f32& value);

private:
    QString m_name;
    ISceneNode *m_terrainnode;
    IrrlichtDevice *m_device;

    static constexpr int levels_count = 4;
    f32 m_levels[levels_count];
};

#endif // TERRAIN_H
