#include "terrain.h"

Terrain::Terrain(const QString &name, ITerrainSceneNode *node, IrrlichtDevice *device)
{
    m_name = name;
    m_terrainnode = node;
    m_device = device;

    // material
    IGPUProgrammingServices *gpu = m_device->getVideoDriver()->getGPUProgrammingServices();
    s32 material = gpu->addHighLevelShaderMaterialFromFiles("D:/shaders/terrain.vsh", "main", EVST_VS_1_1,
                                                            "D:/shaders/terrain.fsh", "main", EPST_PS_1_1,
                                                            this, EMT_TRANSPARENT_ALPHA_CHANNEL);

    m_terrainnode->setMaterialType((E_MATERIAL_TYPE) material);
    m_terrainnode->setMaterialFlag(EMF_BACK_FACE_CULLING, true);
    m_terrainnode->setMaterialFlag(EMF_LIGHTING, true);
    m_terrainnode->setMaterialFlag(EMF_FOG_ENABLE, false);

    // levels init
    m_levels[0] = 0.1f;
    m_levels[1] = 0.3f;
    m_levels[2] = 0.5f;
    m_levels[3] = 0.7f;
}

Terrain::~Terrain()
{

}

void Terrain::OnSetConstants(IMaterialRendererServices *services, s32)
{
    if (!(services || m_device))
        return;

    // model matrix
    matrix4 model_matrix = m_device->getVideoDriver()->getTransform(ETS_WORLD);
    services->setVertexShaderConstant("ModelMatrix", model_matrix.pointer(), 16);

    // levels
    services->setPixelShaderConstant("level1", &m_levels[0], 1);
    services->setPixelShaderConstant("level2", &m_levels[1], 1);
    services->setPixelShaderConstant("level3", &m_levels[2], 1);
    services->setPixelShaderConstant("level4", &m_levels[3], 1);

    // maximum height
    f32 terrainHeight = m_terrainnode->getBoundingBox().getExtent().Y;
    services->setPixelShaderConstant("TerrainHeight", &terrainHeight, 1);

    // textures
    s32 t0 = 0;
    s32 t1 = 1;
    s32 t2 = 2;

    vector2df textureScale[3];
    for (int i = 0; i < 3; ++i)
        textureScale[i] = vector2df(50.0f, 50.0f);

    services->setPixelShaderConstant("Texture_0", &t0, 1);
    services->setPixelShaderConstant("Texture_1", &t1, 1);
    services->setPixelShaderConstant("Texture_2", &t2, 1);
    services->setPixelShaderConstant("Texture_0_Scale", reinterpret_cast<f32*>(&textureScale[0]), 2);
    services->setPixelShaderConstant("Texture_1_Scale", reinterpret_cast<f32*>(&textureScale[1]), 2);
    services->setPixelShaderConstant("Texture_2_Scale", reinterpret_cast<f32*>(&textureScale[2]), 2);
}

const QString& Terrain::name() const
{
    return m_name;
}

void Terrain::setName(const QString &name)
{
    m_name = name;
}

const f32 &Terrain::level(int num) const
{
    return m_levels[num];
}

void Terrain::setLevel(int num, const f32 &value)
{
    if (value >= 0.0f && value <= 1.0f)
        m_levels[num] = value;
}


