#include "glass.h"

Glass::Glass(IMeshSceneNode *node, IrrlichtDevice *device, const dimension2du &reflectionTexSize)
{
    // basis
    m_device = device;
    m_smgr = m_device->getSceneManager();
    m_glassnode = node;

    // constants
    m_EyePos = m_device->getSceneManager()->getActiveCamera()->getPosition();

    // material
    IGPUProgrammingServices *gpu = m_smgr->getVideoDriver()->getGPUProgrammingServices();
    s32 material = gpu->addHighLevelShaderMaterialFromFiles("D:/shaders/glass.vsh", "main", EVST_VS_1_1,
                                                            "D:/shaders/glass.fsh", "main", EPST_PS_1_1,
                                                            this, EMT_TRANSPARENT_ALPHA_CHANNEL);
    m_glassnode->setMaterialType((E_MATERIAL_TYPE) material);
    // m_glassnode->setMaterialFlag(EMF_BACK_FACE_CULLING, false);
    m_glassnode->setMaterialFlag(EMF_LIGHTING, false);
    m_glassnode->setMaterialFlag(EMF_FOG_ENABLE, false);

    m_ReflectionTexture = m_smgr->getVideoDriver()->addRenderTargetTexture(reflectionTexSize);
    m_glassnode->setMaterialTexture(0, m_ReflectionTexture);

    // cam for reflections
    ICameraSceneNode *main_cam = m_smgr->getActiveCamera();
    m_glasscam = m_smgr->addCameraSceneNode();
    m_smgr->setActiveCamera(main_cam);
}

Glass::~Glass()
{
    m_ReflectionTexture->drop();
}

void Glass::OnSetConstants(IMaterialRendererServices *services, s32)
{
    if (!(services || m_device))
        return;

    services->setVertexShaderConstant("eyePos", reinterpret_cast<f32*>(&m_EyePos), 3);
}

void Glass::updateRendertarget()
{
    if (m_ReflectionTexture && m_glassnode && m_smgr)
    {
        ICameraSceneNode *camera = m_smgr->getActiveCamera();
        m_glasscam->setFarValue(camera->getFarValue());
        m_glasscam->setProjectionMatrix(m_device->getVideoDriver()->getTransform(ETS_PROJECTION));

        vector3df water_pos = m_glassnode->getPosition();
        vector3df camera_pos = camera->getPosition();
        if (camera_pos.Y >= water_pos.Y)
        {
            m_glasscam->setPosition(vector3df(camera_pos.X,2*camera_pos.Y,camera_pos.Z));
            vector3df target_direction = vector3df(camera->getTarget() - camera_pos);
            target_direction.normalize();
            target_direction.Y *= -1;

            m_glasscam->setTarget(m_glasscam->getPosition() + target_direction*20000);
            m_glasscam->setUpVector(camera->getUpVector());
        }
        else
        {
            m_glasscam->setPosition(camera->getPosition());

            vector3df target_direction = vector3df(camera->getTarget() - camera_pos);
            target_direction.normalize();

            m_glasscam->setTarget(m_glasscam->getPosition() + target_direction*20000);
        }

        m_glassnode->setVisible(false);
        m_smgr->setActiveCamera(m_glasscam);
        m_smgr->getVideoDriver()->setRenderTarget(m_ReflectionTexture, true, true, SColor(0,100,100,100));
        m_smgr->drawAll();
        m_smgr->getVideoDriver()->setRenderTarget(0);
        m_smgr->setActiveCamera(camera);
        m_glassnode->setVisible(true);
    }
}

