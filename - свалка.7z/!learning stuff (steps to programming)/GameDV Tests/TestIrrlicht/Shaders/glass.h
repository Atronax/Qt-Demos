#ifndef GLASS_H
#define GLASS_H

#include "shaders.h"

class Glass : public IShaderConstantSetCallBack
{
public:
    Glass(IMeshSceneNode* node, IrrlichtDevice *device, const dimension2du& reflectionTexSize);
    ~Glass();

    virtual void OnSetConstants(video::IMaterialRendererServices* services, s32);

    void updateRendertarget(); // updates reflection texture

private:
   ISceneNode     *m_glassnode;
   IrrlichtDevice *m_device;
   ISceneManager  *m_smgr;

   ICameraSceneNode *m_glasscam;
   ITexture *m_ReflectionTexture;

   vector3df m_EyePos;

};

#endif // GLASS_H
