#include "reflectingwater.h"

ReflectingWater::ReflectingWater(const QString& name, IMeshSceneNode* node, IrrlichtDevice *device, const dimension2du& reflectionTexSize)
{
    // basis
    m_name = name;
    m_waternode = node;
    m_device = device;
    m_smgr = m_device->getSceneManager();

    // constants
    m_AddedColor = SColor(0,0,0,30); //SColor(255,1,1,30);
    m_MultiColor = SColor(255,190,190,210);
    m_WaveHeight = 5.0f;
    m_WaveLength = 50.0f;
    m_WaveSpeed = 10.0f;
    m_WaveDisplacement = 7.0f;
    m_WaveRepetition = 5.0f;
    m_RefractionFactor = 0.8f;

    // material
    IGPUProgrammingServices *gpu = m_smgr->getVideoDriver()->getGPUProgrammingServices();
    s32 material = gpu->addHighLevelShaderMaterialFromFiles("D:/shaders/reflecting_water.vsh", "main", EVST_VS_1_1,
                                                            "D:/shaders/reflecting_water.fsh", "main", EPST_PS_1_1,
                                                            this, EMT_TRANSPARENT_ALPHA_CHANNEL);
    m_waternode->setMaterialType((E_MATERIAL_TYPE) material);
    m_waternode->setMaterialFlag(EMF_BACK_FACE_CULLING, false);
    m_waternode->setMaterialFlag(EMF_LIGHTING, false);
    m_waternode->setMaterialFlag(EMF_FOG_ENABLE, false);

    m_ReflectionTexture = m_smgr->getVideoDriver()->addRenderTargetTexture(reflectionTexSize);
    m_waternode->setMaterialTexture(0, m_ReflectionTexture);

    // cam for reflections
    ICameraSceneNode *main_cam = m_smgr->getActiveCamera();
    m_watercam = m_smgr->addCameraSceneNode();
    m_smgr->setActiveCamera(main_cam);
}

ReflectingWater::~ReflectingWater()
{
    m_ReflectionTexture->drop();
}

const QString& ReflectingWater::name() const
{
    return m_name;
}

void ReflectingWater::setName(const QString &name)
{
    m_name = name;
}

const SColorf &ReflectingWater::addedColor()
{
    return m_AddedColor;
}

void ReflectingWater::setAddedColor(const SColorf &color)
{
    m_AddedColor = color;
}

void ReflectingWater::OnSetConstants(IMaterialRendererServices *services, s32)
{
    if (!(services || m_device))
        return;

    float time = (float)m_device->getTimer()->getRealTime();
    services->setVertexShaderConstant("Time", &time, 1);
    services->setVertexShaderConstant("WaveHeight", &m_WaveHeight, 1);
    services->setVertexShaderConstant("WaveLength", &m_WaveLength, 1);
    services->setVertexShaderConstant("WaveSpeed", &m_WaveSpeed, 1);

    services->setPixelShaderConstant("AddedColor", reinterpret_cast<f32*>(&m_AddedColor), 4);
    services->setPixelShaderConstant("MultiColor", reinterpret_cast<f32*>(&m_MultiColor), 4);
    services->setPixelShaderConstant("WaveDisplacement", &m_WaveDisplacement, 1);
    services->setPixelShaderConstant("WaveRepetition", &m_WaveRepetition, 1);
    services->setPixelShaderConstant("RefractionFactor", &m_RefractionFactor, 1);
    float fUnderWater = (m_smgr->getActiveCamera()->getPosition().Y < m_waternode->getPosition().Y) ? 1.0f : 0.0f;
    services->setPixelShaderConstant("UnderWater", &fUnderWater, 1);
}

void ReflectingWater::updateRendertarget()
{
    if (m_ReflectionTexture && m_waternode && m_smgr)
    {
        ICameraSceneNode *camera = m_smgr->getActiveCamera();
        m_watercam->setFarValue(camera->getFarValue());
        m_watercam->setProjectionMatrix(m_device->getVideoDriver()->getTransform(ETS_PROJECTION));

        vector3df water_pos = m_waternode->getPosition();
        vector3df camera_pos = camera->getPosition();
        if (camera_pos.Y >= water_pos.Y)
        {
            m_watercam->setPosition(vector3df(camera_pos.X,2.0f*camera_pos.Y,camera_pos.Z));
            vector3df target_direction = vector3df(camera->getTarget() - camera_pos);
            target_direction.normalize();
            target_direction.Y *= -1;

            m_watercam->setTarget(m_watercam->getPosition()+target_direction*100);
            m_watercam->setUpVector(camera->getUpVector());

        }
        else
        {
            m_watercam->setPosition(camera->getPosition());

            vector3df target_direction = vector3df(camera->getTarget() - camera_pos);
            target_direction.normalize();

            m_watercam->setTarget(m_watercam->getPosition() + target_direction*100);
        }

        m_waternode->setVisible(false);
        m_smgr->setActiveCamera(m_watercam);
        m_smgr->getVideoDriver()->setRenderTarget(m_ReflectionTexture, true, true, SColor(0,100,100,100));
        m_smgr->drawAll();
        m_smgr->getVideoDriver()->setRenderTarget(0);
        m_smgr->setActiveCamera(camera);
        m_waternode->setVisible(true);
    }
}
