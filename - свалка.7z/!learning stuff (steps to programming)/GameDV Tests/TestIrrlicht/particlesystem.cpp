#include "particlesystem.h"
ParticleSystem::ParticleSystem(IrrlichtDevice* device, const QString& name, const Type& type, ISceneNode* parent, bool isMesh)
{
    m_device = device;
    m_name = name;
    m_type = type;

    m_parent = parent;
    m_isMesh = isMesh;

    ps_node = nullptr;
    ps_emitter = nullptr;
    ps_affector = nullptr;

    initFor (m_type);
}

ParticleSystem::~ParticleSystem()
{
    if (ps_node)
        ps_node->drop();

    if (ps_emitter)
        ps_emitter->drop();

    if (ps_affector)
        ps_affector->drop();
}

const ParticleSystem::Type& ParticleSystem::type() const
{
    return m_type;    
}

void ParticleSystem::setType(const ParticleSystem::Type& type)
{
    m_type = type;
}

void ParticleSystem::initFor(const ParticleSystem::Type &type)
{
    // common
    ps_node = m_device->getSceneManager()->addParticleSystemSceneNode(false);
    ps_node->setPosition(m_parent->getPosition());
    ps_node->setParent(m_parent);

    // different
    switch (type)
    {
    case Type::SMOKE:
        if (m_isMesh)
            ps_emitter = ps_node->createAnimatedMeshSceneNodeEmitter((IAnimatedMeshSceneNode*)m_parent, true, vector3df(0.0f,0.1f,0.0f));
        else
            ps_emitter = ps_node->createBoxEmitter(aabbox3d<f32>(-500.0f,-500.0f,-500.0f, 500.0f,500.0f,500.0f));
        ps_node->setEmitter(ps_emitter);
        ps_emitter->setMinParticlesPerSecond(400);
        ps_emitter->setMinStartSize(dimension2df(1.0f,1.0f));
        ps_emitter->setMaxStartSize(dimension2df(5.0f,5.0f));

        ps_affector = ps_node->createScaleParticleAffector(dimension2df(2.0f,2.0f));
        ps_node->addAffector(ps_affector);

        ps_node->setMaterialFlag(EMF_LIGHTING, false);
        ps_node->setMaterialType(EMT_TRANSPARENT_ALPHA_CHANNEL);
        ps_node->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("textures/smoke.png"));
        break;

    case Type::BUBBLES:
        if (m_isMesh)
            ps_emitter = ps_node->createAnimatedMeshSceneNodeEmitter((IAnimatedMeshSceneNode*)m_parent, true, vector3df(0.0f,0.1f,0.0f));
        else
            ps_emitter = ps_node->createBoxEmitter(aabbox3d<f32>(-500.0f,-500.0f,-500.0f, 500.0f,500.0f,500.0f));
        ps_node->setEmitter(ps_emitter);
        ps_emitter->setDirection(vector3df(0.0f, -0.05f, 0.0f));
        ps_emitter->setMinParticlesPerSecond(2000);
        ps_emitter->setMinStartSize(dimension2df(2.5f,2.5f));
        ps_emitter->setMaxStartSize(dimension2df(5.5f,5.5f));

        ps_node->setMaterialFlag(EMF_LIGHTING, false);
        ps_node->setMaterialType(EMT_TRANSPARENT_ALPHA_CHANNEL);
        ps_node->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("textures/bubble.png")); // bubble.png;
        break;

    case Type::RAIN:
        if (m_isMesh)
            ps_emitter = ps_node->createAnimatedMeshSceneNodeEmitter((IAnimatedMeshSceneNode*)m_parent, true, vector3df(0.0f,0.1f,0.0f));
        else
            ps_emitter = ps_node->createBoxEmitter(aabbox3d<f32>(-500.0f,-500.0f,-500.0f, 500.0f,500.0f,500.0f));
        ps_node->setEmitter(ps_emitter);
        ps_emitter->setDirection(vector3df(0.0f, 0.0f, 0.0f));
        ps_emitter->setMinParticlesPerSecond(5000);

        ps_emitter->setMinStartSize(dimension2df(1.5f,3.5f));
        ps_emitter->setMaxStartSize(dimension2df(1.5f,10.5f));
        ps_emitter->setMaxStartColor(SColor(35, 255, 255, 255));


        ps_affector = ps_node->createGravityAffector(vector3df(0.0f, -0.3f, 0.0f), 1);
        ps_node->addAffector(ps_affector);

        ps_node->setMaterialFlag(EMF_LIGHTING, false);
        ps_node->setMaterialType(EMT_TRANSPARENT_ALPHA_CHANNEL);
        ps_node->setMaterialTexture(0, m_device->getVideoDriver()->getTexture("textures/raindrop.png"));
        break;

    case Type::FIRECAMP:
        if (m_isMesh)
            ps_emitter = ps_node->createMeshEmitter(((IMeshSceneNode*)m_parent)->getMesh(), true, vector3df(0.0f,0.1f,0.0f));
        else
            ps_emitter = ps_node->createBoxEmitter(aabbox3df(-5,0,-5, 5,1,5), vector3df(0.0f,0.03f,0.0f));
        ps_emitter->setMinStartSize(dimension2df(.5f,.2f));
        ps_emitter->setMaxStartSize(dimension2df(.5f,.2f));
        ps_emitter->setMinStartColor(SColor(35, 255, 0, 0));
        ps_node->setEmitter(ps_emitter);

        ps_affector = ps_node->createFadeOutParticleAffector();
        ps_node->addAffector(ps_affector);

        ps_node->setMaterialFlag(EMF_LIGHTING, false);
        ps_node->setMaterialType(EMT_SOLID);
        break;

    }
}


