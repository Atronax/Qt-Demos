#include "miscellaneous.h"

#include "player.h"
Player::Player(btRigidBody *body, ISceneNode *node)
{
    setBody(body);
    setNode(node);
}

Player::~Player()
{

}

void Player::resolveCollisions(Entity *rhs)
{
    Miscellaneous *object = dynamic_cast<Miscellaneous*>(rhs);
    if (object)
    {
        /*
        if (object->type() == Miscellaneous::BASE)
        {
            if (body()->getTotalForce().isZero()) // ->getLinearVelocity().isZero())// == btVector3(0.0f, 0.0f, 0.0f))
            {
                qDebug("here");
                IAnimatedMeshSceneNode* anim_node = dynamic_cast<IAnimatedMeshSceneNode*>(node());
                if (anim_node)
                    anim_node->setMD2Animation(EMAT_STAND);
            }
        }
        */

        if (object->type() == Miscellaneous::BOX)
            // emit broken(object); Breaks boxes

        if (object->type() == Miscellaneous::SPHERE)
            emit changeSphereTexture(object);
    }
}

Player::VisualState Player::state() const
{
    return m_state;
}

void Player::setState(const Player::VisualState &state)
{
    if (m_state != state)
    {
        m_state = state;

        IAnimatedMeshSceneNode *mesh = dynamic_cast<IAnimatedMeshSceneNode*>(node());
        switch (m_state)
        {
        case VisualState::STANDING:
            mesh->setMD2Animation(EMAT_STAND);
            break;

        case VisualState::RUNNING:
            mesh->setMD2Animation(EMAT_RUN);
            break;

        case VisualState::JUMPING:
            mesh->setMD2Animation(EMAT_JUMP);
            break;

        default:
            break;
        }
    }
}
