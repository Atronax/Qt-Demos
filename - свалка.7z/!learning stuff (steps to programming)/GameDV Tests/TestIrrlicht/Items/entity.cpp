#include "entity.h"
Entity::Entity()
{
}

Entity::~Entity()
{
    m_node->remove();

    delete m_body->getMotionState();
    delete m_body->getCollisionShape();
    delete m_body;
}

btRigidBody *Entity::body() const
{
    return m_body;
}

void Entity::setBody(btRigidBody *body)
{
    m_body = body;
}
ISceneNode *Entity::node() const
{
    return m_node;
}

void Entity::setNode(ISceneNode *node)
{
    m_node = node;
}



