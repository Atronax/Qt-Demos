#ifndef PLAYER_H
#define PLAYER_H

class Miscellaneous;

#include "entity.h"
class Player : public Entity
{
    Q_OBJECT
public:
    explicit Player(btRigidBody *body, ISceneNode *node);
    ~Player();

    void resolveCollisions(Entity *rhs);

    enum VisualState {STANDING = 9000, RUNNING, JUMPING};
    void setState(const VisualState &state);
    VisualState state() const;

private:
    VisualState m_state;

signals:
    void broken(Miscellaneous *object);
    void changeSphereTexture(Miscellaneous *object);
};

#endif // PLAYER_H
