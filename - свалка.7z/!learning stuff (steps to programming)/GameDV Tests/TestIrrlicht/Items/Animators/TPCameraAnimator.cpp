#include "TPCameraAnimator.h"
using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace gui;

ThirdPersonCameraAnimator::ThirdPersonCameraAnimator(ISceneManager *manager, btDiscreteDynamicsWorld *world, ICursorControl *cursor, ISceneNode *player, vector3df targetOffset, f32 distance, f32 initAngleY, f32 initAngleZ, f32 mindistance, f32 maxdistance, f32 minAngle, f32 maxAngle, f32 rotationSpeed)
    : World(world),
      Manager(manager),
      Cursor(cursor),
      AngleY(initAngleY),
      AngleZ(initAngleZ),
      RotationSpeed(rotationSpeed)
{    
    setTarget(player);
    setTargetOffset(targetOffset);

    setDistanceBoundaries(mindistance, maxdistance);
    setDistance(distance);

    setAngleBoundaries(-maxAngle, -minAngle);
    setActive(true);
}

ThirdPersonCameraAnimator::~ThirdPersonCameraAnimator()
{
}

void ThirdPersonCameraAnimator::updateCursorPosition()
{
    irr::core::position2d<irr::f32> pos = Cursor->getRelativePosition();

    if (pos.X < 0.5f || pos.X > 0.5f)
        pos.X = 0.5f;

    if (pos.Y < 0.5f || pos.Y > 0.5f)
        pos.Y = 0.5f;
    if (pos.Y > 0.5f)
        pos.Y = 0.5f;

    Cursor->setPosition(pos);
}

void ThirdPersonCameraAnimator::updateCameraPosition(const vector3df &oldCameraPosition, vector3df &newCameraPosition)
{
    // Physics representation of camera FROM and TO positions.
    btTransform cameraFrom;
    cameraFrom.setIdentity();
    cameraFrom.setOrigin(btVector3(oldCameraPosition.X, oldCameraPosition.Y, oldCameraPosition.Z));

    btTransform cameraTo;
    cameraTo.setIdentity();
    cameraTo.setOrigin(btVector3(newCameraPosition.X, newCameraPosition.Y, newCameraPosition.Z));

    // Camera collision shape.
    btSphereShape cameraCollisionShape (0.5f);

    // Setup convex result callback (collision filtering).
    btCollisionWorld::ClosestConvexResultCallback ClosestConvex(cameraFrom.getOrigin(), cameraTo.getOrigin());
    ClosestConvex.m_collisionFilterMask = btBroadphaseProxy::StaticFilter;

    // Make collision test and use its results to get updated camera position
    World->convexSweepTest(&cameraCollisionShape, cameraFrom, cameraTo, ClosestConvex);
    if (ClosestConvex.hasHit())
    {
        const btScalar minFraction = ClosestConvex.m_closestHitFraction;

        // Get closest hit point.
        btVector3 DesiredPosition = btVector3(newCameraPosition.X, newCameraPosition.Y, newCameraPosition.Z);
        DesiredPosition.setInterpolate3(cameraFrom.getOrigin(), cameraTo.getOrigin(), minFraction);

        // Update new camera position;
        newCameraPosition = vector3df(DesiredPosition.x(), DesiredPosition.y(), DesiredPosition.z());
    }
}

bool ThirdPersonCameraAnimator::isActive()
{
    return Active;
}

void ThirdPersonCameraAnimator::setActive(bool status)
{    
    Active = status;
    if(Active)
    {
        Cursor->setVisible(false);
        updateCursorPosition();
    }
    else
        Cursor->setVisible(true);
}

f32 ThirdPersonCameraAnimator::getDistance()
{
    return Distance;
}

void ThirdPersonCameraAnimator::setDistance(f32 newDistance)
{    
    if (newDistance >= Mindistance && newDistance <= Maxdistance)
    {
        // check if newDistance is good enough to set it as Distance
        Distance = newDistance;
    }
    else
    {
        // else check boundaries to set the appropriate value of Distance
        if (Distance < Mindistance)
            Distance = Mindistance;
        if (Distance > Maxdistance)
            Distance = Maxdistance;
    }
}

f32 ThirdPersonCameraAnimator::getDistanceBoundariesMin()
{
    return Mindistance;
}

f32 ThirdPersonCameraAnimator::getDistanceBoundariesMax()
{
    return Maxdistance;
}

void ThirdPersonCameraAnimator::setDistanceBoundaries(f32 newMinDistance, f32 newMaxDistance)
{
    if (newMinDistance > 0.0f && newMaxDistance > 0.0f) // && (newMinDistance < Distance && newMaxDistance > Distance))
    {
        Mindistance = newMinDistance;
        Maxdistance = newMaxDistance;
    }
}

f32 ThirdPersonCameraAnimator::getAngleBoundariesMin()
{
    return MinAngle;
}

f32 ThirdPersonCameraAnimator::getAngleBoundariesMax()
{
    return MaxAngle;
}

void ThirdPersonCameraAnimator::setAngleBoundaries(f32 newMinAngle, f32 newMaxAngle)
{
    MinAngle = newMinAngle;
    MaxAngle = newMaxAngle;

    // Bound MinAngle/MaxAngle to avoid problematic areas
    if (MinAngle < -90.0f)
        MinAngle = -90.0f;
    if (MinAngle > 90.0f)
        MinAngle = 90.0f;

    if (MaxAngle < -90.0f)
        MaxAngle = -90.0f;
    if (MaxAngle > 90.0f)
        MaxAngle = 90.0f;

    if (MinAngle > MaxAngle)
        MaxAngle = MinAngle + 1.0f;

    // Ensure Vertical Rotation Angle is bounded correctly
    if (AngleZ < MinAngle)
        AngleZ = MinAngle;
    if (AngleZ > MaxAngle)
        AngleZ = MaxAngle;
}

void ThirdPersonCameraAnimator::setTarget(ISceneNode *newTarget)
{
    Target = newTarget;
}

const vector3df &ThirdPersonCameraAnimator::getTargetOffset()
{
    return TargetOffset;
}

void ThirdPersonCameraAnimator::setTargetOffset(const vector3df &newTargetOffset)
{
    TargetOffset = newTargetOffset;
}

f32 ThirdPersonCameraAnimator::getRotationSpeed()
{
    return RotationSpeed;
}

void ThirdPersonCameraAnimator::setRotationSpeed(f32 newRotationSpeed)
{
    RotationSpeed = newRotationSpeed;
}

//! Animates the camera
void ThirdPersonCameraAnimator::animateNode(irr::scene::ISceneNode *node, irr::u32)
{
    // make sure you don't go attaching this animator to anything other than a camera
    ICameraSceneNode *camera = (ICameraSceneNode*)node;
    if (Manager->getActiveCamera() != camera)
        return;

    if(Active)
    {
        position2df pos = Cursor->getRelativePosition();

        if (pos.X < 0.5f - EPSILON || pos.X > 0.5 + EPSILON)
            AngleY -= (pos.X - 0.5f)*RotationSpeed;

        if (pos.Y < 0.5f - EPSILON || pos.Y > 0.5f + EPSILON)
            AngleZ -= (pos.Y - 0.5f)*RotationSpeed;

        // Ensure Vertical Rotation Angle is bounded correctly
        if(AngleZ < MinAngle)
            AngleZ = MinAngle;
        if(AngleZ > MaxAngle)
            AngleZ = MaxAngle;

        updateCursorPosition();
    }

    // Camera is changing its position. Assumes the camera is *NOT* a child of the player node.
    vector3df ZoomFactor(Distance,0,0);
    ZoomFactor.rotateXYBy(-AngleZ, irr::core::vector3df(0,0,0));
    ZoomFactor.rotateXZBy( AngleY, irr::core::vector3df(0,0,0));

    vector3df oldPosition = Target->getPosition();
    vector3df newPosition = Target->getPosition() + ZoomFactor + TargetOffset;
    updateCameraPosition(oldPosition, newPosition);

    camera->setPosition(newPosition);
    camera->setTarget(Target->getPosition() + TargetOffset);
}

//! Creates clone of this animator
irr::scene::ISceneNodeAnimator *ThirdPersonCameraAnimator::createClone(irr::scene::ISceneNode *, irr::scene::ISceneManager *newManager)
{
    ISceneNodeAnimator *clone = new ThirdPersonCameraAnimator(newManager, World, Cursor, Target, TargetOffset, Distance, AngleY, AngleZ, Mindistance, Maxdistance, MinAngle, MaxAngle, RotationSpeed);
    return clone;
}
