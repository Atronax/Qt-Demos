#ifndef TPCAMERAANIMATOR_H
#define TPCAMERAANIMATOR_H

#include <irrlicht.h>
#include <btBulletDynamicsCommon.h>

class ThirdPersonCameraAnimator : public irr::scene::ISceneNodeAnimator
{
public:
    ThirdPersonCameraAnimator(irr::scene::ISceneManager *manager, btDiscreteDynamicsWorld *world, irr::gui::ICursorControl *cursor, irr::scene::ISceneNode *player, irr::core::vector3df targetOffset = irr::core::vector3df(0,0,0), irr::f32 distance = 50.0f, irr::f32 initAngleY = 180.0f, irr::f32 initAngleZ = 10.0f, irr::f32 Mindistance = 20.0f, irr::f32 Maxdistance = 200.0f, irr::f32 minAngle = -45.0f, irr::f32 maxAngle = 89.0f, irr::f32 rotationSpeed = 60.0f);
    virtual ~ThirdPersonCameraAnimator();

    //! ISceneNodeAnimator overrides
    virtual void animateNode(irr::scene::ISceneNode *node, irr::u32 timeMs);
    virtual ISceneNodeAnimator* createClone(irr::scene::ISceneNode* node, irr::scene::ISceneManager* newManager = 0);

    //! Camera activeness controls
    bool isActive();
    void setActive(bool status);

    //! Zoom controls
    irr::f32 getDistance();
    void setDistance(irr::f32 newDistance);

    irr::f32 getDistanceBoundariesMin();
    irr::f32 getDistanceBoundariesMax();
    void setDistanceBoundaries(irr::f32 newMinDistance, irr::f32 newMaxDistance);

    //! Angle controls
    irr::f32 getAngleBoundariesMin();
    irr::f32 getAngleBoundariesMax();
    void setAngleBoundaries(irr::f32 newMinAngle, irr::f32 newMaxAngle);

    //! Target controls
    void setTarget (irr::scene::ISceneNode* newTarget);

    const irr::core::vector3df& getTargetOffset();
    void setTargetOffset (const irr::core::vector3df& newTargetOffset);

    //! Motion controls
    irr::f32 getRotationSpeed();
    void setRotationSpeed(irr::f32 newRotationSpeed);

private:
    void updateCursorPosition();
    void updateCameraPosition(const irr::core::vector3df& oldCameraPosition, irr::core::vector3df& newCameraPosition);

    // Basis.
    btDiscreteDynamicsWorld *World;
    irr::scene::ISceneManager *Manager;
    irr::gui::ICursorControl *Cursor;
    irr::scene::ISceneNode *Target;

    // State.
    static constexpr float EPSILON = 0.001f;
    irr::f32 AngleY, AngleZ;

    irr::core::vector3df TargetOffset;
    irr::f32 Mindistance, Maxdistance;
    irr::f32 MinAngle, MaxAngle;
    irr::f32 RotationSpeed;
    irr::f32 Distance;
    bool Active;
};

#endif // TPCAMERAANIMATOR_H
