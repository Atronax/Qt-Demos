#ifndef ENTITY_H
#define ENTITY_H

#include <irrlicht.h>
using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;

#include <btBulletDynamicsCommon.h>

#include <QObject>
class Entity : public QObject
{
    Q_OBJECT
public:
    explicit Entity();
    virtual ~Entity();

    virtual void resolveCollisions(Entity* rhs) = 0;

    btRigidBody *body() const;
    void setBody(btRigidBody *body);

    ISceneNode *node() const;
    void setNode(ISceneNode *node);

private:
    btRigidBody *m_body;
    ISceneNode  *m_node;

};

#endif // ENTITY_H
