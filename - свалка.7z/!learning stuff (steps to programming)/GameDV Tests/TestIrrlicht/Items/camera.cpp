#include "camera.h"
Camera::Camera(const Type &type, IrrlichtDevice* device, btDiscreteDynamicsWorld* world, ISceneNode *target)
{
    m_device = device;
    m_world = world;
    m_target = target;

    setCamera(nullptr);
    setAnimator(nullptr);
    setType(type);
}

Camera::~Camera()
{
    if (m_camera)
        m_camera->drop();

    if (m_animator)
        m_animator->drop();
}

Camera::Type Camera::type() const
{
    return m_type;
}

void Camera::setType(const Camera::Type &type)
{
    m_type = type;

    switch (m_type)
    {
    case Camera::Type::TPCamera:
        create3DPersonCamera();
        break;

    case Camera::Type::FPCamera:
        create1TPersonCamera();
        break;

    default:
        break;
    }
}

ICameraSceneNode *Camera::camera() const
{
    return m_camera;
}

void Camera::setCamera(ICameraSceneNode *camera)
{
    m_camera = camera;
}

ISceneNodeAnimator *Camera::animator() const
{
    return m_animator;
}

ThirdPersonCameraAnimator *Camera::TPanimator() const
{
    return dynamic_cast<ThirdPersonCameraAnimator*>(m_animator);
}

void Camera::setAnimator(ISceneNodeAnimator *animator)
{
    m_animator = animator;
}

// LIST OF CAMERAS
void Camera::create3DPersonCamera()
{
    m_camera = m_device->getSceneManager()->addCameraSceneNode();
    m_animator = new ThirdPersonCameraAnimator(m_device->getSceneManager(), m_world, m_device->getCursorControl(), m_target, vector3df(0, 15, 0), 2.0f, 180.0f, 10.0f, 2.0f, 50.0f);
    m_camera->addAnimator(m_animator);
}

void Camera::create1TPersonCamera()
{

}
