#include "miscellaneous.h"
Miscellaneous:: Miscellaneous(btRigidBody *body, ISceneNode *node)
{
    setBody(body);
    setNode(node);
}

Miscellaneous::~Miscellaneous()
{

}

void Miscellaneous::resolveCollisions(Entity *)
{
}

int Miscellaneous::type() const
{
    return m_type;
}

void Miscellaneous::setType(int type)
{
    m_type = type;
}


