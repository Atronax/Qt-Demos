#ifndef MISCELLANEOUS_H
#define MISCELLANEOUS_H

#include "entity.h"
class Miscellaneous : public Entity
{
    Q_OBJECT
public:
    explicit Miscellaneous(btRigidBody *body, ISceneNode *node);
    ~Miscellaneous();

    void resolveCollisions(Entity *rhs);

    enum {BASE = 0, BOX, SPHERE};
    int type() const;
    void setType(int type);

private:
    int m_type;

};

#endif // MISCELLANEOUS_H
