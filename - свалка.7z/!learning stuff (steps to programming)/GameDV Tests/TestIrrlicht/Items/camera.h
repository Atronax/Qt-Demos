#ifndef CAMERA_H
#define CAMERA_H

// animators
#include "Animators/TPCameraAnimator.h"

#include "entity.h"
class Camera
{
public:
    enum class Type {TPCamera, FPCamera};
    Camera(const Camera::Type& type, IrrlichtDevice* device, btDiscreteDynamicsWorld* world, ISceneNode* target);
    ~Camera();

    Camera::Type type() const;
    void setType(const Camera::Type &type);

    ICameraSceneNode *camera() const;
    void setCamera(ICameraSceneNode *camera);

    ISceneNodeAnimator *animator() const;
    ThirdPersonCameraAnimator *TPanimator() const;
    void setAnimator(ISceneNodeAnimator *animator);

private:
    void create3DPersonCamera();
    void create1TPersonCamera();

    IrrlichtDevice *m_device;
    btDiscreteDynamicsWorld *m_world;

    Camera::Type m_type;
    ICameraSceneNode *m_camera;
    ISceneNodeAnimator *m_animator;
    ISceneNode *m_target;
};

#endif // CAMERA_H
