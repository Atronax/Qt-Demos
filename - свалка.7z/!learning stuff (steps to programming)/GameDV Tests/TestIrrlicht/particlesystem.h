#ifndef PARTICLESYSTEM_H
#define PARTICLESYSTEM_H

#include <QString>

#include <irrlicht.h>
using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;

class ParticleSystem
{
public:    
    enum class Type {SMOKE, BUBBLES, RAIN, FIRECAMP};

    explicit ParticleSystem(IrrlichtDevice* device, const QString& name, const ParticleSystem::Type& type, ISceneNode* parent, bool isMesh);
    ~ParticleSystem();

    const Type& type() const;
    void setType(const Type &type);

    void initFor(const Type &type);

private:
    IrrlichtDevice* m_device;
    QString m_name;
    Type m_type;

    ISceneNode* m_parent;
    bool m_isMesh;

    IParticleSystemSceneNode* ps_node;
    IParticleEmitter* ps_emitter;
    IParticleAffector* ps_affector;


};

#endif // PARTICLESYSTEM_H
