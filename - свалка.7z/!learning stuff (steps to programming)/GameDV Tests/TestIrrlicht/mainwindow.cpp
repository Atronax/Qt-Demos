// LOGIC
#include <QTimer>

// WIDGETS
#include <QVBoxLayout>

// EVENTS
#include <QKeyEvent>

#include "mainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
{
    setMouseTracking(true);

    setupUserInterface();
    prepareScene();
    setupLayout();
}

MainWindow::~MainWindow()
{
    delete m_engine;
}

void MainWindow::keyPressEvent(QKeyEvent *ev)
{
    if (m_player)
    {
        IAnimatedMeshSceneNode *pnode = dynamic_cast<IAnimatedMeshSceneNode*>(m_player->node());
        btRigidBody *pbody = m_player->body();

        vector3df ppos = pnode->getPosition();
        vector3df pdir = pnode->getRotation().rotationToDirection(vector3df(1,0,0));
        btVector3 direction (pdir.X, pdir.Y, pdir.Z);

        if (ev->key() == Qt::Key_1)
        {
            Miscellaneous* box = m_engine->makeBox(btVector3(ppos.X, ppos.Y, ppos.Z) + btVector3(0.0f, 50.0f, 0.0f), vector3df(5.0f, 5.0f, 5.0f), 1);
            m_engine->makeParticleSystem("Campfire", ParticleSystem::Type::FIRECAMP, (IAnimatedMeshSceneNode*)box->node(), true);
        }

        if (ev->key() == Qt::Key_2)
            m_engine->makeSphere(btVector3(ppos.X, ppos.Y, ppos.Z) + btVector3(0.0f, 50.0f, 0.0f), 50.0f, 1);

        if (ev->key() == Qt::Key_3)
            m_engine->makeConvex("tv.3ds", false, btVector3(ppos.X, ppos.Y, ppos.Z) + btVector3(0.0f, 50.0f, 0.0f), vector3df(5.0f, 5.0f, 5.0f), 1);

        if (ev->key() == Qt::Key_W)
        {
            m_player->setState(Player::VisualState::RUNNING);
            pbody->setLinearVelocity(25*direction);
        }

        if (ev->key() == Qt::Key_A)
        {
            btTransform transform = pbody->getWorldTransform();
            transform.setRotation(btQuaternion(btVector3(0,1,0), -10/57.0)*pbody->getOrientation());

            pbody->setCenterOfMassTransform(transform);
        }

        if (ev->key() == Qt::Key_S)
        {
            m_player->setState(Player::VisualState::RUNNING);
            pbody->setLinearVelocity(-0.5*direction);
        }

        if (ev->key() == Qt::Key_D)
        {
            btTransform transform = pbody->getWorldTransform();
            transform.setRotation(btQuaternion(btVector3(0,1,0),  +10/57.0)*pbody->getOrientation());

            pbody->setCenterOfMassTransform(transform);
        }

        if (ev->key() == Qt::Key_Alt)
            m_camera->TPanimator()->setActive(!m_camera->TPanimator()->isActive());

        if (ev->key() == Qt::Key_Space)
        {
            m_player->setState(Player::VisualState::JUMPING);

            pbody->setLinearVelocity(btVector3(0,50,0));
        }

        if (ev->key() == Qt::Key_Control)
        {
            m_player->setState(Player::VisualState::STANDING);
        }
    }

}

void MainWindow::wheelEvent(QWheelEvent *ev)
{
    if (ev->delta() < 0)
        m_camera->TPanimator()->setDistance(m_camera->TPanimator()->getDistance() + 5.0f);
    else
        m_camera->TPanimator()->setDistance(m_camera->TPanimator()->getDistance() - 5.0f);
}

void MainWindow::setupUserInterface()
{   
    setFixedSize(800,800);
    m_engine = new Engine(this);
}

void MainWindow::setupLayout()
{    
    QGridLayout *layout = new QGridLayout;

    QHBoxLayout *oceancolor_layout = new QHBoxLayout;
    oceancolor_layout->addWidget(m_OceanColor_R);
    oceancolor_layout->addWidget(m_OceanColor_G);
    oceancolor_layout->addWidget(m_OceanColor_B);

    QHBoxLayout *terrainlevel_layout = new QHBoxLayout;
    terrainlevel_layout->addWidget(m_TerrainLevel_1);
    terrainlevel_layout->addWidget(m_TerrainLevel_2);
    terrainlevel_layout->addWidget(m_TerrainLevel_3);
    terrainlevel_layout->addWidget(m_TerrainLevel_4);

    layout->addWidget(m_engine, 0, 0, 10, 3);
    layout->addLayout(oceancolor_layout, 10, 0, 1, 3);
    layout->addLayout(terrainlevel_layout, 11, 0, 1, 3);

    setLayout(layout);
}

void MainWindow::makeTerrainAndWater()
{
    // terrain
    float groundScaleX = 100.0f;
    float groundScaleY = 8.0f;
    float groundScaleZ = 100.0f;
    m_engine->makeGround("D:/tamriel256.jpg", btVector3(-128.0f*groundScaleX, 0.0f, -128.0f*groundScaleZ), vector3df(groundScaleX, groundScaleY, groundScaleZ));

    // Terrain level
    Terrain *terrain = m_engine->terrainObjectByName("Terrain");

    m_TerrainLevel_1 = new QSlider (Qt::Horizontal);
    m_TerrainLevel_1->setObjectName("TerrainLevel_1");
    m_TerrainLevel_1->setRange(0, 100);
    m_TerrainLevel_1->setValue(terrain->level(0)*100);
    connect (m_TerrainLevel_1, SIGNAL(valueChanged(int)), this, SLOT(setTerrainLevel(int)));

    m_TerrainLevel_2 = new QSlider (Qt::Horizontal);
    m_TerrainLevel_2->setObjectName("TerrainLevel_2");
    m_TerrainLevel_2->setRange(0, 100);
    m_TerrainLevel_2->setValue(terrain->level(1)*100);
    connect (m_TerrainLevel_2, SIGNAL(valueChanged(int)), this, SLOT(setTerrainLevel(int)));

    m_TerrainLevel_3 = new QSlider (Qt::Horizontal);
    m_TerrainLevel_3->setObjectName("TerrainLevel_3");
    m_TerrainLevel_3->setRange(0, 100);
    m_TerrainLevel_3->setValue(terrain->level(2)*100);
    connect (m_TerrainLevel_3, SIGNAL(valueChanged(int)), this, SLOT(setTerrainLevel(int)));

    m_TerrainLevel_4 = new QSlider (Qt::Horizontal);
    m_TerrainLevel_4->setObjectName("TerrainLevel_4");
    m_TerrainLevel_4->setRange(0, 100);
    m_TerrainLevel_4->setValue(terrain->level(3)*100);
    connect (m_TerrainLevel_4, SIGNAL(valueChanged(int)), this, SLOT(setTerrainLevel(int)));


    // Ocean color
    SColorf ocean_color = m_engine->waterObjectByName("OceanWater")->addedColor();

    m_OceanColor_R = new QSlider (Qt::Horizontal);
    m_OceanColor_R->setObjectName("OceanColor_R");
    m_OceanColor_R->setRange(0, 255);
    m_OceanColor_R->setValue(ocean_color.r);
    connect (m_OceanColor_R, SIGNAL(valueChanged(int)), this, SLOT(setOceanColor(int)));

    m_OceanColor_G = new QSlider (Qt::Horizontal);
    m_OceanColor_G->setObjectName("OceanColor_G");
    m_OceanColor_G->setRange(0, 255);
    m_OceanColor_G->setValue(ocean_color.g);
    connect (m_OceanColor_G, SIGNAL(valueChanged(int)), this, SLOT(setOceanColor(int)));

    m_OceanColor_B = new QSlider (Qt::Horizontal);
    m_OceanColor_B->setObjectName("OceanColor_B");
    m_OceanColor_B->setRange(0, 255);
    m_OceanColor_B->setValue(ocean_color.b);
    connect (m_OceanColor_B, SIGNAL(valueChanged(int)), this, SLOT(setOceanColor(int)));

    // sky
    m_engine->device()->getSceneManager()->addSkyDomeSceneNode(m_engine->device()->getVideoDriver()->getTexture("textures/skydome.png"), 16, 8, 0.9, 2.0, 600.0f);
    m_engine->makeClouds();
}

void MainWindow::makePlayerAndCamera()
{
    m_player = m_engine->makePlayer(btVector3(0,100*8.0f,0), vector3df(0.5f, 0.5f, 0.5f), 50);
    m_camera = new Camera(Camera::Type::TPCamera, m_engine->device(), m_engine->world(), m_player->node());
    m_camera->camera()->setFarValue(100000);
    m_camera->TPanimator()->setRotationSpeed(30);
    m_camera->TPanimator()->setTargetOffset(vector3df(0.0f, 20.0f, 0.0f));

    // Тестируем систему частиц.
    // m_engine->makeParticleSystem("Smoke", ParticleSystem::Type::SMOKE, m_player->node(), true);
    m_engine->makeParticleSystem("Bubbles", ParticleSystem::Type::BUBBLES, m_camera->camera(), false);
}

void MainWindow::prepareScene()
{
    // Настраиваем окружение.
    m_engine->device()->getSceneManager()->setAmbientLight(SColorf(0.5f, 0.5f, 0.5f, 1.0f));
    // video->setFog(SColor(255,255,255,255), EFT_FOG_EXP, 0.0f, 5000.0f, 0.1f, false, true);

    // Создаем ландшафт и игрока с камерой.
    makeTerrainAndWater();
    makePlayerAndCamera();
}

// slots
void MainWindow::setOceanColor(int value)
{
    QString name = static_cast<QSlider*>(sender())->objectName();

    ReflectingWater *ocean = m_engine->waterObjectByName("OceanWater");
    SColorf old = ocean->addedColor();

    if (name == "OceanColor_R")
        ocean->setAddedColor(SColorf(value/256.0, old.g, old.b, old.a));

    if (name == "OceanColor_G")
        ocean->setAddedColor(SColorf(old.r, value/256.0, old.b, old.a));

    if (name == "OceanColor_B")
        ocean->setAddedColor(SColorf(old.r, old.g, value/256.0, old.a));

}

void MainWindow::setTerrainLevel(int value)
{
    QString name = static_cast<QSlider*>(sender())->objectName();

    Terrain *terrain = m_engine->terrainObjectByName("Terrain");

    if (name == "TerrainLevel_1")
        terrain->setLevel(0, value/100.0f);

    if (name == "TerrainLevel_2")
        terrain->setLevel(1, value/100.0f);

    if (name == "TerrainLevel_3")
        terrain->setLevel(2, value/100.0f);

    if (name == "TerrainLevel_4")
        terrain->setLevel(3, value/100.0f);
}
