#ifndef ENGINE_H
#define ENGINE_H

// Common
#include <QList>

// Irrlicht
#include <irrlicht.h>
using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;

// Bullet
#include <btBulletDynamicsCommon.h>
#include <BulletCollision/Gimpact/btGImpactCollisionAlgorithm.h>
#include <BulletCollision/CollisionShapes/btHeightfieldTerrainShape.h>

// Assimp and IrrAssimp
#include "IrrAssimp/IrrAssimp.h"

// User Defined
#include "Shaders/shaders.h"
#include "particlesystem.h"
#include "Nodes/nodes.h"
#include "Items/items.h"

#include <QWidget>
class Engine : public QWidget
{
    Q_OBJECT
public:
    explicit Engine(QWidget *parent = nullptr);
    ~Engine();

    // BASIS
    IrrlichtDevice *device() const;
    btDiscreteDynamicsWorld *world() const;

    // SHADERS
    Terrain *terrainObjectByName(const QString& obj_name);
    ReflectingWater* waterObjectByName(const QString& obj_name);

    // GENERATORS
    Player* makePlayer (const btVector3& position, const vector3df& scale, btScalar mass);

    Miscellaneous* makeBox (const btVector3& position, const vector3df& scale, btScalar mass);
    Miscellaneous* makeSphere (const btVector3& position, const btScalar& radius, btScalar mass);
    Miscellaneous* makeGround (const path& filename, const btVector3& position, const vector3df& scale);
    void makeClouds();

    ParticleSystem* makeParticleSystem(const QString& name, const ParticleSystem::Type& type, ISceneNode* parent, bool isMesh);
    Miscellaneous* makeConvex (const path& filename, bool isAnimated, const btVector3& position, const vector3df& scale, btScalar mass);

    // CLEANERS
    void cleanObjects();

protected:
    void timerEvent(QTimerEvent *ev);
    void resizeEvent(QResizeEvent *ev);

private:    
    btTriangleMesh* convertIrrlichtMeshToBulletMesh(IMesh* mesh, const vector3df& scale);

    // CORE
    void destroyObject(Entity* object);
    void updateEngineState();
    void updateRenderState(btRigidBody* object);
    static constexpr int m_FPS = 60;

    QList<ISceneNode*> m_nodes;
    QList<btRigidBody*> m_bodies;
    QList<btTriangleMesh*> m_meshes;

    // IRRLICHT-GE
    void initDevice();
    void cleanIrrlicht();
    IrrlichtDevice *m_device;

    // BULLET-PE    
    void initWorld();
    void cleanBullet();
    btDiscreteDynamicsWorld *m_world;
    btCollisionDispatcher *m_collisionDispatcher;
    btBroadphaseInterface *m_broadphaseAlgorithm;
    btDefaultCollisionConfiguration *m_collisionConfig;
    btSequentialImpulseConstraintSolver *m_constraintSolver;    

    // COLLISIONS
    void checkCollisions();

    // SHADER OBJECTS
    QList<Terrain*> m_terrain_objects;
    QList<ReflectingWater*> m_water_objects;
    QList<Glass*> m_glass_objects;

    // PARTICLE OBJECTS
    QList<ParticleSystem*> m_particle_objects;

public slots:
    void onBroken(Miscellaneous* object);
    void onChangeSphereTexture(Miscellaneous* sphere);

};

#endif // ENGINE_H
