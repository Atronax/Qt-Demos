#ifndef CONTEXTMENU_H
#define CONTEXTMENU_H

class GameManager;

#include <QMenu>
class ContextMenu : public QMenu
{
    Q_OBJECT
public:
    explicit ContextMenu(GameManager* gamemanager, const QString& title = "", QWidget* parent = nullptr);
    ~ContextMenu();

private:
    void buildActions();
    void buildMenu();

    GameManager* m_gamemanager;

    // 1. Chooses an object as a current one:
    // - building blocks
    QAction *act_1x1box;
    QAction *act_1x2box;
    QAction *act_2x1box;
    QAction *act_1x1barrel;
    QAction *act_2x2barrel;
    QAction *act_1x1brick;
    QAction *act_tree_fir;
    QAction *act_ground;
    QAction *act_grass;
    QAction *act_moon;
    QAction *act_stcoin;
    QAction *act_ststar;

    // - collectibles
    QAction *act_dyncoin;
    QAction *act_dynstar;
    QAction *act_potion_restore_hp;
    QAction *act_potion_add_hp;
    QAction *act_potion_add_damage;
    QAction *act_potion_add_defence;

    // - enemies
    QAction *act_dwarf;
    QAction *act_unicorn;

    // saves and loads a level in an editormode or the game in the gamemode
    QAction *act_save_level;
    QAction *act_load_level;

    QAction *act_save_game;
    QAction *act_load_game;

};

#endif // CONTEXTMENU_H
