#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

class ContextMenu;
class WorldManager;

#include <QGraphicsScene>
#include <QGraphicsView>
class GameManager : public QGraphicsView
{
    Q_OBJECT
public:
    explicit GameManager(QWidget *parent = nullptr);
    ~GameManager();

    QGraphicsView *getView();
    QGraphicsScene *getScene();
    WorldManager *worldmanager() const;

protected:
    void keyPressEvent(QKeyEvent *ev);
    void mousePressEvent(QMouseEvent *ev);
    void wheelEvent(QWheelEvent *ev);

private:
    void buildSceneAndView();    
    void buildWorldManager();
    void buildContextMenu();

    bool itemExistsAt (const QPointF& position) const;
    void createBodyAt (const QPointF& position) const;
    void removeBodyAt (const QPointF& position) const;
    void rotateBodyAt (const QPointF& position, bool isClockwise) const;
    void turnBodyToDynamic (const QPointF& position) const;
    void turnBodyToStatic  (const QPointF& position) const;

    void currentItemIsAt (const QPointF& position);
    void moveCurrentItemTo (bool toTop, bool toLeft, bool toBottom, bool toRight) const;

    WorldManager *m_worldmanager;
    ContextMenu *context_menu;

    QGraphicsScene *scene;
    QGraphicsView *view;
    QGraphicsItem *current_item;

signals:

public slots:
    void changeBackground();
};

#endif // GAMEMANAGER_H
