// items
#include "Items/entity.h"
#include "Items/enemy.h"
#include "Items/player.h"

#include "contactlistener.h"
ContactListener::ContactListener()
{
    m_contacts = QVector<Contact>();
}

ContactListener::~ContactListener()
{

}

const QVector<Contact>& ContactListener::contacts() const
{
    return m_contacts;
}

void ContactListener::BeginContact(b2Contact* contact)
{
    Contact current_contact = {contact->GetFixtureA(), contact->GetFixtureB()};
    m_contacts.push_back(current_contact);

    Player *player = dynamic_cast<Player*>(reinterpret_cast<Entity*>(contact->GetFixtureA()->GetBody()->GetUserData()));
    Enemy *enemy = dynamic_cast<Enemy*>(reinterpret_cast<Entity*>(contact->GetFixtureA()->GetBody()->GetUserData()));    

    if (!enemy)
        enemy = dynamic_cast<Enemy*>(reinterpret_cast<Entity*>(contact->GetFixtureB()->GetBody()->GetUserData()));
    if (!player)
        player = dynamic_cast<Player*>(reinterpret_cast<Entity*>(contact->GetFixtureB()->GetBody()->GetUserData()));

    if (enemy)
        enemy->startAttacking();
    if (player)
        player->startAttacking();

}

void ContactListener::EndContact(b2Contact* contact)
{
    Contact current_contact = {contact->GetFixtureA(), contact->GetFixtureB()};
    foreach (Contact saved_contact, m_contacts)
    {
        if (saved_contact == current_contact)
            m_contacts.removeOne(saved_contact);
    }

    Player *player = dynamic_cast<Player*>(reinterpret_cast<Entity*>(contact->GetFixtureA()->GetBody()->GetUserData()));
    Enemy *enemy = dynamic_cast<Enemy*>(reinterpret_cast<Entity*>(contact->GetFixtureA()->GetBody()->GetUserData()));
    if (!enemy)
        enemy = dynamic_cast<Enemy*>(reinterpret_cast<Entity*>(contact->GetFixtureB()->GetBody()->GetUserData()));
    if (!player)
        player = dynamic_cast<Player*>(reinterpret_cast<Entity*>(contact->GetFixtureB()->GetBody()->GetUserData()));

    if (enemy)
        enemy->stopAttacking();
    if (player)
        player->stopAttacking();
}

void ContactListener::PreSolve(b2Contact*, const b2Manifold*)
{
}

void ContactListener::PostSolve(b2Contact*, const b2ContactImpulse*)
{
}
