// logic
#include <QTimer>

// events
#include <QKeyEvent>

// items
#include "windows/inventory.h"
#include "windows/statistics.h"
#include "gamemanager.h"
#include "worldmanager.h"

#include "player.h"
Player::Player (GameManager* manager, b2Body* body, QGraphicsItem* parent)
{    
    setParentItem(parent);
    setManager(manager);

    setBody(body);
    setSolid(true);
    setSprite(new Sprite(this));

    initialize();    
}

Player::~Player()
{
    if (m_attacking_timer->isActive())
        m_attacking_timer->stop();
    m_attacking_timer->deleteLater();

    delete m_inventory;
    delete m_statistics;
}

void Player::initialize()
{
    // visuals
    sprite()->fillComponents(manager()->worldmanager()->imagesCache()->player(), manager()->worldmanager()->imagesCache()->player_framesizes());

    // game logic
    setLevel(0);
    setCurrentExperience(0);
    setNeededExperience(500);
    setMaximumHealth(5000);
    setDamage(20);
    setDefence(10);

    // inventory
    m_inventory = new Inventory(this);

    // statistics
    m_statistics = new Statistics(this);

    // jumping
    setIsJumpingAllowed(false);

    // attacking
    m_target = nullptr;
    m_attacking_timer = new QTimer(this);
    connect(m_attacking_timer, SIGNAL(timeout()), this, SLOT(attack()));
}

void Player::startAttacking()
{
    m_attacking_timer->start(200);
}

void Player::stopAttacking()
{
    m_target = nullptr;
    m_attacking_timer->stop();
}

void Player::checkCollision(Entity *rhs)
{
    Enemy* enemy = dynamic_cast<Enemy*>(rhs);
    BuildBlock* buildblock = dynamic_cast<BuildBlock*>(rhs);
    Collectible* collectible = dynamic_cast<Collectible*>(rhs);
    EquipmentItem* equipmentitem = dynamic_cast<EquipmentItem*>(rhs);

    if (enemy)
        m_target = enemy;

    if (buildblock)
    {
        bool on_leftside = (pos().x() + rect().width() == buildblock->pos().x());
        bool on_rightside = (pos().x() == buildblock->pos().x() + buildblock->rect().width());
        bool on_topside = (pos().y() < buildblock->pos().y());

        if (on_topside && !(on_leftside || on_rightside))
            setIsJumpingAllowed(true);
    }

    if (collectible)
        emit got(collectible);

    if (equipmentitem)
        emit got(equipmentitem);
}

bool Player::isJumpingAllowed() const
{
    return m_isJumpingAllowed;
}

void Player::setIsJumpingAllowed(bool value)
{    
    m_isJumpingAllowed = value;
}

void Player::levelUp()
{
    setLevel(1+level());
    setCurrentExperience(0);
    setNeededExperience(500*(1+level()));
    setDamage(1+damage());
    setDefence(1+defence());
    setMaximumHealth(maximumHealth() + level()*100.0);
}

void Player::updateState(const QPointF&)
{
    if (visualState() != ATTACKING)
    {
        if (body()->GetLinearVelocity().x == 0 && body()->GetLinearVelocity().y == 0)
           setVisualState(AFK);
    }
}

Inventory *Player::inventory() const
{
    return m_inventory;
}

Statistics *Player::statistics() const
{
    return m_statistics;
}

void Player::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (sprite())
    {
        int type = sprite()->type();
        if (type == Sprite::STATIC)
            sprite()->drawStatic(painter);
        if (type == Sprite::DYNAMIC)
            sprite()->drawDynamic(painter);
    }   

    drawExperiencebar(painter, QRect(rect().x(), rect().y()-30, rect().width(), 8));
    drawDDbar(painter, QRect(rect().x(), rect().y()-20, rect().width(), 8));
    drawHealthbar(painter, QRect(rect().x(), rect().y()-10, rect().width(), 8));
}

// slots
void Player::attack()
{
    if (m_target && visualState() == ATTACKING)
    {
        m_target->setCurrentHealth(m_target->currentHealth() - damage() + damage()*(m_target->defence()/100.0));
        if (m_target->currentHealth() <= 0)
            emit killed(m_target);
    }
}
