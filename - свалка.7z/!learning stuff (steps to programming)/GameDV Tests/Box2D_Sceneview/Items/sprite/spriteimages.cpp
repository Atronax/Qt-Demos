#include "spriteimages.h"

SpriteImages::SpriteImages()
{
    // static images
    m_coin = nullptr;
    m_star = nullptr;
    m_crate = nullptr;
    m_barrel = nullptr;
    m_brick = nullptr;
    m_ground = nullptr;
    m_grass = nullptr;
    m_moon = nullptr;

    m_potion_add_hp = nullptr;
    m_potion_restore_hp = nullptr;
    m_potion_add_damage = nullptr;
    m_potion_add_defence = nullptr;

    // dynamic images
    m_tree_fir = nullptr;

    fillPlayerSpritesheet();
    fillDwarfSpritesheet();
    fillUnicornSpritesheet();
}

SpriteImages::~SpriteImages()
{
    // static images
    delete m_coin;
    delete m_star;
    delete m_crate;
    delete m_barrel;
    delete m_brick;
    delete m_ground;
    delete m_grass;
    delete m_moon;
    delete m_potion_restore_hp;
    delete m_potion_add_hp;
    delete m_potion_add_damage;
    delete m_potion_add_defence;

    // dynamic images
    delete m_tree_fir;

    m_player_spritesheet->clear();
    m_dwarf_spritesheet->clear();
    m_unicorn_spritesheet->clear();

    delete m_player_spritesheet;
    delete m_dwarf_spritesheet;
    delete m_unicorn_spritesheet;
}

// static
QPixmap* SpriteImages::coin()
{
    if (!m_coin)
        m_coin = new QPixmap(":/images/sprites/static/coin.png");

    return m_coin;
}

QPixmap *SpriteImages::star()
{
    if (!m_star)
        m_star = new QPixmap(":/images/sprites/static/star.png");

    return m_star;
}

QPixmap *SpriteImages::crate()
{
    if (!m_crate)
        m_crate = new QPixmap(":/images/sprites/static/crate.png");

    return m_crate;
}

QPixmap *SpriteImages::barrel()
{
    if (!m_barrel)
        m_barrel = new QPixmap(":/images/sprites/static/barrel.png");

    return m_barrel;
}

QPixmap *SpriteImages::brick()
{
    if (!m_brick)
        m_brick = new QPixmap(":/images/sprites/static/brick.png");

    return m_brick;
}

QPixmap *SpriteImages::ground()
{
    if (!m_ground)
        m_ground = new QPixmap(":/images/sprites/static/ground.png");

    return m_ground;
}

QPixmap *SpriteImages::grass()
{
    if (!m_grass)
        m_grass = new QPixmap(":/images/sprites/static/grass.png");

    return m_grass;
}

QPixmap *SpriteImages::moon()
{
    if (!m_moon)
        m_moon = new QPixmap(":/images/sprites/static/moon.png");

    return m_moon;
}

QPixmap *SpriteImages::potion_restore_hp()
{
    if (!m_potion_restore_hp)
        m_potion_restore_hp = new QPixmap(":/images/sprites/static/potion_restore_hp.png");

    return m_potion_restore_hp;
}

QPixmap *SpriteImages::potion_add_hp()
{
    if (!m_potion_add_hp)
        m_potion_add_hp = new QPixmap(":/images/sprites/static/potion_add_hp.png");

    return m_potion_add_hp;
}

QPixmap *SpriteImages::potion_add_damage()
{
    if (!m_potion_add_damage)
        m_potion_add_damage = new QPixmap(":/images/sprites/static/potion_add_damage.png");

    return m_potion_add_damage;
}

QPixmap *SpriteImages::potion_add_defence()
{
    if (!m_potion_add_defence)
        m_potion_add_defence = new QPixmap(":/images/sprites/static/potion_add_defence.png");

    return m_potion_add_defence;
}

QPixmap *SpriteImages::tree_fir()
{
    if (!m_tree_fir)
        m_tree_fir = new QPixmap(":/images/sprites/dynamic/trees/fir.png");

    return m_tree_fir;
}

// dynamic
void SpriteImages::fillPlayerSpritesheet()
{
    m_player_spritesheet = new QVector<QPixmap*>;
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_afk.png"));
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_moving.png"));
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_jumping.png"));
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_attacking.png"));
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_moving.png"));
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_moving.png"));
    m_player_spritesheet->append(new QPixmap(":/images/sprites/dynamic/dwarf/dwarf_dying.png"));

    m_player_framesizes = new QVector<QPair<float,float> >;
    m_player_framesizes->append(QPair<float,float>(40.0,62.0));
    m_player_framesizes->append(QPair<float,float>(344.0/8.0,63.0));
    m_player_framesizes->append(QPair<float,float>(258.0/6.0,64.0));
    m_player_framesizes->append(QPair<float,float>(394.0/8.0,63.0));
    m_player_framesizes->append(QPair<float,float>(344.0/8.0,63.0));
    m_player_framesizes->append(QPair<float,float>(344.0/8.0,63.0));
    m_player_framesizes->append(QPair<float,float>(276.0/6.0,64.0));

}

void SpriteImages::fillDwarfSpritesheet()
{
    m_dwarf_spritesheet = m_player_spritesheet;

    m_dwarf_framesizes = m_player_framesizes;
}

void SpriteImages::fillUnicornSpritesheet()
{
    m_unicorn_spritesheet = new QVector<QPixmap*>;
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_afk.png"));
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_moving.png"));
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_jumping.png"));
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_attacking.png"));
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_moving.png"));
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_moving.png"));
    m_unicorn_spritesheet->append(new QPixmap(":/images/sprites/dynamic/unicorn/unicorn_dying.png"));

    m_unicorn_framesizes = new QVector<QPair<float,float> >;
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
    m_unicorn_framesizes->append(QPair<float,float>(100.0,100.0));
}

QVector<QPixmap*>* SpriteImages::player() const
{
    return m_player_spritesheet;
}

QVector<QPixmap*>* SpriteImages::dwarf() const
{
    return m_dwarf_spritesheet;
}

QVector<QPixmap*>* SpriteImages::unicorn() const
{
    return m_unicorn_spritesheet;
}

QVector<QPair<float,float> >* SpriteImages::player_framesizes() const
{
    return m_player_framesizes;
}

QVector<QPair<float,float> >* SpriteImages::dwarf_framesizes() const
{
    return m_dwarf_framesizes;
}

QVector<QPair<float,float> >* SpriteImages::unicorn_framesizes() const
{
    return m_unicorn_framesizes;
}
