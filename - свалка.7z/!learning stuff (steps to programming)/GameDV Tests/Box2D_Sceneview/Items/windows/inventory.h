#ifndef INVENTORY_H
#define INVENTORY_H

#include <QMap>
#include <QList>

#include "../equipmentitem.h"
#include <QGraphicsRectItem>
class Inventory: public QGraphicsRectItem
{
public:
    Inventory(QGraphicsItem* parent);
    ~Inventory();

    EquipmentItem* getEquippedItemOf (int equipmentType);
    void changeEquippedItemTo (int equipmentType, EquipmentItem* item);
    void undressItemFrom (int equipmentType);

    QMap<int,EquipmentItem*> m_equipment;
    QList<EquipmentItem*> m_inventory;

protected:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    void makeInventoryCells();
    void makeInventory();

    QList<QRectF> m_inventoryCells;
};

#endif // INVENTORY_H
