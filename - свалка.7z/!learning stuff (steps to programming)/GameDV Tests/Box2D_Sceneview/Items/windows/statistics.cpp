#include <QPainter>

#include "statistics.h"
Statistics::Statistics(QGraphicsItem* parent)
{
    setParentItem(parent);
    makeStatistics();
    initVariables();
}

Statistics::~Statistics()
{
}

void Statistics::makeStatistics()
{
    setRect(0,0,600,400);
    setPos(-300,-500);
    hide();
}

void Statistics::initVariables()
{
    m_coinsCollected = 0;
    m_starsCollected = 0;
    m_damageDealt = 0;
    m_enemiesKilled = 0;
    m_gnomesKilled = 0;
    m_unicornsKilled = 0;
}
int Statistics::starsCollected() const
{
    return m_starsCollected;
}

void Statistics::setStarsCollected(int starsCollected)
{
    m_starsCollected = starsCollected;
}

int Statistics::unicornsKilled() const
{
    return m_unicornsKilled;
}

void Statistics::setUnicornsKilled(int unicornsKilled)
{
    m_unicornsKilled = unicornsKilled;
}

int Statistics::gnomesKilled() const
{
    return m_gnomesKilled;
}

void Statistics::setGnomesKilled(int gnomesKilled)
{
    m_gnomesKilled = gnomesKilled;
}

int Statistics::enemiesKilled() const
{
    return m_enemiesKilled;
}

void Statistics::setEnemiesKilled(int enemiesKilled)
{
    m_enemiesKilled = enemiesKilled;
}

int Statistics::damageDealt() const
{
    return m_damageDealt;
}

void Statistics::setDamageDealt(int damageDealt)
{
    m_damageDealt = damageDealt;
}

int Statistics::coinsCollected() const
{
    return m_coinsCollected;
}

void Statistics::setCoinsCollected(int coinsCollected)
{
    m_coinsCollected = coinsCollected;
}

void Statistics::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    // draw frames
    QRectF frame = rect();
    QRectF content = frame.adjusted(20,30,-20,-30);

    painter->setBrush(QBrush(QColor(255,255,255,200)));
    painter->setFont(QFont("Deutsch Gothic", 14));
    painter->setPen(QPen(QBrush(Qt::white), 2));

    painter->drawRect(frame);
    painter->drawRect(content);
    painter->drawText(frame, QObject::tr("Статистика"), QTextOption(Qt::AlignTop | Qt::AlignHCenter));

    // draw content
    painter->setPen(QPen(QBrush(Qt::black), 2));

    QList<QRectF> content_rects;
    QList<QString> content_text = createStatisticsText();
    for (int i = 0; i < 6; ++i)
    {
        content_rects.push_back(QRectF(content.x(), content.y() + i*30, content.width(), 30));
        painter->drawRect(content_rects.at(i));
        painter->drawText(content_rects.at(i), content_text.at(i), QTextOption(Qt::AlignCenter));
    }

}

QList<QString> Statistics::createStatisticsText()
{
    QList<QString> statisticsText;

    statisticsText << QString(QObject::tr("Собрано монет: %1").arg(m_coinsCollected))
                   << QString(QObject::tr("Собрано звезд: %1").arg(m_starsCollected))
                   << QString(QObject::tr("Побеждено противников: %1").arg(m_enemiesKilled))
                   << QString(QObject::tr("Побеждено дворфов: %1").arg(m_gnomesKilled))
                   << QString(QObject::tr("Побеждено единорогов: %1").arg(m_unicornsKilled))
                   << QString(QObject::tr("И т.д и т.п."));

    return statisticsText;
}



