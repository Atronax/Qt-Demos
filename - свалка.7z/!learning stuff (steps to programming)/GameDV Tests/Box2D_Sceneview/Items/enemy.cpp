#include <QTimer>

#include "gamemanager.h"
#include "worldmanager.h"

#include "enemy.h"
Enemy::Enemy(GameManager *manager, b2Body *body, QGraphicsItem* parent)
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);

    setBody(body);
    setSprite(new Sprite(this));
    setParentItem(parent);
    setManager(manager);

    m_target = nullptr;

    m_attack_timer = new QTimer(this);
    connect (m_attack_timer, SIGNAL(timeout()), this, SLOT(attack()));    
}

Enemy::~Enemy()
{
    qDebug("in enemy destructor");

    if (m_attack_timer->isActive())
        m_attack_timer->stop();
    m_attack_timer->deleteLater();
}

void Enemy::checkCollision(Entity *rhs)
{
    Player* player = dynamic_cast<Player*>(rhs);
    if (visualState() == ATTACKING && player)
    {
        m_target = player;
        // m_target->setCurrentHealth(m_target->currentHealth() - damage() + damage()*(m_target->defence()/100.0));
        // if (m_target->currentHealth() <= 0)
        //     emit killed(m_target);
    }
}

void Enemy::setEnemyType(int type)
{
    m_enemyType = type;

    switch (m_enemyType)
    {
    case GNOME:
        sprite()->fillComponents(manager()->worldmanager()->imagesCache()->dwarf(), manager()->worldmanager()->imagesCache()->dwarf_framesizes());

        setLevel(0);
        setCurrentExperience(40);
        setNeededExperience(1000000);
        setMaximumHealth(200);
        setDamage(20);
        setDefence(15);
        break;

    case UNICORN:
        sprite()->fillComponents(manager()->worldmanager()->imagesCache()->unicorn(), manager()->worldmanager()->imagesCache()->unicorn_framesizes());

        setLevel(0);
        setCurrentExperience(200);
        setNeededExperience(1000000);
        setMaximumHealth(1500);
        setDamage(3);
        setDefence(10);
        break;
    }
}

int Enemy::enemyType() const
{
    return m_enemyType;
}

void Enemy::updateState(const QPointF& player_pos)
{
    prepareGeometryChange();

    int distance = sqrt(pow(player_pos.x() - x(),2) + pow(player_pos.y()-y(),2));

    if (currentHealth() < 20)
        setVisualState(DYING);
    else if (distance <= 64 + rect().width())
        setVisualState(ATTACKING);
    else if (player_pos.x() < x() && distance <= 32*10)
    {
        setVisualState(MOVING_LEFT);
        body()->SetLinearVelocity(b2Vec2(-3.0f, body()->GetLinearVelocity().y));
    }
    else if (player_pos.x() > x() && distance <= 32*10)
    {
        setVisualState(MOVING_RIGHT);
        body()->SetLinearVelocity(b2Vec2(+3.0f, body()->GetLinearVelocity().y));
    }
    else
        setVisualState(Sprite::AFK);

    update();

}

void Enemy::startAttacking()
{
    m_attack_timer->start(500);
}

void Enemy::stopAttacking()
{
    m_attack_timer->stop();
}

void Enemy::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (sprite())
    {
        int type = sprite()->type();
        if (type == Sprite::STATIC)
            sprite()->drawStatic(painter);
        if (type == Sprite::DYNAMIC)
            sprite()->drawDynamic(painter);
    }

    drawHealthbar(painter, QRect(rect().x(), rect().y()-10, rect().width(), 8));
}

// slots
void Enemy::attack()
{
    if (m_target)
    {
        m_target->setCurrentHealth(m_target->currentHealth() - damage() + damage()*(m_target->defence()/100.0));
        if (m_target->currentHealth() <= 0)
            emit killed(m_target);
    }
}
