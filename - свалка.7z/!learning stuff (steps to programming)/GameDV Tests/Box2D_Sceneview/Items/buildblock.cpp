#include "gamemanager.h"
#include "worldmanager.h"

#include "buildblock.h"
BuildBlock::BuildBlock(GameManager *manager, b2Body* body, QGraphicsItem* parent)
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);

    setBody(body);
    setSprite(new Sprite(this));
    setParentItem(parent);
    setManager(manager);
}

BuildBlock::~BuildBlock()
{

}

int BuildBlock::buildblockType() const
{
    return m_buildblockType;
}

void BuildBlock::setBuildBlockType(int type)
{
    m_buildblockType = type;

    switch (m_buildblockType)
    {
    case BOX_1X1: case BOX_1X2: case BOX_2X1:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->crate());
        break;

    case BARREL_1X1: case BARREL_2X2:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->barrel());
        break;

    case BRICK_1X1:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->brick());
        break;

    case TREE_FIR:
        sprite()->setDynamic(manager()->worldmanager()->imagesCache()->tree_fir(), 100, 100);
        break;

    case GROUND:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->ground());
        break;

    case GRASS:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->grass());
        break;

    case MOON:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->moon());
        break;

    case STATIC_COIN:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->coin());
        break;

    case STATIC_STAR:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->star());
        break;

    default:
        break;
    }
}

void BuildBlock::checkCollision(Entity *)
{

}

void BuildBlock::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (sprite())
    {
        int type = sprite()->type();
        if (type == Sprite::STATIC)
            sprite()->drawStatic(painter);
        if (type == Sprite::DYNAMIC)
            sprite()->drawDynamic(painter);
    }
}

