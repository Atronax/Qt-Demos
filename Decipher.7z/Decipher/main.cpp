#include <QApplication>

#include "decipherwindow.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    DecipherWindow window;
    window.show();

    return app.exec();
}
