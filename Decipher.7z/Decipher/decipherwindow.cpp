#include "decipherwindow.h"

#include <QDebug>

DecipherWindow::DecipherWindow(QWidget *parent) : QWidget(parent)
{    
    LoadLogic();
    SetupGUI();
    ConnectButtons();
}

DecipherWindow::~DecipherWindow()
{
    ClearGUI();
    ClearLogic();
}

void DecipherWindow::SetupGUI()
{
    te_center = new QTextEdit (tr("Здесь вы увидите зашифрованное сообщение."));
    te_center->setFont(QFont("Times New Roman", 14));

    lbl_inputData = new QLabel (tr("Фраза:"));
    le_inputData = new QLineEdit (tr(""));

    lbl_inputKey = new QLabel (tr("Ключ:"));
    le_inputKey = new QLineEdit (tr(""));

    lbl_language = new QLabel (m_logic->getLanguage());
    cb_language = new QComboBox;
    cb_language->addItems(m_logic->getSupportedLanguages());
    connect (cb_language, SIGNAL(activated(const QString&)), this, SLOT(onChooseLanguage(const QString&)));

    pb_cipher = new QPushButton(tr("Зашифровать ключом"));
    pb_decipher = new QPushButton(tr("Расшифровать ключом"));

    pb_cipherMorze = new QPushButton(tr("Зашифровать Морзе"));
    pb_decipherMorze = new QPushButton(tr("Расшифровать Морзе"));

    lyt_inputData = new QHBoxLayout;
    lyt_inputData->addWidget(lbl_inputData);
    lyt_inputData->addWidget(le_inputData);

    lyt_inputKey = new QHBoxLayout;
    lyt_inputKey->addWidget(lbl_inputKey);
    lyt_inputKey->addWidget(le_inputKey);

    lyt_language = new QHBoxLayout;
    lyt_language->addWidget(lbl_language);
    lyt_language->addWidget(cb_language);

    lyt_buttons = new QHBoxLayout;
    lyt_buttons->addWidget(pb_decipher);
    lyt_buttons->addWidget(pb_cipher);

    lyt_main = new QGridLayout(this);
    lyt_main->addWidget(te_center, 0, 0, 1, 2, Qt::AlignCenter);
    lyt_main->addLayout(lyt_inputData, 1, 0, 1, 2, Qt::AlignCenter);
    lyt_main->addLayout(lyt_inputKey, 2, 0, 1, 2, Qt::AlignCenter);
    lyt_main->addLayout(lyt_language, 3, 0, Qt::AlignCenter);
    lyt_main->addLayout(lyt_buttons, 3, 1, Qt::AlignCenter);

    setLayout(lyt_main);

}

void DecipherWindow::LoadLogic()
{
    m_logic = new DecipherLogic();
}

void DecipherWindow::ConnectButtons()
{
    connect(pb_decipher, SIGNAL(pressed()), this, SLOT(Decipher()));
    connect(pb_cipher, SIGNAL(pressed()), this, SLOT(Cipher()));
}

bool DecipherWindow::IsDataValid()
{
    bool isValid = true;
    QString data = le_inputData->text();

    if (data == "")
        isValid = false;

    return isValid;
}

bool DecipherWindow::IsKeywordValid()
{
    bool isValid = true;
    QString keyword = le_inputKey->text();

    if (keyword == "")
        isValid = false;

    return isValid;
}

void DecipherWindow::ClearGUI()
{
    te_center->deleteLater();

    lbl_inputData->deleteLater();
    le_inputData->deleteLater();

    lbl_inputKey->deleteLater();
    le_inputKey->deleteLater();

    lbl_language->deleteLater();
    cb_language->deleteLater();

    pb_cipher->deleteLater();
    pb_decipher->deleteLater();

    pb_cipherMorze->deleteLater();
    pb_decipherMorze->deleteLater();

    lyt_inputData->deleteLater();
    lyt_inputKey->deleteLater();
    lyt_language->deleteLater();
    lyt_buttons->deleteLater();
    lyt_main->deleteLater();
}

void DecipherWindow::ClearLogic()
{
    delete m_logic;
}

void DecipherWindow::DecipherKeyword()
{
    if (IsDataValid() && IsKeywordValid())
    {
        m_logic->setData(le_inputData->text());
        m_logic->setKeyword(le_inputKey->text());
        te_center->setText(m_logic->DecipherKeyword());
    }
    else
        te_center->setText(tr("Введите шифр и ключ"));
}

void DecipherWindow::DecipherMorze()
{
    if (IsDataValid())
    {
        m_logic->setData(le_inputData->text());
        te_center->setText(m_logic->DecipherMorze());
    }
    else
        te_center->setText(tr("Введите шифр Морзе."));
}

void DecipherWindow::CipherKeyword()
{
    if (IsDataValid() && IsKeywordValid())
    {
        m_logic->setData(le_inputData->text());
        m_logic->setKeyword(le_inputKey->text());
        te_center->setText(m_logic->CipherKeyword());
    }
    else
        te_center->setText(tr("Введите фразу для шифрования и ключ."));
}

void DecipherWindow::CipherMorze()
{
    if (IsDataValid())
    {
        m_logic->setData(le_inputData->text());
        te_center->setText(m_logic->CipherMorze());
    }
    else
        te_center->setText(tr("Введите фразу для шифрования."));
}

void DecipherWindow::onChooseLanguage(const QString &new_language)
{
    lbl_language->setText(new_language);
    m_logic->setLanguage(new_language);

    if (new_language == "MORZE RU" || new_language == "MORZE EN")
    {
        disconnect(pb_decipher, SIGNAL(pressed()), this, SLOT(DecipherKeyword()));
        disconnect(pb_cipher, SIGNAL(pressed()), this, SLOT(CipherKeyword()));

        pb_cipher->hide();
        pb_decipher->hide();

        lyt_buttons->replaceWidget(pb_cipher, pb_cipherMorze);
        lyt_buttons->replaceWidget(pb_decipher, pb_decipherMorze);

        connect(pb_decipherMorze, SIGNAL(pressed()), this, SLOT(DecipherMorze()));
        connect(pb_cipherMorze, SIGNAL(pressed()), this, SLOT(CipherMorze()));

        pb_cipherMorze->show();
        pb_decipherMorze->show();

    }
    else
    {
        disconnect(pb_decipherMorze, SIGNAL(pressed()), this, SLOT(DecipherMorze()));
        disconnect(pb_cipherMorze, SIGNAL(pressed()), this, SLOT(CipherMorze()));

        pb_cipherMorze->hide();
        pb_decipherMorze->hide();

        lyt_buttons->replaceWidget(pb_cipherMorze, pb_cipher);
        lyt_buttons->replaceWidget(pb_decipherMorze, pb_decipher);

        connect(pb_decipher, SIGNAL(pressed()), this, SLOT(DecipherKeyword()));
        connect(pb_cipher, SIGNAL(pressed()), this, SLOT(CipherKeyword()));

        pb_cipher->show();
        pb_decipher->show();
    }
}
