#ifndef DECIPHERLOGIC_H
#define DECIPHERLOGIC_H

#include <QString>
#include <QStringList>

class DecipherLogic
{
public:
    DecipherLogic();

    // Шифрование с применением ключа
    const QString& CipherKeyword();
    const QString& DecipherKeyword();

    // Шифрование с помощью азбуки Морзе
    const QString& CipherMorze();
    const QString& DecipherMorze();

    // Вспомогательные методы
    const QString& getData() const;
    void setData (const QString&);

    const QString& getKeyword() const;
    void setKeyword (const QString&);

    const QString getLanguage() const;
    void setLanguage (const QString&);

    const QStringList getSupportedLanguages() const;

private:

    void CastInputToLowercase();
    void GenerateKeyFromKeyword();
    void ProcessTask(bool cipher);


    const QStringList m_supportedLanguages = {"RU", "UA", "EN", "MORZE RU", "MORZE EN"};
    QString m_language;

    // 11 букв в каждом ряду, далее знаки ".,!", пробел пропускается
    const QStringList m_morzeRU = {".-", "-...", ".--", "--.", "-..", ".", ".", "...-", "--..", "..", ".---",
                                   "-.-", ".-..", "--", "-.", "---", ".--.", ".-.", "...", "-", "..-", "..-.",
                                   "....", "-.-.", "---.", "----", "--.-", ".--.-.", "-.--", "-..-", "...-...", "..--", ".-.-",
                                   "......", ".-.-.-", "--..--", " "};

    const QStringList m_morzeEN = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--",
                                   "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..",
                                   "......", ".-.-.-", "--..--", " "};

    const QStringList m_morzeNumbers = {".----", "..---", "...--", "....-", ".....",
                                        "-....", "--...", "---..", "----.", "-----"};

    QStringList m_morze;


    const QString m_alphabetRU = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя.,! ";
    const QString m_alphabetUA = "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя.,! ";
    const QString m_alphabetEN = "abcdefghijklmnopqrstuvwxyz.,! ";
    const QString m_numbers = "1234567890";

    QString m_alphabet;
    QString m_data, m_keyword;
    QString m_key, m_result;

    const int m_lettersRU = 33;
    const int m_lettersUA = 33;
    const int m_lettersEN = 26;
    int m_letters;
};

#endif // DECIPHERLOGIC_H
