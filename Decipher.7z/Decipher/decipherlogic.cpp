#include "decipherlogic.h"

#include <QDebug>

DecipherLogic::DecipherLogic()
{
    setLanguage("RU");
}

const QString& DecipherLogic::CipherKeyword()
{
    CastInputToLowercase();
    GenerateKeyFromKeyword();
    ProcessTask(true);

    return m_result;
}

const QString& DecipherLogic::DecipherKeyword()
{
    qDebug() << "in Decipher";

    CastInputToLowercase();
    GenerateKeyFromKeyword();
    ProcessTask(false);

    return m_result;
}

const QString& DecipherLogic::CipherMorze()
{
    CastInputToLowercase();

    int size = m_data.size();

    m_result = "";
    for (int i = 0; i < size; ++i)
        m_result += m_morze.at(m_alphabet.indexOf(m_data.at(i))) + " ";

    return m_result;
}

const QString& DecipherLogic::DecipherMorze()
{
    CastInputToLowercase();

    m_result = "";
    QStringList symbols = m_data.split(" ");

    QString string = m_data;
    foreach (QString symbol, symbols)
    {
        for (int i = 0; i < m_morze.size(); ++ i)
        {
            if (m_morze.at(i) == symbol)
            {
                m_result += m_alphabet.at(i);

                if (m_alphabet.at(i) == "е")
                    break;
            }
        }

        string = string.remove(0, symbol.size() + 1);
        qDebug() << string;
        if (string.startsWith(" "))
            m_result += ' ';
    }

    return m_result;
}

const QString &DecipherLogic::getData() const
{
    return m_data;
}

void DecipherLogic::setData(const QString &new_data)
{
    m_data = new_data;

    qDebug() << m_data;
}

const QString &DecipherLogic::getKeyword() const
{
    return m_keyword;
}

void DecipherLogic::setKeyword(const QString &new_keyword)
{
    m_keyword = new_keyword;

    qDebug() << m_keyword;
}

const QString DecipherLogic::getLanguage() const
{
    return m_language;
}

void DecipherLogic::setLanguage(const QString &new_language)
{
    m_language = new_language;
    m_morze.clear();

    if (m_language == "RU" || m_language == "MORZE RU")
    {
        m_alphabet = m_alphabetRU;
        m_letters = m_lettersRU;
        if (m_language == "MORZE RU")
            m_morze = m_morzeRU;
    }
    else if (m_language == "UA")
    {
        m_alphabet = m_alphabetUA;
        m_letters = m_lettersUA;
    }
    else if (m_language == "EN" || m_language == "MORZE EN")
    {
        m_alphabet = m_alphabetEN;
        m_letters = m_lettersEN;
        if (m_language == "MORZE EN")
            m_morze = m_morzeEN;
    }

    qDebug() << m_alphabet << " - букв: " << m_letters << " - морзянка: " << m_morze;
}

const QStringList DecipherLogic::getSupportedLanguages() const
{
    return m_supportedLanguages;
}

void DecipherLogic::CastInputToLowercase()
{
    m_data = m_data.toLower();
    m_keyword = m_keyword.toLower();
}

void DecipherLogic::GenerateKeyFromKeyword()
{
    int punct = 0;
    for (int i = 0; i < m_data.size(); ++i)
    {
        // пропускаем знаки пунктуации
        if (m_data.at(i) == ' ' || m_data.at(i) == ',' || m_data.at(i) == '.' || m_data.at(i) == '!')
        {
            m_key[i] = m_data.at(i);
            ++punct;
        }
        else
        {
            if (punct == 0)
                m_key[i] = m_keyword[i % m_keyword.size()];
            else
                m_key[i] = m_keyword[(i - punct) % m_keyword.size()];
        }
    }
}

void DecipherLogic::ProcessTask(bool cipher)
{
    // назначаем соответствующие числа символам в строках m_data, m_key, создаем result_indexes
    int size = m_data.size();
    QVector<int> data_indexes (size), key_indexes (size), result_indexes (size);

    int curr_char;
    for (int i = 0; i < size; ++i)
    {
        data_indexes[i] = m_alphabet.indexOf(m_data.at(i)) + 1;
        key_indexes[i] = m_alphabet.indexOf(m_key.at(i)) + 1;

        if (data_indexes.at(i) == m_letters + 1 || data_indexes.at(i) == m_letters + 2 || data_indexes.at(i) == m_letters + 3 || data_indexes.at(i) == m_letters + 4)
            curr_char = data_indexes.at(i);
        else
        {
            if (cipher)
            {
                // CIPHER
                curr_char = data_indexes[i] - key_indexes[i];
                if (curr_char < 1)
                    curr_char += m_letters;
            }
            else
            {
                // DECIPHER
                curr_char = data_indexes.at(i) + key_indexes.at(i);
                if (curr_char > m_letters)
                    curr_char -= m_letters;
            }
        }

        result_indexes[i] = curr_char;
    }

    // собираем result
    m_result = "";
    for (int it = 0; it < result_indexes.size(); ++it)
         m_result += m_alphabet.at(result_indexes.at(it) - 1);
}
