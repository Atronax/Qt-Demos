#ifndef DECIPHERWINDOW_H
#define DECIPHERWINDOW_H

#include <QWidget>

#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QComboBox>
#include <QPushButton>
#include <QLayout>

#include "decipherlogic.h"

class DecipherWindow : public QWidget
{
    Q_OBJECT
public:
    explicit DecipherWindow(QWidget *parent = nullptr);
    ~DecipherWindow();

private:
    void SetupGUI();
    void LoadLogic();
    void ConnectButtons();

    bool IsDataValid();
    bool IsKeywordValid();

    void ClearGUI();
    void ClearLogic();

    QTextEdit *te_center;
    QLabel *lbl_inputData, *lbl_inputKey, *lbl_language;
    QLineEdit *le_inputData, *le_inputKey;
    QComboBox *cb_language;
    QPushButton *pb_cipher, *pb_decipher, *pb_cipherMorze, *pb_decipherMorze;
    QHBoxLayout *lyt_inputData, *lyt_inputKey, *lyt_language, *lyt_buttons;
    QGridLayout *lyt_main;

    DecipherLogic *m_logic;

signals:

public slots:
    void DecipherKeyword();
    void DecipherMorze();
    void CipherKeyword();
    void CipherMorze();

    void onChooseLanguage(const QString&);
};

#endif // DECIPHERWINDOW_H
