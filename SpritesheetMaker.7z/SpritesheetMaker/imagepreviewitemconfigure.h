#ifndef IMAGEPREVIEWITEMCONFIGURE_H
#define IMAGEPREVIEWITEMCONFIGURE_H

class QLineEdit;
class QPushButton;
class QFormLayout;

#include <QDialog>
class ImagePreviewItemConfigure : public QDialog
{
    Q_OBJECT

public:
    explicit ImagePreviewItemConfigure(QWidget* parent = nullptr, Qt::WindowFlags flags = 0, const QPoint& position = QPoint(0,0));
    ~ImagePreviewItemConfigure();

    const QString& path() const;

protected:
    void paintEvent(QPaintEvent* ev);

private:
    void buildUI();

    QString m_path;

    QLineEdit* m_image_browser;
    QPushButton* m_pb_ok, *m_pb_cancel;
    QFormLayout* m_layout;

public slots:
    void updatePath();
};

#endif // IMAGEPREVIEWITEMCONFIGURE_H
