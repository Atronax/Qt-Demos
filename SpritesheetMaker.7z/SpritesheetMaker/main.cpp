#include <QApplication>

#include "mainwindow.h"
int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    MainWindow *appwindow = new MainWindow;
    appwindow->show();   

    return app.exec();
}
