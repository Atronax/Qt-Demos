#ifndef VERTICALQLABEL_H
#define VERTICALQLABEL_H

#include <QLabel>
class VerticalQLabel : public QLabel
{
public:
    explicit VerticalQLabel(QWidget* parent = 0);
    explicit VerticalQLabel(const QString& text, QWidget* parent = 0);
    ~VerticalQLabel();

protected:
    void paintEvent (QPaintEvent *ev);
};

#endif // VERTICALQLABEL_H
