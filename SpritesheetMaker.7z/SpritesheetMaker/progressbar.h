#ifndef PROGRESSBAR_H
#define PROGRESSBAR_H

#include <QProgressBar>
#include <QPaintEvent>

class ProgressBar : public QProgressBar
{
public:
    ProgressBar(QWidget* parent = nullptr);
    ~ProgressBar();

protected:
    void paintEvent(QPaintEvent* ev);

};

#endif // PROGRESSBAR_H
