#ifndef CRYPTER_H
#define CRYPTER_H

#include <QTextCodec>
#include <QTextStream>

class Crypter
{
public:
    Crypter();
    ~Crypter();

    QString cipherRussian (QString& text, int shift, bool toEncode);
    QString cipherEnglish (QString& text, int shift, bool toEncode);

private:
    // Constants
    const int ENGLISH_FIRST_LETTER_CODE = 97;
    const int ENGLISH_LATEST_LETTER_CODE = 122;
    const int ENGLISH_LETTERS_COUNT = 26;

    const int RUSSIAN_FIRST_LETTER_CODE = 1072;
    const int RUSSIAN_LATEST_LETTER_CODE = 1103;
    const int RUSSIAN_LETTERS_COUNT = 33;

    // Helpers used to decipher unicode texts and to get symbols' codes
    QTextStream m_HelperStream;
    QString m_HelperString;
};

#endif // CRYPTER_H
