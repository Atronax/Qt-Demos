#include "verticalqlabel.h"
#include <QPainter>

VerticalQLabel::VerticalQLabel(QWidget *parent)
    : QLabel(parent)
{

}

VerticalQLabel::VerticalQLabel(const QString &text, QWidget *parent)
    : QLabel(text, parent)
{

}

VerticalQLabel::~VerticalQLabel()
{

}

void VerticalQLabel::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED (ev);

    QPainter painter (this);
    painter.rotate(90);
    painter.drawText(0, 0, text());
}
