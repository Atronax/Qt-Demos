// logic
#include <QPainter>
#include <QStyleOption>

// events
#include <QPaintEvent>

// widgets
#include <QLineEdit>
#include <QPushButton>
#include <QFormLayout>

#include "imagepreviewitemconfigure.h"
ImagePreviewItemConfigure::ImagePreviewItemConfigure(QWidget* parent, Qt::WindowFlags flags, const QPoint& position)
    : QDialog (parent, flags)
{    
    buildUI();
    setGeometry(position.x(),position.y(),width(),height());
}

ImagePreviewItemConfigure::~ImagePreviewItemConfigure()
{

}

const QString& ImagePreviewItemConfigure::path() const
{
    return m_path;
}

void ImagePreviewItemConfigure::buildUI()
{
    m_image_browser = new QLineEdit(this);
    m_image_browser->setMinimumWidth(200);
    connect(m_image_browser, SIGNAL(returnPressed()), this, SLOT(updatePath()));

    m_pb_ok = new QPushButton(tr("Лады"), this);
    connect(m_pb_ok, SIGNAL(clicked()), this, SLOT(accept()));

    m_pb_cancel = new QPushButton(tr("Нелады"), this);
    connect(m_pb_cancel, SIGNAL(clicked()), this, SLOT(reject()));

    m_layout = new QFormLayout(this);
    m_layout->setMargin(0);
    m_layout->addRow(tr("Новое изображение: "), m_image_browser);
    m_layout->addRow(m_pb_cancel, m_pb_ok);

    setLayout(m_layout);
}


void ImagePreviewItemConfigure::updatePath()
{
    m_path = (static_cast<QLineEdit*>(sender()))->text();
}

void ImagePreviewItemConfigure::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED(ev);

    QStyleOption option;
    option.initFrom(this);

    QPainter painter(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &painter, this);
}
