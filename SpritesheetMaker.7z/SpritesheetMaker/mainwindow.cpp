#include "mainwindow.h"

// LOGIC
#include <QDesktopWidget>
#include <QApplication>
#include <QStyleOption>
#include <QPainter>
#include <QDateTime>
#include <QImage>

// WIDGETS
#include <QFileDialog>
#include "imagepreviewpanel.h"
#include "verticalqlabel.h"
#include "progressbar.h"
#include <QPushButton>
#include <QSlider>

#include <QGridLayout>

// CTR+DTR
MainWindow::MainWindow(QWidget *parent) : QWidget(parent)
{
    initVars();
    buildUI();
}

MainWindow::~MainWindow()
{
}

// GETTERS
ProgressBar* MainWindow::progressbar() const
{
    return m_progressbar;
}

int MainWindow::inARow() const
{
    return m_inARow;
}

int MainWindow::inAColumn() const
{
    return m_inAColumn;
}

int MainWindow::framewidth() const
{
    return m_framewidth;
}

int MainWindow::frameheight() const
{
    return m_frameheight;
}

int MainWindow::paddingX() const
{
    return m_padding_x;    
}

int MainWindow::paddingY() const
{
    return m_padding_y;
}

int MainWindow::imagesCount() const
{
    return m_totalImages;
}

void MainWindow::setImagesCount(int value)
{
    m_totalImages = value;
}

// BUILDERS
void MainWindow::buildUI()
{
    makeEditorAndButtons();
    makeRowColumnCountControls();
    makeFramesizeControls();
    makePaddingControls();
    polishUI();
}

void MainWindow::initVars()
{
    m_framewidth = 100;
    m_frameheight = 100;
    m_padding_x = 5;
    m_padding_y = 5;
}

void MainWindow::makeEditorAndButtons()
{
    m_image_preview_panel = new ImagePreviewPanel(this);

    pb_load_images = new QPushButton(tr("Загрузить изображения"), this);
    connect (pb_load_images, SIGNAL(clicked()), this, SLOT(loadImages()));

    pb_make_spritesheet = new QPushButton(tr("Создать спрайтлист"), this);
    connect (pb_make_spritesheet, SIGNAL(clicked()), this, SLOT(makeSpritesheet()));

    m_progressbar = new ProgressBar(this);
}

void MainWindow::makeRowColumnCountControls()
{
    QString text = QString(tr("В ряду: ")) + QString::number(inARow()) + "\n" + QString(tr("В столбце: ")) + QString::number(inAColumn());
    m_inARowAndColumn_label = new QLabel (text, this);

    m_inARow_slider = new QSlider (Qt::Horizontal, this);
    m_inARow_slider->setRange(1, 20);
    m_inARow_slider->setValue(inARow());
    connect (m_inARow_slider, SIGNAL(valueChanged(int)), this, SLOT(setImagesInARow(int)));

    m_inAColumn_slider = new QSlider (Qt::Horizontal, this);
    m_inAColumn_slider->setRange(1, 20);    
    m_inAColumn_slider->setValue(inAColumn());    
    connect (m_inAColumn_slider, SIGNAL(valueChanged(int)), this, SLOT(setImagesInAColumn(int)));
}

void MainWindow::makeFramesizeControls()
{
    QString text = QString(tr("Ширина кадра: ")) + QString::number(framewidth()) + "\n" + QString(tr("Высота кадра: ")) + QString::number(frameheight());
    m_framesize_label = new QLabel (text, this);

    m_framewidth_slider = new QSlider (Qt::Vertical, this);
    m_framewidth_slider->setRange(1, 1000);
    m_framewidth_slider->setValue(framewidth());
    connect (m_framewidth_slider, SIGNAL(valueChanged(int)), this, SLOT(setFramewidth(int)));

    m_frameheight_slider = new QSlider (Qt::Vertical, this);
    m_frameheight_slider->setRange(1, 1000);
    m_frameheight_slider->setValue(frameheight());
    connect (m_frameheight_slider, SIGNAL(valueChanged(int)), this, SLOT(setFrameheight(int)));
}

void MainWindow::makePaddingControls()
{
    QString text = tr("Ширина отступа: ") + QString::number(paddingX()) + "\n" + tr("Высота отступа: ") + QString::number(paddingY());
    m_padding_label = new QLabel (text, this);

    m_padding_x_slider = new QSlider (Qt::Vertical, this);
    m_padding_x_slider->setRange(0, 32);
    m_padding_x_slider->setValue(paddingX());
    connect (m_padding_x_slider, SIGNAL(valueChanged(int)), this, SLOT(setPaddingX(int)));

    m_padding_y_slider = new QSlider (Qt::Vertical, this);    
    m_padding_y_slider->setRange(0, 32);
    m_padding_y_slider->setValue(paddingY());
    connect (m_padding_y_slider, SIGNAL(valueChanged(int)), this, SLOT(setPaddingY(int)));
}

void MainWindow::setupLayout()
{
    m_layout = new QGridLayout (this);
    m_layout->addWidget(pb_load_images, 8, 0, 1, 3);
    m_layout->addWidget(pb_make_spritesheet, 8, 6, 1, 3);
    m_layout->addWidget(m_progressbar, 9, 1, 1, 7);
    setLayout(m_layout);
}

void MainWindow::installStylesheet()
{
    QFile style_file (qApp->applicationDirPath() + "/stylesheets/style.qss");
    QString style_string = "";
    if (style_file.open(QIODevice::ReadOnly | QIODevice::Text))
        style_string = style_file.readAll();
    qApp->setStyleSheet(style_string);
}

void MainWindow::polishUI()
{
    setupLayout();
    hideAllControls();
    installStylesheet();
    setMaximumSize(QDesktopWidget().geometry().size());
}

// EVENTS
void MainWindow::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED(ev);

    QStyleOption option;
    option.init(this);

    QPainter painter(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &painter, this);
}

// HELPFULL FUNCTIONS
void MainWindow::hideAllControls()
{
    m_framesize_label->hide();
    m_padding_label->hide();
    m_inARowAndColumn_label->hide();

    m_framewidth_slider->hide();
    m_frameheight_slider->hide();
    m_padding_x_slider->hide();
    m_padding_y_slider->hide();
    m_inARow_slider->hide();
    m_inAColumn_slider->hide();

    m_image_preview_panel->hide();

    pb_make_spritesheet->setEnabled(false);
}

void MainWindow::showAllControls()
{
    m_framesize_label->show();
    m_padding_label->show();
    m_inARowAndColumn_label->show();

    m_framewidth_slider->show();    
    m_frameheight_slider->show();    
    m_padding_x_slider->show();
    m_padding_y_slider->show();
    m_inARow_slider->show();
    m_inAColumn_slider->show();

    m_image_preview_panel->show();

    pb_make_spritesheet->setEnabled(true);
}

void MainWindow::updateWorkspace()
{
    m_layout->addWidget(m_image_preview_panel, 0, 2, 5, 5);

    m_layout->addWidget(m_framesize_label, 0, 0, 1, 2);
    m_layout->addWidget(m_framewidth_slider, 1, 0, 6, 1);
    m_layout->addWidget(m_frameheight_slider, 1, 1, 6, 1);

    m_layout->addWidget(m_padding_label, 0, 7, 1, 2);
    m_layout->addWidget(m_padding_x_slider, 1, 7, 6, 1);
    m_layout->addWidget(m_padding_y_slider, 1, 8, 6, 1);

    m_layout->addWidget(m_inARowAndColumn_label, 6, 2, 2, 1);
    m_layout->addWidget(m_inARow_slider, 6, 3, 1, 4);
    m_layout->addWidget(m_inAColumn_slider, 7, 3, 1, 4);    

    setImagesCount(m_image_preview_panel->getItems().size());
    setImagesInARow(1);
    setFramewidth(100);
    setFrameheight(100);
    setPaddingX(0);
    setPaddingY(0);
}

// SLOTS
void MainWindow::setImagesInARow(int value)
{
    m_inARow = value;
    m_inAColumn = (m_totalImages - m_totalImages%m_inARow) / m_inARow;
    m_inARowAndColumn_label->setText(QString(tr("В рядке: ") + QString::number(inARow()) + tr(" картинок.")) + "\n" +
                                     QString(tr("В столбце: ") + QString::number(inAColumn()) + tr(" картинок.")));
    m_inARow_slider->setValue(m_inARow);
    m_inAColumn_slider->setValue(m_inAColumn);
}

void MainWindow::setImagesInAColumn(int value)
{
    m_inAColumn = value;
    m_inARow = (m_totalImages - m_totalImages%m_inAColumn) / m_inAColumn;
    m_inARowAndColumn_label->setText(QString(tr("В рядке: ") + QString::number(inARow()) + tr(" картинок.")) + "\n" +
                                     QString(tr("В столбце: ") + QString::number(inAColumn()) + tr(" картинок.")));
    m_inARow_slider->setValue(m_inARow);
    m_inAColumn_slider->setValue(m_inAColumn);
}

void MainWindow::setFramewidth(int value)
{
    m_framewidth = value;
    m_framesize_label->setText(QString(tr("Ширина кадра: ")) + QString::number(framewidth()) + "\n" +
                               QString(tr("Высота кадра: ")) + QString::number(frameheight()));
    m_framewidth_slider->setValue(m_framewidth);

}

void MainWindow::setFrameheight(int value)
{
    m_frameheight = value;
    m_framesize_label->setText(QString(tr("Ширина кадра: ")) + QString::number(framewidth()) + "\n" +
                               QString(tr("Высота кадра: ")) + QString::number(frameheight()));
    m_frameheight_slider->setValue(m_frameheight);
}

void MainWindow::setPaddingX(int value)
{
    m_padding_x = value;
    m_padding_label->setText(QString(tr("Ширина отступа: ")) + QString::number(paddingX()) + "\n" +
                             QString(tr("Высота отступа: ")) + QString::number(paddingY()));
    m_padding_x_slider->setValue(m_padding_x);
}

void MainWindow::setPaddingY(int value)
{
    m_padding_y = value;
    m_padding_label->setText(QString(tr("Ширина отступа: ")) + QString::number(paddingX()) + "\n" +
                             QString(tr("Высота отступа: ")) + QString::number(paddingY()));
    m_padding_y_slider->setValue(m_padding_y);
}

void MainWindow::playSound(LPCWSTR soundpath)
{
    PlaySound (soundpath, GetModuleHandle(NULL), SND_FILENAME | SND_ASYNC);
}

void MainWindow::loadImages()
{
    playSound(L"sounds/button_clicked.wav");

    QStringList filenames = QFileDialog::getOpenFileNames(this, tr("Выбор раскадровки"), QString(), tr("Пикчи (*.png *.jpg)"));
    if (!filenames.isEmpty())
    {        
        m_image_preview_panel->setItems(filenames);
        updateWorkspace();
        showAllControls();
    }
}

void MainWindow::makeSpritesheet()
{
    playSound(L"sounds/button_clicked.wav");

    int total_width = inARow()*framewidth();
    int total_height = inAColumn()*frameheight();

    int current_frame = 0;
    int x = 0, y = 0;

    QImage result(total_width+paddingX()*(inARow()-1), total_height+paddingY()*(inAColumn()-1), QImage::Format_RGBA8888_Premultiplied);
    QPainter painter;
    painter.begin(&result);
        m_progressbar->setFormat(tr("%v изображений из %m обработано"));
        m_progressbar->setRange(0, m_image_preview_panel->getItems().size());
        foreach (ImagePreviewItem *image_item, m_image_preview_panel->getItems())
        {
            QImage image_to_draw = image_item->image();
            if (image_to_draw.width() != framewidth() && image_to_draw.height() != frameheight())
                image_to_draw = image_to_draw.scaled(framewidth(), frameheight());
            painter.drawImage(x,y,image_to_draw);

            ++current_frame;
            if (current_frame%inARow() == 0)
            {
                x = 0;
                y += frameheight() + paddingY();
            }
            else
                x += framewidth() + paddingX();

            m_progressbar->setValue(current_frame);
            qApp->processEvents();
        }
    painter.end();

    result.save("result" + QDateTime::currentDateTime().toString("MM-dd-HH-mm") + ".png", "png");
    m_progressbar->setFormat(tr("Сохранение завершено успешно"));
}

