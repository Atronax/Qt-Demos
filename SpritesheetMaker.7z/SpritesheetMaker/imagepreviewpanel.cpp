#include "imagepreviewpanel.h"

// logic
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QApplication>
#include <QStyleOption>
#include <QPainter>
#include <QScreen>
#include <QTimer>
#include <QColor>

#include <QThread>

// widgets
#include "mainwindow.h"
#include "progressbar.h"

// events
#include <QMouseEvent>

ImagePreviewPanel::ImagePreviewPanel(QWidget *parent)
    : QWidget (parent)
{
    animation = nullptr;    
    animation_updater = nullptr;

    layout = new QVBoxLayout(this);
    layout->setMargin(0);
    setLayout(layout);
}

ImagePreviewPanel::~ImagePreviewPanel()
{
    clearItems();
    delete layout;
}

void ImagePreviewPanel::mousePressEvent(QMouseEvent *ev)
{
    if (ev->button() == Qt::RightButton)
        currentItemIsAt(ev->globalPos());
}

void ImagePreviewPanel::keyPressEvent(QKeyEvent *ev)
{
    if (ev->modifiers() == Qt::ShiftModifier)
    {
        if (ev->key() == Qt::Key_M)
        {
            foreach (ImagePreviewItem* item, getItems())
            {
                setMaskOn(item, mask_color);
                item->update();
            }
        }


        if (ev->key() == Qt::Key_R)
        {
            int last_index = items.size() - 1;
            for (int i = 0; i <= items.size() / 2; ++i)
            {
                items.swap(i, last_index - i);
                items.at(i)->update();
            }
        }

    }

    if (ev->modifiers() == Qt::NoModifier)
    {
        if (ev->key() == Qt::Key_R && current_item)
        {
            QImage to_edit = current_item->image();
            QTransform transform_matrix;
            transform_matrix.rotate(90, Qt::ZAxis);
            current_item->setImage(to_edit);
            current_item->update();
        }

        if (ev->key() == Qt::Key_Delete && current_item)
        {
            layout->removeWidget(current_item);
            items.removeOne(current_item);
            delete current_item;
        }
    }
}

void ImagePreviewPanel::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED(ev);

    QStyleOption option;
    option.init(this);

    QPainter painter(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &painter, this);

}

int ImagePreviewPanel::getRowsCount(int images_count)
{
    return (images_count - images_count%10 + 10) / 10;
}

const QList<ImagePreviewItem*>& ImagePreviewPanel::getItems() const
{
    return items;
}

void ImagePreviewPanel::setItems(const QStringList &imagepathesList)
{
    clearItems();
    fillItems(imagepathesList);
}

void ImagePreviewPanel::fillItems(const QStringList &imagepathesList)
{
    MainWindow* mainwindow = dynamic_cast<MainWindow*>(parent());
    if (mainwindow)
    {
        mainwindow->progressbar()->setRange(0, imagepathesList.size());
        mainwindow->progressbar()->setFormat(tr("%v изображений из %m подготовлено"));
    }

    QList<QHBoxLayout*> row_layouts;
    for (int row = 0; row < getRowsCount(imagepathesList.size()); ++row)
    {
        QHBoxLayout *row_layout = new QHBoxLayout;
        row_layouts.append(row_layout);
        layout->addLayout(row_layout);
    }

    for (int i = 0; i < imagepathesList.size(); ++i)
    {
        ImagePreviewItem *item = new ImagePreviewItem(imagepathesList.at(i), this);
        connect (item, SIGNAL(maskColorChanged(QColor)), this, SLOT(setMaskColor(QColor)));
        row_layouts.at(i/10)->addWidget(item);
        items.append(item);

        mainwindow->progressbar()->setValue(i + 1);
        qApp->processEvents();
    }

    animation = new ImagePreviewItem (this);
    animation->setImage(items.at(0)->image());
    animation_fps = 30;
    animation_frame = 0;

    animation_updater = new QTimer (this);
    animation_updater->start(1000/animation_fps);
    connect (animation_updater, SIGNAL(timeout()), this, SLOT(updateAnimationItem()));

    layout->addWidget(animation, 50, Qt::AlignHCenter);
}

void ImagePreviewPanel::clearItems()
{
    if (!items.isEmpty())
    {
        foreach (ImagePreviewItem* image_preview_item, items)
        {
            disconnect (image_preview_item, SIGNAL(maskColorChanged(QColor)), this, SLOT(setMaskColor(QColor)));
            layout->removeWidget(image_preview_item);
            items.removeOne(image_preview_item);
            delete image_preview_item;
        }

        if (animation)
        {
            disconnect (animation_updater, SIGNAL(timeout()), this, SLOT(updateAnimationItem()));
            layout->removeWidget(animation);
            delete animation_updater;
            delete animation;
        }
    }
}

void ImagePreviewPanel::setMaskOn(ImagePreviewItem* item, const QColor &mask_color)
{
    QImage under_edit = item->image();
    QImage alpha_channel = under_edit.createMaskFromColor(mask_color.rgb(), Qt::MaskOutColor);
    under_edit.setAlphaChannel(alpha_channel);
    item->setImage(under_edit);
}

void ImagePreviewPanel::currentItemIsAt(const QPoint &mouse_position)
{
    QWidget* chosen_widget = qApp->widgetAt(mouse_position);
    if (chosen_widget)
        current_item = dynamic_cast<ImagePreviewItem*>(chosen_widget);

    if (current_item)
        qDebug("oh yeah!");
}

// slots
void ImagePreviewPanel::setMaskColor(const QColor &new_mask_color)
{
    mask_color = new_mask_color;

    qDebug(mask_color.name().toUtf8());
}

void ImagePreviewPanel::updateAnimationItem()
{
    ++animation_frame;
    if (animation_frame >= items.size())
        animation_frame = 0;
    animation->setImage(items.at(animation_frame)->image());
    animation->update();
}



