#ifndef MAINWINDOW_H
#define MAINWINDOW_H

class QLabel;
class QSlider;
class QPushButton;
class ProgressBar;
class QGridLayout;
class ImagePreviewPanel;
#include <qt_windows.h>
#include <QWidget>
class MainWindow : public QWidget
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    ProgressBar* progressbar() const;

    int imagesCount() const;
    void setImagesCount(int value);

    int inARow() const;
    int inAColumn() const;
    int framewidth() const;
    int frameheight() const;
    int paddingX() const;
    int paddingY() const;

protected:
    void paintEvent(QPaintEvent *ev);

private:
    void initVars();
    void buildUI();
    void makeEditorAndButtons();
    void makeFramesizeControls();
    void makePaddingControls();
    void makeRowColumnCountControls();
    void installStylesheet();
    void setupLayout();
    void polishUI();

    void hideAllControls();    
    void updateWorkspace();
    void showAllControls();

    void playSound(LPCWSTR soundpath);

    QGridLayout *m_layout;

    // helpfull stuff

    /* == main components == */
    ImagePreviewPanel *m_image_preview_panel;
    QPushButton *pb_make_spritesheet, *pb_load_images;    
    ProgressBar *m_progressbar;

    /* == row/column count controls == */
    QLabel *m_inARowAndColumn_label;
    QSlider *m_inARow_slider, *m_inAColumn_slider;
    int m_totalImages;
    int m_inARow, m_inAColumn;

    /* == framesize controls == */
    QLabel *m_framesize_label;
    QSlider *m_framewidth_slider, *m_frameheight_slider;
    int m_framewidth, m_frameheight;

    /* == padding controls == */
    QLabel *m_padding_label;
    QSlider *m_padding_x_slider, *m_padding_y_slider;
    int m_padding_x, m_padding_y;

signals:

public slots:
    void setImagesInARow(int value);
    void setImagesInAColumn(int value);
    void setFramewidth(int value);
    void setFrameheight(int value);
    void setPaddingX(int value);
    void setPaddingY(int value);

    void loadImages();
    void makeSpritesheet();
};

#endif // MAINWINDOW_H
