# SpritesheetMaker (QT5)

This is a small to tool to help us to create animations based on sprites.
Load a pack of frames as a base of spritelist, choose which ones you want to edit.
Grab a mask color and set up mask based on it for each image (Shift+RMB,Shift+M).
Drag and drop items to swap their positions. Delete unnecessary ones or change
them to get a new frame. Watch the resulting animation. Save it to png format and 
use it whenever you need.
