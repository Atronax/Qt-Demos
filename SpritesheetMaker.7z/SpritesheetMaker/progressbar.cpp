#include <QPainter>
#include <QFont>

#include "progressbar.h"

ProgressBar::ProgressBar(QWidget* parent)
    : QProgressBar(parent)
{
    setFormat("");
}

ProgressBar::~ProgressBar()
{

}

void ProgressBar::paintEvent(QPaintEvent *ev)
{
    QRect full_rect = rect();
    QBrush full_rect_brush = QBrush(QColor("#241E46"), Qt::Dense2Pattern);

    float curr_width = static_cast<float>(value()-minimum())/(maximum()-minimum());
    QRect curr_rect = QRect(full_rect.x(), full_rect.y(), full_rect.width()*curr_width, full_rect.height());
    QBrush curr_rect_brush = QBrush(QColor("#FF4500"));

    QPainterPath full_path, curr_path;
    full_path.addRoundedRect(full_rect, 10, 50);
    curr_path.addRoundedRect(curr_rect, 10, 50);

    QPainter painter (this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setFont(QFont("Deutsch Gothic", 10, 20, true));
    painter.setPen(QPen(QColor("#FAFAD2")));

    painter.fillPath(full_path, full_rect_brush);
    painter.fillPath(curr_path, curr_rect_brush);

    QString text = format();
    text.replace(QRegExp("%v"), QString::number(value()));
    text.replace(QRegExp("%m"), QString::number(maximum()));
    painter.drawText(full_rect, text, QTextOption(Qt::AlignCenter));
}
