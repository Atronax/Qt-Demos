#include "crypter.h"

Crypter::Crypter()
{
    // setupping stream to get needed output
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("Windows-1251"));
    m_HelperStream.setString(&m_HelperString);
}

Crypter::~Crypter()
{
}

QString Crypter::cipherRussian(QString &text, int shift, bool toEncode)
{
    QString result;

    // lower all letters of the text
    text = text.toLower();

    // for each symbol of the string
    for (int i = 0; i < text.length(); ++i)
    {
        // get input symbol
        QChar input = text.at(i);
        QChar output;

        // using win1251 codec send unicode symbol over textstream to storage
        m_HelperStream << input.unicode();

        // we do not change puncuation and spaces
        if (input.isPunct() || input.isSpace())
            output = input;
        else
        {
            // use input symbol code to find encoded symbol code and get qchar using this information
            // we withdraw symbol 'ё' as it is positioned far away from the original set
            int output_code;
            if (toEncode == true)
            {
                output_code = m_HelperString.toInt() + shift;
                if (output_code > RUSSIAN_LATEST_LETTER_CODE) // code of 'я'
                    output_code -= RUSSIAN_LETTERS_COUNT;
            }
            else
            {
                output_code = m_HelperString.toInt() - shift;
                if (output_code < RUSSIAN_FIRST_LETTER_CODE) // code of 'а'
                    output_code += RUSSIAN_LETTERS_COUNT;
            }

            output = QChar(output_code);

            // qDebug(QString(input + ' ' + m_HelperString).toUtf8());
        }

        // clear string to save ability of using it for another symbols
        m_HelperString.clear();

        // push symbol to res string
        result.append(output);
    }

    return result;
}

QString Crypter::cipherEnglish(QString &text, int shift, bool toEncode)
{
    QString result;

    // lower all letters of the text
    text = text.toLower();

    // for each symbol of the string
    for (int i = 0; i < text.length(); ++i)
    {
        // get input symbol
        QChar input = text.at(i);
        QChar output;

        // using win1251 codec send unicode symbol over textstream to storage
        m_HelperStream << input.unicode();

        // we do not change puncuation and spaces
        if (input.isPunct() || input.isSpace())
            output = input;
        else
        {
            // use input symbol code to find encoded symbol code and get qchar using this information
            // we withdraw symbol 'ё' as it is positioned far away from the original set
            int output_code;
            if (toEncode == true)
            {
                output_code = m_HelperString.toInt() + shift;
                if (output_code > ENGLISH_LATEST_LETTER_CODE) // code of 'я'
                    output_code -= ENGLISH_LETTERS_COUNT;
            }
            else
            {
                output_code = m_HelperString.toInt() - shift;
                if (output_code < ENGLISH_FIRST_LETTER_CODE) // code of 'а'
                    output_code += ENGLISH_LETTERS_COUNT;
            }

            output = QChar(output_code);

            // qDebug(QString(input + ' ' + m_HelperString).toUtf8());
        }

        // clear string to save ability of using it for another symbols
        m_HelperString.clear();

        // push symbol to res string
        result.append(output);
    }

    return result;
}
