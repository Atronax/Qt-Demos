#ifndef IMAGEPREVIEWITEM_H
#define IMAGEPREVIEWITEM_H

#include <QWidget>
class ImagePreviewItem : public QWidget
{
    Q_OBJECT

public:
    explicit ImagePreviewItem(QWidget *parent = nullptr);
    explicit ImagePreviewItem(const QString& image_path, QWidget *parent = nullptr);
    ~ImagePreviewItem();

    const QImage& image() const;
    void setImage(const QImage& new_image);

protected:
    void mousePressEvent(QMouseEvent *ev);

    void dragEnterEvent(QDragEnterEvent *ev);
    void dragMoveEvent(QDragMoveEvent *ev);
    void dropEvent(QDropEvent *ev);

    void paintEvent(QPaintEvent *ev);

private:
    QImage m_image;

signals:
    void maskColorChanged(const QColor& mask_color);

public slots:
    void drag();
};

#endif // IMAGEPREVIEWITEM_H
