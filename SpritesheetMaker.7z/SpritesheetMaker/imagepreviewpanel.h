#ifndef IMAGEPREVIEWPANEL_H
#define IMAGEPREVIEWPANEL_H

#include "imagepreviewitem.h"
#include <QWidget>
#include <QList>

class QTimer;
class QHBoxLayout;
class QVBoxLayout;
class ImagePreviewPanel : public QWidget
{
    Q_OBJECT

public:
    explicit ImagePreviewPanel(QWidget *parent = 0);
    ~ImagePreviewPanel();

    const QList<ImagePreviewItem*>& getItems() const;
    void setItems (const QStringList& imagepathesList);

protected:
    void keyPressEvent(QKeyEvent* ev);
    void mousePressEvent(QMouseEvent* ev);
    void paintEvent(QPaintEvent *ev);

private:
    /* == менеджер компоновки == */
    QVBoxLayout* layout;

    /* ==  вспомогательные функции == */
    int getRowsCount(int images_count);

    /* ==  работа с списком превью-обьектов == */
    void clearItems();
    void fillItems(const QStringList& imagepathesList);
    QList<ImagePreviewItem*> items;

    /* ==  работа с текущим обьектом == */
    void currentItemIsAt(const QPoint& mouse_position);
    void setMaskOn(ImagePreviewItem* item, const QColor& mask_color);
    ImagePreviewItem* current_item;
    QColor mask_color;

    /* ==  работа с обьектом-анимацией == */
    ImagePreviewItem *animation;
    QTimer *animation_updater;
    int animation_fps,
        animation_frame;

signals:

public slots:
    void updateAnimationItem();
    void setMaskColor(const QColor& new_mask_color);

};

#endif // IMAGEPREVIEWPANEL_H
