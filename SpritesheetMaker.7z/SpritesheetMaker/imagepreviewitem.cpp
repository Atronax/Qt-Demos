// logic
#include <QStyleOption>
#include <QPainter>

// events
#include <QMouseEvent>
#include <QPaintEvent>

// drag&&drop
#include <QDrag>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QMimeData>

// widgets
#include <QDialog>
#include <QLineEdit>
#include <QFormLayout>

#include "imagepreviewitemconfigure.h"
#include "imagepreviewitem.h"
ImagePreviewItem::ImagePreviewItem(QWidget *parent)
    : QWidget (parent)
{
    setFixedSize(100,100);
    setAcceptDrops(true);
}

ImagePreviewItem::ImagePreviewItem(const QString& image_path, QWidget *parent)
    : QWidget (parent)
{
    setFixedSize(80,80);
    setAcceptDrops(true);
    setMouseTracking(true);
    setImage(QImage(image_path.toUtf8()));
    setFocusPolicy(Qt::ClickFocus);

}

ImagePreviewItem::~ImagePreviewItem()
{

}

const QImage& ImagePreviewItem::image() const
{
    return m_image;
}

void ImagePreviewItem::setImage(const QImage &new_image)
{
    m_image = new_image;
}

void ImagePreviewItem::mousePressEvent(QMouseEvent *ev)
{
    if (ev->modifiers() == Qt::ShiftModifier)
    {
          QPixmap pixmap = grab(QRect(ev->x(), ev->y(), 1, 1));
          QRgb rgb = pixmap.toImage().pixel(0,0);
          emit maskColorChanged(QColor::fromRgb(rgb));
    }

    if (ev->modifiers() == Qt::NoModifier)
    {
        if (ev->button() == Qt::LeftButton)
            drag();

        if (ev->button() == Qt::RightButton)
        {
            ImagePreviewItemConfigure dialog (this, Qt::FramelessWindowHint, ev->globalPos());
            if (dialog.exec() == QDialog::Accepted)
                setImage(QImage(dialog.path()));
        }
    }

    parent()->event(ev);
}

void ImagePreviewItem::dragEnterEvent(QDragEnterEvent *ev)
{
    ev->acceptProposedAction();
}

void ImagePreviewItem::dragMoveEvent(QDragMoveEvent *ev)
{
    ev->acceptProposedAction();
}

void ImagePreviewItem::dropEvent(QDropEvent *ev)
{    
    QImage source_image = qvariant_cast<QImage>(ev->mimeData()->imageData());
    if (!source_image.isNull())
    {
        ImagePreviewItem* source = qobject_cast<ImagePreviewItem*>(ev->source());
        ImagePreviewItem* target = this;

        source->setImage(target->image());
        target->setImage(source_image);

        source->update();
        target->update();

        ev->acceptProposedAction();
    }
}

void ImagePreviewItem::paintEvent(QPaintEvent *ev)
{
    Q_UNUSED(ev);

    QStyleOption option;
    option.init(this);

    QPainter painter(this);
    painter.drawImage(rect(), m_image);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &painter, this);
}

void ImagePreviewItem::drag()
{
    if (!m_image.isNull())
    {
        QMimeData *data = new QMimeData;
        data->setImageData(m_image);

        QDrag *drag = new QDrag (this);
        drag->setMimeData(data);
        drag->setPixmap(QPixmap::fromImage(m_image).scaled(size()));
        drag->start(Qt::MoveAction);
    }
}
