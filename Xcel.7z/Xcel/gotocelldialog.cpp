// LOGIC
#include <QRegExp>
#include <QRegExpValidator>
#include <QLayout>

// WIDGETS
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>

#include "gotocelldialog.h"

QLineEdit* GoToCellDialog::getLocationLinedit()
{
    return le_location;
}

void GoToCellDialog::createWidgets()
{
    le_location = new QLineEdit;
    le_location->setValidator(new QRegExpValidator(QRegExp("[A-Za-z][1-9][0-9]{0,2}"), this));
    connect (le_location, SIGNAL(textChanged(QString)), this, SLOT(on_le_location_text_changed()));

    lbl_location = new QLabel(tr("&Cell location"));
    lbl_location->setBuddy(le_location);

    pb_ok = new QPushButton(tr("Ok"));
    connect (pb_ok, SIGNAL(clicked()), this, SLOT(accept()));

    pb_cancel = new QPushButton(tr("Cancel"));
    connect (pb_cancel, SIGNAL(clicked()), this, SLOT(reject()));
}

void GoToCellDialog::initLayout()
{
    QGridLayout* layout = new QGridLayout;
    layout->addWidget(lbl_location, 0, 0, 1, 1);
    layout->addWidget(le_location, 0, 1, 1, 1);
    layout->addWidget(pb_ok, 1, 0, 1, 1);
    layout->addWidget(pb_cancel, 1, 1, 1, 1);

    setLayout(layout);

    setWindowTitle(tr("Go to cell"));
    setFixedSize(sizeHint());
}

// SLOTS
void GoToCellDialog::on_le_location_text_changed()
{
    pb_ok->setEnabled(le_location->hasAcceptableInput());
}
