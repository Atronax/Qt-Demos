#include "spreadsheetcompare.h"

bool SpreadsheetCompare::operator() (const QStringList& lhs, const QStringList& rhs) const
{
    for (int i = 0; i < KeyCount; ++i)
    {
        int iCurrentColumn = iKeys[i];

        if (iCurrentColumn != -1)
        {
            if (lhs.at(iCurrentColumn) != rhs.at(iCurrentColumn))
            {
                if (isAscending[i])
                    return lhs.at(iCurrentColumn) < rhs.at(iCurrentColumn);
                else
                    return lhs.at(iCurrentColumn) > rhs.at(iCurrentColumn);
            }
        }
    }

    return false;
}
