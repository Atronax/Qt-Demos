// LOGIC
#include <QLayout>

// WIDGETS
#include <QPushButton>
#include <QComboBox>
#include <QGroupBox>
#include <QLabel>


#include "sortdialog.h"

void SortDialog::createWidgets()
{
    pb_ok = new QPushButton (tr("Ok"));
    pb_ok->setObjectName("OkButton");
    pb_ok->setDefault(true);
    connect (pb_ok, SIGNAL(clicked()), this, SLOT(accept()));

    pb_cancel = new QPushButton (tr("Cancel"));
    pb_cancel->setObjectName("CancelButton");
    connect (pb_cancel, SIGNAL(clicked()), this, SLOT(reject()));

    pb_more = new QPushButton (tr("&More"));
    pb_more->setObjectName("MoreButton");
    pb_more->setCheckable(true);
    connect (pb_more, SIGNAL(toggled(bool)), this, SLOT(onMoreButton(bool)));

    createPrimaryGroupbox ();
    createSecondaryGroupbox ();
    createTertiaryGroupbox ();
}

void SortDialog::initLayout()
{
    QGridLayout *layout = new QGridLayout;

    layout->addWidget(gb_primary, 0, 0, 3, 3);
    layout->addWidget(pb_ok, 0, 3, 1, 1);
    layout->addWidget(pb_cancel, 1, 3, 1, 1);
    layout->addWidget(pb_more, 2, 3, 1, 1);

    setLayout(layout);

    setWindowTitle(tr("Sort"));
    setFixedSize(sizeHint());
}

void SortDialog::createPrimaryGroupbox()
{
    gb_primary = new QGroupBox("&Primary Key");

    cb_primary_column = new QComboBox;
    cb_primary_column->addItem("None");
    lbl_primary_column = new QLabel ("Column: ");
    lbl_primary_column->setBuddy(cb_primary_column);

    cb_primary_order = new QComboBox;
    cb_primary_order->addItem("Ascending");
    cb_primary_order->addItem("Descending");
    lbl_primary_order = new QLabel ("Order: ");
    lbl_primary_order->setBuddy(cb_primary_order);

    QGridLayout* primary_layout = new QGridLayout;
    primary_layout->addWidget(lbl_primary_column, 0, 0, 1, 1);
    primary_layout->addWidget(cb_primary_column, 0, 1, 1, 1);
    primary_layout->addWidget(lbl_primary_order, 1, 0, 1, 1);
    primary_layout->addWidget(cb_primary_order, 1, 1, 1, 1);

    gb_primary->setLayout(primary_layout);
}

void SortDialog::createSecondaryGroupbox()
{
    gb_secondary = new QGroupBox("&Secondary Key");

    cb_secondary_column = new QComboBox;
    cb_secondary_column->addItem("None");
    lbl_secondary_column = new QLabel ("Column: ");
    lbl_secondary_column->setBuddy(cb_secondary_column);

    cb_secondary_order = new QComboBox;
    cb_secondary_order->addItem("Ascending");
    cb_secondary_order->addItem("Descending");
    lbl_secondary_order = new QLabel ("Order: ");
    lbl_secondary_order->setBuddy(cb_secondary_order);

    QGridLayout* secondary_layout = new QGridLayout;
    secondary_layout->addWidget(lbl_secondary_column, 0, 0, 1, 1);
    secondary_layout->addWidget(cb_secondary_column, 0, 1, 1, 1);
    secondary_layout->addWidget(lbl_secondary_order, 1, 0, 1, 1);
    secondary_layout->addWidget(cb_secondary_order, 1, 1, 1, 1);

    gb_secondary->setLayout(secondary_layout);
}

void SortDialog::createTertiaryGroupbox()
{
    gb_tertiary = new QGroupBox("&Tertiary Key");

    cb_tertiary_column = new QComboBox;
    cb_tertiary_column->addItem("None");
    lbl_tertiary_column = new QLabel ("Column: ");
    lbl_tertiary_column->setBuddy(cb_tertiary_column);

    cb_tertiary_order = new QComboBox;
    cb_tertiary_order->addItem("Ascending");
    cb_tertiary_order->addItem("Descending");
    lbl_tertiary_order = new QLabel ("Order: ");
    lbl_tertiary_order->setBuddy(cb_tertiary_order);

    QGridLayout* tertiary_layout = new QGridLayout;
    tertiary_layout->addWidget(lbl_tertiary_column, 0, 0, 1, 1);
    tertiary_layout->addWidget(cb_tertiary_column, 0, 1, 1, 1);
    tertiary_layout->addWidget(lbl_tertiary_order, 1, 0, 1, 1);
    tertiary_layout->addWidget(cb_tertiary_order, 1, 1, 1, 1);

    gb_tertiary->setLayout(tertiary_layout);
}

void SortDialog::setColumnRange(QChar first, QChar last)
{
    cb_primary_column->clear();
    cb_secondary_column->clear();
    cb_tertiary_column->clear();

    cb_secondary_column->addItem(tr("None"));
    cb_tertiary_column->addItem(tr("None"));

    cb_primary_column->setMinimumSize(cb_secondary_column->sizeHint());
    QChar cur_column = first;
    while (cur_column <= last)
    {
        cb_primary_column->addItem(cur_column);
        cb_secondary_column->addItem(cur_column);
        cb_tertiary_column->addItem(cur_column);

        cur_column = cur_column.unicode() + 1;
    }
}

// SLOTS
void SortDialog::onMoreButton(bool show)
{
    if (show)
    {
        QGridLayout* layout = qobject_cast<QGridLayout*>(this->layout());
        layout->addWidget(gb_secondary, 3, 0, 3, 3);
        layout->addWidget(gb_tertiary, 6, 0, 3, 3);
        setLayout(layout);

        gb_secondary->show();
        gb_tertiary->show();
    }
    else
    {
        QGridLayout* layout = qobject_cast<QGridLayout*>(this->layout());
        layout->removeWidget(gb_secondary);
        layout->removeWidget(gb_tertiary);
        setLayout(layout);

        gb_secondary->hide();
        gb_tertiary->hide();
    }

    setFixedSize(sizeHint());
}
