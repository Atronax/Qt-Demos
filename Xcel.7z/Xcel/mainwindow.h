#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class QAction;
class QLabel;
class QColorDialog;
class QFontDialog;

#include "spreadsheet.h"
#include "finddialog.h"
#include "gotocelldialog.h"
#include "sortdialog.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = 0)
        : QMainWindow (parent),
          finddialog (nullptr),
          dlg_color (nullptr),
          dlg_font (nullptr)
    {
        setMouseTracking(true);
        setAttribute(Qt::WA_DeleteOnClose);

        spreadsheet = new Spreadsheet;
        setCentralWidget(spreadsheet);

        loadStylesheets();

        createActions();
        createMenus();
        createContextMenu();
        createToolbars();
        createStatusbar();

        loadSettings();        

        setWindowIcon(QIcon(":/images/icon.png"));
        setCurrentFile ("");
    }

    ~MainWindow()
    {

    }

protected:
    void contextMenuEvent(QContextMenuEvent* ev);
    void closeEvent(QCloseEvent* ev);

private:
    void createActions ();
    void createMenus ();
    void createContextMenu ();
    void createToolbars ();
    void createStatusbar ();

    void saveSettings ();
    void loadSettings ();

    void loadStylesheets ();

    bool ok_to_continue ();
    void setCurrentFile (const QString& filename);
    QString stripped_name (const QString& full_name);
    QString style_name (const QString& full_name);
    bool saveFile (const QString& filename);
    bool loadFile (const QString& filename);

    void update_recent_fileactions ();
    void mdi_update_recent_fileactions ();

    Spreadsheet *spreadsheet;
    FindDialog *finddialog;
    QLabel *lbl_location, *lbl_formula;
    QStringList recent_files;
    QString current_file;
    QStringList styles_names, styles_sheets;

    // RECENT FILES MENU
    enum {MaxRecentFiles = 5};
    QAction *act_recent_files [MaxRecentFiles], *act_separator;

    // FILE MENU
    QToolBar *tb_file;
    QMenu *menu_file;
    QAction *act_new, *act_open, *act_save, *act_save_as, *act_close, *act_exit;

    // EDIT MENU
    QToolBar *tb_edit;
    QMenu *menu_edit, *menu_edit_select;
    QAction *act_cut, *act_copy, *act_paste, *act_delete,
            *act_selectRow, *act_selectColumn, *act_selectAll,
            *act_find, *act_gotocell;

    // TOOLS MENU
    QMenu *menu_tools;
    QAction *act_foreground_color, *act_background_color,
            *act_font,
            *act_align_left, *act_align_center, *act_align_right,
            *act_recalculate, *act_sort;
    QColorDialog *dlg_color;
    QFontDialog *dlg_font;

    // OPTIONS MENU
    QMenu *menu_options, *menu_options_styles;
    QAction *act_showGrid, *act_autoRecalculation,
            *act_simpleStyle;
    QVector<QAction*> act_styles;

    // HELP MENU
    QMenu *menu_help;
    QAction *act_about, *act_aboutQT;

    // CONTEXT MENU
    QMenu *menu_context;

    // CELL TOOLBAR
    QToolBar *tb_cell;
    QLineEdit *le_celldata;


signals:

public slots:

private slots:
    void new_file ();
    void open ();
    bool save ();
    bool save_as ();
    void find ();
    void gotocell ();
    void sort ();
    void about ();
    void open_recent_file ();
    void update_statusbar ();    
    void on_cellChanged ();
    void setStyle ();
    void on_cellChosen (QString);
    void on_celldata_textChanged (QString);
    void on_spreadsheet_modified ();
    void on_choose_color ();
    void set_background_color (QColor);
    void set_foreground_color (QColor);
    void on_choose_font ();
    void set_items_font (QFont);
    void on_align ();
};

#endif // MAINWINDOW_H
