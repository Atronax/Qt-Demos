// LOGIC
#include <QLayout>

// WIDGETS
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>

#include "finddialog.h"

void FindDialog::createWidgets()
{
    lineedit = new QLineEdit;
    connect (lineedit, SIGNAL(textChanged(QString)), this, SLOT(enableFindButton(QString)));

    label = new QLabel (tr("Find &what: "));
    label->setBuddy (lineedit);

    cb_case = new QCheckBox (tr("Match &case"));
    cb_backward = new QCheckBox (tr("Search backward"));

    pb_find = new QPushButton (tr("&Find"));
    pb_find->setDefault (true);
    pb_find->setEnabled (false);
    connect (pb_find, SIGNAL(clicked()), this, SLOT(onFindClicked()));

    pb_close = new QPushButton (tr("Close"));
    connect (pb_close, SIGNAL(clicked()), this, SLOT(close()));
}

void FindDialog::initLayout()
{
    QHBoxLayout *top_left = new QHBoxLayout;
    top_left->addWidget(label);
    top_left->addWidget(lineedit);

    QVBoxLayout *left = new QVBoxLayout;
    left->addLayout(top_left);
    left->addWidget(cb_case);
    left->addWidget(cb_backward);

    QVBoxLayout *right = new QVBoxLayout;
    right->addWidget(pb_find);
    right->addWidget(pb_close);
    right->addStretch();

    QHBoxLayout *main_l = new QHBoxLayout;
    main_l->addLayout(left);
    main_l->addLayout(right);

    setLayout(main_l);

    setWindowTitle(tr("Find"));
    setFixedHeight(sizeHint().height());
}

// SLOTS
void FindDialog::onFindClicked()
{
    QString text = lineedit->text();
    Qt::CaseSensitivity cs = cb_case->isChecked() ? Qt::CaseSensitive : Qt::CaseInsensitive;

    if (cb_backward->isChecked())
        emit findPrevious(text, cs);
    else
        emit findNext (text, cs);
}

void FindDialog::enableFindButton(const QString &text)
{
    pb_find->setEnabled(!text.isEmpty());
}
