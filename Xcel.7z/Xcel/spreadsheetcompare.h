#ifndef SPREADSHEETCOMPARE_H
#define SPREADSHEETCOMPARE_H

#include <QStringList>

class SpreadsheetCompare
{
public:
    bool operator() (const QStringList& lhs, const QStringList& rhs) const;

    enum {KeyCount = 3};
    int iKeys [KeyCount];
    bool isAscending [KeyCount];
};

#endif // SPREADSHEETCOMPARE_H
