#ifndef CELL_H
#define CELL_H

#include <QTableWidgetItem>

class Cell : public QTableWidgetItem
{
public:
    Cell()
    {
        setDirty();
    }

    ~Cell()
    {

    }

    QTableWidgetItem* clone() const;

    void setData (int role, const QVariant &value);
    QVariant data (int role) const;

    void setFormula (const QString& formula);
    QString formula () const;

    void setDirty ();

private:
    QVariant value() const;
    QVariant evaluateExpression (const QString& expression, int& pos) const;
    QVariant evaluateTerm (const QString& expression, int& pos) const;
    QVariant evaluateFactor (const QString& expression, int& pos) const;

    const QVariant INVALID;
    mutable QVariant value_cache;
    mutable bool value_cache_is_dirty;
};

#endif // CELL_H
