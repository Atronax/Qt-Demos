#ifndef SPREADSHEET_H
#define SPREADSHEET_H

#include <QTableWidget>
#include <QHeaderView>

#include "spreadsheetcompare.h"
#include "cell.h"
#include "celldelegate.h"

class Spreadsheet : public QTableWidget
{
    Q_OBJECT

public:
    Spreadsheet(QWidget *parent = 0) : QTableWidget (parent)
    {        
        setup();
        clear();
    }

    ~Spreadsheet()
    {

    }

    bool writeFile (const QString& filename);
    bool readFile (const QString& filename);

    void clear ();
    void sort (const SpreadsheetCompare& compare_functor);

    QString currentLocation () const;
    QString currentFormula () const;
    QTableWidgetSelectionRange selectedRange() const;

    // INLINES
    inline bool autoRecalculate () const
    {
        return autoRecalculation;
    }

protected:
    void setup ();

    virtual void keyPressEvent(QKeyEvent* ev);
    virtual void mousePressEvent(QMouseEvent* ev);

private:
    enum {MagicNumber = 0x7F51C883, RowCount = 999, ColumnCount = 26};

    Cell* cell (int iRow, int iColumn) const;
    QString text (int iRow, int iColumn) const;
    QString formula (int iRow, int iColumn) const;
    void setFormula (int iRow, int iColumn, const QString& formula);

    bool autoRecalculation;


signals:
    void cellChosen (const QString& what_cell);
    void modified ();

public slots:
    void cut ();
    void copy ();
    void paste ();
    void del ();

    void selectCurrentRow ();
    void selectCurrentColumn ();

    void setAutoRecalculation (bool to_what);
    void recalculate ();

    void findNext (const QString& string, Qt::CaseSensitivity cs);
    void findPrevious (const QString& string, Qt::CaseSensitivity cs);

private slots:
    void on_smth_changed ();
};

#endif // SPREADSHEET_H
