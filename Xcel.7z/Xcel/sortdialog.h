#ifndef SORTDIALOG_H
#define SORTDIALOG_H

#include <QDialog>

class QLabel;
class QGroupBox;
class QComboBox;
class QPushButton;

class SortDialog : public QDialog
{
    Q_OBJECT

public:
    SortDialog(QWidget* parent = 0) : QDialog (parent)
    {
        createWidgets();
        initLayout();

        setColumnRange ('A', 'Z');
    }

    ~SortDialog()
    {

    }

    void setColumnRange (QChar first, QChar last);
    QComboBox *cb_primary_column, *cb_secondary_column, *cb_tertiary_column, *cb_primary_order, *cb_secondary_order, *cb_tertiary_order;

private:
    void createWidgets ();
    void createPrimaryGroupbox ();
    void createSecondaryGroupbox ();
    void createTertiaryGroupbox ();
    void initLayout ();

    QLabel *lbl_primary_column, *lbl_secondary_column, *lbl_tertiary_column, *lbl_primary_order, *lbl_secondary_order, *lbl_tertiary_order;   
    QGroupBox *gb_primary, *gb_secondary, *gb_tertiary;
    QPushButton *pb_ok, *pb_cancel, *pb_more;

private slots:
    void onMoreButton (bool show);
};


#endif // SORTDIALOG_H
