#include <QApplication>

#include "mainwindow.h"

int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    MainWindow *main_wnd = new MainWindow;
    main_wnd->show();

    return app.exec();
}
