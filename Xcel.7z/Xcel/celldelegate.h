#ifndef CELLDELEGATE_H
#define CELLDELEGATE_H

#include <QStyledItemDelegate>
#include <QPainter>

class CellDelegate : public QStyledItemDelegate
{
public:
    CellDelegate(QObject *parent = 0) : QStyledItemDelegate (parent)
    {

    }

    ~CellDelegate()
    {

    }

protected:
    virtual void initStyleOption(QStyleOptionViewItem *opt, const QModelIndex& index) const;
    virtual void paint(QPainter* painter, const QStyleOptionViewItem& opt, const QModelIndex& index) const;
};

#endif // CELLDELEGATE_H
