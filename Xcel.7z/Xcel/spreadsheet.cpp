// LOGIC
#include <QApplication>
#include <QMouseEvent>
#include <QClipboard>
#include <QFile>

// WIDGETS
#include <QMessageBox>

#include "spreadsheet.h"

void Spreadsheet::setup()
{
    autoRecalculation = true;

    setItemPrototype(new Cell);
    setItemDelegate (new CellDelegate);

    setSelectionMode(ContiguousSelection);
    setMouseTracking(true);

    horizontalHeader()->setMinimumHeight(30);
    verticalHeader()->setMinimumWidth(40);

    connect (this, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(on_smth_changed()));
}

// EVENTS
void Spreadsheet::keyPressEvent(QKeyEvent *ev)
{
    if (ev->key() == Qt::Key_R && ev->modifiers() == Qt::ControlModifier)
    {
        QList<QTableWidgetItem*> selection = selectedItems();
        foreach(QTableWidgetItem* item, selection)
        {
            resizeColumnToContents(item->column());
            resizeRowToContents(item->row());
        }
    }
    else
        QTableWidget::keyPressEvent(ev);
}

void Spreadsheet::mousePressEvent(QMouseEvent *ev)
{
    if (ev->button() == Qt::LeftButton && ev->modifiers() == Qt::AltModifier)
        emit cellChosen (QString(QChar('A' + columnAt(ev->pos().x()))) + QString::number(1 + rowAt(ev->pos().y())));
    else
        QTableWidget::mousePressEvent(ev);
}


void Spreadsheet::clear()
{
    setRowCount(0);
    setColumnCount(0);
    setRowCount(RowCount);
    setColumnCount(ColumnCount);

    for (int i = 0; i < ColumnCount; ++i)
    {
        QTableWidgetItem* item = new QTableWidgetItem (QString(QChar('A' + i)));
        setHorizontalHeaderItem(i, item);
    }

    setCurrentCell(0, 0);
}

Cell* Spreadsheet::cell(int iRow, int iColumn) const
{
    return static_cast<Cell*> (item(iRow, iColumn));    
}

QString Spreadsheet::text(int iRow, int iColumn) const
{
    Cell* current_cell = cell(iRow, iColumn); // Подосрительное место
    if (current_cell)
        return current_cell->text();
    else
        return "";
}

QString Spreadsheet::formula(int iRow, int iColumn) const
{
    Cell* current_cell = cell (iRow, iColumn); // Подосрительное место
    if (current_cell)
        return current_cell->formula();
    else
        return "";
}

void Spreadsheet::setFormula(int iRow, int iColumn, const QString &formula)
{
    Cell* current_cell = cell (iRow, iColumn);       

    if (!current_cell)
    {
        current_cell = new Cell;
        setItem(iRow, iColumn, current_cell);
    }

    current_cell->setFormula(formula);
}

QString Spreadsheet::currentLocation() const
{
    return QChar('A' + currentColumn()) + QString::number(currentRow()+1);
}

QString Spreadsheet::currentFormula() const
{
    return formula(currentRow(), currentColumn());
}

void Spreadsheet::on_smth_changed()
{
    if (autoRecalculation)
        recalculate();

    emit modified();
}

// SAVE AND LOAD FUNCTIONS
bool Spreadsheet::writeFile(const QString &filename)
{
    QFile file (filename);
    if (!file.open(QIODevice::WriteOnly))
    {
        QMessageBox::warning(this,
                             tr("Spreadsheet"),
                             tr("Cannot write file %1: \n %2.").arg(file.fileName()).arg(file.errorString()));
        return false;
    }

    QDataStream out (&file);
    out.setVersion(QDataStream::Qt_5_4);
    out << quint32 (MagicNumber); // format of new binary data file

    QApplication::setOverrideCursor(Qt::WaitCursor);
    for (int iRow = 0; iRow < RowCount; ++iRow)
    {
        for (int iColumn = 0; iColumn < ColumnCount; ++iColumn)
        {
            QString cellData = formula (iRow, iColumn);
            if (!cellData.isEmpty())
                out << quint16(iRow) << quint16(iColumn) << cellData
                    << item(iRow, iColumn)->background() << item(iRow, iColumn)->foreground()
                    << item(iRow, iColumn)->font() << item(iRow, iColumn)->textAlignment();
        }
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
    }
    QApplication::restoreOverrideCursor();

    return true;
}

bool Spreadsheet::readFile(const QString &filename)
{
    QFile file (filename);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this,
                             tr("Spreadsheet"),
                             tr("Cannot read file %1: \n %2.").arg(file.fileName()).arg(file.errorString()));
        return false;
    }

    QDataStream in (&file);
    in.setVersion(QDataStream::Qt_5_4);

    quint32 magic_number;
    in >> magic_number;

    if (magic_number != MagicNumber)
    {
        QMessageBox::warning(this,
                             tr("Spreadsheet"),
                             tr("The file is not a Spreadsheet file."));
        return false;
    }

    clear();

    quint16 row;
    quint16 column;
    QString data;
    QBrush background;
    QBrush foreground;
    QFont font;
    int text_alignment;

    QApplication::setOverrideCursor(Qt::WaitCursor);
    while (!in.atEnd())
    {
        in >> row >> column >> data >> background >> foreground >> font >> text_alignment;
        setFormula(row, column, data);
        item(row, column)->setBackground(background);
        item(row, column)->setForeground(foreground);
        item(row, column)->setFont(font);
        item(row, column)->setTextAlignment(text_alignment);
    }
    QApplication::restoreOverrideCursor();

    return true;

}

// EDIT MENU
void Spreadsheet::cut()
{
    copy();
    del();
}

QTableWidgetSelectionRange Spreadsheet::selectedRange() const
{
    QList<QTableWidgetSelectionRange> all_ranges = selectedRanges();

    if (all_ranges.isEmpty())
        return QTableWidgetSelectionRange();
    else
        return all_ranges.first();
}

void Spreadsheet::copy()
{
    QTableWidgetSelectionRange selection = selectedRange();

    QString selected_data;
    for (int i = 0; i < selection.rowCount(); ++i)
    {
        if (i > 0)
            selected_data += "\n";
        for (int j = 0; j < selection.columnCount(); ++j)
        {
            if (j > 0)
                selected_data += "\t";

            selected_data += formula(selection.topRow() + i, selection.leftColumn() + j);
        }
    }

    QApplication::clipboard()->setText(selected_data);
}

void Spreadsheet::paste()
{
    QTableWidgetSelectionRange selection = selectedRange();

    QString data_to_paste = QApplication::clipboard()->text();
    QStringList data_rows = data_to_paste.split('\n');
    QStringList columns = data_rows.first().split('\t');

    int iRowsCount = data_rows.count();
    int iColumnsCount = columns.count();

    if (selection.rowCount()*selection.columnCount() != 1 && (selection.rowCount() != iRowsCount || selection.columnCount() != iColumnsCount))
    {
        QMessageBox::information(this,
                                 tr("Spreadsheet"),
                                 tr("The data cannot be pasted because the copy and paste areas are not the same size."));
        return;
    }

    for (int i = 0; i < iRowsCount; ++i)
    {
        QStringList data_columns = data_rows.at(i).split('\t');

        for (int j = 0; j < iColumnsCount; ++j)
        {
            int iCurrentRow = selection.topRow() + i;
            int iCurrentColumn = selection.leftColumn() + j;

            if (iCurrentRow < selection.topRow() + iRowsCount && iCurrentColumn < selection.leftColumn() + iColumnsCount)
                setFormula(iCurrentRow, iCurrentColumn, data_columns.at(j));
        }
    }

    on_smth_changed();
}

void Spreadsheet::del()
{
    QList<QTableWidgetItem*> items_to_delete = selectedItems();
    if (!items_to_delete.isEmpty())
    {
        foreach (QTableWidgetItem *item, items_to_delete)
            delete item;

        on_smth_changed();
    }
}

void Spreadsheet::selectCurrentRow()
{
    selectRow(currentRow());
}

void Spreadsheet::selectCurrentColumn()
{
    selectColumn(currentColumn());
}

void Spreadsheet::findNext(const QString &string, Qt::CaseSensitivity cs)
{
    int iCurrentRow = currentRow();
    int iCurrentColumn = currentColumn() + 1;

    while (iCurrentRow < RowCount)
    {
        while (iCurrentColumn < ColumnCount)
        {
            if (text(iCurrentRow, iCurrentColumn).contains(string, cs))
            {
                clearSelection();
                setCurrentCell(iCurrentRow, iCurrentColumn);
                activateWindow();
                return;
            }

            ++iCurrentColumn;
        }

        ++iCurrentRow;
        iCurrentColumn = 0;
    }

    QApplication::beep();
}

void Spreadsheet::findPrevious(const QString &string, Qt::CaseSensitivity cs)
{
    int iCurrentRow = currentRow();
    int iCurrentColumn = currentColumn() - 1;

    while (iCurrentRow >= 0)
    {
        while (iCurrentColumn >= 0)
        {
            if (text(iCurrentRow, iCurrentColumn).contains(string, cs))
            {
                clearSelection();
                setCurrentCell(iCurrentRow, iCurrentColumn);
                activateWindow();
                return;
            }

            --iCurrentColumn;
        }

        --iCurrentRow;
        iCurrentColumn = ColumnCount - 1;
    }

    QApplication::beep();
}

// TOOLS MENU
void Spreadsheet::setAutoRecalculation(bool to_what)
{
    autoRecalculation = to_what;

    if (autoRecalculation)
        recalculate();
}

void Spreadsheet::recalculate()
{
    for (int iRow = 0; iRow < RowCount; ++iRow)
        for (int iColumn = 0; iColumn < ColumnCount; ++iColumn)
        {
            if (cell(iRow, iColumn))
                cell(iRow, iColumn)->setDirty();
        }

    viewport()->update();
}

void Spreadsheet::sort(const SpreadsheetCompare &compare_functor)
{
    QList<QStringList> rows_to_sort;
    QTableWidgetSelectionRange selection = selectedRange();

    for (int i = 0; i < selection.rowCount(); ++i)
    {
        QStringList current_row;
        for (int j = 0; j < selection.columnCount(); ++j)
            current_row.append(formula(selection.topRow() + i, selection.leftColumn() + j));

        rows_to_sort.append(current_row);
    }

    qStableSort(rows_to_sort.begin(), rows_to_sort.end(), compare_functor);

    for (int i = 0; i < selection.rowCount(); ++i)
        for (int j = 0; j < selection.columnCount(); ++j)
            setFormula(selection.topRow() + i, selection.leftColumn() + j, rows_to_sort[i][j]);

    clearSelection();
    on_smth_changed();
}
