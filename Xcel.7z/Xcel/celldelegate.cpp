#include "celldelegate.h"

void CellDelegate::initStyleOption(QStyleOptionViewItem *opt, const QModelIndex &index) const
{
    if (opt->state & QStyle::State_HasFocus)
        opt->state = opt->state & ~QStyle::State_HasFocus;
    else
        QStyledItemDelegate::initStyleOption(opt, index);
}

void CellDelegate::paint(QPainter *painter, const QStyleOptionViewItem &opt, const QModelIndex &index) const
{
    if (!index.isValid())
        return;

    QStyleOptionViewItem new_opt = opt;
    new_opt.palette.setBrush(QPalette::Highlight, QBrush("#F4FCF4"));
    new_opt.palette.setBrush(QPalette::HighlightedText, QBrush(Qt::black));

    painter->setRenderHint(QPainter::Antialiasing);

    QStyledItemDelegate::initStyleOption(&new_opt, index);

    if (opt.state & QStyle::State_Selected)
    {
        painter->fillRect(opt.rect, Qt::SolidPattern);
        QStyledItemDelegate::paint(painter, new_opt, index);
    }
    else if (opt.state & QStyle::State_Active || opt.state & QStyle::State_Enabled)
    {
        if (opt.state & QStyle::State_MouseOver)
            painter->fillRect(opt.rect, Qt::Dense4Pattern);
        else
            painter->fillRect(opt.rect, QBrush("#FFFFEC"));
        QStyledItemDelegate::paint(painter, new_opt, index);       
    }
    else
       QStyledItemDelegate::paint(painter, opt, index);
}
