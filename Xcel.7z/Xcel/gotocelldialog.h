#ifndef GOTOCELLDIALOG_H
#define GOTOCELLDIALOG_H

#include <QDialog>

class QLabel;
class QLineEdit;
class QPushButton;

class GoToCellDialog : public QDialog
{
    Q_OBJECT

public:
    GoToCellDialog(QWidget *parent = 0) : QDialog(parent)
    {
        createWidgets();
        initLayout();
    }

    ~GoToCellDialog()
    {

    }

    QLineEdit* getLocationLinedit ();

private:
    void createWidgets();
    void initLayout();

    QLabel *lbl_location;
    QLineEdit *le_location;
    QPushButton *pb_ok, *pb_cancel;

private slots:
    void on_le_location_text_changed ();
};

#endif // GOTOCELLDIALOG_H
