// LOGIC
#include <QRegExp>
#include <QtMath>

#include "cell.h"

QTableWidgetItem* Cell::clone() const
{
    return new Cell(*this);
}

void Cell::setFormula(const QString &formula)
{
    setData(Qt::EditRole, formula);
}

QString Cell::formula() const
{
    return data(Qt::EditRole).toString();
}

void Cell::setData(int role, const QVariant &value)
{
    QTableWidgetItem::setData(role, value);
    if (role == Qt::EditRole)
        setDirty();
}

QVariant Cell::data(int role) const
{
    if (role == Qt::DisplayRole)
    {
        if (value().isValid())
            return value().toString();
        else
            return "####";
    }
    else
        return QTableWidgetItem::data(role);
}

void Cell::setDirty()
{
    value_cache_is_dirty = true;
}

QVariant Cell::value() const
{
    if (value_cache_is_dirty)
    {
        QString data = formula();
        if (data.startsWith('\''))
            value_cache = data.mid(1);
        else if (data.startsWith('='))
        {
            value_cache = INVALID;

            QString expression = data.mid(1);
            expression.replace(" ", "");
            expression.append(QChar::Null);

            int current_position = 0;
            value_cache = evaluateExpression (expression, current_position);
            if (expression.at(current_position) != QChar::Null)
                value_cache = INVALID;
        }
        else
        {
            bool bOk;
            double number = data.toDouble(&bOk);
            if (bOk)
                value_cache = number;
            else
                value_cache = data;
        }
        value_cache_is_dirty = false;
    }

    return value_cache;
}

QVariant Cell::evaluateExpression(const QString &expression, int &pos) const
{
    QVariant result = evaluateTerm(expression, pos);

    while (expression.at(pos) != QChar::Null)
    {
        QChar operation = expression.at(pos);
        if (operation != '+' && operation != '-')
            return result;

        ++pos;

        QVariant term = evaluateTerm(expression, pos);
        if (result.type() == QVariant::Double && term.type() == QVariant::Double)
        {
            if (operation == '+')
                result = result.toDouble() + term.toDouble();
            else
                result = result.toDouble() - term.toDouble();
        }
        else
            result = INVALID;
    }

    return result;
}

QVariant Cell::evaluateTerm(const QString &expression, int &pos) const
{
    QVariant result = evaluateFactor(expression, pos);

    while (expression.at(pos) != QChar::Null)
    {
        QChar operation = expression.at(pos);
        if (operation != '*' && operation != '/')
            return result;

        ++pos;

        QVariant factor = evaluateFactor(expression, pos);
        if (result.type() == QVariant::Double && factor.type() == QVariant::Double)
        {
            if (operation == '*')
                result = result.toDouble() * factor.toDouble();
            else
            {
                if (factor.toDouble() == 0.0)
                    result = INVALID;
                else
                    result = result.toDouble() / factor.toDouble();
            }
        }
        else
            result = INVALID;
    }

    return result;
}

QVariant Cell::evaluateFactor(const QString &expression, int &pos) const
{
    QVariant result;

    bool isNegative = false;

    if (expression.at(pos) == '-')
    {
        isNegative = true;
        ++pos;
    }

    if (expression.at(pos) == '(')
    {
        ++pos;

        result = evaluateExpression(expression, pos);
        if (expression.at(pos) != ')')
            result = INVALID;

        if (expression.at(pos) != QChar::Null)
            ++pos;
    }
    else
    {
        QRegExp regexp_cell("[A-Za-z][1-9][0-9]{0,2}");
        QRegExp regexp_cos ("cos"), regexp_sin ("sin"), regexp_tg("tg"), regexp_ctg("ctg");
        QRegExp regexp_acos ("acos"), regexp_asin ("asin") , regexp_atg ("arctg"), regexp_actg ("arcctg"); // TO DO
        QRegExp regexp_exp ("exp");

        QString current_token;
        while (expression.at(pos).isLetterOrNumber() || expression.at(pos) == '.')
        {
            current_token += expression.at(pos);
            ++pos;
        }

        if (regexp_cell.exactMatch(current_token))
        {
            int iCurrentRow = current_token.mid(1).toInt() - 1;
            int iCurrentColumn = current_token.at(0).toUpper().unicode() - 'A';

            Cell *current_cell = static_cast<Cell*>(tableWidget()->item(iCurrentRow, iCurrentColumn));
            if (current_cell)
                result = current_cell->value();
            else
                result = 0.0;
        }
        else if (regexp_cos.exactMatch(current_token) || regexp_sin.exactMatch(current_token) ||
                 regexp_tg.exactMatch(current_token) || regexp_ctg.exactMatch(current_token))
        {
            const double epsilon = 1.0e-10;
            const double zero = 0.0;
            double radians = qDegreesToRadians(evaluateExpression(expression, pos).toDouble());

            qreal sin = qSin(radians);
            if (qAbs(sin - zero) < epsilon)
                sin = 0.0;

            qreal cos = qCos(radians);
            if (qAbs(cos - zero) < epsilon)
                cos = 0.0;

            if (regexp_cos.exactMatch(current_token))
                result = cos;

            if (regexp_sin.exactMatch(current_token))
                result = sin;

            if (regexp_tg.exactMatch(current_token))
                result = sin/cos;

            if (regexp_ctg.exactMatch(current_token))
                result = cos/sin;
        }
        else if (regexp_exp.exactMatch(current_token))
            result = exp(evaluateExpression(expression, pos).toDouble());
        else
        {
            bool bOk;
            result = current_token.toDouble(&bOk);
            if (!bOk)
                result = INVALID;
        }
    }

    if (isNegative)
    {
        if (result.type() == QVariant::Double)
            result = -result.toDouble();
        else
            result = INVALID;
    }

    return result;
}
