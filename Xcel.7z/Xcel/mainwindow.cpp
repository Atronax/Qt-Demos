// LOGIC
#include <QApplication>
#include <QCloseEvent>
#include <QSettings>
#include <QAction>

// WIDGETS
#include <QFileDialog>
#include <QMessageBox>
#include <QColorDialog>
#include <QFontDialog>
#include <QStatusBar>
#include <QLineEdit>
#include <QComboBox>
#include <QToolBar>
#include <QMenuBar>
#include <QMenu>
#include <QLabel>

#include "mainwindow.h"

void MainWindow::closeEvent(QCloseEvent *ev)
{
    if (ok_to_continue())
    {
        saveSettings();
        ev->accept();
    }
    else
        ev->ignore();

}

void MainWindow::createActions()
{
    // FILE MENU
    act_new = new QAction (tr("&New"), this);
    act_new->setIcon(QIcon(":/images/new.png")); // add
    act_new->setShortcut(QKeySequence::New);
    act_new->setStatusTip(tr("Creates a new spreadsheet file"));
    connect (act_new, SIGNAL(triggered()), this, SLOT(new_file()));

    act_open = new QAction (tr("&Open"), this);
    act_open->setIcon(QIcon(":/images/open.png"));
    act_open->setShortcut(QKeySequence::Open);
    act_open->setStatusTip(tr("Opens file, chosen by you"));
    connect (act_open, SIGNAL(triggered()), this, SLOT(open()));

    act_save = new QAction (tr("&Save"), this);
    act_save->setIcon(QIcon(":/images/save.png"));
    act_save->setShortcut(QKeySequence::Save);
    act_save->setStatusTip(tr("Saves recently made changes to current file"));
    connect (act_save, SIGNAL(triggered()), this, SLOT(save()));

    act_save_as = new QAction (tr("&Save as"), this);
    act_save_as->setIcon(QIcon(":/images/save_as.png"));
    act_save_as->setShortcut(QKeySequence::SaveAs);
    act_save_as->setStatusTip(tr("Saves data to a new file"));
    connect (act_save_as, SIGNAL(triggered()), this, SLOT(save_as()));

    for (int i = 0; i < MaxRecentFiles; ++i)
    {
        act_recent_files[i] = new QAction (this);
        act_recent_files[i]->setVisible (false);
        connect (act_recent_files[i], SIGNAL(triggered()), this, SLOT(open_recent_file()));
    }

    act_close = new QAction (tr("&Close"), this);
    act_close->setIcon(QIcon(":/images/close.png"));
    act_close->setShortcut(QKeySequence::Close);
    act_close->setStatusTip(tr("Closes this window"));
    connect (act_close, SIGNAL(triggered()), this, SLOT(close()));

    act_exit = new QAction (tr("E&xit"), this);
    act_exit->setIcon(QIcon(":/images/exit.png"));
    act_exit->setShortcut(tr("Ctrl+Q"));
    act_exit->setStatusTip(tr("Exits the application"));
    connect (act_exit, SIGNAL(triggered()), qApp, SLOT(closeAllWindows()));

    // EDIT MENU
    act_cut = new QAction (tr("&Cut"), this);
    act_cut->setIcon(QIcon(":/images/cut.png"));
    act_cut->setShortcut(QKeySequence::Cut);
    act_cut->setStatusTip(tr("Cuts selected data"));
    connect (act_cut, SIGNAL(triggered()), spreadsheet, SLOT(cut()));

    act_copy = new QAction (tr("Cop&y"), this);
    act_copy->setIcon(QIcon(":/images/copy.png"));
    act_copy->setShortcut(QKeySequence::Copy);
    act_copy->setStatusTip(tr("Copies selected data"));
    connect (act_copy, SIGNAL(triggered()), spreadsheet, SLOT(copy()));

    act_paste = new QAction (tr("&Paste"), this);
    act_paste->setIcon(QIcon(":/images/paste.png"));
    act_paste->setShortcut(QKeySequence::Paste);
    act_paste->setStatusTip(tr("Pastes selected data"));
    connect (act_paste, SIGNAL(triggered()), spreadsheet, SLOT(paste()));

    act_delete = new QAction (tr("&Delete"), this);
    act_delete->setIcon(QIcon(":/images/delete.png"));
    act_delete->setShortcut(QKeySequence::Delete);
    act_delete->setStatusTip(tr("Deletes selected data"));
    connect (act_delete, SIGNAL(triggered()), spreadsheet, SLOT(del()));

    act_selectRow = new QAction (tr("Select &row"), this);
    act_selectRow->setStatusTip(tr("Selects all the cells in the current row"));
    connect (act_selectRow, SIGNAL(triggered()), spreadsheet, SLOT(selectCurrentRow()));

    act_selectColumn = new QAction (tr("Select c&olumn"), this);
    act_selectColumn->setStatusTip(tr("Selects all the cells in the current column"));
    connect (act_selectColumn, SIGNAL(triggered()), spreadsheet, SLOT(selectCurrentColumn()));

    act_selectAll = new QAction (tr("&All"), this);
    act_selectAll->setShortcut(QKeySequence::SelectAll);
    act_selectAll->setStatusTip(tr("Selects all the cells in the spreadsheet"));
    connect (act_selectAll, SIGNAL(triggered()), spreadsheet, SLOT(selectAll()));

    act_find = new QAction (tr("&Find"), this);
    act_find->setIcon(QIcon(":/images/find.png"));
    act_find->setShortcut(QKeySequence::Find);
    act_find->setStatusTip(tr("Finds cell with the chosen text"));
    connect (act_find, SIGNAL(triggered()), this, SLOT(find()));

    act_gotocell = new QAction (tr("&Go to cell"), this);
    act_gotocell->setIcon(QIcon(":/images/gotocell.png"));
    act_gotocell->setShortcut(tr("Ctrl+Alt+G"));
    act_gotocell->setStatusTip(tr("Goes to the chosen cell"));
    connect (act_gotocell, SIGNAL(triggered()), this, SLOT(gotocell()));

    // TOOLS MENU
    act_font = new QAction (tr("Choose &font"), this);
    act_font->setIcon(QIcon(":/images/font.png"));
    act_font->setShortcut(tr("Ctrl+Alt+F"));
    act_font->setStatusTip(tr("Sets chosen font as selected text font"));
    connect (act_font, SIGNAL(triggered()), this, SLOT(on_choose_font()));

    act_foreground_color = new QAction (tr("Choose &text color"), this);
    act_foreground_color->setObjectName("Foreground Tool");
    act_foreground_color->setIcon(QIcon(":/images/foreground_color.png"));
    act_foreground_color->setShortcut(tr("Ctrl+Alt+T"));
    act_foreground_color->setStatusTip(tr("Sets chosen color as selected text color"));
    connect (act_foreground_color, SIGNAL(triggered()), this, SLOT(on_choose_color()));

    act_background_color = new QAction (tr("Choose &background color"), this);
    act_background_color->setObjectName("Background Tool");
    act_background_color->setIcon(QIcon(":/images/background_color.png"));
    act_background_color->setShortcut(tr("Ctrl+Alt+B"));
    act_background_color->setStatusTip(tr("Sets chosen color as selected cells background"));
    connect (act_background_color, SIGNAL(triggered()), this, SLOT(on_choose_color()));

    act_align_left = new QAction (tr("Align &left"), this);
    act_align_left->setObjectName("Align Left");
    act_align_left->setIcon(QIcon(":/images/align_left.png"));
    act_align_left->setStatusTip(tr("Alings selected text to the left side"));
    connect (act_align_left, SIGNAL(triggered()), this, SLOT(on_align()));

    act_align_center = new QAction (tr("Align &center"), this);
    act_align_center->setObjectName("Align Center");
    act_align_center->setIcon(QIcon(":/images/align_center.png"));
    act_align_center->setStatusTip(tr("Alings selected text to center"));
    connect (act_align_center, SIGNAL(triggered()), this, SLOT(on_align()));

    act_align_right = new QAction (tr("Align r&ight"), this);
    act_align_right->setObjectName("Align Right");
    act_align_right->setIcon(QIcon(":/images/align_right.png"));
    act_align_right->setStatusTip(tr("Alings selected text to the right side"));
    connect (act_align_right, SIGNAL(triggered()), this, SLOT(on_align()));

    act_recalculate = new QAction (tr("&Recalculate"), this);
    act_recalculate->setIcon(QIcon(":/images/recalculate.png"));
    act_recalculate->setShortcut(tr("Ctrl+Alt+R"));
    act_recalculate->setStatusTip(tr("Recalculates all formulas in the spreadsheet"));
    connect (act_recalculate, SIGNAL(triggered()), spreadsheet, SLOT(recalculate()));

    act_sort = new QAction (tr("&Sort"), this);
    act_sort->setIcon(QIcon(":/images/sort.png"));
    act_sort->setShortcut(tr("Ctrl+Alt+S"));
    act_sort->setStatusTip(tr("Sorts data in the selected region of the spreadsheet"));
    connect (act_sort, SIGNAL(triggered()), this, SLOT(sort()));

    // OPTIONS MENU
    act_showGrid = new QAction (tr("&Show Grid"), this);
    act_showGrid->setCheckable(true);
    act_showGrid->setChecked(spreadsheet->showGrid());
    act_showGrid->setStatusTip(tr("Shows or hides the spreadsheets grid"));
    connect (act_showGrid, SIGNAL(toggled(bool)), spreadsheet, SLOT(setShowGrid(bool)));

    act_autoRecalculation = new QAction (tr("&Auto recalculation"), this);
    act_autoRecalculation->setCheckable(true);
    act_autoRecalculation->setChecked(spreadsheet->autoRecalculate());
    act_autoRecalculation->setStatusTip(tr("Switches auto recalculation hint"));
    connect (act_autoRecalculation, SIGNAL(toggled(bool)), spreadsheet, SLOT(setAutoRecalculation(bool)));

    // OPTIONS MENU : STYLES
    foreach (QString stylename, styles_names)
    {
        act_styles.append(new QAction (stylename, this));
        act_styles.last()->setObjectName(stylename);
        act_styles.last()->setStatusTip("Sets the " + stylename + " style for applications' windows");
        connect (act_styles.last(), SIGNAL(triggered()), this, SLOT(setStyle()));
    }

    act_simpleStyle = new QAction (tr("simple"), this);
    act_simpleStyle->setObjectName("simple");
    act_simpleStyle->setStatusTip(tr("Sets the simple style for applications' windows"));
    connect (act_simpleStyle, SIGNAL(triggered()), this, SLOT(setStyle()));
    act_styles.append(act_simpleStyle);

    // HELP MENU
    act_about = new QAction (tr("&About"), this);
    act_about->setIcon(QIcon(":/images/icon.png"));
    act_about->setStatusTip(tr("Shows the XCel Aout box"));
    connect (act_about, SIGNAL(triggered()), this, SLOT(about()));

    act_aboutQT = new QAction (tr("About &QT"), this);
    act_aboutQT->setIcon(QIcon(":/images/qt.png"));
    act_aboutQT->setStatusTip(tr("Shows the Qt library's About box"));
    connect (act_aboutQT, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
}

void MainWindow::createMenus()
{
    menu_file = menuBar()->addMenu(tr("&File"));
    menu_file->addAction(act_new);
    menu_file->addAction(act_open);
    menu_file->addAction(act_save);
    menu_file->addAction(act_save_as);
    act_separator = menu_file->addSeparator();
    for (int i = 0; i < MaxRecentFiles; ++i)
        menu_file->addAction(act_recent_files[i]);
    menu_file->addSeparator();
    menu_file->addAction(act_close);
    menu_file->addAction(act_exit);

    menu_edit = menuBar()->addMenu(tr("&Edit"));
    menu_edit->addAction(act_cut);
    menu_edit->addAction(act_copy);
    menu_edit->addAction(act_paste);
    menu_edit->addAction(act_delete);
    menu_edit_select = menu_edit->addMenu(tr("Select"));
    menu_edit_select->addAction(act_selectRow);
    menu_edit_select->addAction(act_selectColumn);
    menu_edit_select->addAction(act_selectAll);
    menu_edit->addSeparator();
    menu_edit->addAction(act_find);
    menu_edit->addAction(act_gotocell);

    menu_tools = menuBar()->addMenu(tr("&Tools"));
    menu_tools->addAction(act_background_color);
    menu_tools->addAction(act_foreground_color);
    menu_tools->addSeparator();
    menu_tools->addAction(act_font);
    menu_tools->addSeparator();
    menu_tools->addAction(act_recalculate);
    menu_tools->addAction(act_sort);

    menu_options = menuBar()->addMenu(tr("&Options"));
    menu_options_styles = menu_options->addMenu(tr("Styles"));
    foreach (QAction* act_style, act_styles)
        menu_options_styles->addAction(act_style);
    menu_options_styles->addAction(act_simpleStyle);
    menu_options->addAction(act_showGrid);
    menu_options->addAction(act_autoRecalculation);

    menuBar()->addSeparator();

    menu_help = menuBar()->addMenu(tr("&Help"));
    menu_help->addAction(act_about);
    menu_help->addAction(act_aboutQT);
}

void MainWindow::contextMenuEvent(QContextMenuEvent *ev)
{
    menu_context->exec(ev->globalPos());
}

void MainWindow::createContextMenu()
{
    menu_context = new QMenu;
    menu_context->addMenu(menu_edit);
    menu_context->addMenu(menu_tools);
    menu_context->addMenu(menu_options);
}

void MainWindow::createToolbars()
{
    tb_file = addToolBar(tr("&File"));
    tb_file->setIconSize(QSize(32, 32));
    tb_file->setStatusTip(tr("File toolbar"));
    tb_file->addAction(act_new);
    tb_file->addAction(act_open);
    tb_file->addAction(act_save);

    tb_edit = addToolBar(tr("&Edit"));
    tb_edit->setIconSize(QSize(32, 32));
    tb_edit->setStatusTip(tr("Edit toolbar"));
    tb_edit->addAction(act_cut);
    tb_edit->addAction(act_copy);
    tb_edit->addAction(act_paste);
    tb_edit->addSeparator();
    tb_edit->addAction(act_find);
    tb_edit->addAction(act_gotocell);

    le_celldata = new QLineEdit (this);
    connect(le_celldata, SIGNAL(textChanged(QString)), this, SLOT(on_celldata_textChanged(QString)));
    connect(spreadsheet, SIGNAL(cellChosen(QString)), this, SLOT(on_cellChosen(QString)));

    tb_cell = addToolBar(tr("&Cell"));
    tb_cell->setIconSize(QSize(32, 32));
    tb_cell->setStatusTip(tr("Cell toolbar"));
    tb_cell->addWidget(le_celldata);
    tb_cell->addSeparator();
    tb_cell->addAction(act_background_color);
    tb_cell->addAction(act_foreground_color);
    tb_cell->addSeparator();
    tb_cell->addAction(act_align_left);
    tb_cell->addAction(act_align_center);
    tb_cell->addAction(act_align_right);
    tb_cell->addSeparator();
    tb_cell->addAction(act_font);
}

void MainWindow::createStatusbar()
{
    lbl_location = new QLabel (" W999 ");
    lbl_location->setAlignment(Qt::AlignHCenter);
    lbl_location->setMinimumSize(lbl_location->sizeHint());

    lbl_formula = new QLabel;
    lbl_formula->setIndent(3);

    statusBar()->addWidget(lbl_location);
    statusBar()->addWidget(lbl_formula, 1);

    connect(spreadsheet, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(on_cellChanged()));
    connect(spreadsheet, SIGNAL(modified()), this, SLOT(on_spreadsheet_modified()));

    update_statusbar();
}

void MainWindow::update_statusbar()
{
    lbl_location->setText(spreadsheet->currentLocation());
    lbl_formula->setText(spreadsheet->currentFormula());
}

void MainWindow::on_spreadsheet_modified()
{
    setWindowModified(true);
    update_statusbar();
}

// File menu
bool MainWindow::ok_to_continue()
{
    if (isWindowModified())
    {
        int answer = QMessageBox::warning(this,
                                          tr("XCel"),
                                          tr("The document has been modified. \n Do you want to save changes?"),
                                          QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);

        if (answer == QMessageBox::Yes)
            return save();
        else if (answer == QMessageBox::Cancel)
            return false;
    }

    return true;
}

void MainWindow::new_file()
{
    MainWindow* main_wnd = new MainWindow;
    main_wnd->show();
}

void MainWindow::open()
{
    if (ok_to_continue())
    {
        QString filename = QFileDialog::getOpenFileName(this,
                                                        tr("Open XCel file"),
                                                        ".",
                                                        tr("Spreadsheet files (*.sp)"));

        if (!filename.isEmpty())
            loadFile(filename);
    }
}

bool MainWindow::save()
{
    if (current_file.isEmpty())
        return save_as();
    else
        return saveFile (current_file);
}

bool MainWindow::save_as()
{
    QString filename = QFileDialog::getSaveFileName(this,
                                                    tr("Save XCel file"),
                                                    ".",
                                                    tr("Spreadsheet files (*.sp)"));

    if (filename.isEmpty())
        return false;
    else
        return saveFile(filename);
}

bool MainWindow::saveFile(const QString &filename)
{
    if (!spreadsheet->writeFile(filename))
    {
        statusBar()->showMessage(tr("Saving canceled"), 2000);
        return false;
    }

    setCurrentFile(filename);
    statusBar()->showMessage(tr("File saved"), 2000);
    return true;
}

bool MainWindow::loadFile(const QString &filename)
{
    if (!spreadsheet->readFile(filename))
    {
        statusBar()->showMessage(tr("Loading canceled"), 2000);
        return false;
    }

    setCurrentFile(filename);
    statusBar()->showMessage(tr("File loaded"), 2000);
    return true;
}

QString MainWindow::stripped_name(const QString &full_name)
{
    return QFileInfo(full_name).fileName();
}

void MainWindow::setCurrentFile(const QString &filename)
{
    current_file = filename;
    setWindowModified(false);

    QString shown_name = "Untitled";
    if (!current_file.isEmpty())
    {
        shown_name = stripped_name(current_file);
        recent_files.removeAll(current_file);
        recent_files.prepend(current_file);
        mdi_update_recent_fileactions();
    }

    setWindowTitle(tr("%1[*] ~ %2").arg(shown_name).arg(tr("XCel")));
}

void MainWindow::mdi_update_recent_fileactions ()
{
    foreach (QWidget* window, QApplication::topLevelWidgets())
        if (MainWindow *main_wnd = qobject_cast<MainWindow*>(window))
            main_wnd->update_recent_fileactions();
}

void MainWindow::update_recent_fileactions()
{
    QMutableStringListIterator it (recent_files);
    while (it.hasNext())
    {
        if (!QFile::exists(it.next()))
            it.remove();
    }

    for (int i = 0; i < MaxRecentFiles; ++i)
    {
        if (i < recent_files.count())
        {
            QString text = tr ("&%1 %2").arg(i + 1).arg(stripped_name(recent_files[i]));

            act_recent_files[i]->setText(text);
            act_recent_files[i]->setData(recent_files[i]);
            act_recent_files[i]->setVisible(true);
        }
        else
            act_recent_files[i]->setVisible(false);
    }

    act_separator->setVisible(!recent_files.isEmpty());
}

void MainWindow::open_recent_file()
{
    if (ok_to_continue())
    {
        QAction *action = qobject_cast<QAction*> (sender());
        if (action)
            loadFile(action->data().toString());
    }
}

void MainWindow::find()
{
    if (!finddialog)
    {
        finddialog = new FindDialog (this);
        connect (finddialog, SIGNAL(findNext(const QString&, Qt::CaseSensitivity)),
                 spreadsheet, SLOT(findNext(const QString&, Qt::CaseSensitivity)));
        connect (finddialog, SIGNAL(findPrevious(const QString&, Qt::CaseSensitivity)),
                 spreadsheet, SLOT(findPrevious(const QString&, Qt::CaseSensitivity)));
    }

    finddialog->show();
    finddialog->raise();
    finddialog->activateWindow();
}

void MainWindow::gotocell()
{
    GoToCellDialog dialog (this);
    if (dialog.exec())
    {
        QString str = dialog.getLocationLinedit()->text().toUpper();
        spreadsheet->setCurrentCell(str.mid(1).toInt() - 1, str[0].unicode() - 'A');
    }
}

void MainWindow::sort()
{
    SortDialog dialog (this);

    QTableWidgetSelectionRange range = spreadsheet->selectedRange();
    dialog.setColumnRange('A' + range.leftColumn(), 'A' + range.rightColumn());

    if (dialog.exec())
    {
        SpreadsheetCompare compare;
        compare.iKeys[0] = dialog.cb_primary_column->currentIndex();
        compare.iKeys[1] = dialog.cb_secondary_column->currentIndex() - 1;
        compare.iKeys[2] = dialog.cb_tertiary_column->currentIndex() - 1;

        compare.isAscending[0] = (dialog.cb_primary_order->currentIndex() == 0);
        compare.isAscending[1] = (dialog.cb_secondary_order->currentIndex() == 0);
        compare.isAscending[2] = (dialog.cb_tertiary_order->currentIndex() == 0);

        spreadsheet->sort(compare);
    }
}

void MainWindow::on_cellChanged()
{
    Cell* current_cell = static_cast<Cell*>(spreadsheet->currentItem());

    if (current_cell)
        le_celldata->setText(current_cell->formula());
    else
        le_celldata->setText("");

    update_statusbar();
}

void MainWindow::setStyle()
{
    QString style = (qobject_cast<QAction*>(sender()))->objectName();

    int iIndex = styles_names.indexOf(QRegExp(style));
    if (iIndex != -1)
        setStyleSheet(styles_sheets.at(iIndex));
    else if (style == "simple")
        setStyleSheet ("");
}

void MainWindow::on_cellChosen(QString what_cell)
{
    le_celldata->insert(what_cell);
}

void MainWindow::on_celldata_textChanged(QString formula)
{
    Cell *current_cell = static_cast<Cell*>(spreadsheet->currentItem());

    if (current_cell)
        current_cell->setFormula(formula);
    else
    {
        Cell *new_cell = new Cell;
        spreadsheet->setItem(spreadsheet->currentRow(), spreadsheet->currentColumn(), new_cell);
        new_cell->setFormula(formula);
    }

    spreadsheet->recalculate();
    update_statusbar();
}

void MainWindow::on_choose_color()
{
    if (!dlg_color)
        dlg_color = new QColorDialog (this);

    if (sender()->objectName() == "Foreground Tool")
    {
        disconnect (dlg_color, SIGNAL(colorSelected(QColor)), this, SLOT(set_background_color(QColor)));
        connect (dlg_color, SIGNAL(colorSelected(QColor)), this, SLOT(set_foreground_color(QColor)));
    }
    else if (sender()->objectName() == "Background Tool")
    {
        disconnect (dlg_color, SIGNAL(colorSelected(QColor)), this, SLOT(set_foreground_color(QColor)));
        connect (dlg_color, SIGNAL(colorSelected(QColor)), this, SLOT(set_background_color(QColor)));
    }

    dlg_color->show();
    dlg_color->raise();
}

void MainWindow::on_choose_font()
{
    if (!dlg_font)
    {
        dlg_font = new QFontDialog (this);
        connect (dlg_font, SIGNAL(currentFontChanged(QFont)), this, SLOT(set_items_font(QFont)));
    }

    dlg_font->show();
    dlg_font->raise();
}

void MainWindow::set_items_font (QFont what)
{
    QList<QTableWidgetItem*> selection = spreadsheet->selectedItems();
    foreach(QTableWidgetItem* item, selection)
        item->setFont(what);
}

void MainWindow::on_align()
{
    QList<QTableWidgetItem*> selection = spreadsheet->selectedItems();

    if (sender()->objectName() == "Align Left")
    {
        foreach(QTableWidgetItem* item, selection)
            item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    }

    if (sender()->objectName() == "Align Center")
    {
        foreach(QTableWidgetItem* item, selection)
            item->setTextAlignment(Qt::AlignCenter);
    }

    if (sender()->objectName() == "Align Right")
    {
        foreach(QTableWidgetItem* item, selection)
            item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
    }
}


void MainWindow::set_foreground_color (QColor what)
{
    QList<QTableWidgetItem*> selection = spreadsheet->selectedItems();
    foreach(QTableWidgetItem* item, selection)
        item->setForeground(what);
}

void MainWindow::set_background_color (QColor what)
{
    QList<QTableWidgetItem*> selection = spreadsheet->selectedItems();
    foreach(QTableWidgetItem* item, selection)
        item->setBackground(what);
}

void MainWindow::about()
{
    QMessageBox::about(this,
                       tr("About XCel"),
                       tr("<H2>XCel 0.8alpha </H2>"
                          "<p>Copyright Zamana\'s, 2015 Zoftware Inc."));
}

void MainWindow::saveSettings()
{
    QSettings settings ("Software Inc.", "XCel");
    settings.setValue("geometry", saveGeometry());
    settings.setValue("recent_files", recent_files);
    settings.setValue("show_grid", act_showGrid->isChecked());
    settings.setValue("auto_recalculation", act_autoRecalculation->isChecked());
}

void MainWindow::loadSettings()
{
    QSettings settings ("Software Inc.", "XCel");

    restoreGeometry(settings.value("geometry").toByteArray());
    recent_files = settings.value("recent_files").toStringList();
    mdi_update_recent_fileactions();

    act_showGrid->setChecked(settings.value("show_grid", true).toBool());
    act_autoRecalculation->setChecked(settings.value("auto_recalculation", true).toBool());
}

QString MainWindow::style_name (const QString& filename)
{
    QString style_name = filename;
    style_name.replace("style_", "");
    style_name.replace(".qss", "");

    return style_name;
}

void MainWindow::loadStylesheets()
{
    QDir dir(QApplication::applicationDirPath() + "/styles");
    QStringList files = dir.entryList(QStringList("*.qss"));

    foreach (QString filename, files)
    {
        QFile file (dir.absoluteFilePath(filename));
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            styles_sheets.append(file.readAll());
            styles_names.append(style_name(filename));
        }
        file.close();
    }
}
