#ifndef FINDDIALOG_H
#define FINDDIALOG_H

#include <QDialog>

class QCheckBox;
class QLabel;
class QLineEdit;
class QPushButton;

class FindDialog : public QDialog
{
    Q_OBJECT

public:
    FindDialog(QWidget* parent = 0) : QDialog (parent)
    {
        createWidgets();
        initLayout();
    }

    ~FindDialog()
    {

    }

private:
    void createWidgets ();
    void initLayout ();

    QLabel *label;
    QLineEdit *lineedit;
    QCheckBox *cb_case, *cb_backward;
    QPushButton *pb_find, *pb_close;


signals:
    void findNext (const QString& string, Qt::CaseSensitivity cs);
    void findPrevious (const QString& string, Qt::CaseSensitivity cs);

private slots:
    void onFindClicked ();
    void enableFindButton (const QString& text);
};

#endif // FINDDIALOG_H
