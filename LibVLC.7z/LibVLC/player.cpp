// Core
#include <vlc-qt/Common.h>
#include <vlc-qt/Instance.h>

// Player
#include <vlc-qt/Audio.h>
#include <vlc-qt/Video.h>
#include <vlc-qt/Media.h>
#include <vlc-qt/MediaPlayer.h>

// Playlist
#include "playlistmodel.h"
#include "playlistview.h"

// Widgets
#include <vlc-qt/WidgetVolumeSlider.h>
#include <vlc-qt/WidgetSeek.h>
#include "videowidget.h"
#include <QPushButton>
#include "equalizer.h"
#include <QGridLayout>

// Events
#include <QMouseEvent>

#include "player.h"
Player::Player(QWidget *parent)
    : QWidget(parent)
{
    // core
    m_instance = new VlcInstance(VlcCommon::args(), this);
    m_player = new VlcMediaPlayer(m_instance);


    // playlist
    m_playlist = new QMediaPlaylist(this);
    m_playlist->addMedia(QUrl::fromLocalFile("d:/pit.flv"));
    m_playlist->addMedia(QUrl::fromLocalFile("d:/video.avi"));
    m_playlist->addMedia(QUrl("http://89.105.158.158:80/udp/239.255.1.7:1234"));

    m_playlist_model = new PlaylistModel(this);
    m_playlist_model->setPlaylist(m_playlist);

    m_playlist_view = new PlaylistView;
    m_playlist_view->setModel(m_playlist_model);
    connect (m_playlist_view, SIGNAL(signalSendUrls(QStringList)), this, SLOT(onMediaAdded(QStringList)));
    connect (m_playlist_view, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(onMediaChanged(QModelIndex)));
    connect (m_playlist_view, SIGNAL(swapIndexes(QModelIndex,QModelIndex)), m_playlist_model, SLOT(swapIndexes(QModelIndex,QModelIndex)));

    // videowidget
    m_videowidget = new VideoWidget(m_player, this);
    m_player->setVideoWidget(m_videowidget);
    connect (m_player, SIGNAL(playing()), m_videowidget, SLOT(onMediaChanged()));
    connect(m_videowidget, SIGNAL(togglePause()), this, SLOT(onTogglePause()));
    connect(m_videowidget, SIGNAL(showPlaylist()), this, SLOT(onTogglePlaylist()));

    // seekwidget
    m_seekwidget = new VlcWidgetSeek(m_player, this);
    connect (m_player, SIGNAL(lengthChanged(int)), m_seekwidget, SLOT(updateFullTime(int)));
    connect (m_player, SIGNAL(timeChanged(int)), m_seekwidget, SLOT(updateCurrentTime(int)));

    // volumewidget
    m_volumewidget = new VlcWidgetVolumeSlider (m_player, this);
    m_volumewidget->setOrientation(Qt::Horizontal);
    m_volumewidget->setValue(m_player->audio()->volume());
    connect (m_videowidget, SIGNAL(signalChangeVolume(bool)), this, SLOT(onVolumeChanged(bool)));
    connect (m_volumewidget, SIGNAL(sliderMoved(int)), m_player->audio(), SLOT(setVolume(int)));
    // connect (m_volumewidget, SIGNAL(valueChanged(int)), m_player->audio(), SLOT(setVolume(int)));
    connect (m_volumewidget, &VlcWidgetVolumeSlider::valueChanged, this, [=](int value){m_player->audio()->setVolume(value);});

    // equalizer
    m_equalizer = nullptr;
    pb_toggle_equalizer = new QPushButton(tr("Еквалайзер"), this);
    pb_toggle_equalizer->setCheckable(true);
    connect(pb_toggle_equalizer, SIGNAL(toggled(bool)), this, SLOT(onToggleEqualizer(bool)));


    // layout
    m_layout = new QGridLayout (this);
    m_layout->setColumnStretch(1, 200);
    setLayout(m_layout);

    m_layout->setMargin(0);
    m_layout->addWidget(m_playlist_view, 0, 0, 10, 1);
    m_layout->addWidget(m_videowidget, 0, 1, 9, 10);
    m_layout->addWidget(m_seekwidget, 9, 1, 1, 9);
    m_layout->addWidget(m_volumewidget, 10, 1, 1, 1);
    m_layout->addWidget(pb_toggle_equalizer, 10, 0, 1, 1);
}

Player::~Player()
{
    delete m_playlist_view;
    delete m_playlist_model;
    delete m_playlist;

    delete m_layout;
    delete m_equalizer;
    delete m_seekwidget;
    delete pb_toggle_equalizer;
    m_videowidget->release();

    delete m_player;
    delete m_instance;
}

// slots
void Player::onMediaChanged(const QModelIndex& index)
{
    QMediaContent media = m_playlist->media(index.row());
    bool isLocalFile = media.canonicalUrl().isLocalFile();

    m_player->stop();
    if (isLocalFile)
        m_player->open(new VlcMedia(media.canonicalUrl().path(), isLocalFile, m_instance));
    else
        m_player->open(new VlcMedia(media.canonicalUrl().toString(), isLocalFile, m_instance));    
}

void Player::onMediaAdded(const QStringList& media)
{
    if (media.at(0) == "M3UPlaylist:")
    {
        foreach (QString media_filename, media)
        {
            if (media_filename == "M3UPlaylist:")
                continue;

            QStringList media_to_add = media_filename.split("-,-");

            QNetworkRequest request;
            request.setHeader(QNetworkRequest::ContentDispositionHeader, media_to_add.at(0));
            request.setUrl(media_to_add.at(1));

            m_playlist->addMedia(QMediaContent(request));
        }
    }
    else
    {
        foreach (QString media_filename, media)
            m_playlist->addMedia(QUrl::fromLocalFile(media_filename));
    }
}

void Player::onVolumeChanged(bool isIncreasing)
{
    if (isIncreasing)
        m_player->audio()->setVolume(m_player->audio()->volume() + 1);
    else
        m_player->audio()->setVolume(m_player->audio()->volume() - 1);

    m_volumewidget->setValue(m_player->audio()->volume());
}

void Player::onToggleEqualizer(bool isVisible)
{
    if (!m_equalizer)
        m_equalizer = new Equalizer(m_player, this);

    if (isVisible)
    {
        m_equalizer->show();
        m_equalizer->raise();
    }
    else
        m_equalizer->hide();
}

void Player::onTogglePlaylist()
{
    if (!m_playlist_view->isVisible() && !m_videowidget->isFullScreen())
    {
        m_layout->removeWidget(m_videowidget);
        m_layout->removeWidget(m_playlist_view);
        m_layout->addWidget(m_playlist_view, 0, 0, 10, 1);
        m_layout->addWidget(m_videowidget, 0, 1, 9, 10);
        m_layout->addWidget(m_seekwidget, 9, 1, 1, 9);

        m_playlist_view->setVisible(true);
    }
    else
    {
        m_layout->removeWidget(m_videowidget);
        m_layout->removeWidget(m_seekwidget);
        m_layout->addWidget(m_videowidget, 0, 0, 9, 10);
        m_layout->addWidget(m_seekwidget, 9, 0, 1, 10);

        m_playlist_view->setVisible(false);
    }
}

void Player::onTogglePause()
{
    if (m_player->state() == Vlc::Playing)
        m_player->pause();
    else
        m_player->play();

}

