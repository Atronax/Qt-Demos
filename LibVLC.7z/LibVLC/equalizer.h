/*
* VLC-Qt Simple Player
* Copyright (C) 2015 Tadej Novak <tadej@tano.si>
*/

#ifndef EQUALIZER_H
#define EQUALIZER_H

class VlcMediaPlayer;

#include <QDialog>
#include "ui_Equalizer.h"
class Equalizer : public QDialog, Ui::Equalizer
{
    Q_OBJECT

public:
    explicit Equalizer(VlcMediaPlayer *mediaplayer, QWidget *parent = 0);

private:
    void makeBands();
    void setupEqualizer(VlcMediaPlayer *mediaplayer);
    void setupSliderUnits();

    QMap<QSlider*, int> m_bands;
    VlcMediaPlayer *m_mediaPlayer;

public slots:
    void applyChangesForBand(int value);
    void applySelectedPreset();
    void toggle(bool checked);


};

#endif // EQUALIZER_H
