#ifndef VIDEOWIDGET_H
#define VIDEOWIDGET_H

class QMenu;
class QKeyEvent;
class QMouseEvent;
class QWheelEvent;
class VlcMediaPlayer;

#include <vlc-qt/WidgetVideo.h>
class VideoWidget : public VlcWidgetVideo
{
    Q_OBJECT
public:
    explicit VideoWidget(VlcMediaPlayer* player, QWidget *parent = nullptr);
    ~VideoWidget();

protected:
    virtual void keyPressEvent (QKeyEvent *ev);
    virtual void mousePressEvent(QMouseEvent *ev);
    virtual void mouseDoubleClickEvent (QMouseEvent *ev);
    virtual void wheelEvent(QWheelEvent *ev);

    virtual void contextMenuEvent(QContextMenuEvent *ev);
    virtual void closeEvent(QCloseEvent *ev);

private:
    void updateAudioTrackMenu();
    void updateVideoTrackMenu();
    void updateSubtitleTrackMenu();

    VlcMediaPlayer *m_player;

    QMenu *context_menu,
          *cm_aspectRatio, *cm_audioTracks, *cm_videoTracks, *cm_subtitleTracks;

signals:
    void togglePause();
    void showPlaylist();
    void signalChangeVolume(bool isAdding);

public slots:
    void slotSetAspectRatio();

    void onMediaChanged();
    void slotSetAudioTrack();
    void slotSetVideoTrack();
    void slotSetSubtitleTrack();
    void slotSetSubtitleFromFile();

};

#endif // VIDEOWIDGET_H
