/*
* VLC-Qt Simple Player
* Copyright (C) 2015 Tadej Novak <tadej@tano.si>
*/

#include <vlc-qt/Audio.h>
#include <vlc-qt/Equalizer.h>
#include <vlc-qt/MediaPlayer.h>

#include "equalizer.h"
Equalizer::Equalizer(VlcMediaPlayer *mediaPlayer, QWidget *parent)
    : QDialog (parent)
{
    setupUi(this);

    makeBands();
    setupEqualizer(mediaPlayer);
    setupSliderUnits();
}

void Equalizer::makeBands()
{
    // Default equalizer has ten bands
    m_bands.insert(firstBand, 0);
    m_bands.insert(secondBand, 1);
    m_bands.insert(thirdBand, 2);
    m_bands.insert(fourthBand, 3);
    m_bands.insert(fifthBand, 4);
    m_bands.insert(sixthBand, 5);
    m_bands.insert(seventhBand, 6);
    m_bands.insert(eighthBand, 7);
    m_bands.insert(ninethBand, 8);
    m_bands.insert(tenthBand, 9);
}

void Equalizer::setupEqualizer(VlcMediaPlayer *mediaplayer)
{
    // Setup equalizer
    m_mediaPlayer = mediaplayer;
    auto equalizer = m_mediaPlayer->equalizer();
    for (uint i = 0; i < equalizer->presetCount(); ++i)
        presetComboBox->addItem(equalizer->presetNameAt(i));

    connect(presetComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), m_mediaPlayer->equalizer(), &VlcEqualizer::loadFromPreset);
    connect(m_mediaPlayer->equalizer(), &VlcEqualizer::presetLoaded, this, &Equalizer::applySelectedPreset);

    connect(preamp, &QSlider::valueChanged, equalizer, &VlcEqualizer::setPreamplification);
    foreach (QSlider *slider, findChildren<QSlider*>())
    {
        if (slider != preamp)
            connect(slider, &QSlider::valueChanged, this, &Equalizer::applyChangesForBand);
    }
}

void Equalizer::setupSliderUnits()
{
    // Set sliders value with unit
    foreach (QSlider *slider, findChildren<QSlider*>())
    {
        QLabel *valueLabel = findChild<QLabel*>(slider->objectName() + "Label");
        connect(slider, &QSlider::valueChanged, this, [=](int value) {valueLabel->setText(QString::number(value) + " dB");});
    }

    connect(toggleEqualizer, &QCheckBox::toggled, this, &Equalizer::toggle);
}

// slots
void Equalizer::applyChangesForBand(int value)
{
    int bandIndex = m_bands.value(static_cast<QSlider*>(sender()));
    m_mediaPlayer->equalizer()->setAmplificationForBandAt(static_cast<float>(value), bandIndex);
}

void Equalizer::applySelectedPreset()
{
    auto equalizer = m_mediaPlayer->equalizer();

    disconnect(preamp, 0, equalizer, 0);
    foreach (QSlider *slider, findChildren<QSlider*>())
    {
        if (slider == preamp)
            slider->setValue(equalizer->preamplification());
        else
            slider->setValue(equalizer->amplificationForBandAt(m_bands.value(slider)));
    }
    connect(preamp, &QSlider::valueChanged, equalizer, &VlcEqualizer::setPreamplification);
}

void Equalizer::toggle(bool checked)
{
    foreach (QSlider *slider, findChildren<QSlider*>())
        slider->setEnabled(checked);

    presetComboBox->setEnabled(checked);
    m_mediaPlayer->equalizer()->setEnabled(checked);
}

