#ifndef PLAYER_H
#define PLAYER_H

// core
class VlcInstance;
class VlcMediaPlayer;

// playlist
#include <QMediaContent>
class QMediaPlaylist;
class PlaylistModel;
class PlaylistView;

// widgets
class VideoWidget;
class VlcWidgetSeek;
class VlcWidgetVolumeSlider;
class QPushButton;
class Equalizer;
class QGridLayout;

// events
class QMouseEvent;

#include <QWidget>
class Player: public QWidget
{
    Q_OBJECT
public:
    explicit Player (QWidget* parent = nullptr);
    ~Player();

protected:

private:
    // player
    VlcInstance* m_instance;
    VlcMediaPlayer* m_player;    

    // playlist
    QMediaPlaylist *m_playlist;
    PlaylistModel *m_playlist_model;
    PlaylistView *m_playlist_view;

    // video
    VideoWidget* m_videowidget;
    VlcWidgetSeek* m_seekwidget;
    VlcWidgetVolumeSlider* m_volumewidget;

    // equalizer
    QPushButton *pb_toggle_equalizer;
    Equalizer *m_equalizer;

    // layout
    QGridLayout* m_layout;

signals:

public slots:
    void onMediaChanged(const QModelIndex& index);
    void onMediaAdded(const QStringList& media);

    void onVolumeChanged(bool isIncreasing);

    void onToggleEqualizer(bool isVisible);
    void onTogglePlaylist();
    void onTogglePause();

};

#endif // PLAYER_H
