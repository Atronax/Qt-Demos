#include "m3uparser.h"

M3UParser::M3UParser(const QString &file_to_parse)
{
    to_parse.setFileName(file_to_parse);
    if (!to_parse.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    in.setDevice(&to_parse);
    in.setCodec("Windows-1251");
}

M3UParser::~M3UParser()
{
    to_parse.close();
}

void M3UParser::parseExtendedM3U()
{
    QString line, curr_media;
    QString name_of_channel, url;

    while(!in.atEnd())
    {
        line = in.readLine();
        if (line.startsWith("#EXTINF:"))
        {
            QStringList list = line.split(",");
            name_of_channel = list.at(1); // at (1) - name of channel
            url = in.readLine();

            curr_media = name_of_channel + "-,-" + url;
            media.append(curr_media);
        }
    }
}

void M3UParser::parseSimpleM3U()
{
    in.seek(0);
    while (!in.atEnd())
        media.append(in.readLine());
}

bool M3UParser::isExtended()
{
    QString line = in.readLine();
    if (line.startsWith("#EXTM3U"))
        return true;
    else
        return false;
}

const QStringList& M3UParser::getMedia() const
{
    return media;
}
