// helping includes
#include <QApplication>
#include <QDesktopWidget>
#include <QFileDialog>
#include <QMenu>

#include <vlc-qt/Audio.h>
#include <vlc-qt/Video.h>
#include <vlc-qt/Media.h>
#include <vlc-qt/MediaPlayer.h>

// events
#include <QKeyEvent>
#include <QMouseEvent>
#include <QWheelEvent>

#include "videowidget.h"
VideoWidget::VideoWidget(VlcMediaPlayer* player, QWidget *parent)
    : VlcWidgetVideo(player, parent)
{
    setAttribute(Qt::WA_OpaquePaintEvent);


    m_player = player;

    cm_aspectRatio = new QMenu (tr("Отношение сторон"));
    cm_aspectRatio->addAction(tr("Игнорировать"), this, SLOT(slotSetAspectRatio()));
    cm_aspectRatio->addAction(tr("Стандартный размер"), this, SLOT(slotSetAspectRatio()));

    cm_audioTracks = new QMenu (tr("Звуковые дорожки"));

    cm_videoTracks = new QMenu (tr("Видеодорожки"));

    cm_subtitleTracks = new QMenu (tr("Субтитры"));

    context_menu = new QMenu (this);
    context_menu->addMenu(cm_aspectRatio);
    context_menu->addMenu(cm_audioTracks);
    context_menu->addMenu(cm_videoTracks);
    context_menu->addMenu(cm_subtitleTracks);
}

VideoWidget::~VideoWidget()
{
    delete context_menu;
}

void VideoWidget::keyPressEvent(QKeyEvent *ev)
{
    if (ev->key() == Qt::Key_Space)
        emit togglePause();
}

void VideoWidget::mousePressEvent(QMouseEvent *ev)
{    
    if (ev->button() == Qt::LeftButton)
        emit togglePause();
    if (ev->button() == Qt::MiddleButton)
        emit showPlaylist();
}

void VideoWidget::mouseDoubleClickEvent(QMouseEvent *ev)
{    
    if (ev->button() == Qt::LeftButton)
    {
        setWindowFlags(windowFlags()^Qt::Window);
        showFullScreen();
    }
}

void VideoWidget::wheelEvent(QWheelEvent *ev)
{
    if (ev->angleDelta().ry() > 0)
        emit signalChangeVolume (true);
    if (ev->angleDelta().ry() < 0)
        emit signalChangeVolume (false);
}

void VideoWidget::contextMenuEvent(QContextMenuEvent *ev)
{
    context_menu->exec(ev->globalPos());
}

void VideoWidget::closeEvent(QCloseEvent *ev)
{
    ev->ignore();
}

void VideoWidget::updateAudioTrackMenu()
{
    cm_audioTracks->clear();
    for (int i = 0; i < m_player->audio()->trackIds().size(); ++i)
    {
        QString trackName = m_player->audio()->trackDescription().at(i);
        cm_audioTracks->addAction(trackName, this, SLOT(slotSetAudioTrack()));
    }
}

void VideoWidget::updateVideoTrackMenu()
{
    cm_videoTracks->clear();
    for (int i = 0; i < m_player->video()->trackIds().size(); ++i)
    {
        QString trackName = m_player->video()->trackDescription().at(i);
        cm_videoTracks->addAction(trackName, this, SLOT(slotSetVideoTrack()));
    }
}

void VideoWidget::updateSubtitleTrackMenu()
{
    cm_subtitleTracks->clear();
    qDebug (QString::number(m_player->video()->subtitleCount()).toUtf8());
    if (m_player->video()->subtitleCount() != 0)
    {
        for (int i = 0; i < m_player->video()->subtitleIds().size(); ++i)
        {
            QString trackName  = m_player->video()->subtitleDescription().at(i);
            cm_subtitleTracks->addAction(trackName, this, SLOT(slotSetSubtitleTrack()));
        }
    }
    cm_subtitleTracks->addAction(tr("Из файла: "), this, SLOT(slotSetSubtitleFromFile()));
}

void VideoWidget::slotSetAspectRatio()
{
    QString aspectRatio = ((QAction *) sender())->text();

    if (aspectRatio == tr("Игнорировать"))
    {
        QSize screen_size = qApp->desktop()->screenGeometry().size();
        float ratio = (float)screen_size.width()/(float)screen_size.height();
        if (ratio == 1.0)
            setAspectRatio(Vlc::R_1_1);
        if (ratio == 4.0/3.0)
            setAspectRatio(Vlc::R_4_3);
        if (ratio == 5.0/4.0)
            setAspectRatio(Vlc::R_5_4);
        if (ratio == 16.0/9.0)
            setAspectRatio(Vlc::R_16_9);
    }
    if (aspectRatio == tr("Стандартный размер"))
        setAspectRatio(defaultAspectRatio());
}

void VideoWidget::onMediaChanged()
{
    if (m_player->currentMedia())
    {
         updateAudioTrackMenu();
         updateVideoTrackMenu();
         updateSubtitleTrackMenu();
    }
}

void VideoWidget::slotSetAudioTrack()
{
    if (m_player->currentMedia())
    {
        QString trackName = static_cast<QAction*>(sender())->text();

        int trackID = -1;
        for (int i = 0; i < m_player->audio()->trackDescription().size(); ++i)
        {
            if (m_player->audio()->trackDescription().at(i) == trackName)
                trackID = m_player->audio()->trackIds().at(i);
        }

        m_player->audio()->setTrack(trackID);
    }
}

void VideoWidget::slotSetVideoTrack()
{
    if (m_player->currentMedia())
    {
        QString trackName = static_cast<QAction*>(sender())->text();

        int trackID = -1;
        for (int i = 0; i < m_player->video()->trackDescription().size(); ++i)
        {
            if (m_player->video()->trackDescription().at(i) == trackName)
                trackID = m_player->video()->trackIds().at(i);
        }

        m_player->video()->setTrack(trackID);
    }
}

void VideoWidget::slotSetSubtitleTrack()
{
    if (m_player->currentMedia())
    {
        QString trackName = static_cast<QAction*>(sender())->text();

        int trackID = -1;
        for (int i = 0; i < m_player->video()->subtitleDescription().size(); ++i)
        {
            if (m_player->video()->subtitleDescription().at(i) == trackName)
                trackID = m_player->video()->subtitleIds().at(i);
        }

        m_player->video()->setSubtitle(trackID);
    }
}

void VideoWidget::slotSetSubtitleFromFile()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("Выбор файла субтитров"));
    if (m_player->currentMedia() && !filename.isEmpty())
        m_player->video()->setSubtitleFile(filename);

    updateSubtitleTrackMenu();
}
