#include <QApplication>
#include "player.h"

int main (int argc, char* argv[])
{
    QCoreApplication::setAttribute(Qt::AA_X11InitThreads); // xlibs to be thread-safe
    QApplication app (argc, argv);

    Player *player = new Player;
    player->showMaximized();

    return app.exec();
}
