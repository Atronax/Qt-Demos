#include "wavplayer.h"

QSize WavPlayer::sizeHint() const
{
    return QSize(300, 120);
}

void WavPlayer::slotPlaySound(bool toggled)
{
    if (toggled)
    {
        currentSound->play();
        toggleSound->setText("Wow!!!");
    }
    else
    {
        currentSound->stop();
        toggleSound->setText("Play it!!!");
    }
}

void WavPlayer::slotSetSound()
{
    QString command = ((QLineEdit *) sender())->text();

    if (command == QString("stop"))
    {
        currentSound->stop();
        toggleSound->setText("Play it!!!");
    }
    else
    {
        currentSound->play(command);
        toggleSound->setText("Wow!!!");
    }
}
