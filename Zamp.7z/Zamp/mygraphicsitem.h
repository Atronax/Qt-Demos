#ifndef MYGRAPHICSITEM_H
#define MYGRAPHICSITEM_H

#include <QApplication>
#include <QGraphicsItem>
#include <QPainter>

class MyGraphicsItem : public QGraphicsItem
{
public:
    virtual QRectF boundingRect() const;
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    virtual void mousePressEvent (QGraphicsSceneMouseEvent *ev);
    virtual void mouseReleaseEvent (QGraphicsSceneMouseEvent *ev);

private:
    enum {iPenWidth = 3};
};

#endif // MYGRAPHICSITEM_H
