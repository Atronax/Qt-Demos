#ifndef DRAGDROPDELEGATE_H
#define DRAGDROPDELEGATE_H

#include <QItemDelegate>
#include <QPainter>

class DragDropDelegate: public QItemDelegate
{
public:
    DragDropDelegate (QObject *parent) : QItemDelegate (parent)
    {
        this->
    }
};

#endif // DRAGDROPDELEGATE_H
