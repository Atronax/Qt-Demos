#ifndef MYGRAPHICSVIEW_H
#define MYGRAPHICSVIEW_H

#include <QGraphicsView>

#include <QtMultimedia/QSound>
#include <QtMultimedia/QSoundEffect>

class MyGraphicsView : public QGraphicsView
{
    Q_OBJECT
public:
    MyGraphicsView(QGraphicsScene *scene, QWidget *parent = 0) : QGraphicsView (scene, parent) {}

public slots:
    void slotZoomIn ();
    void slotZoomOut ();
    void slotRotateLeft ();
    void slotRotateRight ();
};

#endif // MYGRAPHICSVIEW_H
