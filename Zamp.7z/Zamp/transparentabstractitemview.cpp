#include "transparentabstractitemview.h"

void TransparentListView::paintEvent(QPaintEvent *ev)
{
    QPainter painter(this->viewport());
    // painter.setBrush(QColor(133, 164, 214,  200));
    // painter.fillRect(ev->rect(), painter.brush());
    painter.setPen(QColor(255, 0, 0,  255));
    painter.setFont(QFont("Tahoma", 20, false, true));

    QListView::paintEvent(ev);
}
