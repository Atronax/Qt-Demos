#ifndef TRANSPARENTLISTVIEW_H
#define TRANSPARENTLISTVIEW_H

#include <QListView>
#include <QPaintEvent>
#include <QPainter>
#include <QPainterPath>

class TransparentListView : public QListView
{
    Q_OBJECT
public:
    TransparentListView(QWidget *parent = 0) : QListView (parent)
    {
        setAttribute(Qt::WA_TranslucentBackground, true);
        setAttribute(Qt::WA_Mapped, true);
        setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnBottomHint);


        QPalette pal = palette();
        pal.setColor(QPalette::Text, Qt::red);
        setPalette(pal);
    }

protected:
    void paintEvent(QPaintEvent *ev);

signals:

public slots:

};

#endif // TRANSPARENTABSTRACTITEMVIEW_H
