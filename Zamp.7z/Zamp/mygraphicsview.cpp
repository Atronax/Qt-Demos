#include "mygraphicsview.h"

void MyGraphicsView::slotZoomIn()
{    
    scale (1.1, 1.1);

    QSound *button_clicked = new QSound("D:/button_clicked.wav", this);
    button_clicked->play();
}

void MyGraphicsView::slotZoomOut()
{
    scale (1/1.1, 1/1.1);

    QSound *button_clicked = new QSound("D:/button_clicked.wav", this);
    button_clicked->play();
}

void MyGraphicsView::slotRotateLeft()
{
    rotate (-5);

    QSound *button_clicked = new QSound("D:/button_clicked.wav", this);
    button_clicked->play();
}

void MyGraphicsView::slotRotateRight()
{
    rotate (5);

    QSound *button_clicked = new QSound("D:/button_clicked.wav", this);
    button_clicked->play();
}
