#include "mygraphicsitem.h"

QRectF MyGraphicsItem::boundingRect() const
{
    QPointF pos (-10 - iPenWidth,  -10 - iPenWidth);
    QSizeF size ( 20 + 2*iPenWidth, 20 + 2*iPenWidth);

    return QRectF (pos, size);
}

void MyGraphicsItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->save();
    painter->setPen(QPen(Qt::blue, iPenWidth));
    painter->drawEllipse(-10,-10,20,20);
    painter->restore();
}

void MyGraphicsItem::mousePressEvent(QGraphicsSceneMouseEvent *ev)
{
    QApplication::setOverrideCursor(Qt::PointingHandCursor);
    QGraphicsItem::mousePressEvent(ev);
}

void MyGraphicsItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *ev)
{
    QApplication::restoreOverrideCursor();
    QGraphicsItem::mouseReleaseEvent(ev);
}
