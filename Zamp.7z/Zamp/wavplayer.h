#ifndef PLAYSOUND_H
#define PLAYSOUND_H

#include <QObject>

#include <QVBoxLayout>

#include <QPushButton>
#include <QLineEdit>
#include <QSound>

class WavPlayer : public QWidget
{
    Q_OBJECT
public:
    WavPlayer(const char *musicPath, QWidget *parent = 0) : QWidget(parent)
    {
          currentSound = new QSound (musicPath);
          currentSound->setLoops(-1);

          toggleSound = new QPushButton (QIcon("D:/sound.png"),"PLAY IT!!!", this);
          toggleSound->setMinimumHeight(40);
          toggleSound->setCheckable(true);          

          lineedit = new QLineEdit (this);
          lineedit->setMinimumHeight(40);

          layout = new QVBoxLayout;
          layout->addWidget(toggleSound);
          layout->setMargin(0);
          layout->addWidget(lineedit);
          setLayout(layout);

          QObject::connect (toggleSound, SIGNAL(toggled(bool)), SLOT(slotPlaySound(bool)));
          QObject::connect (lineedit, SIGNAL(returnPressed()), SLOT(slotSetSound()));

         setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
    }

    ~WavPlayer()
    {
        delete currentSound;
        delete toggleSound;
        delete layout;

        if (this->parent() == 0)
            delete this;
    }

protected:
    virtual QSize sizeHint() const;

private:
    QSound *currentSound;

    QPushButton *toggleSound;
    QLineEdit *lineedit;
    QVBoxLayout *layout;

signals:

public slots:
    void slotPlaySound (bool toggled);
    void slotSetSound ();

};

#endif // PLAYSOUND_H
