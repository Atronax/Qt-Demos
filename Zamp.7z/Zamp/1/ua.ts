<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>VideoPlayer</name>
    <message>
        <location filename="videoplayer.cpp" line="136"/>
        <source>Открыть медиа</source>
        <translation>Відкрити медіа</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="267"/>
        <source>mm мин. ss сек.</source>
        <translation>mm хв. ss сек.</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="269"/>
        <source>hh час. mm мин. ss сек.</source>
        <translation>hh год. mm хв. ss сек.</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="284"/>
        <source>Настройка цветовой гаммы</source>
        <translation>Налаштування палітри кольорів</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="308"/>
        <source>Закрыть</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="314"/>
        <source>Тон</source>
        <translation>Відтінок</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="315"/>
        <source>Насыщенность</source>
        <translation>Насиченість</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="316"/>
        <source>Контраст</source>
        <translation>Яскравість</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="58"/>
        <source>Настроить цветовую гамму</source>
        <translation>Налаштувати палітру кольорів</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="59"/>
        <source>Открыть файл</source>
        <translation>Відкрити файл</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="83"/>
        <source>Плейлист</source>
        <translation>Плейліст</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="94"/>
        <source>Выкл. ПК после завершения</source>
        <translation>Вимкн. ПК після завершення</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="95"/>
        <source>Выйти</source>
        <translation>Вимнути</translation>
    </message>
    <name>VideoWidget</name>
    <message>
        <location filename="videowidget.cpp" line="51"/>
        <source>Расширить до границ</source>
        <translation>Розширити до меж</translation>
    </message>
    <message>
        <location filename="videowidget.cpp" line="53"/>
        <source>Стандартный размер</source>
        <translation>Стандартний розмір</translation>
    </message>
    <message>
        <location filename="videowidget.h" line="23"/>
        <source>Расширить до границ</source>
        <translation>Розширити до меж</translation>
    </message>
    <message>
        <location filename="videowidget.h" line="24"/>
        <source>Стандартный размер</source>
        <translation>Стандартний розмір</translation>
    </message>
</context>
</TS>
