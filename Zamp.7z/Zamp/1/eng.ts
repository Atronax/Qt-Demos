<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>VideoPlayer</name>
    <message>
        <location filename="videoplayer.cpp" line="136"/>
        <source>Открыть медиа</source>
        <translation>Open Media</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="267"/>
        <source>mm мин. ss сек.</source>
        <translation>mm:ss</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="269"/>
        <source>hh час. mm мин. ss сек.</source>
        <translation>hh:mm:ss</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="284"/>
        <source>Настройка цветовой гаммы</source>
        <translation>Parameters of HSV</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="308"/>
        <source>Закрыть</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="314"/>
        <source>Тон</source>
        <translation>Hue</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="315"/>
        <source>Насыщенность</source>
        <translation>Saturation</translation>
    </message>
    <message>
        <location filename="videoplayer.cpp" line="316"/>
        <source>Контраст</source>
        <translation>Contrast</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="58"/>
        <source>Настроить цветовую гамму</source>
        <translation>Change parameters of HSV</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="59"/>
        <source>Открыть файл</source>
        <translation>Open file</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="83"/>
        <source>Плейлист</source>
        <translation>Playlist</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="94"/>
        <source>Выкл. ПК после завершения</source>
        <translation>Turn off PC after finished</translation>
    </message>
    <message>
        <location filename="videoplayer.h" line="95"/>
        <source>Выйти</source>
        <translation>Exit</translation>
    </message>
    <name>VideoWidget</name>
    <message>
        <location filename="videowidget.cpp" line="51"/>
        <source>Расширить до границ</source>
        <translation>Expand to borders</translation>
    </message>
    <message>
        <location filename="videowidget.cpp" line="53"/>
        <source>Стандартный размер</source>
        <translation>Stardard size</translation>
    </message>
    <message>
        <location filename="videowidget.h" line="23"/>
        <source>Расширить до границ</source>
        <translation>Expand to borders</translation>
    </message>
    <message>
        <location filename="videowidget.h" line="24"/>
        <source>Стандартный размер</source>
        <translation>Standard size</translation>
    </message>
</context>
</TS>
