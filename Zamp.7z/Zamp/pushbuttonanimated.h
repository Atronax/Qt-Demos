#ifndef PUSHBUTTONANIMATED_H
#define PUSHBUTTONANIMATED_H

#include <QPushButton>

#include <QPropertyAnimation>
#include <QStateMachine>
#include <QState>

class PushButtonAnimated : public QPushButton
{
    Q_OBJECT
public:
    PushButtonAnimated(const QString &text, QWidget *parent = 0) : QPushButton (text, parent)
    {
    }

    void start_RB_Animation ()
    {
        QState* state1 = new QState;
        QState* state2 = new QState;

        state1->assignProperty(this, "minimumHeight", minimumHeight());
        state2->assignProperty(this, "minimumHeight", minimumHeight() + 40);

        state1->addTransition(this, SIGNAL(clicked()), state2);
        state2->addTransition(this, SIGNAL(clicked()), state1);

        QPropertyAnimation *animation = new QPropertyAnimation (this, "minimumHeight");
        animation->setEasingCurve(QEasingCurve::BezierSpline);
        animation->setDuration(400);

        state_machine.addState(state1);
        state_machine.addState(state2);
        state_machine.setInitialState(state1);
        state_machine.addDefaultAnimation(animation);

        state_machine.start();
    }

private:
    QStateMachine state_machine;

public slots:

};

#endif // PUSHBUTTONANIMATED_H
