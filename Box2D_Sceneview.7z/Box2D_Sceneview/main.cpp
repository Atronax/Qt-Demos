#include <QApplication>

#include "gamemanager.h"
int main (int argc, char* argv[])
{
    QApplication app (argc, argv);

    GameManager *game = new GameManager;
    game->showMaximized();

    return app.exec();
}
