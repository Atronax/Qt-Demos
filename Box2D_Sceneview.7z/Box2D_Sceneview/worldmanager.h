#ifndef WORLDMANAGER_H
#define WORLDMANAGER_H

// core
#include <Box2D/Box2D.h>
class ContactListener;
class QGraphicsItem;
class GameManager;

// sprite images cache
#include "Items/sprite/spriteimages.h"

// items
#include "items/entity.h"
#include "Items/equipmentitem.h"
#include "Items/collectible.h"
#include "Items/buildblock.h"
#include "Items/player.h"
#include "Items/enemy.h"

#include <QObject>
class WorldManager : public QObject
{
    Q_OBJECT
public:
    explicit WorldManager(GameManager* manager, QWidget* parent = nullptr);
    ~WorldManager();

    // getters and object needed by other classes
    QList<b2Body*>& dynamic_bodies();
    SpriteImages* imagesCache() const;
    float32 tilesize() const;
    b2World* world() const;
    Player* player() const;

    // generators
    void makeCurrentObject (const QPointF& origin);
    EquipmentItem* makeEquipmentItem (const QPointF& origin, int radius, int type, const QString& name, QPixmap* image, bool isDynamic, bool isSolid, bool isRotatable);
    Collectible* makeCollectible (const QPointF& origin, int radius, int type, bool isDynamic, bool isSolid, bool isRotatable);
    BuildBlock* makeBuildblock (const QPointF& origin, const QSize& size, int type, bool isBody, bool isDynamic, bool isSolid, bool isRotatable);
    Player* makePlayer (const QPointF& origin, int radius);
    Enemy* makeEnemy (const QPointF& origin, int radius, int type);

private:
    // core
    GameManager* m_manager;
    b2World *m_world;

    static constexpr float32 m_tilesize = 32.0f;
    static constexpr float32 m_timestep = 60.0f;
    static constexpr int32 m_veliterations = 8;
    static constexpr int32 m_positerations = 3;
    static constexpr float PI = 3.14159265359;

    QTimer *physics_updater;
    QTimer *sprite_updater;

    // bodies
    uint m_currentObject; // what to make
    SpriteImages *m_imagesCache;
    ContactListener *m_listener;
    QList<b2Body*> m_dynbodies;
    Player *m_player;

    // saving and loading (in gameplay mode, in editor mode)
    void clearScene();

    void saveLevelAs(const QString& level_filename);
    void loadLevelFrom(const QString& level_filename);
    static constexpr int32 pmap_const = 0x2f3adff2;

    void saveGameAs(const QString& gamesave_filename);
    void loadGameFrom(const QString& gamesave_filename);
    static constexpr int32 save_const = 0x4a2dffb2;

signals:

public slots:
    void updateCollisions();
    void updatePhysics();
    void updateSprites();

    void changeCurrentObject();

    void onSaveLevel();
    void onLoadLevel();
    void onSaveGame();
    void onLoadGame();

    void onKilled(Enemy* enemy);
    void onKilled(Player* player);
    void onGot(Collectible* coin);
    void onGot(EquipmentItem* equipmentitem);
};

#endif // WORLDMANAGER_H
