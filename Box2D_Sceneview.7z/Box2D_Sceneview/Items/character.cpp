// painting
#include <QLinearGradient>
#include <QPainter>

#include "character.h"
Character::Character()
{

}

Character::~Character()
{

}

void Character::setVisualState(int value)
{
    if (sprite())
    {
        m_visualState = value;
        sprite()->setState(m_visualState);
    }
}

int Character::visualState() const
{
    return m_visualState;
}

QRectF Character::boundingRect() const
{
    return rect().adjusted(-1,-1-32,+1,+1);
}

float Character::currentHealth() const
{
    return m_currentHealth;
}

float Character::maximumHealth() const
{
    return m_maximumHealth;
}

void Character::setCurrentHealth(float value)
{
    if (value < m_maximumHealth)
        m_currentHealth = value;
    else
        m_currentHealth = m_maximumHealth;
}

void Character::setMaximumHealth(float value)
{
    m_maximumHealth = value;
    setCurrentHealth(m_maximumHealth);
}

void Character::drawHealthbar(QPainter *painter, const QRect& health_rect)
{
    if (painter)
    {
        QRect full_rect = health_rect;
        QRect curr_rect = QRect(full_rect.x(), full_rect.y(), ((float)currentHealth()/maximumHealth())*full_rect.width(), full_rect.height());

        QLinearGradient gradient;
        gradient.setStart(curr_rect.x() + curr_rect.width()/2,curr_rect.y());
        gradient.setFinalStop(curr_rect.x() + curr_rect.width()/2, curr_rect.y() + curr_rect.height());
        gradient.setColorAt(0, Qt::darkGreen);
        gradient.setColorAt(0.5, Qt::green);
        gradient.setColorAt(1, Qt::darkGreen);

        painter->setPen(Qt::red);
        painter->fillRect(full_rect, Qt::black);
        painter->fillRect(curr_rect, QBrush(gradient));
        painter->drawText(full_rect, QString::number(static_cast<int>(currentHealth())), QTextOption(Qt::AlignCenter));
    }
}

int Character::damage() const
{
    return m_damage;
}

void Character::setDamage(int value)
{
    m_damage = value;
}

int Character::defence() const
{
    return m_defence;
}

void Character::setDefence(int value)
{
    if (value >= 0 && value <= 80)
        m_defence = value;
}

void Character::drawDDbar(QPainter *painter, const QRect& dd_rect)
{
    if (painter)
    {
        QRect full_rect = dd_rect;
        QRect damage_rect = QRect(full_rect.x(), full_rect.y(), full_rect.width()/2, full_rect.height());
        QRect defence_rect = QRect(full_rect.x() + full_rect.width()/2, full_rect.y(), full_rect.width()/2, full_rect.height());

        painter->setPen(Qt::black);
        painter->fillRect(damage_rect, Qt::red);
        painter->fillRect(defence_rect, Qt::gray);
        painter->drawText(damage_rect, QString::number(damage()), QTextOption(Qt::AlignCenter));
        painter->drawText(defence_rect, QString::number(defence()), QTextOption(Qt::AlignCenter));
    }
}

int Character::experience() const
{
    return m_currentExperience;
}

int Character::neededExperience() const
{
    return m_neededExperience;
}

int Character::level() const
{
    return m_level;
}

void Character::setLevel(int value)
{
    m_level = value;
}

void Character::setCurrentExperience(int value)
{
    m_currentExperience = value;
}

void Character::setNeededExperience(int value)
{
    m_neededExperience = value;
}

void Character::drawExperiencebar(QPainter *painter, const QRect &experience_rect)
{
    if (painter)
    {
        QRect full_rect = experience_rect;
        QRect level_rect = QRect(full_rect.x(), full_rect.y(), full_rect.width()/3, full_rect.height());
        QRect full_exp_rect = QRect(full_rect.x() + full_rect.width()/3, full_rect.y(), 2*full_rect.width()/3, full_rect.height());
        QRect curr_exp_rect = QRect(full_exp_rect.x(), full_exp_rect.y(), ((float)experience()/neededExperience())*full_exp_rect.width(), full_exp_rect.height());

        painter->setPen(Qt::green);
        painter->fillRect(curr_exp_rect, QColor(255, 255, 0));
        painter->drawText(level_rect, QString("L: %1").arg(level()), QTextOption(Qt::AlignCenter));
        painter->drawText(full_exp_rect, QString::number(experience()), QTextOption(Qt::AlignCenter));
    }
}
