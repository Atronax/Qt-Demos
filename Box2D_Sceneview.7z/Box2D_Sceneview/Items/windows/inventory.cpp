#include <QPainter>

#include "inventory.h"
Inventory::Inventory(QGraphicsItem* parent)
{
    setParentItem(parent);
    makeInventory();
    hide();
}

Inventory::~Inventory()
{
    m_inventoryCells.clear();
    m_inventory.clear();
    m_equipment.clear();
}


void Inventory::makeInventory()
{
    // setup rect and position
    setPos(-320,-500);
    setRect(0,0,620,400);

    // make inventory cells
    makeInventoryCells();

    // make equipment cells
}

EquipmentItem *Inventory::getEquippedItemOf(int equipmentType)
{
    return m_equipment[equipmentType];
}

void Inventory::changeEquippedItemTo(int equipmentType, EquipmentItem *item)
{
    foreach (EquipmentItem* inventory_item, m_inventory)
    {
        if (inventory_item == item && inventory_item->equipmentType() == equipmentType)
        {
            m_inventory.removeOne(item);
            m_equipment[equipmentType] = item;
        }
    }
}

void Inventory::undressItemFrom(int equipmentType)
{
    m_equipment.remove(equipmentType);
    m_inventory.append(m_equipment[equipmentType]);
}

void Inventory::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{    
    qDebug(QString("Вящей:" + QString::number(m_inventory.size())).toUtf8());

    // frames
    QRectF frame = rect();
    QRectF content = frame.adjusted(10,20,-10,-20);
    QRectF content_inv = QRectF(content.x(),content.y(), content.width()/2.0, content.height());
    QRectF content_eqp = QRectF(content.x() + content.width()/2.0, content.y(), content.width()/2.0, content.height());

    painter->setBrush(QBrush(QColor(255,255,255,200)));
    painter->drawRect(frame);
    painter->drawRect(content);
    painter->drawRect(content_inv);
    painter->drawRect(content_eqp);

    // inventory rects
    foreach (QRectF cell, m_inventoryCells)
        painter->drawRect(cell);

    // items in inventory
    for (int i = 0; i < m_inventory.size(); ++i)
        m_inventory[i]->setPos(m_inventoryCells[i].topLeft());

    QGraphicsRectItem::paint(painter, option, widget);
}

void Inventory::makeInventoryCells()
{
    QRectF frame = rect();
    QRectF content = frame.adjusted(10,20,-10,-20);
    QRectF content_inv = QRectF(content.x(),content.y(), content.width()/2.0, content.height());

    for (int y = content_inv.y(); y < content_inv.y() + content_inv.height(); y += 30)
        for (int x = content_inv.x(); x < content_inv.x() + content_inv.width(); x += 30)
            m_inventoryCells.push_back(QRectF(x,y,30,30));
}



