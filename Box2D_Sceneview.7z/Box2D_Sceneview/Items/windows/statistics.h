#ifndef STATISTICS_H
#define STATISTICS_H

#include <QGraphicsRectItem>
class Statistics : public QGraphicsRectItem
{
public:
    Statistics(QGraphicsItem* parent);
    ~Statistics();

    int coinsCollected() const;
    void setCoinsCollected(int coinsCollected);

    int starsCollected() const;
    void setStarsCollected(int starsCollected);

    int damageDealt() const;
    void setDamageDealt(int damageDealt);

    int enemiesKilled() const;
    void setEnemiesKilled(int enemiesKilled);

    int gnomesKilled() const;
    void setGnomesKilled(int gnomesKilled);

    int unicornsKilled() const;
    void setUnicornsKilled(int unicornsKilled);

protected:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    QList<QString> createStatisticsText();
    void makeStatistics();
    void initVariables();

    int m_coinsCollected;
    int m_starsCollected;

    int m_damageDealt;

    int m_enemiesKilled;
    int m_gnomesKilled;
    int m_unicornsKilled;

};


#endif // STATISTICS_H
