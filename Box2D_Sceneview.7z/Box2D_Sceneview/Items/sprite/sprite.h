#ifndef SPRITE_H
#define SPRITE_H

#include "spriteimages.h"
#include <QGraphicsItem>
class Sprite
{
public:
    Sprite(QGraphicsItem* m_parent = nullptr);
    ~Sprite();    

    // == Установка спрайта или спрайт-листа == //    
    void setStatic(QPixmap* static_sprite);
    void setDynamic(QPixmap* dynamic_sprite, const float& framewidth, const float& frameheight);
    void fillComponents(QVector<QPixmap*>* components, QVector<QPair<float,float> >* framesizes);

    // == Отрисовка содержимого == //
    void drawStatic(QPainter* painter);
    void drawDynamic(QPainter* painter);
    void nextFrame();

    // == Тип (динамический или статический) == //
    enum TYPE {NOTHING = 0, STATIC = 1, DYNAMIC = 2} ;
    const int& type() const;

    // == Управление состоянием == //
    enum {AFK = 0, MOVING_LEFT = 1, MOVING_RIGHT = 2, JUMPING = 3, ATTACKING = 4, CASTING = 5, DEFENDING = 6, DYING = 7};
    void setState (const int& new_state);
    const int& prevstate() const;
    const int& state() const;

private:
    // Container For Sprite:
    QGraphicsItem *m_parent;

    // Sprite Type:
    // 1. Static Sprite
    // 2. Dynamic Sprite
    // 3. Component Based Sprite
    // 4. Current Frame Position and Sizes
    int m_type;
    bool m_bHasComponents;
    QPixmap *m_static_sprite;
    QPixmap *m_dynamic_sprite;
    QVector<QPixmap*>* m_components;
    QVector<QPair<float,float>>* m_framesizes;
    float currFrameX, currFrameY, currFrameW, currFrameH;

    int m_state, m_prevstate;

};

#endif // SPRITE_H
