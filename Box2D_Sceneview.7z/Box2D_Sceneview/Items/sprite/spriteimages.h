#ifndef SPRITEIMAGES_H
#define SPRITEIMAGES_H

#include <QVector>
#include <QPixmap>

class SpriteImages
{
public:
    SpriteImages();
    ~SpriteImages();

    // statics
    QPixmap *coin();
    QPixmap *star();
    QPixmap *crate();
    QPixmap *barrel();
    QPixmap *brick();
    QPixmap *ground();
    QPixmap *grass();
    QPixmap *moon();
    QPixmap *potion_restore_hp();
    QPixmap *potion_add_hp();
    QPixmap *potion_add_damage();
    QPixmap *potion_add_defence();

    // dynamics
    QPixmap *tree_fir();

    QVector<QPixmap*>* player() const;
    QVector<QPair<float,float>>* player_framesizes() const;

    QVector<QPixmap*>* dwarf() const;
    QVector<QPair<float,float>>* dwarf_framesizes() const;

    QVector<QPixmap*>* unicorn() const;
    QVector<QPair<float,float>>* unicorn_framesizes() const;

private:
    void fillPlayerSpritesheet();
    void fillDwarfSpritesheet();
    void fillUnicornSpritesheet();

    // STATICS
    // - building blocks:
    QPixmap *m_coin, *m_star;
    QPixmap *m_crate, *m_barrel, *m_brick, *m_ground, *m_grass, *m_moon;

    // - collectibles:
    QPixmap *m_potion_restore_hp, *m_potion_add_hp, *m_potion_add_damage, *m_potion_add_defence;

    // - items:
    // uses a file containing tuples "type-name-filepath" to gen a map of pixmaps
    // QMap<int, QList<QString, QPixmap*>> m_items;

    // - enemies:

    // DYNAMICS
    // - building blocks:
    QPixmap* m_tree_fir;

    // - collectibles:

    // - items:

    // - enemies:
    QVector<QPixmap*>* m_player_spritesheet;
    QVector<QPixmap*>* m_dwarf_spritesheet;
    QVector<QPixmap*>* m_unicorn_spritesheet;

    QVector<QPair<float,float> >* m_player_framesizes;
    QVector<QPair<float,float> >* m_dwarf_framesizes;
    QVector<QPair<float,float> >* m_unicorn_framesizes;


};

#endif // SPRITEIMAGES_H
