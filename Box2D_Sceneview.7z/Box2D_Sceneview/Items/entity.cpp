#include <QTimer>

#include "entity.h"
Entity::Entity()
{
    m_sprite = nullptr;
}

Entity::~Entity()
{
    qDebug("in entity destr");
    delete m_sprite;
    if (!m_sprite)
        qDebug("sprite is deleted");
}

b2Body* Entity::body() const
{
    return m_body;
}

Sprite* Entity::sprite() const
{
    return m_sprite;
}

GameManager *Entity::manager() const
{
    return m_manager;
}

void Entity::setBody(b2Body *body)
{
    m_body = body;
}

void Entity::setSprite(Sprite *sprite)
{
    m_sprite = sprite;
}

void Entity::setManager(GameManager *manager)
{
    m_manager = manager;
}

bool Entity::isBody() const
{
    return m_isBody;
}

bool Entity::isDynamic() const
{
    return m_isDynamic;
}

bool Entity::isSolid() const
{
    return m_isSolid;
}

bool Entity::isRotatable() const
{
    return m_isRotatable;
}

void Entity::setIsBody(bool value)
{
    m_isBody = value;
}

void Entity::setDynamic(bool new_value)
{
    m_isDynamic = new_value;
}

void Entity::setSolid(bool new_value)
{
    m_isSolid = new_value;
}

void Entity::setRotatable(bool new_value)
{
    m_isRotatable = new_value;
}

void Entity::queueToDeletion()
{
    QTimer *deletion_timer = new QTimer(this);
    deletion_timer->setSingleShot(true);
    connect (deletion_timer, &QTimer::timeout, this, [&](){delete this;});
    deletion_timer->start(1000);
}
