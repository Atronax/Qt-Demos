#ifndef COLLECTIBLE_H
#define COLLECTIBLE_H

#include "entity.h"
#include <QGraphicsEllipseItem>
class Collectible : public Entity, public QGraphicsEllipseItem
{
    Q_OBJECT
public:
    explicit Collectible(GameManager *manager, b2Body *body = nullptr, QGraphicsItem* parent = nullptr);
    virtual ~Collectible();

    virtual void checkCollision(Entity* rhs);

    // ТИП
    enum {DYNAMIC_COIN = 1000, DYNAMIC_STAR, POTION_RESTORE_HP, POTION_ADD_MAX_HP, POTION_ADD_DAMAGE, POTION_ADD_DEFENCE};
    void setCollectibleType (int type);
    int collectibleType() const;

protected:
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    int m_collectibleType;

};

#endif // COLLECTIBLE_H
