#ifndef ENTITY_H
#define ENTITY_H

class GameManager;

#include <Box2D/Box2D.h>
#include "sprite/sprite.h"

#include <QObject>
class Entity : public QObject
{
    Q_OBJECT
public:
    explicit Entity();
    virtual ~Entity();

    virtual void checkCollision (Entity* rhs) = 0;

    b2Body* body() const;
    Sprite* sprite() const;
    GameManager* manager() const;
    void setBody(b2Body* body);
    void setSprite(Sprite* sprite);   
    void setManager(GameManager* manager);

    bool isBody() const;
    bool isSolid() const;
    bool isDynamic() const;
    bool isRotatable() const;
    void setIsBody(bool value);
    void setSolid(bool value);
    void setDynamic(bool value);
    void setRotatable(bool value);

    void queueToDeletion();

protected:
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) = 0;

private:
    GameManager *m_manager;
    Sprite *m_sprite;
    b2Body *m_body;

    bool m_isBody;
    bool m_isSolid;
    bool m_isDynamic;
    bool m_isRotatable;
};

#endif // ENTITY_H
