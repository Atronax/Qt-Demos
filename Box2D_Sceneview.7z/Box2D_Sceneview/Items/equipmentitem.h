#ifndef EQUIPMENTITEM_H
#define EQUIPMENTITEM_H

class QHoverEvent;

// to supress incomplete type warnings
#include <QPen>
#include <QBrush>
#include <QFont>

#include "entity.h"
#include <QGraphicsEllipseItem>
class EquipmentItem : public Entity, public QGraphicsEllipseItem
{
public:
    explicit EquipmentItem(GameManager *manager, b2Body *body = nullptr, QGraphicsItem* parent = nullptr);
    virtual ~EquipmentItem();

    virtual void checkCollision (Entity* rhs);

    // ТИП
    enum {HEAD = 3000, SHOULDERS, ARMOR, GLOVES, LHAND, RHAND, LEGS, BOOTS};
    void setEquipmentType (int type);
    int equipmentType() const;

    // ИМЯ
    const QString& name() const;
    void setName(const QString& value);

    // АТТРИБУТЫ
    int health() const;
    void setHealth(int health);

    int attack() const;
    void setAttack(int attack);

    int defence() const;
    void setDefence(int defence);

    // ИНФОБЛОК
    void showInfoblock();
    void hideInfoblock();

protected:
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    void hoverEnterEvent(QGraphicsSceneHoverEvent* ev);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent* ev);

private:
    // core
    int m_equipmentType;

    // visual side
    QFont m_font;
    QBrush m_brush;
    QPen m_pen;

    // attributes
    QString m_name;
    int m_health;
    int m_attack;
    int m_defence;

    // infoblock
    QGraphicsRectItem* m_information;
};

#endif // EQUIPMENTITEM_H
