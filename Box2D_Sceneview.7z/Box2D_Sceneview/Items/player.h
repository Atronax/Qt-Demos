#ifndef PLAYER_H
#define PLAYER_H

class Enemy;
class Inventory;
class Statistics;
class GameManager;
class Collectible;
class EquipmentItem;

#include "character.h"
class Player: public Character
{
    Q_OBJECT
public:
    explicit Player(GameManager *manager, b2Body* body = nullptr, QGraphicsItem* parent = nullptr);
    virtual ~Player();

    virtual void checkCollision(Entity* rhs);
    virtual void updateState(const QPointF& player_pos);

    // inventory subsystem
    Inventory* inventory() const;
    Statistics* statistics() const;

    // leveling subsystem
    void levelUp();

    // jumping subsystem
    bool isJumpingAllowed() const;
    void setIsJumpingAllowed(bool value);

    // attacking subsystem
    void startAttacking();
    void stopAttacking();

protected:    
    void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    void initialize();

    bool m_isJumpingAllowed;

    Inventory *m_inventory;
    Statistics *m_statistics;

    QTimer *m_attacking_timer;
    Enemy *m_target;

signals:
    void killed(Enemy* enemy);
    void got(Collectible* coin);
    void got(EquipmentItem* coin);

public slots:
    void attack();
};

#endif // PLAYER_H
