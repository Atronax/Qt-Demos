#include <QGraphicsSceneHoverEvent>
#include <QPainter>

#include "equipmentitem.h"
EquipmentItem::EquipmentItem(GameManager *manager, b2Body *body, QGraphicsItem* parent)
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);
    setAcceptHoverEvents(true);

    setBody(body);
    setSprite(new Sprite(this));
    setParentItem(parent);
    setManager(manager);

    m_health = 0;
    m_attack = 0;
    m_defence = 0;

}

EquipmentItem::~EquipmentItem()
{
    delete m_information;
}

void EquipmentItem::checkCollision(Entity *)
{

}

void EquipmentItem::setEquipmentType(int type)
{
    m_equipmentType = type;

    m_font = QFont("Stylo", 12)  ;
    switch (m_equipmentType)
    {
    case HEAD:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case SHOULDERS:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case ARMOR:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case GLOVES:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case LHAND:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case RHAND:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case LEGS:
        m_pen = QPen(Qt::red);
        m_brush = QBrush(Qt::red);
        break;

    case BOOTS:
        m_pen = QPen(Qt::white);
        m_brush = QBrush(Qt::white);
        break;
    }
}

int EquipmentItem::equipmentType() const
{
    return m_equipmentType;
}

const QString &EquipmentItem::name() const
{
    return m_name;
}

void EquipmentItem::setName(const QString &value)
{
    m_name = value;
}

int EquipmentItem::defence() const
{
    return m_defence;
}

void EquipmentItem::setDefence(int defence)
{
    m_defence = defence;
}

int EquipmentItem::attack() const
{
    return m_attack;
}

void EquipmentItem::setAttack(int attack)
{
    m_attack = attack;
}

int EquipmentItem::health() const
{
    return m_health;
}

void EquipmentItem::setHealth(int health)
{
    m_health = health;
}

void EquipmentItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->setPen(m_pen);
    painter->setBrush(m_brush);
    painter->setFont(QFont("Stylo", 30));
    painter->drawRect(rect());
    painter->drawText(rect(), m_name, QTextOption(Qt::AlignTop | Qt::AlignHCenter));

    if (sprite())
    {
        int type = sprite()->type();
        if (type == Sprite::STATIC)
            sprite()->drawStatic(painter);
        if (type == Sprite::DYNAMIC)
            sprite()->drawDynamic(painter);
    }


}

void EquipmentItem::hoverEnterEvent(QGraphicsSceneHoverEvent *)
{
    qDebug("in equipmentitem hoverenter");
    showInfoblock();
}

void EquipmentItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *)
{
    qDebug("in equipmentitem hoverleave");
    hideInfoblock();
}

void EquipmentItem::showInfoblock()
{
    if (!m_information)
    {
        // frame
        m_information = new QGraphicsRectItem (0,0, 200, 300, this);
        m_information->setZValue(zValue() + 1.0);
        m_information->setBrush(QColor(0,0,0,200));
        m_information->setPen(QPen(Qt::black, 2));

        // name
        QGraphicsTextItem *m_infoname = new QGraphicsTextItem(name(), m_information);
        m_infoname->setFont(m_font);
        m_infoname->setDefaultTextColor(m_pen.color());
        m_infoname->setPos(m_information->boundingRect().width()/2.0 - m_infoname->boundingRect().width()/2.0, m_information->y());

        // other attributes
        QGraphicsTextItem *m_infohealth = new QGraphicsTextItem(tr("Здоровье: +") + QString::number(health()), m_information);
        m_infohealth->setFont(m_font);
        m_infohealth->setDefaultTextColor(m_pen.color());
        m_infohealth->setPos(m_information->boundingRect().width()/2.0 - m_infohealth->boundingRect().width()/2.0, m_information->y() + 40);

        QGraphicsTextItem *m_infoattack = new QGraphicsTextItem(tr("Атака: +") + QString::number(attack()), m_information);
        m_infoattack->setFont(m_font);
        m_infoattack->setDefaultTextColor(m_pen.color());
        m_infoattack->setPos(m_information->boundingRect().width()/2.0 - m_infoattack->boundingRect().width()/2.0, m_information->y() + 60);

        QGraphicsTextItem *m_infodefence = new QGraphicsTextItem(tr("Защита: +") + QString::number(defence()), m_information);
        m_infodefence->setFont(m_font);
        m_infodefence->setDefaultTextColor(m_pen.color());
        m_infodefence->setPos(m_information->boundingRect().width()/2.0 - m_infodefence->boundingRect().width()/2.0, m_information->y() + 80);

    }

    m_information->show();
}

void EquipmentItem::hideInfoblock()
{
    if (m_information)
        m_information->hide();
}


