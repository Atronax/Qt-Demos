#ifndef CHARACTER_H
#define CHARACTER_H

#include "entity.h"
#include <QGraphicsEllipseItem>
class Character: public Entity, public QGraphicsEllipseItem
{
    Q_OBJECT
public:
    explicit Character();
    virtual ~Character();

    virtual void checkCollision (Entity* rhs) = 0;
    virtual void updateState (const QPointF& player_pos)
    {
        Q_UNUSED(player_pos);
    }

    // ВНУТРЕННЕЕ СОСТОЯНИЕ
    // health
    float currentHealth() const;
    float maximumHealth() const;
    void setCurrentHealth(float value);
    void setMaximumHealth(float value);
    void drawHealthbar(QPainter* painter, const QRect& health_rect);

    // damage and defence
    int damage() const;
    int defence() const;
    void setDamage(int value);
    void setDefence(int value);
    void drawDDbar(QPainter* painter, const QRect& dd_rect);

    // leveling system
    int level() const;
    int experience() const;
    int neededExperience() const;
    void setLevel(int value);
    void setCurrentExperience(int value);
    void setNeededExperience(int value);
    void drawExperiencebar(QPainter* painter, const QRect& experience_rect);

    // ВИЗУАЛЬНОЕ СОСТОЯНИЕ
    enum {AFK,
          MOVING_LEFT,
          MOVING_RIGHT,
          JUMPING,
          ATTACKING,
          CASTING,
          DEFENDING,
          DYING};
    void setVisualState(int value);
    int visualState() const;

protected:
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) = 0;
    QRectF boundingRect() const;

private:
    int m_visualState;

    float m_currentHealth;
    float m_maximumHealth;

    int m_damage;
    int m_defence;

    int m_currentExperience;
    int m_neededExperience;
    int m_level;
};

#endif // CHARACTER_H
