#ifndef ENEMY_H
#define ENEMY_H

class Player;

#include "character.h"
class Enemy : public Character
{
    Q_OBJECT
public:    
    explicit Enemy(GameManager *manager, b2Body *body = nullptr, QGraphicsItem* parent = nullptr);
    virtual ~Enemy();

    virtual void checkCollision(Entity* rhs);

    // ТИП
    enum {GNOME = 2000, UNICORN};
    void setEnemyType (int type);
    int enemyType() const;

    // СОСТОЯНИЕ
    void updateState(const QPointF& player_pos);

    // АТАКА
    void startAttacking();
    void stopAttacking();

protected:
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    int m_enemyType;

    QTimer *m_attack_timer;
    Player *m_target;

public slots:
    void attack();

signals:
    void killed(Player* player);
};

#endif // ENEMY_H
