#include "gamemanager.h"
#include "worldmanager.h"

#include "collectible.h"
Collectible::Collectible(GameManager *manager, b2Body *body, QGraphicsItem* parent)
{
    setCacheMode(QGraphicsItem::ItemCoordinateCache);

    setBody(body);
    setSprite(new Sprite(this));
    setParentItem(parent);
    setManager(manager);
}

Collectible::~Collectible()
{
    qDebug("in collectible destr");
}

int Collectible::collectibleType() const
{
    return m_collectibleType;
}

void Collectible::setCollectibleType(int type)
{
    m_collectibleType = type;

    switch (m_collectibleType)
    {
    case DYNAMIC_COIN:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->coin());
        break;

    case DYNAMIC_STAR:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->star());
        break;

    case POTION_RESTORE_HP:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->potion_restore_hp());
        break;

    case POTION_ADD_MAX_HP:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->potion_add_hp());
        break;

    case POTION_ADD_DAMAGE:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->potion_add_damage());
        break;

    case POTION_ADD_DEFENCE:
        sprite()->setStatic(manager()->worldmanager()->imagesCache()->potion_add_defence());
        break;

    default:
        break;
    }
}

void Collectible::checkCollision(Entity *)
{

}

void Collectible::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    if (sprite())
    {
        int type = sprite()->type();
        if (type == Sprite::STATIC)
            sprite()->drawStatic(painter);
        if (type == Sprite::DYNAMIC)
            sprite()->drawDynamic(painter);
    }
}
