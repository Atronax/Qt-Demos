#ifndef BUILDBLOCK_H
#define BUILDBLOCK_H

#include "entity.h"
#include <QGraphicsRectItem>
class BuildBlock : public Entity, public QGraphicsRectItem
{
    Q_OBJECT
public:    
    explicit BuildBlock(GameManager *manager, b2Body* body = nullptr, QGraphicsItem* parent = nullptr);
    virtual ~BuildBlock();

    virtual void checkCollision (Entity* rhs);

    // ТИП
    enum {BARREL_1X1 = 0, BARREL_2X2, BOX_1X1, BOX_1X2, BOX_2X1, STATIC_COIN, STATIC_STAR,
                          BRICK_1X1, TREE_FIR, GROUND, GRASS, MOON};
    void setBuildBlockType (int type);
    int buildblockType () const;

protected:
    virtual void paint (QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    int m_buildblockType;
};

#endif // BUILDBLOCK_H
