// EVENTS
#include <QKeyEvent>
#include <QMouseEvent>

// WIDGETS
#include <QFileDialog>
#include <QScrollBar>

// items
#include "Items/windows/statistics.h"
#include "Items/windows/inventory.h"
#include "items/equipmentitem.h" // test code
#include "worldmanager.h"
#include "contextmenu.h"
#include "gamemanager.h"
GameManager::GameManager(QWidget *parent)
    : QGraphicsView(parent),
      current_item(nullptr)
{
    buildSceneAndView();
    buildWorldManager();
    buildContextMenu();

    QGraphicsRectItem* item = new QGraphicsRectItem(nullptr);
    scene->addItem(item);
    scene->removeItem(item);
    delete item;
}

GameManager::~GameManager()
{

}

// Builds
void GameManager::buildSceneAndView()
{
    scene = new QGraphicsScene(this);

    view = this;
    horizontalScrollBar()->setDisabled(true);
    verticalScrollBar()->setDisabled(true);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setBackgroundBrush(QPixmap(":/images/seamless_sky.jpg"));
    setOptimizationFlags(QGraphicsView::DontSavePainterState);
    setViewportUpdateMode(QGraphicsView::MinimalViewportUpdate);
    setCacheMode(QGraphicsView::CacheBackground);
    setScene(scene);
}

void GameManager::buildWorldManager()
{
    m_worldmanager = new WorldManager(this);

    m_worldmanager->makeBuildblock(QPointF(-32, 0), QSize(32, 1000), BuildBlock::BOX_1X1, true, false, true, false); // lw
    m_worldmanager->makeBuildblock(QPointF(0, 900), QSize(5000, 100), BuildBlock::BOX_1X1, true, false, true, false); // gr
    m_worldmanager->makeBuildblock(QPointF(5000, 0), QSize(32, 1000), BuildBlock::BOX_1X1, true, false, true, false); // rw
    m_worldmanager->makeBuildblock(QPointF(12*32, 12*32), QSize(64, 64), BuildBlock::BOX_1X1, true, false, true, false); // ct 
    m_worldmanager->makePlayer(QPointF(132, 800), 32);    

    // test code
    m_worldmanager->makeEquipmentItem(QPointF(1000,800), 15, EquipmentItem::HEAD, "Шлем великого Кукурузо", new QPixmap("D:/downloads/helmet.png"), true, false, true);
    m_worldmanager->makeEquipmentItem(QPointF(900,800), 15, EquipmentItem::BOOTS, "Ботинки из комплекта", new QPixmap("D:/downloads/boots.png"), true, false, true);
}

void GameManager::buildContextMenu()
{
    context_menu = new ContextMenu(this, tr("Контекстное меню"), this);
}

// Getters
QGraphicsView *GameManager::getView()
{
    return view;
}

QGraphicsScene *GameManager::getScene()
{
    return scene;
}

WorldManager *GameManager::worldmanager() const
{
    return m_worldmanager;
}

// Events
void GameManager::keyPressEvent(QKeyEvent *ev)
{
    Player* player = m_worldmanager->player();
    b2Body* plbody = player->body();

    int key = ev->key();
    if (ev->modifiers() == Qt::NoModifier)
    {
        if (key == Qt::Key_W)
        {
            if (player->isJumpingAllowed())
            {
                player->setVisualState(Character::JUMPING);
                plbody->SetLinearVelocity(b2Vec2(plbody->GetLinearVelocity().x, -10.0f));
                player->setIsJumpingAllowed(false);
            }
        }

        if (key == Qt::Key_A)
        {
            player->setVisualState(Character::MOVING_LEFT);
            plbody->SetLinearVelocity(b2Vec2(-10.0f, plbody->GetLinearVelocity().y));
        }

        if (key == Qt::Key_S)
        {

        }

        if (key == Qt::Key_D)
        {
            player->setVisualState(Character::MOVING_RIGHT);
            plbody->SetLinearVelocity(b2Vec2(+10.0f, plbody->GetLinearVelocity().y));
        }

        if (key == Qt::Key_I)
        {
            if (!player->inventory()->isVisible() && !player->statistics()->isVisible())
                player->inventory()->show();
            else
                player->inventory()->hide();
        }

        if (key == Qt::Key_O)
        {
            if (!player->inventory()->isVisible() && !player->statistics()->isVisible())
                player->statistics()->show();
            else
                player->statistics()->hide();
        }

        if (key == Qt::Key_Space)
        {
            player->setVisualState(Character::ATTACKING);
        }

        if (key == Qt::Key_B)
        {
            changeBackground();
        }
    }

    if (ev->modifiers() == Qt::ShiftModifier)
    {
        if (key == Qt::Key_A)
            moveCurrentItemTo(false, true, false, false);

        if (key == Qt::Key_D)
            moveCurrentItemTo(false, false, false, true);

        if (key == Qt::Key_W)
            moveCurrentItemTo(true, false, false, false);

        if (key == Qt::Key_S)
            moveCurrentItemTo(false, false, true, false);
    }

     QGraphicsView::keyPressEvent(ev);
}

void GameManager::mousePressEvent(QMouseEvent *ev)
{
    if (ev->modifiers() == Qt::ShiftModifier)
    {
        if (ev->button() == Qt::LeftButton)
            currentItemIsAt(ev->localPos());

        if (ev->button() == Qt::RightButton)        
            context_menu->exec(ev->globalPos());
    }
    if (ev->modifiers() == Qt::ControlModifier)
    {
        if (ev->button() == Qt::LeftButton)
            turnBodyToStatic(ev->localPos());

        if (ev->button() == Qt::RightButton)
            turnBodyToDynamic(ev->localPos());        
    }
    if (ev->modifiers() == Qt::NoModifier)
    {
        if (ev->button() == Qt::LeftButton)
            createBodyAt(ev->localPos());

        if (ev->button() == Qt::RightButton)
            removeBodyAt(ev->localPos());
    }
}

void GameManager::wheelEvent(QWheelEvent *ev)
{
    if (ev->modifiers() == Qt::NoModifier)
    {
        QPoint scene_pos = mapFromGlobal(QCursor::pos());

        if (ev->delta() < 0)
            rotateBodyAt(scene_pos, true);

        if (ev->delta() > 0)
            rotateBodyAt(scene_pos, false);
    }
}

void GameManager::createBodyAt(const QPointF &position) const
{
    QPoint scene_pos = mapToScene(position.toPoint()).toPoint();
    QPoint aligned_pos = QPoint(scene_pos.x() - scene_pos.x()%32, scene_pos.y() - scene_pos.y()%32);
    if (!itemExistsAt(position))
        m_worldmanager->makeCurrentObject(aligned_pos);
}

void GameManager::removeBodyAt(const QPointF &position) const
{
    QGraphicsItem* current_item = itemAt(position.toPoint());
    if (current_item)
    {
        Entity *current_entity = dynamic_cast<Entity*>(current_item);
        if (current_entity && !current_entity->isSolid())
        {
            if (current_entity->isBody())
            {
                for (b2Body* body = m_worldmanager->world()->GetBodyList(); body; body = body->GetNext())
                {
                    Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
                    if (entity == current_entity)
                    {
                        if (current_entity->isDynamic())
                            m_worldmanager->dynamic_bodies().removeOne(body);
                        m_worldmanager->world()->DestroyBody(body);
                        scene->removeItem(current_item);
                        delete current_item;
                        break;
                    }
                }
            }
            else
            {
                scene->removeItem(current_item);
                delete current_item;
            }
        }
    }
}

void GameManager::rotateBodyAt(const QPointF &position, bool isClockwise) const
{
    QGraphicsItem* current_item = itemAt(position.toPoint());
    if (current_item)
    {
        Entity *current_entity = dynamic_cast<Entity*>(current_item);
        if (current_entity && !current_entity->isSolid())
        {
            if (current_entity->isBody())
            {
                for (b2Body* body = m_worldmanager->world()->GetBodyList(); body; body = body->GetNext())
                {
                    Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
                    if (entity == current_entity)
                    {
                        if (isClockwise)
                            body->SetTransform(body->GetPosition(), body->GetAngle() + 2.0/57.0);
                        else
                            body->SetTransform(body->GetPosition(), body->GetAngle() - 2.0/57.0);

                        current_item->setRotation(body->GetAngle()*57.0f);
                    }
                }
            }
            else
            {
                current_item->setTransformOriginPoint(current_item->boundingRect().center());
                if (isClockwise)
                    current_item->setRotation(current_item->rotation() + 2.0);
                else
                    current_item->setRotation(current_item->rotation() - 2.0);
            }
        }
    }
}

void GameManager::currentItemIsAt(const QPointF &position)
{
    current_item = itemAt(position.toPoint());
}

void GameManager::moveCurrentItemTo(bool toTop, bool toLeft, bool toBottom, bool toRight) const
{
    if (current_item)
    {
        uint8 pixToTop = toTop ? 3 : 0;
        uint8 pixToLeft = toLeft ? 3 : 0;
        uint8 pixToRight = toRight ? 3 : 0;
        uint8 pixToBottom = toBottom ? 3 : 0;

        Entity *current_entity = dynamic_cast<Entity*>(current_item);
        if (current_entity->isBody())
        {
            for (b2Body* body = m_worldmanager->world()->GetBodyList(); body; body = body->GetNext())
            {
                Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
                if (entity == current_entity)
                {
                    float32 dx = (pixToLeft-pixToRight)/m_worldmanager->tilesize();
                    float32 dy = (pixToTop-pixToBottom)/m_worldmanager->tilesize();

                    body->SetTransform(body->GetPosition() - b2Vec2(dx, dy), body->GetAngle());
                    current_item->setPos(body->GetPosition().x*m_worldmanager->tilesize(), body->GetPosition().y*m_worldmanager->tilesize());
                }
            }
        }
        else
            current_item->setPos(current_item->pos().x() - (pixToLeft-pixToRight), current_item->pos().y() - (pixToTop - pixToBottom));

    }
}

void GameManager::turnBodyToStatic(const QPointF &position) const
{
    QGraphicsItem* current_item = itemAt(position.toPoint());
    if (current_item)
    {
        Entity *current_entity = dynamic_cast<Entity*>(current_item);

        for (b2Body* body = m_worldmanager->world()->GetBodyList(); body; body = body->GetNext())
        {
            Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
            if (entity == current_entity)
            {
                body->SetType(b2_staticBody);
                current_entity->setDynamic(false);
                m_worldmanager->dynamic_bodies().removeOne(body);
            }
        }
    }
}

void GameManager::turnBodyToDynamic(const QPointF &position) const
{
    QGraphicsItem* current_item = itemAt(position.toPoint());
    if (current_item)
    {
        Entity *current_entity = dynamic_cast<Entity*>(current_item);

        for (b2Body* body = m_worldmanager->world()->GetBodyList(); body; body = body->GetNext())
        {
            Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
            if (entity == current_entity)
            {
                body->SetType(b2_dynamicBody);
                current_entity->setDynamic(true);
                m_worldmanager->dynamic_bodies().append(body);
            }
        }
    }
}

bool GameManager::itemExistsAt(const QPointF &position) const
{
    if (itemAt(position.toPoint()) != nullptr)
        return true;
    else
        return false;
}

// slots
void GameManager::changeBackground()
{
    QString background_filename = QFileDialog::getOpenFileName(nullptr, tr("Выбор фона"), QString(), tr("Изображения (*.bmp *.jpg *.png)"));

    setBackgroundBrush(QPixmap(background_filename));
}
