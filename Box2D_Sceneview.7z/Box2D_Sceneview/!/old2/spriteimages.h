#ifndef SPRITEIMAGES_H
#define SPRITEIMAGES_H

#include <QVector>
#include <QPixmap>
class SpriteImages
{
public:
    SpriteImages();
    ~SpriteImages();

    QPixmap *coin();
    QPixmap *star();
    QPixmap *crate();
    QPixmap *barrel();
    QPixmap *snow();
    QPixmap *potion_restore_hp();
    QPixmap *potion_add_hp();
    QPixmap *potion_add_damage();
    QPixmap *potion_add_defence();

    QVector<QPixmap*>* player() const;
    QVector<QPixmap*>* dwarf() const;
    QVector<QPixmap*>* unicorn() const;

    QVector<QPair<float,float> >* player_framesizes() const;
    QVector<QPair<float,float> >* dwarf_framesizes() const;
    QVector<QPair<float,float> >* unicorn_framesizes() const;

private:
    void fillPlayerSpritesheet();
    void fillDwarfSpritesheet();
    void fillUnicornSpritesheet();

    // static_images
    QPixmap *m_coin, *m_star;
    QPixmap *m_crate, *m_barrel;
    QPixmap *m_snow;
    QPixmap *m_potion_restore_hp, *m_potion_add_hp, *m_potion_add_damage, *m_potion_add_defence;

    // dynamic_images
    QVector<QPixmap*>* m_player_spritesheet;
    QVector<QPixmap*>* m_dwarf_spritesheet;
    QVector<QPixmap*>* m_unicorn_spritesheet;

    QVector<QPair<float,float> >* m_player_framesizes;
    QVector<QPair<float,float> >* m_dwarf_framesizes;
    QVector<QPair<float,float> >* m_unicorn_framesizes;
};

#endif // SPRITEIMAGES_H
