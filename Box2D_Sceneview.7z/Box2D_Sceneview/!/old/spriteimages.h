#ifndef SPRITEIMAGES_H
#define SPRITEIMAGES_H

#include <QImage>
#include <QVector>

class SpriteImages
{
public:
    SpriteImages();
    ~SpriteImages();

    QImage *coin();
    QImage *star();
    QImage *crate();
    QImage *barrel();
    QImage *snow();
    QImage *potion_restore_hp();
    QImage *potion_add_hp();
    QImage *potion_add_damage();
    QImage *potion_add_defence();

    QVector<QImage*>* player() const;
    QVector<QImage*>* dwarf() const;
    QVector<QImage*>* unicorn() const;

    QVector<QPair<float,float> >* player_framesizes() const;
    QVector<QPair<float,float> >* dwarf_framesizes() const;
    QVector<QPair<float,float> >* unicorn_framesizes() const;

private:
    void fillPlayerSpritesheet();
    void fillDwarfSpritesheet();
    void fillUnicornSpritesheet();

    // static_images
    QImage *m_coin, *m_star;
    QImage *m_crate, *m_barrel;
    QImage *m_snow;
    QImage *m_potion_restore_hp, *m_potion_add_hp, *m_potion_add_damage, *m_potion_add_defence;

    // dynamic_images
    QVector<QImage*>* m_player_spritesheet;
    QVector<QImage*>* m_dwarf_spritesheet;
    QVector<QImage*>* m_unicorn_spritesheet;

    QVector<QPair<float,float> >* m_player_framesizes;
    QVector<QPair<float,float> >* m_dwarf_framesizes;
    QVector<QPair<float,float> >* m_unicorn_framesizes;
};

#endif // SPRITEIMAGES_H
