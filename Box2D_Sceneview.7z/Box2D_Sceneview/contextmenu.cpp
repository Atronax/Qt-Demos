#include "worldmanager.h"
#include "gamemanager.h"

#include "contextmenu.h"
ContextMenu::ContextMenu(GameManager* gamemanager, const QString& title, QWidget* parent)
    : QMenu (title, parent)
{
    m_gamemanager = gamemanager;
    buildActions();
    buildMenu();
}

ContextMenu::~ContextMenu()
{    
    act_save_level->deleteLater();
    act_load_level->deleteLater();

    act_save_game->deleteLater();
    act_load_game->deleteLater();

    act_1x1box->deleteLater();
    act_1x2box->deleteLater();
    act_2x1box->deleteLater();
    act_1x1barrel->deleteLater();
    act_2x2barrel->deleteLater();
    act_1x1brick->deleteLater();
    act_moon->deleteLater();
    act_grass->deleteLater();
    act_ground->deleteLater();
    act_stcoin->deleteLater();
    act_dyncoin->deleteLater();
    act_ststar->deleteLater();
    act_dynstar->deleteLater();
    act_tree_fir->deleteLater();

    act_potion_add_hp->deleteLater();
    act_potion_add_damage->deleteLater();
    act_potion_restore_hp->deleteLater();
    act_potion_add_defence->deleteLater();

    act_dwarf->deleteLater();
    act_unicorn->deleteLater();
}

void ContextMenu::buildActions()
{
    // СОХРАНЕНИЕ и ЗАГРУЗКА
    act_save_level = new QAction(tr("Сохранить уровень"), this);
    connect (act_save_level, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(onSaveLevel()));

    act_load_level = new QAction(tr("Загрузить уровень"), this);
    connect (act_load_level, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(onLoadLevel()));

    act_save_game = new QAction(tr("Сохранить игру"), this);
    connect (act_save_game, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(onSaveGame()));

    act_load_game = new QAction(tr("Загрузить игру"), this);
    connect (act_load_game, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(onLoadGame()));

    // СТРОИТЕЛЬНЫЕ БЛОКИ
    act_1x1box = new QAction(tr("Ящик 1х1"), this);
    act_1x1box->setObjectName("Box_1x1");
    connect (act_1x1box, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_2x1box = new QAction(tr("Ящик 2х1"), this);
    act_2x1box->setObjectName("Box_2x1");
    connect (act_2x1box, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_1x2box = new QAction(tr("Ящик 1х2"), this);
    act_1x2box->setObjectName("Box_1x2");
    connect (act_1x2box, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_1x1barrel = new QAction(tr("Бочка 1х1"), this);
    act_1x1barrel->setObjectName("Barrel_1x1");
    connect (act_1x1barrel, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_2x2barrel = new QAction(tr("Бочка 2х2"), this);
    act_2x2barrel->setObjectName("Barrel_2x2");
    connect (act_2x2barrel, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_1x1brick = new QAction(tr("Кирпич 1х1"), this);
    act_1x1brick->setObjectName("Brick_1x1");
    connect (act_1x1brick, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_tree_fir = new QAction(tr("Ель"), this);
    act_tree_fir->setObjectName("Tree_Fir");
    connect (act_tree_fir, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_ground = new QAction(tr("Земля"), this);
    act_ground->setObjectName("Ground");
    connect (act_ground, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_grass = new QAction(tr("Трава"), this);
    act_grass->setObjectName("Grass");
    connect (act_grass, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_moon = new QAction(tr("Луна"), this);
    act_moon->setObjectName("Moon");
    connect (act_moon, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_stcoin = new QAction(tr("Статическая монетка"), this);
    act_stcoin->setObjectName("Static Coin");
    connect (act_stcoin, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_ststar = new QAction(tr("Статическая звезда"), this);
    act_ststar->setObjectName("Static Star");
    connect (act_ststar, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    // СОБИРАЕМОЕ
    act_potion_restore_hp = new QAction(tr("Зелье восстановления здоровья"), this);
    act_potion_restore_hp->setObjectName("Potion RestoreHP");
    connect (act_potion_restore_hp, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_potion_add_hp = new QAction(tr("Зелье повышения здоровья"), this);
    act_potion_add_hp->setObjectName("Potion AddHP");
    connect (act_potion_add_hp, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_potion_add_damage = new QAction(tr("Зелье повышения урона"), this);
    act_potion_add_damage->setObjectName("Potion AddDamage");
    connect (act_potion_add_damage, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_potion_add_defence = new QAction(tr("Зелье повышения защиты"), this);
    act_potion_add_defence->setObjectName("Potion AddDefence");
    connect (act_potion_add_defence, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_dyncoin = new QAction(tr("Динамическая монетка"), this);
    act_dyncoin->setObjectName("Dynamic Coin");
    connect (act_dyncoin, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_dynstar = new QAction(tr("Динамическая звезда"), this);
    act_dynstar->setObjectName("Dynamic Star");
    connect (act_dynstar, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    // ВРАГИ
    act_dwarf = new QAction(tr("Дворф"), this);
    act_dwarf->setObjectName("Gnome");
    connect (act_dwarf, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));

    act_unicorn = new QAction(tr("Единорог"), this);
    act_unicorn->setObjectName("Unicorn");
    connect (act_unicorn, SIGNAL(triggered()), m_gamemanager->worldmanager(), SLOT(changeCurrentObject()));


}

void ContextMenu::buildMenu()
{
    QMenu *context_levels_menu = new QMenu (tr("Работа с уровнями"), this);
    context_levels_menu->addAction(act_save_level);
    context_levels_menu->addAction(act_load_level);

    QMenu *context_saves_menu = new QMenu (tr("Работа с сохранениями"), this);
    context_saves_menu->addAction(act_save_game);
    context_saves_menu->addAction(act_load_game);

    QMenu *context_building_menu = new QMenu (tr("Строительные материалы"), this);
    context_building_menu->addAction(act_1x1box);
    context_building_menu->addAction(act_1x2box);
    context_building_menu->addAction(act_2x1box);
    context_building_menu->addSeparator();
    context_building_menu->addAction(act_1x1barrel);
    context_building_menu->addAction(act_2x2barrel);
    context_building_menu->addSeparator();
    context_building_menu->addAction(act_1x1brick);
    context_building_menu->addSeparator();
    context_building_menu->addAction(act_moon);
    context_building_menu->addAction(act_tree_fir);
    context_building_menu->addAction(act_ground);
    context_building_menu->addAction(act_grass);
    context_building_menu->addSeparator();
    context_building_menu->addAction(act_stcoin);
    context_building_menu->addAction(act_ststar);

    QMenu *context_collectibles_menu = new QMenu (tr("Сокровища"), this);
    context_collectibles_menu->addAction(act_dyncoin);
    context_collectibles_menu->addAction(act_dynstar);
    context_collectibles_menu->addSeparator();
    context_collectibles_menu->addAction(act_potion_restore_hp);
    context_collectibles_menu->addAction(act_potion_add_hp);
    context_collectibles_menu->addAction(act_potion_add_damage);
    context_collectibles_menu->addAction(act_potion_add_defence);

    QMenu *context_enemies_menu = new QMenu (tr("Противники"), this);
    context_enemies_menu->addAction(act_dwarf);
    context_enemies_menu->addAction(act_unicorn);

    addMenu(context_levels_menu);
    addMenu(context_saves_menu);
    addSeparator();
    addMenu(context_building_menu);
    addMenu(context_collectibles_menu);
    addMenu(context_enemies_menu);
}
