// logic
#include <QFileDialog>
#include <QTimer>

// graphics
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>

// items
#include "Items/windows/inventory.h"
#include "Items/windows/statistics.h"
#include "contactlistener.h"
#include "gamemanager.h"
#include "worldmanager.h"
WorldManager::WorldManager(GameManager* manager, QWidget* parent)
{    
    m_manager = manager;
    setParent(parent);

    m_imagesCache = new SpriteImages();
    m_listener = new ContactListener();

    m_world = new b2World(b2Vec2(0.0f, 10.0f));
    m_world->SetContactListener(m_listener);

    physics_updater = new QTimer (this);
    connect (physics_updater, SIGNAL(timeout()), this, SLOT(updatePhysics()));
    physics_updater->start(1000/60);

    sprite_updater = new QTimer (this);
    connect (sprite_updater, SIGNAL(timeout()), this, SLOT(updateSprites()));
    sprite_updater->start(1000/15);
}

WorldManager::~WorldManager()
{
    // clear dynamic bodies list
    m_dynbodies.clear();

    // destroy contact listener
    delete m_listener;

    // delete image cache
    delete m_imagesCache;

    // delete updaters
    physics_updater->stop();
    physics_updater->deleteLater();

    sprite_updater->stop();
    sprite_updater->deleteLater();

    // clear world and destroy it
    for (b2Body* body = world()->GetBodyList(); body; body = body->GetNext())
        m_world->DestroyBody(body);
    delete m_world;
}

// ************************************************************************************************* getters
QList<b2Body *> &WorldManager::dynamic_bodies()
{
    return m_dynbodies;
}

SpriteImages* WorldManager::imagesCache() const
{
    return m_imagesCache;
}

float32 WorldManager::tilesize() const
{
    return m_tilesize;
}

b2World* WorldManager::world() const
{
    return m_world;
}

Player *WorldManager::player() const
{
    return m_player;
}

// ******************************************** functions to create bodies and scene items, connected to them
BuildBlock *WorldManager::makeBuildblock(const QPointF &origin, const QSize &size, int type, bool isBody, bool isDynamic, bool isSolid, bool isRotatable)
{
    if (isBody)
    {
        // make body definition
        b2BodyDef body_def;
        if (isDynamic)
            body_def.type = b2_dynamicBody;
        else
            body_def.type = b2_staticBody;
        if (isRotatable)
            body_def.fixedRotation = false;
        else
            body_def.fixedRotation = true;
        body_def.position.Set(origin.x()/m_tilesize, origin.y()/m_tilesize);

        // make shape
        b2PolygonShape body_shape;
        const b2Vec2 points[] = {b2Vec2(0, 0),
                                 b2Vec2(size.width()/tilesize(), 0),
                                 b2Vec2(size.width()/tilesize(), size.height()/tilesize()),
                                 b2Vec2(0, size.height()/tilesize())};
        body_shape.Set(points, 4);

        // make physical definition
        b2FixtureDef fixture_def;
        fixture_def.shape = &body_shape;
        fixture_def.friction = 1.0f;
        if (isDynamic)
            fixture_def.density = 1.0f;
        else
            fixture_def.density = 0.0f;

        // make body
        b2Body *body = m_world->CreateBody(&body_def);
        body->CreateFixture(&fixture_def);

        // make correspoding visual representation
        Entity *buildblock_entity = new BuildBlock (m_manager, body, nullptr);
        BuildBlock *buildblock = dynamic_cast<BuildBlock*>(buildblock_entity);
        buildblock->setRect(0, 0, size.width(), size.height());
        buildblock->setPos(origin.x(), origin.y());
        buildblock->setBuildBlockType(type);
        buildblock->setIsBody(true);
        buildblock->setDynamic(isDynamic);
        buildblock->setSolid(isSolid);
        buildblock->setRotatable(isRotatable);

        // attach user data to body, push body into dynamic if needed
        body->SetUserData(buildblock_entity);
        if (isDynamic)
            m_dynbodies.append(body);

        // show object on the scene and return the pointer to it
        m_manager->getScene()->addItem(buildblock);
        return buildblock;
    }
    else
    {
        BuildBlock *buildblock = new BuildBlock(m_manager);
        buildblock->setZValue(-1000);
        buildblock->setRect(0, 0, size.width(), size.height());
        buildblock->setPos(origin.x(), origin.y());
        buildblock->setBuildBlockType(type);
        buildblock->setIsBody(false);
        buildblock->setDynamic(isDynamic);
        buildblock->setSolid(isSolid);
        buildblock->setRotatable(isRotatable);
        m_manager->getScene()->addItem(buildblock);
        return buildblock;
    }
}

Collectible *WorldManager::makeCollectible(const QPointF &origin, int radius, int type, bool isDynamic, bool isSolid, bool isRotatable)
{
    // make body definition
    b2BodyDef body_def;
    if (isDynamic)
        body_def.type = b2_dynamicBody;
    else
        body_def.type = b2_staticBody;
    if (isRotatable)
        body_def.fixedRotation = false;
    else
        body_def.fixedRotation = true;
    body_def.position.Set(origin.x()/m_tilesize, origin.y()/m_tilesize);

    // make shape
    b2CircleShape body_shape;
    body_shape.m_radius = radius/m_tilesize;

    // make physical definition
    b2FixtureDef fixture_def;
    fixture_def.shape = &body_shape;
    if (isDynamic)
    {
        fixture_def.density = 1.0f;
        fixture_def.friction = 0.3f;
        fixture_def.restitution = 0.5f;
    }
    else
        fixture_def.density = 0.0f;

    // make body
    b2Body *body = m_world->CreateBody(&body_def);
    body->CreateFixture(&fixture_def);

    // make correspoding visual representation
    Entity *collectible_entity = new Collectible(m_manager, body, nullptr);
    Collectible *collectible = dynamic_cast<Collectible*>(collectible_entity);
    collectible->setRect(-radius, -radius, 2*radius, 2*radius);
    collectible->setPos(origin.x(), origin.y());
    collectible->setCollectibleType(type);
    collectible->setIsBody(true);
    collectible->setDynamic(isDynamic);
    collectible->setSolid(isSolid);
    collectible->setRotatable(isRotatable);

    // attach user data to body, push body into dynamic if needed and show object on the scene
    body->SetUserData(collectible_entity);
    if (isDynamic)
        m_dynbodies.append(body);

    // show object on the scene and return the pointer to it
    m_manager->getScene()->addItem(collectible);
    return collectible;
}

Enemy *WorldManager::makeEnemy(const QPointF &origin, int radius, int type)
{
    // make body definition
    b2BodyDef body_def;
    body_def.type = b2_dynamicBody;
    body_def.fixedRotation = true;
    body_def.allowSleep = false;
    body_def.position.Set(origin.x()/m_tilesize, origin.y()/m_tilesize);

    // make shape
    b2CircleShape body_shape;
    body_shape.m_radius = radius/m_tilesize;

    // make physical definition
    b2FixtureDef fixture_def;
    fixture_def.shape = &body_shape;
    fixture_def.density = 1.0f;
    fixture_def.friction = 1.0f;

    // make body
    b2Body *body = m_world->CreateBody(&body_def);
    body->CreateFixture(&fixture_def);

    // make correspoding visual representation
    Entity* enemy_entity = new Enemy(m_manager, body, nullptr);
    Enemy *enemy = dynamic_cast<Enemy*>(enemy_entity);
    enemy->setEnemyType(type);
    enemy->setIsBody(true);
    enemy->setDynamic(true);
    enemy->setSolid(false);
    enemy->setRotatable(false);
    enemy->setRect(-radius, -radius, 2*radius, 2*radius);
    enemy->setPos(origin.x(), origin.y());

    // connections
    connect (enemy, SIGNAL(killed(Player*)), this, SLOT(onKilled(Player*)));

    // attach user data to body, push body into dynamic if needed and show object on the scene
    body->SetUserData(enemy_entity);
    m_dynbodies.append(body);

    // show object on the scene and return the pointer to it
    m_manager->getScene()->addItem(enemy);
    return enemy;
}

Player* WorldManager::makePlayer(const QPointF &origin, int radius)
{
    // make body definition
    b2BodyDef body_def;
    body_def.type = b2_dynamicBody;
    body_def.fixedRotation = true;
    body_def.allowSleep = false;
    body_def.position.Set(origin.x()/m_tilesize, origin.y()/m_tilesize);

    // make shape    
    b2CircleShape body_shape;
    body_shape.m_radius = radius/m_tilesize;

    // make physical definition
    b2FixtureDef fixture_def;
    fixture_def.shape = &body_shape;
    fixture_def.density = 1.0f;
    fixture_def.friction = 1.0f;

    // make body
    b2Body *body = m_world->CreateBody(&body_def);
    body->CreateFixture(&fixture_def);

    // make correspoding visual representation
    Entity* player_entity = new Player(m_manager, body, nullptr);
    Player* player = dynamic_cast<Player*>(player_entity);
    player->setIsBody(true);
    player->setDynamic(true);
    player->setSolid(false);
    player->setRotatable(false);
    player->setRect(-radius, -radius, 2*radius, 2*radius);
    player->setPos(origin.x(), origin.y());

    // connections
    connect (player, SIGNAL(killed(Enemy*)), this, SLOT(onKilled(Enemy*)));
    connect (player, SIGNAL(got(Collectible*)), this, SLOT(onGot(Collectible*)));
    connect (player, SIGNAL(got(EquipmentItem*)), this, SLOT(onGot(EquipmentItem*)));

    // attach user data to body, push body into dynamic if needed and show object on the scene
    body->SetUserData(player_entity);      
    m_dynbodies.append(body);

    // show object on the scene and return the pointer to it
    m_player = player;

    m_manager->getScene()->addItem(player);
    return player;
}

EquipmentItem *WorldManager::makeEquipmentItem(const QPointF &origin, int radius, int type, const QString& name, QPixmap* image, bool isDynamic, bool isSolid, bool isRotatable)
{
    // make body definition
    b2BodyDef body_def;
    if (isDynamic)
        body_def.type = b2_dynamicBody;
    else
        body_def.type = b2_staticBody;
    if (isRotatable)
        body_def.fixedRotation = false;
    else
        body_def.fixedRotation = true;
    body_def.position.Set(origin.x()/m_tilesize, origin.y()/m_tilesize);

    // make shape
    b2CircleShape body_shape;
    body_shape.m_radius = radius/m_tilesize;

    // make physical definition
    b2FixtureDef fixture_def;
    fixture_def.shape = &body_shape;
    if (isDynamic)
    {
        fixture_def.density = 1.0f;
        fixture_def.friction = 0.3f;
        fixture_def.restitution = 0.5f;
    }
    else
        fixture_def.density = 0.0f;

    // make body
    b2Body *body = m_world->CreateBody(&body_def);
    body->CreateFixture(&fixture_def);

    // make correspoding visual representation
    Entity *equipmentitem_entity = new EquipmentItem(m_manager, body, nullptr);
    EquipmentItem *equipmentitem = dynamic_cast<EquipmentItem*>(equipmentitem_entity);
    equipmentitem->setRect(-radius, -radius, 2*radius, 2*radius);
    equipmentitem->setPos(origin.x(), origin.y());
    equipmentitem->sprite()->setStatic(image);
    equipmentitem->setEquipmentType(type);
    equipmentitem->setName(name);

    equipmentitem->setIsBody(true);
    equipmentitem->setDynamic(isDynamic);
    equipmentitem->setSolid(isSolid);
    equipmentitem->setRotatable(isRotatable);

    // attach user data to body, push body into dynamic if needed and show object on the scene
    body->SetUserData(equipmentitem_entity);
    if (isDynamic)
        m_dynbodies.append(body);

    // show object on the scene and return the pointer to it
    m_manager->getScene()->addItem(equipmentitem);
    return equipmentitem;
}

void WorldManager::makeCurrentObject(const QPointF &origin)
{
    // Buildblocks
    if (m_currentObject == BuildBlock::BOX_1X1)
        makeBuildblock(origin, QSize(m_tilesize, m_tilesize), BuildBlock::BOX_1X1, true, false, false, false);
    if (m_currentObject == BuildBlock::BOX_1X2)
        makeBuildblock(origin, QSize(m_tilesize,2*m_tilesize), BuildBlock::BOX_1X2, true, false, false, false);
    if (m_currentObject == BuildBlock::BOX_2X1)
        makeBuildblock(origin, QSize(2*m_tilesize,m_tilesize), BuildBlock::BOX_2X1, true, false, false, false);
    if (m_currentObject == BuildBlock::BARREL_1X1)
        makeBuildblock(origin, QSize(m_tilesize, m_tilesize), BuildBlock::BARREL_1X1, true, false, false, false);
    if (m_currentObject == BuildBlock::BARREL_2X2)
        makeBuildblock(origin, QSize(2*m_tilesize,2*m_tilesize), BuildBlock::BARREL_2X2, true, false, false, false);
    if (m_currentObject == BuildBlock::BRICK_1X1)
        makeBuildblock(origin, QSize(m_tilesize,m_tilesize), BuildBlock::BRICK_1X1, true, false, false, false);
    if (m_currentObject == BuildBlock::MOON)
        makeBuildblock(origin, QSize(10*m_tilesize, 10*m_tilesize), BuildBlock::MOON, false, false, false, false);
    if (m_currentObject == BuildBlock::TREE_FIR)
        makeBuildblock(origin, QSize(m_tilesize*(3+rand()%3), m_tilesize*(3+rand()%3)), BuildBlock::TREE_FIR, false, true, false, false);
    if (m_currentObject == BuildBlock::GROUND)
        makeBuildblock(origin, QSize(m_tilesize, m_tilesize), BuildBlock::GROUND, true, false, false, false);
    if (m_currentObject == BuildBlock::GRASS)
        makeBuildblock(origin, QSize(10*m_tilesize, m_tilesize), BuildBlock::GRASS, false, false, false, false);
    if (m_currentObject == BuildBlock::STATIC_COIN)
        makeBuildblock(origin, QSize(m_tilesize,m_tilesize), BuildBlock::STATIC_COIN, true, false, false, false);
    if (m_currentObject == BuildBlock::STATIC_STAR)
        makeBuildblock(origin, QSize(m_tilesize,m_tilesize), BuildBlock::STATIC_STAR, true, false, false, false);

    // Collectibles
    if (m_currentObject == Collectible::DYNAMIC_COIN)
        makeCollectible(origin, m_tilesize/2, Collectible::DYNAMIC_COIN, true, false, false);
    if (m_currentObject == Collectible::DYNAMIC_STAR)
        makeCollectible(origin, m_tilesize/2, Collectible::DYNAMIC_STAR, true, false, true);
    if (m_currentObject == Collectible::POTION_RESTORE_HP)
        makeCollectible(origin, m_tilesize/2, Collectible::POTION_RESTORE_HP, true, false, true);
    if (m_currentObject == Collectible::POTION_ADD_MAX_HP)
        makeCollectible(origin, m_tilesize/2, Collectible::POTION_ADD_MAX_HP, true, false, true);
    if (m_currentObject == Collectible::POTION_ADD_DAMAGE)
        makeCollectible(origin, m_tilesize/2, Collectible::POTION_ADD_DAMAGE, true, false, true);
    if (m_currentObject == Collectible::POTION_ADD_DEFENCE)
        makeCollectible(origin, m_tilesize/2, Collectible::POTION_ADD_DEFENCE, true, false, true);

    // Enemies
    if (m_currentObject == Enemy::GNOME)
        makeEnemy(origin, m_tilesize/2, Enemy::GNOME);
    if (m_currentObject == Enemy::UNICORN)
        makeEnemy(origin, m_tilesize, Enemy::UNICORN);
}

// updaters of visual and physical side of game
void WorldManager::updatePhysics()
{
    if (!m_dynbodies.isEmpty())
    {        
        m_world->Step(1.0f/m_timestep, m_veliterations, m_positerations);

        Entity *item;
        b2Body *body;


        BuildBlock *buildblock;
        Collectible *collectible;
        EquipmentItem *equipmentitem;
        Player *player;
        Enemy *enemy;

        if (m_dynbodies.size() < 20)
        {
            /*
            if (rand()%3 == 0)
                makeEnemy (QPointF(400 + rand()%301, rand()%101), m_tilesize/2, Enemy::GNOME);
            else
                makeCollectible(QPointF(400 + rand()%301, rand()%101), m_tilesize/2, Collectible::DYNAMIC_COIN, true, false, true);
                */
        }

        for (QList<b2Body*>::iterator it = m_dynbodies.begin(); it != m_dynbodies.end(); ++it)
        {
            body = *it;

            item = reinterpret_cast<Entity*>(body->GetUserData());

            enemy = dynamic_cast<Enemy*>(item);
            player = dynamic_cast<Player*>(item);
            buildblock = dynamic_cast<BuildBlock*>(item);
            collectible = dynamic_cast<Collectible*>(item);
            equipmentitem = dynamic_cast<EquipmentItem*>(item);

            if (enemy)
            {
                enemy->setPos(body->GetPosition().x*m_tilesize, body->GetPosition().y*m_tilesize);
                enemy->setRotation(body->GetAngle()*57.0f);
                enemy->updateState(m_player->pos());
            }

            if (buildblock)
            {
                buildblock->setPos(body->GetPosition().x*m_tilesize,  body->GetPosition().y*m_tilesize);
                buildblock->setRotation(body->GetAngle()*57.0f);
            }

            if (collectible)
            {
                collectible->setPos(body->GetPosition().x*m_tilesize,  body->GetPosition().y*m_tilesize);
                collectible->setRotation(body->GetAngle()*57.0f);
            }

            if (equipmentitem)
            {
                equipmentitem->setPos(body->GetPosition().x*m_tilesize,  body->GetPosition().y*m_tilesize);
                equipmentitem->setRotation(body->GetAngle()*57.0f);
            }

            if (player)
            {
                m_manager->getView()->centerOn(player);
                player->setPos(body->GetPosition().x*m_tilesize, body->GetPosition().y*m_tilesize);
                player->setRotation(body->GetAngle()*57.0f);
                player->updateState(player->pos());
            }
        }

        updateCollisions();
    }
}

void WorldManager::updateCollisions()
{
    foreach(Contact contact, m_listener->contacts())
    {
        Entity* entityA = reinterpret_cast<Entity*>(contact.fixtureA->GetBody()->GetUserData());
        Entity* entityB = reinterpret_cast<Entity*>(contact.fixtureB->GetBody()->GetUserData());
        if (entityA && entityB)
        {
            if (dynamic_cast<Player*>(entityA) != nullptr || dynamic_cast<Player*>(entityB) != nullptr)
            {
                entityA->checkCollision(entityB);
                entityB->checkCollision(entityA);
            }
        }
    }
}

void WorldManager::updateSprites()
{
    Entity *entity;
    foreach (QGraphicsItem* item, m_manager->items())
    {
        entity = dynamic_cast<Entity*>(item);
        if (entity && entity->isDynamic())
            entity->sprite()->nextFrame();
    }
}

// editor functions
void WorldManager::changeCurrentObject()
{
    QString object_name = sender()->objectName();

    // Buildblocks
    if (object_name == "Box_1x1")
        m_currentObject = BuildBlock::BOX_1X1;
    if (object_name == "Box_1x2")
        m_currentObject = BuildBlock::BOX_1X2;
    if (object_name == "Box_2x1")
        m_currentObject = BuildBlock::BOX_2X1;
    if (object_name == "Barrel_1x1")
        m_currentObject = BuildBlock::BARREL_1X1;
    if (object_name == "Barrel_2x2")
        m_currentObject = BuildBlock::BARREL_2X2;
    if (object_name == "Brick_1x1")
        m_currentObject = BuildBlock::BRICK_1X1;
    if (object_name == "Moon")
        m_currentObject = BuildBlock::MOON;
    if (object_name == "Tree_Fir")
        m_currentObject = BuildBlock::TREE_FIR;
    if (object_name == "Ground")
        m_currentObject = BuildBlock::GROUND;
    if (object_name == "Grass")
        m_currentObject = BuildBlock::GRASS;
    if (object_name == "Static Coin")
        m_currentObject = BuildBlock::STATIC_COIN;
    if (object_name == "Static Star")
        m_currentObject = BuildBlock::STATIC_STAR;

    // Collectibles
    if (object_name == "Dynamic Coin")
        m_currentObject = Collectible::DYNAMIC_COIN;
    if (object_name == "Dynamic Star")
        m_currentObject = Collectible::DYNAMIC_STAR;
    if (object_name == "Potion RestoreHP")
        m_currentObject = Collectible::POTION_RESTORE_HP;
    if (object_name == "Potion AddHP")
        m_currentObject = Collectible::POTION_ADD_MAX_HP;
    if (object_name == "Potion AddDamage")
        m_currentObject = Collectible::POTION_ADD_DAMAGE;
    if (object_name == "Potion AddDefence")
        m_currentObject = Collectible::POTION_ADD_DEFENCE;

    // Enemies
    if (object_name == "Gnome")
        m_currentObject = Enemy::GNOME;
    if (object_name == "Unicorn")
        m_currentObject = Enemy::UNICORN;
}

void WorldManager:: saveLevelAs(const QString &level_filename)
{
    if (!level_filename.isEmpty())
    {
        QFile level_file (level_filename);
        if (level_file.open(QIODevice::WriteOnly))
        {
            QDataStream stream;
            stream.setVersion(QDataStream::Qt_5_4);
            stream.setDevice(&level_file);

            stream << pmap_const;

            Enemy *enemy = nullptr;
            BuildBlock *buildblock = nullptr;
            Collectible *collectible = nullptr;

            foreach (QGraphicsItem* item, m_manager->items()) // (b2Body* body = world()->GetBodyList(); body; body = body->GetNext())
            {
                Entity* entity = dynamic_cast<Entity*>(item); //reinterpret(body->GetUserData());

                enemy = dynamic_cast<Enemy*>(entity);
                buildblock = dynamic_cast<BuildBlock*>(entity);
                collectible = dynamic_cast<Collectible*>(entity);

                if (enemy)
                {
                    stream << (QString) "Enemy"
                           << (int)  enemy->enemyType()
                           << (qreal)enemy->rect().width()
                           << (qreal)enemy->rect().height()
                           << (qreal)enemy->pos().x()
                           << (qreal)enemy->pos().y();
                }

                if (buildblock)
                {
                    stream << (QString) "Buildblock"
                           << (int)  buildblock->buildblockType()
                           << (qreal)buildblock->rect().width()
                           << (qreal)buildblock->rect().height()
                           << (qreal)buildblock->pos().x()
                           << (qreal)buildblock->pos().y()
                           << (qreal)buildblock->rotation()
                           << (bool) buildblock->isBody()
                           << (bool) buildblock->isDynamic()
                           << (bool) buildblock->isSolid()
                           << (bool) buildblock->isRotatable();
                }

                if (collectible)
                {
                    stream << (QString) "Collectible"
                           << (int)  collectible->collectibleType()
                           << (qreal)collectible->rect().width()
                           << (qreal)collectible->rect().height()
                           << (qreal)collectible->pos().x()
                           << (qreal)collectible->pos().y()
                           << (bool) collectible->isDynamic()
                           << (bool) collectible->isSolid()
                           << (bool) collectible->isRotatable();
                }
            }

            level_file.close();
        }
    }
}

void WorldManager::loadLevelFrom(const QString &level_filename)
{
    if (!level_filename.isEmpty())
    {
        QFile level_file (level_filename);
        if (level_file.open(QIODevice::ReadOnly))
        {
            clearScene();

            QDataStream stream;
            stream.setVersion(QDataStream::Qt_5_4);
            stream.setDevice(&level_file);

            int32 magic_number;
            stream >> magic_number;
            if (magic_number == pmap_const)
            {
                QString name;
                qreal rectW, rectH, pos_X, pos_Y, rotation;
                bool isBody, isRotatable, isDynamic, isSolid;
                int enemy_type, buildblock_type, collectible_type;

                while (!stream.atEnd())
                {
                    stream >> name;
                    if (name == "Enemy")
                    {
                        stream >> enemy_type >> rectW >> rectH >> pos_X >> pos_Y;
                        makeEnemy(QPointF(pos_X,pos_Y), rectW/2, enemy_type);
                    }

                    if (name == "Buildblock")
                    {
                        stream >> buildblock_type >> rectW >> rectH >> pos_X >> pos_Y >> rotation >> isBody >> isDynamic >> isSolid >> isRotatable;
                        BuildBlock* buildblock = makeBuildblock(QPointF(pos_X,pos_Y), QSize(rectW,rectH), buildblock_type, isBody, isDynamic, isSolid, isRotatable); // !!!
                        buildblock->setRotation(rotation);
                    }

                    if (name == "Collectible")
                    {
                        stream >> collectible_type >> rectW >> rectH >> pos_X >> pos_Y >> isDynamic >> isSolid >> isRotatable;
                        makeCollectible(QPointF(pos_X, pos_Y), rectW/2, collectible_type, isDynamic, isSolid, isRotatable);
                    }
                }
                makePlayer(QPointF(0, 0), 32);
            }
            level_file.close();
        }
    }
}

void WorldManager::saveGameAs(const QString &gamesave_filename)
{
    if (!gamesave_filename.isEmpty())
    {
        QFile gamesave_file (gamesave_filename);
        if (gamesave_file.open(QIODevice::WriteOnly))
        {
            QDataStream stream;
            stream.setVersion(QDataStream::Qt_5_4);
            stream.setDevice(&gamesave_file);

            stream << save_const;

            Enemy *enemy = nullptr;
            Player *player = nullptr;
            BuildBlock *buildblock = nullptr;
            Collectible *collectible = nullptr;

            foreach (QGraphicsItem* item, m_manager->items()) // (b2Body* body = world()->GetBodyList(); body; body = body->GetNext())
            {
                Entity* entity = dynamic_cast<Entity*>(item); //(body->GetUserData());

                enemy = dynamic_cast<Enemy*>(entity);
                player = dynamic_cast<Player*>(entity);
                buildblock = dynamic_cast<BuildBlock*>(entity);
                collectible = dynamic_cast<Collectible*>(entity);

                if (enemy)
                {
                    stream << (QString) "Enemy"
                           << (int)  enemy->enemyType()
                           << (qreal)enemy->rect().width()
                           << (qreal)enemy->rect().height()
                           << (qreal)enemy->pos().x()
                           << (qreal)enemy->pos().y()
                           << (float)enemy->currentHealth();
                }

                if (buildblock)
                {
                    stream << (QString) "Buildblock"
                           << (int)  buildblock->buildblockType()
                           << (qreal)buildblock->rect().width()
                           << (qreal)buildblock->rect().height()
                           << (qreal)buildblock->pos().x()
                           << (qreal)buildblock->pos().y()
                           << (qreal)buildblock->rotation()
                           << (bool) buildblock->isBody()
                           << (bool) buildblock->isDynamic()
                           << (bool) buildblock->isSolid()
                           << (bool) buildblock->isRotatable();
                }

                if (collectible)
                {
                    stream << (QString) "Collectible"
                           << (int)  collectible->collectibleType()
                           << (qreal)collectible->rect().width()
                           << (qreal)collectible->rect().height()
                           << (qreal)collectible->pos().x()
                           << (qreal)collectible->pos().y()
                           << (bool) collectible->isDynamic()
                           << (bool) collectible->isSolid()
                           << (bool) collectible->isRotatable();
                }

                if (player)
                {
                    stream << (QString) "Player"
                           << (qreal)player->pos().x()
                           << (qreal)player->pos().y()
                           << (int)  player->level()
                           << (int)  player->experience()
                           << (int)  player->neededExperience()
                           << (float)player->currentHealth()
                           << (float)player->maximumHealth()
                           << (int)  player->damage()
                           << (int)  player->defence();
                }
            }
            gamesave_file.close();
        }
    }
}

void WorldManager::loadGameFrom(const QString &gamesave_filename)
{
    if (!gamesave_filename.isEmpty())
    {
        QFile gamesave_file (gamesave_filename);
        if (gamesave_file.open(QIODevice::ReadOnly))
        {
            clearScene();

            QDataStream stream;
            stream.setVersion(QDataStream::Qt_5_4);
            stream.setDevice(&gamesave_file);

            int32 magic_number;
            stream >> magic_number;

            if (magic_number == save_const)
            {
                QString name;
                qreal rectW, rectH, pos_X, pos_Y, rotation;
                bool isBody, isRotatable, isDynamic, isSolid;
                int enemy_type, buildblock_type, collectible_type;

                float enemy_current_health;
                float player_current_health;
                float player_maximum_health;
                int player_level;
                int player_current_exp;
                int player_needed_exp;
                int player_damage;
                int player_defence;


                while (!stream.atEnd())
                {
                    stream >> name;
                    if (name == "Enemy")
                    {
                        stream >> enemy_type >> rectW >> rectH >> pos_X >> pos_Y >> enemy_current_health;
                        Enemy *enemy = makeEnemy(QPointF(pos_X,pos_Y), rectW/2, enemy_type);
                        enemy->setCurrentHealth(enemy_current_health);
                    }

                    if (name == "Buildblock")
                    {
                        stream >> buildblock_type >> rectW >> rectH >> pos_X >> pos_Y >> rotation >> isBody >> isDynamic >> isSolid >> isRotatable;
                        BuildBlock* buildblock = makeBuildblock(QPointF(pos_X,pos_Y), QSize(rectW,rectH), buildblock_type, isBody, isDynamic, isSolid, isRotatable); // !!!
                        buildblock->setRotation(rotation);
                    }

                    if (name == "Collectible")
                    {
                        stream >> collectible_type >> rectW >> rectH >> pos_X >> pos_Y >> isDynamic >> isSolid >> isRotatable;
                        makeCollectible(QPointF(pos_X, pos_Y), rectW/2, collectible_type, isDynamic, isSolid, isRotatable);
                    }

                    if (name == "Player")
                    {
                        stream >> rectW >> rectH >> pos_X >> pos_Y
                               >> player_level >> player_current_exp >> player_needed_exp
                               >> player_current_health >> player_maximum_health
                               >> player_damage >> player_defence;

                        Player* player = makePlayer(QPointF(pos_X, pos_Y), rectW/2);

                        player->setLevel(player_level);
                        player->setNeededExperience(player_needed_exp);
                        player->setCurrentExperience(player_current_exp);
                        player->setMaximumHealth(player_maximum_health);
                        player->setCurrentHealth(player_current_health);
                        player->setDamage(player_damage);
                        player->setDefence(player_defence);
                    }
                }
            }

            gamesave_file.close();
        }
    }
}

void WorldManager::onSaveLevel()
{
    QString level_filename = QFileDialog::getSaveFileName(0, tr("Сохраняем уровень"), QString(), "Файл уровня платформера (*.pmap)");

    saveLevelAs(level_filename);
}

void WorldManager::onLoadLevel()
{
    QString level_filename = QFileDialog::getOpenFileName(0, tr("Загружаем уровень"), QString(), "Файл уровня платформера (*.pmap)");

    loadLevelFrom(level_filename);
}

void WorldManager::onSaveGame()
{
    QString savegame_filename = QFileDialog::getSaveFileName(0, tr("Сохранение игры"), QString(), "Сохранение (*.psave)");

    saveGameAs(savegame_filename);
}

void WorldManager::onLoadGame()
{
    QString savegame_filename = QFileDialog::getOpenFileName(0, tr("Загрузка игры"), QString(), "Сохранение (*.psave)");

    loadGameFrom(savegame_filename);
}

void WorldManager::clearScene()
{
    Entity* entity;

    Enemy *enemy;
    Player *player;
    BuildBlock *buildblock;
    Collectible *collectible;

    for (b2Body* body = world()->GetBodyList(); body; body = body->GetNext())
    {
        entity = reinterpret_cast<Entity*>(body->GetUserData());

        enemy = dynamic_cast<Enemy*>(entity);
        player = dynamic_cast<Player*>(entity);
        buildblock = dynamic_cast<BuildBlock*>(entity);
        collectible = dynamic_cast<Collectible*>(entity);

        if (entity->isDynamic())
            m_dynbodies.removeOne(body);

        if (enemy)
        {
            m_manager->getScene()->removeItem(enemy);
            enemy->deleteLater();
        }

        if (player)
        {
            m_manager->getScene()->removeItem(player);
            player->deleteLater();
        }

        if (buildblock)
        {
            m_manager->getScene()->removeItem(buildblock);
            buildblock->deleteLater();
        }

        if (collectible)
        {
            m_manager->getScene()->removeItem(collectible);
            collectible->deleteLater();
        }

        m_world->DestroyBody(body);
    }
}

// ============================game logic
void WorldManager::onGot(Collectible *collectible)
{
    int type = collectible->collectibleType();
    if (type == Collectible::DYNAMIC_COIN)
        m_player->statistics()->setCoinsCollected(m_player->statistics()->coinsCollected() + 1);
    if (type == Collectible::DYNAMIC_STAR)
        m_player->statistics()->setStarsCollected(m_player->statistics()->starsCollected() + 1);

    if (type == Collectible::POTION_RESTORE_HP)
        m_player->setCurrentHealth(m_player->currentHealth() + m_player->maximumHealth()*(1/10.0));
    if (type == Collectible::POTION_ADD_MAX_HP)
        m_player->setMaximumHealth(m_player->maximumHealth() + m_player->maximumHealth()*(2/100.0));
    if (type == Collectible::POTION_ADD_DAMAGE)
        m_player->setDamage(m_player->damage() + 1);
    if (type == Collectible::POTION_ADD_DEFENCE)
        m_player->setDefence(m_player->defence() + 2);

    foreach(b2Body* body, m_dynbodies)
    {
        Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
        if (collectible == dynamic_cast<Collectible*>(entity))
        {
            m_dynbodies.removeOne(body);
            m_world->DestroyBody(body);

            m_manager->getScene()->removeItem(collectible);
            collectible->deleteLater();
            break;
        }
    }
}

void WorldManager::onGot(EquipmentItem *equipmentitem)
{
    qDebug("ongot equipment");
    foreach(b2Body* body, m_dynbodies)
    {
        Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
        if (equipmentitem == dynamic_cast<EquipmentItem*>(entity))
        {
            m_dynbodies.removeOne(body);
            m_world->DestroyBody(body);

            m_manager->getScene()->removeItem(equipmentitem);
            m_player->inventory()->m_inventory.append(equipmentitem);
            equipmentitem->setParentItem(m_player->inventory());
            equipmentitem->setRect(0,0,30,30);
            equipmentitem->setRotation(0);
            break;
        }
    }

}

void WorldManager::onKilled(Enemy *enemy)
{    
    m_player->statistics()->setEnemiesKilled(m_player->statistics()->enemiesKilled() + 1);
    int type = enemy->enemyType();
    if (type == Enemy::GNOME)
        m_player->statistics()->setGnomesKilled(m_player->statistics()->gnomesKilled() + 1);
    if (type == Enemy::UNICORN)
        m_player->statistics()->setUnicornsKilled(m_player->statistics()->unicornsKilled() + 1);

    m_player->setCurrentExperience(m_player->experience() + enemy->experience());
    if (m_player->experience() >= m_player->neededExperience())
        m_player->levelUp();

    foreach(b2Body* body, m_dynbodies)
    {
        Entity *entity = reinterpret_cast<Entity*>(body->GetUserData());
        if (enemy == dynamic_cast<Enemy*>(entity))
        {
            m_dynbodies.removeOne(body);
            m_world->DestroyBody(body);

            m_manager->getScene()->removeItem(enemy);
            enemy->deleteLater();
            break;
        }
    }
}

void WorldManager::onKilled(Player *player)
{
    foreach(b2Body* body, m_dynbodies)
    {
        Entity *data = reinterpret_cast<Entity*>(body->GetUserData());
        if (player == dynamic_cast<Player*>(data))
        {
            m_dynbodies.removeOne(body);
            m_world->DestroyBody(body);

            m_manager->getScene()->removeItem(player);
            player->deleteLater();
            break;
        }        
    }
}
